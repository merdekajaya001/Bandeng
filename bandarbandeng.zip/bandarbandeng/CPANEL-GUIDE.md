# Panduan Upload ke cPanel Shared Hosting
## Bandar Bandeng Kalimantan — Laravel Deployment Guide

---

## Prasyarat cPanel

Pastikan hosting Anda mendukung:
- **PHP 8.1+** (cek di cPanel → Select PHP Version)
- **MySQL 5.7+** atau MariaDB 10.3+
- **Composer** (via Terminal/SSH atau cPanel)
- Ekstensi PHP: pdo_mysql, mbstring, openssl, tokenizer, xml, ctype, json, bcmath, fileinfo, gd

---

## Langkah 1: Persiapan File di Komputer Lokal

### 1.1 Kompres Project

```bash
# Di komputer lokal, masuk ke folder project
cd bandarbandeng-laravel

# Hapus folder yang tidak perlu untuk production
rm -rf node_modules
rm -rf .git

# Buat ZIP
zip -r bandarbandeng.zip . -x "node_modules/*" ".git/*"
```

Atau jika dari Windows: klik kanan folder → Send to → Compressed (zipped) folder.

### 1.2 Cek Isi ZIP

Pastikan ZIP berisi:
- `app/`, `bootstrap/`, `config/`, `database/`, `public/`, `resources/`, `routes/`, `storage/`, `vendor/`
- `artisan`, `composer.json`, `composer.lock`
- `.env.example`
- `database/sql/bandarbandeng.sql`

> **PENTING:** Jika folder `vendor/` belum ada, jalankan `composer install --no-dev` dulu di lokal sebelum ZIP.

---

## Langkah 2: Upload ke cPanel

### 2.1 Buka File Manager

1. Login ke cPanel: `https://domainanda.com/cpanel` atau `https://domainanda.com:2083`
2. Klik **File Manager**
3. Navigasi ke `public_html/`

### 2.2 Upload ZIP

1. Klik **Upload** di toolbar
2. Pilih file `bandarbandeng.zip`
3. Tunggu upload selesai (progress bar 100%)
4. Kembali ke File Manager

### 2.3 Extract ZIP

1. Klik kanan file `bandarbandeng.zip`
2. Pilih **Extract**
3. Extract ke `public_html/`

> **Catatan:** Jika website ini adalah satu-satunya website di hosting, extract langsung ke `public_html/`. Jika ada website lain, buat subfolder misal `public_html/bandarbandeng/`.

### 2.4 Struktur Setelah Extract

```
public_html/
├── app/
├── bootstrap/
├── config/
├── database/
├── public/
│   ├── css/
│   ├── js/
│   ├── images/
│   ├── uploads/
│   └── index.php          ← Entry point Laravel
├── resources/
├── routes/
├── storage/
├── vendor/
├── artisan
├── composer.json
└── .env.example
```

---

## Langkah 3: Pindahkan Public Assets ke Root

**INI LANGKAH KRUSIAL** — Agar Laravel bisa berjalan di shared hosting tanpa mengakses `/public` di URL.

### 3.1 Pindahkan isi folder `public/` ke `public_html/`

1. Buka folder `public/` di File Manager
2. Pilih SEMUA file di dalam `public/` (css, js, images, uploads, index.php, .htaccess)
3. Klik **Move** → pindahkan ke `public_html/`
4. Hapus folder `public/` yang sudah kosong

### 3.2 Edit file `index.php` di `public_html/`

Buka `public_html/index.php`, ubah 2 baris berikut:

**SEBELUM:**
```php
require __DIR__.'/../vendor/autoload.php';
$app = require_once __DIR__.'/../bootstrap/app.php';
```

**SESUDAH:**
```php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
```

Intinya: hapus `/..` dari path karena index.php sekarang ada di root yang sama dengan vendor/ dan bootstrap/.

### 3.3 Edit file `public_html/.htaccess`

Pastikan isi .htaccess seperti ini:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^(.*)$ public/$1 [L]
</IfModule>
```

Atau jika sudah dipindah ke root, gunakan versi standar Laravel:

```apache
<IfModule mod_rewrite.c>
    RewriteEngine On

    # Redirect ke HTTPS
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

    # Handle Authorization Header
    RewriteCond %{HTTP:Authorization} .
    RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]

    # Redirect ke index.php
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^ index.php [L]
</IfModule>
```

---

## Langkah 4: Buat Database MySQL

### 4.1 Buka MySQL Databases

1. Di cPanel, klik **MySQL Databases**
2. Pada "Create New Database":
   - Masukkan nama: `bandarbandeng`
   - Klik **Create Database**
   - Nama lengkap akan jadi: `cpaneluser_bandarbandeng`

### 4.2 Buat Database User

1. Pada "MySQL Users" → "Add New User":
   - Username: `bbkuser`
   - Password: buat password kuat (catat!)
   - Klik **Create User**
   - Nama lengkap: `cpaneluser_bbkuser`

### 4.3 Assign User ke Database

1. Pada "Add User to Database":
   - Pilih user: `cpaneluser_bbkuser`
   - Pilih database: `cpaneluser_bandarbandeng`
   - Klik **Add**
2. Pilih **ALL PRIVILEGES** → Klik **Make Changes**

---

## Langkah 5: Import Database

### 5.1 Buka phpMyAdmin

1. Di cPanel, klik **phpMyAdmin**
2. Pilih database `cpaneluser_bandarbandeng` di sidebar kiri

### 5.2 Import SQL

1. Klik tab **Import**
2. Klik **Choose File** → pilih `database/sql/bandarbandeng.sql`
3. Pastikan:
   - Format: SQL
   - Character set: utf-8
4. Klik **Import** di bawah
5. Tunggu hingga muncul pesan "Import has been successfully finished"

### 5.3 Verifikasi

Pastikan ada 22 tabel di database, termasuk: `users`, `products`, `orders`, `wallets`, dll.

---

## Langkah 6: Konfigurasi .env

### 6.1 Buat file .env

1. Di File Manager, salin file `.env.example` → rename menjadi `.env`
2. Atau buat file baru bernama `.env` di root

### 6.2 Edit isi .env

Buka file `.env` dan sesuaikan:

```env
APP_NAME="Bandar Bandeng Kalimantan"
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL=https://www.bandarbandeng.com

LOG_CHANNEL=stack

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=cpaneluser_bandarbandeng
DB_USERNAME=cpaneluser_bbkuser
DB_PASSWORD=password_yang_anda_buat

BROADCAST_DRIVER=log
CACHE_DRIVER=file
FILESYSTEM_DRIVER=public
QUEUE_DRIVER=database
SESSION_DRIVER=file
SESSION_LIFETIME=120

MAIL_MAILER=smtp
MAIL_HOST=mail.bandarbandeng.com
MAIL_PORT=465
MAIL_USERNAME=noreply@bandarbandeng.com
MAIL_PASSWORD=mail_password_anda
MAIL_ENCRYPTION=ssl
MAIL_FROM_ADDRESS=noreply@bandarbandeng.com
MAIL_FROM_NAME="Bandar Bandeng"

WA_NUMBER=082243922576
```

> **PENTING:**
> - `APP_DEBUG=false` di production!
> - `DB_DATABASE`, `DB_USERNAME` di cPanel selalu diawali `cpaneluser_`
> - Ganti `APP_KEY` nanti setelah generate

---

## Langkah 7: Generate Key dan Storage Link

### Opsi A: Via cPanel Terminal (jika tersedia)

1. Di cPanel, klik **Terminal**
2. Jalankan:

```bash
cd /home/cpaneluser/public_html
php artisan key:generate
php artisan storage:link
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### Opsi B: Via SSH

```bash
ssh cpaneluser@domainanda.com
cd ~/public_html
php artisan key:generate
php artisan storage:link
php artisan config:cache
```

### Opsi C: Via Cron Job (jika tidak ada Terminal)

1. Di cPanel, klik **Cron Jobs**
2. Tambah cron dengan waktu "Once" (one-time):
   ```bash
   cd /home/cpaneluser/public_html && php artisan key:generate
   ```
3. Jalankan, tunggu, lalu hapus cron
4. Ulangi untuk:
   ```bash
   cd /home/cpaneluser/public_html && php artisan storage:link
   ```
   ```bash
   cd /home/cpaneluser/public_html && php artisan config:cache
   ```

### Opsi D: Via PHP Script

Buat file `setup.php` di `public_html/`:

```php
<?php
// setup.php — HAPUS FILE INI SETELAH SELESAI!
echo '<pre>';
echo "Generating key...\n";
echo shell_exec('php artisan key:generate');
echo "Creating storage link...\n";
echo shell_exec('php artisan storage:link');
echo "Caching config...\n";
echo shell_exec('php artisan config:cache');
echo "Done! DELETE THIS FILE NOW.";
echo '</pre>';
```

Akses via browser: `https://domainanda.com/setup.php`

**HAPUS `setup.php` SETELAH SELESAI!**

---

## Langkah 8: Set Permission Folder

### Via File Manager

1. Klik kanan folder `storage/` → **Change Permissions**
   - Set: 755 (atau 775 jika 755 tidak work)
   - Centang "Recursive"
2. Lakukan sama untuk:
   - `bootstrap/cache/` → 755
   - `public_html/uploads/` → 755

### Via Terminal/SSH

```bash
chmod -R 755 storage bootstrap/cache
chmod -R 755 public_html/uploads
```

---

## Langkah 9: Verifikasi

Buka browser dan akses:

1. **Landing Page:** `https://www.bandarbandeng.com/`
   - Harus tampil halaman landing Bandar Bandeng

2. **Login:** `https://www.bandarbandeng.com/login`
   - Login admin: admin@bandarbandeng.com / password
   - Harus redirect ke `/admin`

3. **Cek gambar:** Pastikan upload gambar berfungsi
4. **Cek dark mode:** Klik toggle tema di navbar

---

## Konfigurasi Tambahan

### SSL Certificate

1. Di cPanel, klik **SSL/TLS Status** atau **Let's Encrypt**
2. Aktifkan SSL untuk domain
3. Pastikan `.htaccess` redirect HTTP → HTTPS

### Email

Untuk fitur reset password dan notifikasi:

1. Di cPanel, buat email `noreply@bandarbandeng.com`
2. Update `MAIL_*` di `.env`
3. Atau gunakan SMTP external (Mailgun, SendGrid, dll)

### Cron Job untuk Queue (Opsional)

Jika menggunakan queue untuk email/job:

```bash
* * * * * cd /home/cpaneluser/public_html && php artisan schedule:run >> /dev/null 2>&1
```

---

## Troubleshooting cPanel

### 1. Halaman Blank / White Screen

```bash
# Di .env, set sementara
APP_DEBUG=true

# Cek log
tail -50 storage/logs/laravel.log
```

Setelah tahu errornya, kembalikan `APP_DEBUG=false`.

### 2. Error 404 di Semua Route

- Pastikan `.htaccess` ada di root `public_html/`
- Pastikan `mod_rewrite` aktif di Apache
- Cek `AllowOverride` di Apache config (biasanya sudah default di cPanel)

### 3. Error "The stream or file could not be opened"

```bash
chmod -R 775 storage
chmod -R 775 bootstrap/cache
```

### 4. Storage Link Tidak Berfungsi

```bash
# Hapus link lama
rm public_html/storage

# Buat ulang
php artisan storage:link

# Atau buat manual symlink
ln -s /home/cpaneluser/public_html/storage/app/public /home/cpaneluser/public_html/storage
```

### 5. Composer Tidak Tersedia

Jika hosting tidak punya Composer:
- Install dependency di komputer lokal dulu: `composer install --no-dev`
- Upload folder `vendor/` bersama project ke hosting

### 6. PHP Version Salah

1. cPanel → **Select PHP Version**
2. Pilih PHP 8.1 atau 8.2
3. Centang ekstensi yang dibutuhkan: mbstring, openssl, pdo_mysql, tokenizer, xml, ctype, json, bcmath, fileinfo, gd

### 7. Upload File Gagal (413 Request Entity Too Large)

Tambahkan di `.htaccess`:

```apache
php_value upload_max_filesize 10M
php_value post_max_size 12M
php_value max_execution_time 300
```

Atau buat file `.user.ini`:

```ini
upload_max_filesize = 10M
post_max_size = 12M
max_execution_time = 300
```

---

## Keamanan Production

Setelah deployment, pastikan:

- [ ] `APP_DEBUG=false` di `.env`
- [ ] `APP_KEY` sudah di-generate (tidak kosong)
- [ ] File `setup.php` sudah dihapus
- [ ] Folder `storage/` dan `bootstrap/cache/` permission 755
- [ ] Password admin sudah diganti dari default "password"
- [ ] SSL/HTTPS sudah aktif
- [ ] `.env` tidak bisa diakses via browser (cek: `https://domain/.env` harus 403/404)
- [ ] `phpMyAdmin` hanya bisa diakses via cPanel (tidak publik)
- [ ] Backup database berkala via cPanel → Backup

---

## Backup & Restore

### Backup Database

1. cPanel → **Backup** → **Download a MySQL Database Backup**
2. Pilih `cpaneluser_bandarbandeng`
3. File `.sql.gz` akan ter-download

### Restore Database

1. cPanel → **Backup** → **Restore a MySQL Database**
2. Pilih file backup `.sql.gz`
3. Klik Upload

---

## Informasi Kontak

Jika ada kendala teknis:

- **WhatsApp:** 0822 4392 2576
- **Website:** www.bandarbandeng.com
