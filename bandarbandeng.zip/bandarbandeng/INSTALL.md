# Panduan Instalasi — Bandar Bandeng Kalimantan

## Persyaratan Server

| Komponen | Minimum | Rekomendasi |
|----------|---------|-------------|
| PHP | 8.1 | 8.2+ |
| MySQL | 5.7 | 8.0+ |
| Ekstensi PHP | pdo_mysql, mbstring, openssl, tokenizer, xml, ctype, json, bcmath, fileinfo, gd | sama |
| Composer | 2.x | terbaru |
| Disk Space | 200 MB | 500 MB |

---

## Cara 1: Instalasi via Composer (Rekomendasi untuk VPS/Local)

### Langkah 1: Clone atau Upload File

```bash
# Jika dari Git
git clone <repo-url> /var/www/bandarbandeng
cd /var/www/bandarbandeng

# Atau upload via FTP/SFTP ke document root hosting
```

### Langkah 2: Install Dependency

```bash
composer install --no-dev --optimize-autoloader
```

### Langkah 3: Konfigurasi Environment

```bash
# Salin file .env
cp .env.example .env

# Generate application key
php artisan key:generate
```

Edit file `.env` dan sesuaikan:

```env
APP_NAME="Bandar Bandeng Kalimantan"
APP_URL=http://www.bandarbandeng.com

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=bandarbandeng_db
DB_USERNAME=bandarbandeng_user
DB_PASSWORD=password_anda_disini

MAIL_MAILER=smtp
MAIL_HOST=mail.bandarbandeng.com
MAIL_PORT=465
MAIL_USERNAME=noreply@bandarbandeng.com
MAIL_PASSWORD=mail_password
MAIL_ENCRYPTION=ssl

WA_NUMBER=082243922576
```

### Langkah 4: Buat Database

```bash
# Login ke MySQL
mysql -u root -p

# Buat database dan user
CREATE DATABASE bandarbandeng_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'bandarbandeng_user'@'localhost' IDENTIFIED BY 'password_anda_disini';
GRANT ALL PRIVILEGES ON bandarbandeng_db.* TO 'bandarbandeng_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

### Langkah 5: Import Database

**Opsi A: Import dari SQL dump (CEPAT — termasuk data demo)**

```bash
mysql -u bandarbandeng_user -p bandarbandeng_db < database/sql/bandarbandeng.sql
```

**Opsi B: Jalankan Migration + Seeder (fresh install)**

```bash
php artisan migrate --seed
```

### Langkah 6: Setup Storage Link

```bash
php artisan storage:link
```

### Langkah 7: Set Permission

```bash
chmod -R 775 storage bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
```

### Langkah 8: Optimize

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

### Langkah 9: Jalankan

```bash
# Untuk development
php artisan serve

# Untuk production, gunakan web server (Nginx/Apache)
```

---

## Cara 2: Instalasi via cPanel (Shared Hosting)

> **Detail lengkap ada di file `CPANEL-GUIDE.md`**

### Ringkasan:

1. Login cPanel → File Manager → Upload ZIP project ke `public_html`
2. Extract ZIP
3. Buat database via cPanel → MySQL Databases
4. Import `database/sql/bandarbandeng.sql` via phpMyAdmin
5. Edit `.env` dengan kredensial database
6. Jalankan `php artisan key:generate` via Terminal/Schedule Task
7. Jalankan `php artisan storage:link` via Terminal
8. Website siap diakses

---

## Cara 3: Quick Install via Script

```bash
# Berikan permission eksekusi
chmod +x install.sh

# Jalankan installer
./install.sh
```

Script akan otomatis:
- Cek dependency PHP
- Buat file .env dari .env.example
- Generate key
- Jalankan migration
- Jalankan seeder
- Setup storage link
- Set permission

---

## Akun Demo

Setelah import database, akun berikut tersedia:

| Role | Email | Password |
|------|-------|----------|
| Admin Pusat | admin@bandarbandeng.com | password |
| Stockist Banjarmasin | stockist@bandarbandeng.com | password |
| Stockist Samarinda | stockist2@bandarbandeng.com | password |
| Agen Rizki | agen@bandarbandeng.com | password |
| Agen Berkah | agen2@bandarbandeng.com | password |
| Agen Jaya | agen3@bandarbandeng.com | password |
| Customer Budi | customer@bandarbandeng.com | password |
| Customer Siti | customer2@bandarbandeng.com | password |
| Customer Ahmad | customer3@bandarbandeng.com | password |

> **PENTING:** Segera ganti password akun admin setelah instalasi di production!

---

## Verifikasi Instalasi

Setelah instalasi, verifikasi dengan mengakses:

1. **Landing Page:** `http://domain-anda.com/`
   - Harus menampilkan halaman landing Bandar Bandeng Kalimantan

2. **Login Admin:** `http://domain-anda.com/login`
   - Login dengan admin@bandarbandeng.com / password
   - Harus redirect ke `/admin` dashboard

3. **Login Customer:** `http://domain-anda.com/login`
   - Login dengan customer@bandarbandeng.com / password
   - Harus redirect ke `/pelanggan` dashboard

4. **Database:** Cek via phpMyAdmin
   - Harus ada 22 tabel
   - Tabel `users` harus berisi 9 data demo

---

## Troubleshooting

### Error 500 — Internal Server Error

```bash
# Cek permission
chmod -R 775 storage bootstrap/cache

# Cek .env
cp .env.example .env
php artisan key:generate

# Cek error log
tail -f storage/logs/laravel.log
```

### Error "No application encryption key"

```bash
php artisan key:generate
php artisan config:cache
```

### Error "Storage link exists"

```bash
rm public/storage
php artisan storage:link
```

### Blank Page / White Screen

```bash
# Set debug mode di .env
APP_DEBUG=true

# Clear cache
php artisan view:clear
php artisan config:clear
php artisan cache:clear
```

### Database Connection Refused

- Pastikan `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` benar di `.env`
- Di cPanel, host biasanya `localhost` dan user format `cpaneluser_dbuser`
- Pastikan user MySQL punya privilege ke database

### Upload Gambar Gagal

```bash
# Pastikan folder storage writable
chmod -R 775 storage/app/public
php artisan storage:link
```

---

## Struktur Folder

```
bandarbandeng-laravel/
├── app/
│   ├── Http/
│   │   ├── Controllers/     # Semua controller
│   │   ├── Middleware/       # RoleMiddleware, ThemeMiddleware, dll
│   │   └── Kernel.php
│   ├── Models/              # Eloquent models (18 file)
│   └── Providers/           # Service providers
├── bootstrap/
├── config/                  # Konfigurasi Laravel
├── database/
│   ├── migrations/          # 23 file migration
│   ├── seeders/             # 10 file seeder
│   └── sql/                 # SQL dump siap import
├── public/
│   ├── css/                 # app.css, landing.css, admin.css
│   ├── js/                  # app.js, landing.js
│   ├── images/
│   ├── uploads/             # Upload user
│   └── index.php
├── resources/
│   └── views/               # Blade templates
│       ├── layouts/         # 6 layout file
│       ├── landing/         # Landing page
│       ├── auth/            # Login, Register
│       ├── admin/           # Dashboard admin
│       ├── stockist/        # Dashboard stockist
│       ├── agent/           # Dashboard agent
│       ├── customer/        # Dashboard customer
│       └── components/      # Komponen reusable
├── routes/
│   └── web.php              # Semua route (60+ route)
├── storage/
├── .env.example
├── INSTALL.md               # File ini
├── CPANEL-GUIDE.md          # Panduan cPanel
└── composer.json
```
