<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Stock;
use App\Models\User;
use App\Models\Withdrawal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

/**
 * Admin\DashboardController
 *
 * Handles the admin dashboard with key statistics, chart data,
 * low stock alerts, and recent orders.
 */
class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display the admin dashboard.
     *
     * Gathers total orders, revenue this month, total users by role,
     * total products, low stock alerts, and recent orders.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // ---- Core statistics ----
        $totalOrders = Order::count();
        $revenueThisMonth = Order::where('status', 'completed')
            ->whereYear('created_at', now()->year)
            ->whereMonth('created_at', now()->month)
            ->sum('total');
        $totalProducts = Product::active()->count();

        // Users by role
        $totalAdmins = User::where('role', 'admin')->active()->count();
        $totalStockists = User::stockists()->active()->count();
        $totalAgents = User::agents()->active()->count();
        $totalCustomers = User::where('role', 'customer')->active()->count();
        $totalUsers = User::count();

        // Pending items requiring attention
        $pendingOrders = Order::where('status', 'pending')->count();
        $pendingPayments = Payment::where('status', 'pending')->count();
        $pendingWithdrawals = Withdrawal::where('status', 'pending')->count();

        // Low stock alerts (admin inventory with available qty < 10)
        $lowStockVariants = Stock::byType('admin')
            ->with('productVariant.product')
            ->lowStock(10)
            ->get();

        // Recent orders (latest 10)
        $recentOrders = Order::with(['buyer', 'seller', 'orderItems.productVariant'])
            ->recent()
            ->take(10)
            ->get();

        $stats = [
            'total_orders'         => $totalOrders,
            'revenue_this_month'   => $revenueThisMonth,
            'total_products'       => $totalProducts,
            'total_users'          => $totalUsers,
            'total_admins'         => $totalAdmins,
            'total_stockists'      => $totalStockists,
            'total_agents'         => $totalAgents,
            'total_customers'      => $totalCustomers,
            'pending_orders'       => $pendingOrders,
            'pending_payments'     => $pendingPayments,
            'pending_withdrawals'  => $pendingWithdrawals,
        ];

        return view('admin.dashboard', compact('stats', 'recentOrders', 'lowStockVariants'));
    }

    /**
     * Return JSON statistics for chart rendering.
     *
     * Supports daily, weekly, and monthly sales chart data,
     * order status distribution, and top products.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function getStats(Request $request)
    {
        $validated = $request->validate([
            'period' => 'nullable|in:daily,weekly,monthly',
        ]);

        $period = $validated['period'] ?? 'monthly';

        // ---- Sales chart data based on period ----
        $salesChartData = $this->getSalesChartData($period);

        // ---- Order status distribution ----
        $orderStatusDistribution = Order::selectRaw('status, COUNT(*) as count')
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();

        // ---- Top products by total quantity sold ----
        $topProducts = OrderItem::selectRaw(
            'product_variant_id, SUM(quantity) as total_quantity, SUM(subtotal) as total_revenue'
        )
            ->whereHas('order', function ($q) {
                $q->where('status', 'completed');
            })
            ->with('productVariant.product')
            ->groupBy('product_variant_id')
            ->orderByDesc('total_quantity')
            ->take(10)
            ->get()
            ->map(function ($item) {
                return [
                    'product_name'  => $item->productVariant?->product?->name ?? '-',
                    'variant_name'  => $item->productVariant?->name ?? '-',
                    'total_quantity' => (int) $item->total_quantity,
                    'total_revenue' => (float) $item->total_revenue,
                ];
            });

        // ---- User registration trend (last 12 months) ----
        $userRegistrationTrend = User::selectRaw("
                DATE_FORMAT(created_at, '%Y-%m') as month,
                COUNT(*) as count
            ")
            ->where('created_at', '>=', now()->subMonths(12))
            ->groupByRaw("DATE_FORMAT(created_at, '%Y-%m')")
            ->orderBy('month')
            ->get();

        $data = [
            'sales_chart'             => $salesChartData,
            'order_status_distribution' => $orderStatusDistribution,
            'top_products'            => $topProducts,
            'user_registration_trend' => $userRegistrationTrend,
        ];

        return $this->successResponse('Statistik berhasil dimuat.', $data);
    }

    /**
     * Build sales chart data for the requested period.
     *
     * @param  string  $period  One of: daily, weekly, monthly
     * @return \Illuminate\Support\Collection
     */
    protected function getSalesChartData(string $period)
    {
        return match ($period) {
            'daily' => Order::where('status', 'completed')
                ->selectRaw("
                    DATE(created_at) as date,
                    SUM(total) as revenue,
                    COUNT(*) as order_count
                ")
                ->where('created_at', '>=', now()->subDays(30))
                ->groupByRaw('DATE(created_at)')
                ->orderBy('date')
                ->get(),

            'weekly' => Order::where('status', 'completed')
                ->selectRaw("
                    YEARWEEK(created_at, 1) as yearweek,
                    DATE(DATE_SUB(created_at, INTERVAL WEEKDAY(created_at) DAY)) as week_start,
                    SUM(total) as revenue,
                    COUNT(*) as order_count
                ")
                ->where('created_at', '>=', now()->subWeeks(12))
                ->groupByRaw('YEARWEEK(created_at, 1)')
                ->orderBy('yearweek')
                ->get(),

            default => Order::where('status', 'completed')
                ->selectRaw("
                    DATE_FORMAT(created_at, '%Y-%m') as month,
                    SUM(total) as revenue,
                    COUNT(*) as order_count
                ")
                ->where('created_at', '>=', now()->subMonths(12))
                ->groupByRaw("DATE_FORMAT(created_at, '%Y-%m')")
                ->orderBy('month')
                ->get(),
        };
    }
}
