<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

/**
 * Admin\OrderController
 *
 * Handles viewing and managing all orders in the system.
 * Admin can view orders, update statuses, approve stockist orders,
 * and notify the relevant parties.
 */
class OrderController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display a listing of all orders with filters.
     *
     * Supports filtering by status, order type, date range,
     * and searching by order number or buyer name.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = Order::with(['buyer', 'seller', 'orderItems.productVariant']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        // Filter by order type
        if ($request->filled('order_type')) {
            $query->where('order_type', $request->input('order_type'));
        }

        // Filter by date range
        if ($request->filled('from_date')) {
            $query->whereDate('created_at', '>=', $request->input('from_date'));
        }
        if ($request->filled('to_date')) {
            $query->whereDate('created_at', '<=', $request->input('to_date'));
        }

        // Search by order number or buyer name
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('order_number', 'like', "%{$search}%")
                  ->orWhereHas('buyer', function ($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $orders = $query->recent()->paginate(20)->withQueryString();

        return view('admin.orders.index', compact('orders'));
    }

    /**
     * Display the specified order's details.
     *
     * Includes items, payments, buyer, seller, ratings, and complaints.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $order = Order::with([
            'buyer',
            'seller',
            'orderItems.productVariant.product',
            'payments',
            'ratings',
            'complaints',
        ])->findOrFail($id);

        return view('admin.orders.show', compact('order'));
    }

    /**
     * Update the status of the specified order.
     *
     * Validates the status transition, updates the order with
     * appropriate timestamps, notifies the buyer and seller,
     * and handles stock restoration on cancellation or
     * commission processing on completion.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStatus(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        $validated = $request->validate([
            'status'              => 'required|in:pending,confirmed,processing,shipped,delivered,completed,cancelled,refunded',
            'cancellation_reason' => 'nullable|string|max:500|required_if:status,cancelled',
            'tracking_number'     => 'nullable|string|max:100',
            'notes'               => 'nullable|string|max:500',
        ], [
            'status.required'                  => 'Status wajib dipilih.',
            'cancellation_reason.required_if'  => 'Alasan pembatalan wajib diisi.',
        ]);

        $oldStatus = $order->getOriginal('status');

        // Validate allowed status transition
        $this->validateStatusTransition($oldStatus, $validated['status']);

        DB::transaction(function () use ($order, $validated) {
            $updateData = [
                'status' => $validated['status'],
            ];

            // Set timestamps based on status
            switch ($validated['status']) {
                case 'shipped':
                    $updateData['shipped_at'] = now();
                    if (!empty($validated['tracking_number'])) {
                        $updateData['tracking_number'] = $validated['tracking_number'];
                    }
                    break;
                case 'delivered':
                    $updateData['delivered_at'] = now();
                    break;
                case 'cancelled':
                    $updateData['cancelled_at'] = now();
                    $updateData['cancellation_reason'] = $validated['cancellation_reason'] ?? null;
                    // Restore stock if cancelling a confirmed order
                    $this->restoreStock($order);
                    break;
                case 'completed':
                    // Process commission for seller if applicable
                    $this->processCompletion($order);
                    break;
            }

            if (!empty($validated['notes'])) {
                $updateData['notes'] = $validated['notes'];
            }

            $order->update($updateData);
        });

        // Notify buyer and seller about the status change
        $this->notifyOrderStatusChange($order, $validated['status']);

        $this->logActivity('order.status_updated', "Status pesanan #{$order->order_number} diubah dari {$oldStatus} ke {$validated['status']}.", [
            'order_id'   => $order->id,
            'old_status' => $oldStatus,
            'new_status' => $validated['status'],
        ]);

        return redirect()->route('admin.orders.show', $order->id)
            ->with('success', "Status pesanan #{$order->order_number} berhasil diperbarui ke {$validated['status']}.");
    }

    /**
     * Approve a stockist's order to the admin.
     *
     * For stockist→admin orders only. Confirms the order, deducts
     * stock from admin inventory, adds stock to the stockist's
     * inventory, and notifies the stockist.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function approveOrder($id)
    {
        $order = Order::where('order_type', 'stockist_to_admin')
            ->where('status', 'pending')
            ->with(['orderItems.productVariant', 'buyer'])
            ->findOrFail($id);

        DB::transaction(function () use ($order) {
            // Verify and deduct admin stock
            foreach ($order->orderItems as $item) {
                $adminStock = Stock::byType('admin')
                    ->where('product_variant_id', $item->product_variant_id)
                    ->first();

                if (!$adminStock || $adminStock->available_quantity < $item->quantity) {
                    throw new \Exception("Stok tidak mencukupi untuk varian {$item->productVariant->name}.");
                }

                // Deduct from admin stock
                $adminStock->decrement('quantity', $item->quantity);
                $adminStock->increment('reserved_quantity', $item->quantity);

                // Add to stockist stock
                $stockistStock = Stock::where('user_id', $order->buyer_id)
                    ->where('product_variant_id', $item->product_variant_id)
                    ->where('type', 'stockist')
                    ->first();

                if ($stockistStock) {
                    $stockistStock->increment('quantity', $item->quantity);
                } else {
                    Stock::create([
                        'product_variant_id' => $item->product_variant_id,
                        'user_id'            => $order->buyer_id,
                        'quantity'           => $item->quantity,
                        'reserved_quantity'  => 0,
                        'type'               => 'stockist',
                    ]);
                }
            }

            // Update order status
            $order->update(['status' => 'confirmed']);
        });

        // Notify the stockist that their order has been approved
        Notification::create([
            'user_id' => $order->buyer_id,
            'title'   => 'Pesanan Disetujui',
            'message' => "Pesanan #{$order->order_number} telah disetujui oleh admin.",
            'type'    => 'order_approved',
            'data'    => ['order_id' => $order->id],
        ]);

        $this->logActivity('order.approved', "Pesanan stockist #{$order->order_number} disetujui.", [
            'order_id' => $order->id,
        ]);

        return redirect()->route('admin.orders.show', $order->id)
            ->with('success', "Pesanan stockist #{$order->order_number} berhasil disetujui.");
    }

    /**
     * Validate that the status transition is allowed.
     *
     * @param  string  $from  Current status
     * @param  string  $to    Desired status
     * @return void
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function validateStatusTransition(string $from, string $to): void
    {
        $allowedTransitions = [
            'pending'    => ['confirmed', 'cancelled'],
            'confirmed'  => ['processing', 'cancelled'],
            'processing' => ['shipped', 'cancelled'],
            'shipped'    => ['delivered'],
            'delivered'  => ['completed'],
            'completed'  => ['refunded'],
            'cancelled'  => [],
            'refunded'   => [],
        ];

        $allowed = $allowedTransitions[$from] ?? [];

        if (!in_array($to, $allowed)) {
            abort(400, "Transisi status dari '{$from}' ke '{$to}' tidak diizinkan.");
        }
    }

    /**
     * Restore stock when an order is cancelled.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    protected function restoreStock(Order $order): void
    {
        foreach ($order->orderItems as $item) {
            // Determine which stock type to restore based on order type
            $stockType = match ($order->order_type) {
                'stockist_to_admin'   => 'admin',
                'agent_to_stockist'   => 'stockist',
                'customer_to_agent'   => 'agent',
                default               => null,
            };

            if ($stockType) {
                $stock = Stock::where('product_variant_id', $item->product_variant_id)
                    ->where('type', $stockType)
                    ->when($stockType !== 'admin', function ($q) use ($order) {
                        $q->where('user_id', $order->seller_id);
                    })
                    ->first();

                if ($stock) {
                    $stock->decrement('reserved_quantity', min($item->quantity, $stock->reserved_quantity));
                    $stock->increment('quantity', $item->quantity);
                }
            }
        }
    }

    /**
     * Process order completion: release reserved stock and credit seller wallet.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    protected function processCompletion(Order $order): void
    {
        // Release reserved stock
        foreach ($order->orderItems as $item) {
            $stockType = match ($order->order_type) {
                'stockist_to_admin'   => 'admin',
                'agent_to_stockist'   => 'stockist',
                'customer_to_agent'   => 'agent',
                default               => null,
            };

            if ($stockType) {
                $stock = Stock::where('product_variant_id', $item->product_variant_id)
                    ->where('type', $stockType)
                    ->when($stockType !== 'admin', function ($q) use ($order) {
                        $q->where('user_id', $order->seller_id);
                    })
                    ->first();

                if ($stock) {
                    $stock->decrement('reserved_quantity', min($item->quantity, $stock->reserved_quantity));
                }
            }
        }

        // Credit the seller's wallet with the order total
        $seller = $order->seller;
        if ($seller && $seller->wallet) {
            $seller->wallet->deposit((float) $order->total, "Pembayaran pesanan #{$order->order_number}");
        }
    }

    /**
     * Send notifications to the buyer and seller about a status change.
     *
     * @param  \App\Models\Order  $order
     * @param  string             $newStatus
     * @return void
     */
    protected function notifyOrderStatusChange(Order $order, string $newStatus): void
    {
        $statusLabels = [
            'pending'    => 'Menunggu',
            'confirmed'  => 'Dikonfirmasi',
            'processing' => 'Diproses',
            'shipped'    => 'Dikirim',
            'delivered'  => 'Diterima',
            'completed'  => 'Selesai',
            'cancelled'  => 'Dibatalkan',
            'refunded'   => 'Dikembalikan',
        ];

        $label = $statusLabels[$newStatus] ?? ucfirst($newStatus);

        // Notify the buyer
        Notification::create([
            'user_id' => $order->buyer_id,
            'title'   => 'Status Pesanan Diperbarui',
            'message' => "Pesanan #{$order->order_number} statusnya diubah menjadi: {$label}.",
            'type'    => 'order_status_updated',
            'data'    => [
                'order_id' => $order->id,
                'status'   => $newStatus,
            ],
        ]);

        // Notify the seller (if different from buyer)
        if ($order->seller_id && $order->seller_id !== $order->buyer_id) {
            Notification::create([
                'user_id' => $order->seller_id,
                'title'   => 'Status Pesanan Diperbarui',
                'message' => "Pesanan #{$order->order_number} statusnya diubah menjadi: {$label}.",
                'type'    => 'order_status_updated',
                'data'    => [
                    'order_id' => $order->id,
                    'status'   => $newStatus,
                ],
            ]);
        }
    }
}
