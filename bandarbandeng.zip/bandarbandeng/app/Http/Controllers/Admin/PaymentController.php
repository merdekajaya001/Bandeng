<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

/**
 * Admin\PaymentController
 *
 * Manages payment verification for bank transfer payments.
 * Admin can verify or reject payments with a reason.
 * Verification also credits the seller's wallet.
 */
class PaymentController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display a listing of payments with filters.
     *
     * Supports filtering by status, payment method, date range,
     * and searching by order number.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = Payment::with(['order.buyer', 'order.seller', 'verifiedBy']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        } else {
            // Default: show pending first
            $query->orderByRaw("FIELD(status, 'pending', 'verified', 'rejected', 'refunded')");
        }

        // Filter by payment method
        if ($request->filled('payment_method')) {
            $query->where('payment_method', $request->input('payment_method'));
        }

        // Filter by date range
        if ($request->filled('from_date')) {
            $query->whereDate('created_at', '>=', $request->input('from_date'));
        }
        if ($request->filled('to_date')) {
            $query->whereDate('created_at', '<=', $request->input('to_date'));
        }

        // Search by order number
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->whereHas('order', function ($q) use ($search) {
                $q->where('order_number', 'like', "%{$search}%");
            });
        }

        $payments = $query->latest()->paginate(20)->withQueryString();

        return view('admin.payments.index', compact('payments'));
    }

    /**
     * Verify (approve) a bank transfer payment.
     *
     * Marks the payment as verified, updates the associated order
     * to confirmed status, and credits the seller's wallet
     * with the payment amount.
     *
     * @param  int  $id  Payment ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function verify($id)
    {
        $payment = Payment::where('status', 'pending')
            ->with('order')
            ->findOrFail($id);

        DB::transaction(function () use ($payment) {
            // Mark the payment as verified
            $payment->update([
                'status'      => 'verified',
                'verified_at' => now(),
                'verified_by' => auth()->id(),
            ]);

            // If the associated order is still pending, confirm it
            $order = $payment->order;
            if ($order && $order->status === 'pending') {
                $order->update(['status' => 'confirmed']);
            }

            // Credit the seller's wallet with the payment amount
            if ($order && $order->seller && $order->seller->wallet) {
                $order->seller->wallet->deposit(
                    (float) $payment->amount,
                    "Pembayaran diterima untuk pesanan #{$order->order_number}"
                );
            }
        });

        // Notify the buyer that their payment has been verified
        if ($payment->order && $payment->order->buyer_id) {
            Notification::create([
                'user_id' => $payment->order->buyer_id,
                'title'   => 'Pembayaran Diverifikasi',
                'message' => "Pembayaran untuk pesanan #{$payment->order->order_number} telah diverifikasi.",
                'type'    => 'payment_verified',
                'data'    => [
                    'payment_id' => $payment->id,
                    'order_id'   => $payment->order_id,
                ],
            ]);
        }

        // Notify the seller that payment has been received
        if ($payment->order && $payment->order->seller_id) {
            Notification::create([
                'user_id' => $payment->order->seller_id,
                'title'   => 'Pembayaran Diterima',
                'message' => "Pembayaran untuk pesanan #{$payment->order->order_number} telah diterima dan dikredit ke dompet Anda.",
                'type'    => 'payment_received',
                'data'    => [
                    'payment_id' => $payment->id,
                    'order_id'   => $payment->order_id,
                ],
            ]);
        }

        $this->logActivity('payment.verified', "Pembayaran #{$payment->id} untuk pesanan #{$payment->order->order_number} diverifikasi.", [
            'payment_id' => $payment->id,
            'order_id'   => $payment->order_id,
            'amount'     => $payment->amount,
        ]);

        return redirect()->route('admin.payments.index')
            ->with('success', "Pembayaran berhasil diverifikasi. Pesanan #{$payment->order->order_number} telah dikonfirmasi.");
    }

    /**
     * Reject a payment with a reason.
     *
     * Marks the payment as rejected, notifies the buyer
     * about the rejection with the reason provided.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id  Payment ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function reject(Request $request, $id)
    {
        $payment = Payment::where('status', 'pending')
            ->with('order')
            ->findOrFail($id);

        $validated = $request->validate([
            'rejected_reason' => 'required|string|max:500',
            'notes'           => 'nullable|string|max:500',
        ], [
            'rejected_reason.required' => 'Alasan penolakan wajib diisi.',
            'rejected_reason.max'      => 'Alasan penolakan maksimal 500 karakter.',
        ]);

        DB::transaction(function () use ($payment, $validated) {
            $payment->update([
                'status'          => 'rejected',
                'rejected_reason' => $validated['rejected_reason'],
                'notes'           => $validated['notes'] ?? null,
                'verified_by'     => auth()->id(),
            ]);
        });

        // Notify the buyer that their payment was rejected
        if ($payment->order && $payment->order->buyer_id) {
            Notification::create([
                'user_id' => $payment->order->buyer_id,
                'title'   => 'Pembayaran Ditolak',
                'message' => "Pembayaran untuk pesanan #{$payment->order->order_number} ditolak. Alasan: {$validated['rejected_reason']}",
                'type'    => 'payment_rejected',
                'data'    => [
                    'payment_id'       => $payment->id,
                    'order_id'         => $payment->order_id,
                    'rejected_reason'  => $validated['rejected_reason'],
                ],
            ]);
        }

        $this->logActivity('payment.rejected', "Pembayaran #{$payment->id} ditolak: {$validated['rejected_reason']}.", [
            'payment_id'       => $payment->id,
            'rejected_reason'  => $validated['rejected_reason'],
        ]);

        return redirect()->route('admin.payments.index')
            ->with('success', 'Pembayaran berhasil ditolak.');
    }
}
