<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * Admin\ProductController
 *
 * Handles CRUD operations for products and their variants.
 * Includes authorization checks, DB transactions, validation,
 * activity logging, and flash messages.
 */
class ProductController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display a listing of all products with their variants.
     *
     * Supports search by name and filter by category.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = Product::with(['variants' => function ($q) {
            $q->ordered();
        }]);

        // Search by name
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->input('search') . '%');
        }

        // Filter by category
        if ($request->filled('category')) {
            $query->where('category', $request->input('category'));
        }

        // Filter by active status
        if ($request->filled('is_active')) {
            $query->where('is_active', $request->boolean('is_active'));
        }

        $products = $query->ordered()
            ->paginate(15)
            ->withQueryString();

        // Collect unique categories for filter dropdown
        $categories = Product::select('category')
            ->whereNotNull('category')
            ->where('category', '!=', '')
            ->distinct()
            ->orderBy('category')
            ->pluck('category');

        return view('admin.products.index', compact('products', 'categories'));
    }

    /**
     * Show the form for creating a new product.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        return view('admin.products.create');
    }

    /**
     * Store a newly created product and its variants in storage.
     *
     * Validates product name, slug, description, image upload, category,
     * and variant details (name, fish_count, price, weight_kg, image).
     * Creates the product + variants inside a DB transaction.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'                  => 'required|string|max:255',
            'description'           => 'nullable|string|max:1000',
            'long_description'      => 'nullable|string',
            'category'              => 'nullable|string|max:100',
            'image'                 => 'nullable|image|max:2048',
            'is_active'             => 'boolean',
            'sort_order'            => 'nullable|integer|min:0',
            // Variants
            'variants'                      => 'required|array|min:1',
            'variants.*.name'               => 'required|string|max:255',
            'variants.*.description'        => 'nullable|string|max:500',
            'variants.*.fish_count'         => 'required|integer|min:1',
            'variants.*.price'              => 'required|numeric|min:0',
            'variants.*.weight_kg'          => 'required|numeric|min:0',
            'variants.*.image'              => 'nullable|image|max:2048',
            'variants.*.is_active'          => 'boolean',
            'variants.*.sort_order'         => 'nullable|integer|min:0',
        ], [
            'name.required'                    => 'Nama produk wajib diisi.',
            'variants.required'                => 'Minimal satu varian harus ditambahkan.',
            'variants.min'                     => 'Minimal satu varian harus ditambahkan.',
            'variants.*.name.required'         => 'Nama varian wajib diisi.',
            'variants.*.fish_count.required'   => 'Jumlah ikan wajib diisi.',
            'variants.*.fish_count.min'        => 'Jumlah ikan minimal 1.',
            'variants.*.price.required'        => 'Harga wajib diisi.',
            'variants.*.price.min'             => 'Harga tidak boleh negatif.',
            'variants.*.weight_kg.required'    => 'Berat wajib diisi.',
            'variants.*.weight_kg.min'         => 'Berat tidak boleh negatif.',
            'image.image'                      => 'File harus berupa gambar.',
            'image.max'                        => 'Ukuran gambar maksimal 2MB.',
            'variants.*.image.image'           => 'File varian harus berupa gambar.',
            'variants.*.image.max'             => 'Ukuran gambar varian maksimal 2MB.',
        ]);

        $product = DB::transaction(function () use ($validated, $request) {
            // Handle product image upload
            $imagePath = null;
            if ($request->hasFile('image')) {
                $imagePath = $request->file('image')->store('products', 'public');
            }

            // Create the product
            $product = Product::create([
                'name'             => $validated['name'],
                'slug'             => Str::slug($validated['name']),
                'description'      => $validated['description'] ?? null,
                'long_description' => $validated['long_description'] ?? null,
                'category'         => $validated['category'] ?? null,
                'image'            => $imagePath,
                'is_active'        => $validated['is_active'] ?? true,
                'sort_order'       => $validated['sort_order'] ?? 0,
            ]);

            // Create variants
            foreach ($validated['variants'] as $index => $variantData) {
                $variantImagePath = null;
                if ($request->hasFile("variants.{$index}.image")) {
                    $variantImagePath = $request->file("variants.{$index}.image")
                        ->store('variants', 'public');
                }

                $product->variants()->create([
                    'name'        => $variantData['name'],
                    'slug'        => Str::slug($variantData['name']),
                    'description' => $variantData['description'] ?? null,
                    'fish_count'  => $variantData['fish_count'],
                    'price'       => $variantData['price'],
                    'weight_kg'   => $variantData['weight_kg'],
                    'image'       => $variantImagePath,
                    'is_active'   => $variantData['is_active'] ?? true,
                    'sort_order'  => $variantData['sort_order'] ?? $index,
                ]);
            }

            return $product;
        });

        $this->logActivity('product.created', "Produk '{$product->name}' berhasil dibuat.", [
            'product_id' => $product->id,
        ]);

        return redirect()->route('admin.products.index')
            ->with('success', "Produk '{$product->name}' berhasil dibuat.");
    }

    /**
     * Show the form for editing the specified product.
     *
     * Loads the product with its ordered variants.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
        $product = Product::with(['variants' => function ($q) {
            $q->ordered();
        }])->findOrFail($id);

        return view('admin.products.edit', compact('product'));
    }

    /**
     * Update the specified product and its variants in storage.
     *
     * Handles updating existing variants, creating new variants,
     * and removing variants that were deleted from the form.
     * All wrapped in a DB transaction.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $validated = $request->validate([
            'name'                  => 'required|string|max:255',
            'description'           => 'nullable|string|max:1000',
            'long_description'      => 'nullable|string',
            'category'              => 'nullable|string|max:100',
            'image'                 => 'nullable|image|max:2048',
            'is_active'             => 'boolean',
            'sort_order'            => 'nullable|integer|min:0',
            // Variants
            'variants'                      => 'required|array|min:1',
            'variants.*.id'                 => 'nullable|integer|exists:product_variants,id',
            'variants.*.name'               => 'required|string|max:255',
            'variants.*.description'        => 'nullable|string|max:500',
            'variants.*.fish_count'         => 'required|integer|min:1',
            'variants.*.price'              => 'required|numeric|min:0',
            'variants.*.weight_kg'          => 'required|numeric|min:0',
            'variants.*.image'              => 'nullable|image|max:2048',
            'variants.*.is_active'          => 'boolean',
            'variants.*.sort_order'         => 'nullable|integer|min:0',
        ], [
            'name.required'                    => 'Nama produk wajib diisi.',
            'variants.required'                => 'Minimal satu varian harus ditambahkan.',
            'variants.min'                     => 'Minimal satu varian harus ditambahkan.',
            'variants.*.name.required'         => 'Nama varian wajib diisi.',
            'variants.*.fish_count.required'   => 'Jumlah ikan wajib diisi.',
            'variants.*.fish_count.min'        => 'Jumlah ikan minimal 1.',
            'variants.*.price.required'        => 'Harga wajib diisi.',
            'variants.*.price.min'             => 'Harga tidak boleh negatif.',
            'variants.*.weight_kg.required'    => 'Berat wajib diisi.',
            'variants.*.weight_kg.min'         => 'Berat tidak boleh negatif.',
            'image.image'                      => 'File harus berupa gambar.',
            'image.max'                        => 'Ukuran gambar maksimal 2MB.',
            'variants.*.image.image'           => 'File varian harus berupa gambar.',
            'variants.*.image.max'             => 'Ukuran gambar varian maksimal 2MB.',
        ]);

        DB::transaction(function () use ($validated, $request, $product) {
            // Handle product image upload
            $imagePath = $product->image;
            if ($request->hasFile('image')) {
                // Delete the old image
                if ($imagePath && Storage::disk('public')->exists($imagePath)) {
                    Storage::disk('public')->delete($imagePath);
                }
                $imagePath = $request->file('image')->store('products', 'public');
            }

            // Update the product
            $product->update([
                'name'             => $validated['name'],
                'slug'             => Str::slug($validated['name']),
                'description'      => $validated['description'] ?? null,
                'long_description' => $validated['long_description'] ?? null,
                'category'         => $validated['category'] ?? null,
                'image'            => $imagePath,
                'is_active'        => $validated['is_active'] ?? true,
                'sort_order'       => $validated['sort_order'] ?? 0,
            ]);

            // Collect IDs of variants that should remain
            $variantIdsToKeep = [];

            foreach ($validated['variants'] as $index => $variantData) {
                $variantImagePath = null;
                if ($request->hasFile("variants.{$index}.image")) {
                    $variantImagePath = $request->file("variants.{$index}.image")
                        ->store('variants', 'public');
                }

                if (!empty($variantData['id'])) {
                    // Update existing variant
                    $variant = ProductVariant::where('id', $variantData['id'])
                        ->where('product_id', $product->id)
                        ->first();

                    if ($variant) {
                        $updateData = [
                            'name'        => $variantData['name'],
                            'slug'        => Str::slug($variantData['name']),
                            'description' => $variantData['description'] ?? null,
                            'fish_count'  => $variantData['fish_count'],
                            'price'       => $variantData['price'],
                            'weight_kg'   => $variantData['weight_kg'],
                            'is_active'   => $variantData['is_active'] ?? true,
                            'sort_order'  => $variantData['sort_order'] ?? $index,
                        ];

                        if ($variantImagePath) {
                            // Delete old variant image
                            if ($variant->image && Storage::disk('public')->exists($variant->image)) {
                                Storage::disk('public')->delete($variant->image);
                            }
                            $updateData['image'] = $variantImagePath;
                        }

                        $variant->update($updateData);
                        $variantIdsToKeep[] = $variant->id;
                    }
                } else {
                    // Create new variant
                    $newVariant = $product->variants()->create([
                        'name'        => $variantData['name'],
                        'slug'        => Str::slug($variantData['name']),
                        'description' => $variantData['description'] ?? null,
                        'fish_count'  => $variantData['fish_count'],
                        'price'       => $variantData['price'],
                        'weight_kg'   => $variantData['weight_kg'],
                        'image'       => $variantImagePath,
                        'is_active'   => $variantData['is_active'] ?? true,
                        'sort_order'  => $variantData['sort_order'] ?? $index,
                    ]);
                    $variantIdsToKeep[] = $newVariant->id;
                }
            }

            // Delete variants that were removed from the form
            $product->variants()
                ->whereNotIn('id', $variantIdsToKeep)
                ->each(function ($variant) {
                    if ($variant->image && Storage::disk('public')->exists($variant->image)) {
                        Storage::disk('public')->delete($variant->image);
                    }
                    $variant->delete();
                });
        });

        $this->logActivity('product.updated', "Produk '{$product->name}' berhasil diperbarui.", [
            'product_id' => $product->id,
        ]);

        return redirect()->route('admin.products.index')
            ->with('success', "Produk '{$product->name}' berhasil diperbarui.");
    }

    /**
     * Remove the specified product from storage.
     *
     * Performs a soft check: if the product has any active orders
     * (pending, confirmed, or processing), deletion is refused.
     * Otherwise the product, its images, and variants are deleted
     * inside a DB transaction.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        // Soft check: refuse if there are active orders referencing this product
        $hasActiveOrders = OrderItem::whereHas('order', function ($q) {
            $q->whereIn('status', ['pending', 'confirmed', 'processing']);
        })->whereHas('productVariant', function ($q) use ($product) {
            $q->where('product_id', $product->id);
        })->exists();

        if ($hasActiveOrders) {
            return redirect()->route('admin.products.index')
                ->with('error', "Produk '{$product->name}' tidak dapat dihapus karena masih ada pesanan aktif.");
        }

        DB::transaction(function () use ($product) {
            // Delete product image
            if ($product->image && Storage::disk('public')->exists($product->image)) {
                Storage::disk('public')->delete($product->image);
            }

            // Delete variant images and variants
            foreach ($product->variants as $variant) {
                if ($variant->image && Storage::disk('public')->exists($variant->image)) {
                    Storage::disk('public')->delete($variant->image);
                }
            }

            $product->delete();
        });

        $this->logActivity('product.deleted', "Produk '{$product->name}' berhasil dihapus.", [
            'product_id' => $product->id,
            'product_name' => $product->name,
        ]);

        return redirect()->route('admin.products.index')
            ->with('success', "Produk '{$product->name}' berhasil dihapus.");
    }
}
