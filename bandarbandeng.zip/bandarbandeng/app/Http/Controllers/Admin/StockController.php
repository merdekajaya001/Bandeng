<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

/**
 * Admin\StockController
 *
 * Manages the admin's stock inventory. The admin is the top-level
 * stock holder who supplies stockists. Supports listing inventory,
 * adding stock to a variant, and adjusting stock quantities.
 */
class StockController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display a listing of the admin's stock inventory by product variant.
     *
     * Supports filtering by product and low-stock threshold.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = Stock::byType('admin')
            ->with(['productVariant.product']);

        // Filter by product
        if ($request->filled('product_id')) {
            $query->whereHas('productVariant', function ($q) use ($request) {
                $q->where('product_id', $request->input('product_id'));
            });
        }

        // Filter by low stock only
        if ($request->boolean('low_stock')) {
            $query->lowStock(10);
        }

        // Search by variant name
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->whereHas('productVariant', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }

        $stocks = $query->paginate(20)->withQueryString();

        // Products for the filter dropdown
        $products = Product::active()->ordered()->get();

        // All variants for the add-stock dropdown
        $variants = ProductVariant::active()
            ->with('product')
            ->orderBy('name')
            ->get();

        return view('admin.stocks.index', compact('stocks', 'products', 'variants'));
    }

    /**
     * Add stock quantity to a specific product variant.
     *
     * Creates a new admin stock record if one does not already exist,
     * or increments the existing record. Type is set to 'admin'.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function addStock(Request $request)
    {
        $validated = $request->validate([
            'product_variant_id' => 'required|integer|exists:product_variants,id',
            'quantity'           => 'required|integer|min:1',
        ], [
            'product_variant_id.required' => 'Varian produk wajib dipilih.',
            'product_variant_id.exists'   => 'Varian produk tidak ditemukan.',
            'quantity.required'           => 'Jumlah stok wajib diisi.',
            'quantity.min'                => 'Jumlah stok minimal 1.',
        ]);

        $variant = ProductVariant::with('product')->findOrFail($validated['product_variant_id']);

        DB::transaction(function () use ($validated, $variant) {
            // Find or create the admin stock record
            $stock = Stock::byType('admin')
                ->where('product_variant_id', $validated['product_variant_id'])
                ->first();

            if ($stock) {
                $stock->increment('quantity', $validated['quantity']);
            } else {
                // Create a new stock record (admin user_id = 0 signifies system-level stock)
                Stock::create([
                    'product_variant_id' => $validated['product_variant_id'],
                    'user_id'            => 0,
                    'quantity'           => $validated['quantity'],
                    'reserved_quantity'  => 0,
                    'type'               => 'admin',
                ]);
            }
        });

        $this->logActivity('stock.added', "Stok admin ditambahkan: {$variant->name} sebanyak {$validated['quantity']}.", [
            'product_variant_id' => $validated['product_variant_id'],
            'added_quantity'     => $validated['quantity'],
        ]);

        return redirect()->route('admin.stocks.index')
            ->with('success', "Stok {$variant->name} berhasil ditambahkan sebanyak {$validated['quantity']}.");
    }

    /**
     * Adjust (update) the stock quantity for a specific admin stock record.
     *
     * Sets the absolute quantity value on the stock record.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id  Stock ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStock(Request $request, $id)
    {
        $stock = Stock::byType('admin')
            ->with('productVariant.product')
            ->findOrFail($id);

        $validated = $request->validate([
            'quantity' => 'required|integer|min:0',
        ], [
            'quantity.required' => 'Jumlah stok wajib diisi.',
            'quantity.min'      => 'Jumlah stok tidak boleh negatif.',
        ]);

        $oldQuantity = $stock->quantity;

        DB::transaction(function () use ($stock, $validated) {
            $stock->update([
                'quantity' => $validated['quantity'],
            ]);
        });

        $this->logActivity('stock.updated', "Stok admin diperbarui: {$stock->productVariant->name} dari {$oldQuantity} menjadi {$validated['quantity']}.", [
            'stock_id'     => $stock->id,
            'old_quantity' => $oldQuantity,
            'new_quantity' => $validated['quantity'],
        ]);

        return redirect()->route('admin.stocks.index')
            ->with('success', 'Stok berhasil diperbarui.');
    }
}
