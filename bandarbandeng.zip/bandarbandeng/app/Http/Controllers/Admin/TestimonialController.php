<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Testimonial;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;

/**
 * Admin\TestimonialController
 *
 * Manages testimonials: listing with filters, toggling featured/active
 * status, and deleting with image cleanup.
 */
class TestimonialController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display a listing of testimonials with filters.
     *
     * Supports filtering by featured status, active status,
     * and searching by name or content.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = Testimonial::with('user');

        // Filter by featured status
        if ($request->filled('is_featured')) {
            $query->where('is_featured', $request->boolean('is_featured'));
        }

        // Filter by active status
        if ($request->filled('is_active')) {
            $query->where('is_active', $request->boolean('is_active'));
        }

        // Search by name or content
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('content', 'like', "%{$search}%");
            });
        }

        // Filter by rating
        if ($request->filled('rating')) {
            $query->where('rating', $request->input('rating'));
        }

        $testimonials = $query->latest()->paginate(20)->withQueryString();

        return view('admin.testimonials.index', compact('testimonials'));
    }

    /**
     * Toggle the featured status of a testimonial.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function toggleFeatured($id)
    {
        $testimonial = Testimonial::findOrFail($id);

        DB::transaction(function () use ($testimonial) {
            $testimonial->update([
                'is_featured' => !$testimonial->is_featured,
            ]);
        });

        $statusLabel = $testimonial->is_featured ? 'diunggulkan' : 'dihapus dari unggulan';

        $this->logActivity('testimonial.toggle_featured', "Testimonial #{$id} {$statusLabel}.", [
            'testimonial_id' => $id,
            'is_featured'    => $testimonial->is_featured,
        ]);

        return redirect()->route('admin.testimonials.index')
            ->with('success', "Testimonial berhasil {$statusLabel}.");
    }

    /**
     * Toggle the active status of a testimonial.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function toggleActive($id)
    {
        $testimonial = Testimonial::findOrFail($id);

        DB::transaction(function () use ($testimonial) {
            $testimonial->update([
                'is_active' => !$testimonial->is_active,
            ]);
        });

        $statusLabel = $testimonial->is_active ? 'diaktifkan' : 'dinonaktifkan';

        $this->logActivity('testimonial.toggle_active', "Testimonial #{$id} {$statusLabel}.", [
            'testimonial_id' => $id,
            'is_active'      => $testimonial->is_active,
        ]);

        return redirect()->route('admin.testimonials.index')
            ->with('success', "Testimonial berhasil {$statusLabel}.");
    }

    /**
     * Remove the specified testimonial from storage.
     *
     * Deletes associated image from storage and removes the record.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $testimonial = Testimonial::findOrFail($id);

        DB::transaction(function () use ($testimonial) {
            // Delete testimonial image if exists
            if ($testimonial->image && Storage::disk('public')->exists($testimonial->image)) {
                Storage::disk('public')->delete($testimonial->image);
            }

            $testimonial->delete();
        });

        $this->logActivity('testimonial.deleted', "Testimonial #{$id} dihapus.", [
            'testimonial_id' => $id,
        ]);

        return redirect()->route('admin.testimonials.index')
            ->with('success', 'Testimonial berhasil dihapus.');
    }
}
