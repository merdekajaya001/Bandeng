<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

/**
 * Admin\UserController
 *
 * Manages user accounts: listing with role filters and search,
 * viewing user details with wallet/orders/stats, and toggling
 * the active/inactive status with notification.
 */
class UserController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display a listing of users with role filters and search.
     *
     * Supports filtering by role, active status, and searching
     * by name, email, or phone.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = User::with('wallet');

        // Filter by role
        if ($request->filled('role')) {
            $query->where('role', $request->input('role'));
        }

        // Filter by active status
        if ($request->filled('is_active')) {
            $query->where('is_active', $request->boolean('is_active'));
        }

        // Search by name, email, or phone
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        $users = $query->latest()->paginate(20)->withQueryString();

        // Role options for the filter dropdown
        $roles = [
            'admin'    => 'Administrator',
            'stockist' => 'Stockist',
            'agent'    => 'Agen',
            'customer' => 'Pelanggan',
        ];

        return view('admin.users.index', compact('users', 'roles'));
    }

    /**
     * Display the specified user's details.
     *
     * Includes wallet, stocks, orders (buyer and seller),
     * withdrawals, agent areas, badges, level, and stats.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $user = User::with([
            'wallet',
            'stocks.productVariant.product',
            'buyerOrders.orderItems.productVariant',
            'sellerOrders.orderItems.productVariant',
            'withdrawals',
            'agentAreas',
            'agentBadges',
            'agentLevel',
        ])->findOrFail($id);

        // Get role-specific statistics
        $stats = $this->getUserStats($user);

        // Recent activity logs for this user
        $recentActivities = $user->activityLogs()
            ->recent()
            ->take(10)
            ->get();

        return view('admin.users.show', compact('user', 'stats', 'recentActivities'));
    }

    /**
     * Toggle the active/inactive status of a user.
     *
     * Prevents admin from deactivating themselves.
     * Notifies the user about their status change.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function toggleStatus($id)
    {
        $user = User::findOrFail($id);

        // Prevent admin from deactivating themselves
        if ($user->id === auth()->id()) {
            return redirect()->route('admin.users.show', $user->id)
                ->with('error', 'Anda tidak dapat menonaktifkan akun Anda sendiri.');
        }

        $newStatus = !$user->is_active;
        $statusLabel = $newStatus ? 'diaktifkan' : 'dinonaktifkan';

        DB::transaction(function () use ($user, $newStatus) {
            $user->update([
                'is_active' => $newStatus,
            ]);
        });

        // Notify the user about their status change
        Notification::create([
            'user_id' => $user->id,
            'title'   => $newStatus ? 'Akun Diaktifkan' : 'Akun Dinonaktifkan',
            'message' => $newStatus
                ? 'Akun Anda telah diaktifkan kembali oleh admin.'
                : 'Akun Anda telah dinonaktifkan oleh admin. Silakan hubungi admin untuk informasi lebih lanjut.',
            'type'    => 'account_status_changed',
            'data'    => [
                'is_active' => $newStatus,
            ],
        ]);

        $this->logActivity('user.status_toggled', "User {$user->name} ({$user->role}) {$statusLabel}.", [
            'user_id'   => $user->id,
            'is_active' => $newStatus,
        ]);

        return redirect()->route('admin.users.show', $user->id)
            ->with('success', "Akun {$user->name} berhasil {$statusLabel}.");
    }

    /**
     * Gather role-specific statistics for a user.
     *
     * @param  \App\Models\User  $user
     * @return array
     */
    protected function getUserStats(User $user): array
    {
        $stats = [
            'total_buyer_orders'  => $user->buyerOrders()->count(),
            'total_seller_orders' => $user->sellerOrders()->count(),
            'total_buyer_spent'   => $user->buyerOrders()->where('status', 'completed')->sum('total'),
            'total_seller_revenue' => $user->sellerOrders()->where('status', 'completed')->sum('total'),
        ];

        if ($user->wallet) {
            $stats['wallet_balance']         = $user->wallet->balance;
            $stats['wallet_pending_balance'] = $user->wallet->pending_balance;
        }

        if ($user->isAgent) {
            $stats['total_stock']       = $user->stocks()->where('type', 'agent')->sum('quantity');
            $stats['total_areas']       = $user->agentAreas()->active()->count();
            $stats['total_withdrawals'] = $user->withdrawals()->count();
            $stats['total_withdrawn']   = $user->withdrawals()->where('status', 'approved')->sum('amount');
        }

        if ($user->isStockist) {
            $stats['total_stock']       = $user->stocks()->where('type', 'stockist')->sum('quantity');
            $stats['total_withdrawals'] = $user->withdrawals()->count();
            $stats['total_withdrawn']   = $user->withdrawals()->where('status', 'approved')->sum('amount');
        }

        return $stats;
    }
}
