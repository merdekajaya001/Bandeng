<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Wallet;
use App\Models\Withdrawal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

/**
 * Admin\WithdrawalController
 *
 * Handles withdrawal request management for admin.
 * Admin can approve or reject withdrawal requests from agents and stockists.
 * On approval the pending_balance is debited from the wallet.
 * On rejection the pending_balance is refunded to the available balance.
 */
class WithdrawalController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            Gate::authorize('admin-access');
            return $next($request);
        });
    }

    /**
     * Display a listing of withdrawal requests with filters.
     *
     * Supports filtering by status, user role, and searching by user name.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = Withdrawal::with(['user', 'processedBy']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        } else {
            // Default: show pending first
            $query->orderByRaw("FIELD(status, 'pending', 'approved', 'processed', 'rejected')");
        }

        // Filter by user role
        if ($request->filled('role')) {
            $query->whereHas('user', function ($q) use ($request) {
                $q->where('role', $request->input('role'));
            });
        }

        // Search by user name
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->whereHas('user', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }

        // Filter by date range
        if ($request->filled('from_date')) {
            $query->whereDate('created_at', '>=', $request->input('from_date'));
        }
        if ($request->filled('to_date')) {
            $query->whereDate('created_at', '<=', $request->input('to_date'));
        }

        $withdrawals = $query->latest()->paginate(20)->withQueryString();

        return view('admin.withdrawals.index', compact('withdrawals'));
    }

    /**
     * Approve a withdrawal request.
     *
     * Debits the pending_balance from the user's wallet and marks
     * the withdrawal as approved. The pending_balance was already
     * reserved when the withdrawal was created, so we only need
     * to debit the pending side.
     *
     * @param  int  $id  Withdrawal ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function approve($id)
    {
        $withdrawal = Withdrawal::where('status', 'pending')
            ->with('user.wallet')
            ->findOrFail($id);

        DB::transaction(function () use ($withdrawal) {
            $wallet = $withdrawal->user->wallet;

            if (!$wallet) {
                throw new \Exception('Dompet pengguna tidak ditemukan.');
            }

            // Verify pending balance is sufficient
            if ((float) $wallet->pending_balance < (float) $withdrawal->amount) {
                throw new \Exception('Saldo tertunda pengguna tidak mencukupi untuk penarikan ini.');
            }

            // Debit pending_balance from the wallet
            $wallet->decrement('pending_balance', (float) $withdrawal->amount);
            $wallet->refresh();

            // Create a wallet transaction record for the withdrawal
            $wallet->transactions()->create([
                'type'          => 'withdrawal',
                'amount'        => $withdrawal->amount,
                'balance_after' => $wallet->balance,
                'description'   => "Penarikan disetujui #WDR-{$withdrawal->id}",
                'status'        => 'completed',
            ]);

            // Update the withdrawal status
            $withdrawal->update([
                'status'       => 'approved',
                'processed_at' => now(),
                'processed_by' => auth()->id(),
            ]);
        });

        // Notify the user
        Notification::create([
            'user_id' => $withdrawal->user_id,
            'title'   => 'Penarikan Disetujui',
            'message' => "Penarikan sebesar Rp " . number_format($withdrawal->amount, 0, ',', '.') . " telah disetujui.",
            'type'    => 'withdrawal_approved',
            'data'    => [
                'withdrawal_id' => $withdrawal->id,
                'amount'        => (float) $withdrawal->amount,
            ],
        ]);

        $this->logActivity('withdrawal.approved', "Penarikan #{$withdrawal->id} oleh {$withdrawal->user->name} disetujui sebesar Rp " . number_format($withdrawal->amount, 0, ',', '.'), [
            'withdrawal_id' => $withdrawal->id,
            'user_id'       => $withdrawal->user_id,
            'amount'        => $withdrawal->amount,
        ]);

        return redirect()->route('admin.withdrawals.index')
            ->with('success', "Penarikan #{$withdrawal->id} berhasil disetujui.");
    }

    /**
     * Reject a withdrawal request with a reason.
     *
     * Refunds the pending_balance back to the available balance
     * on the user's wallet and marks the withdrawal as rejected.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id  Withdrawal ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function reject(Request $request, $id)
    {
        $withdrawal = Withdrawal::where('status', 'pending')
            ->with('user.wallet')
            ->findOrFail($id);

        $validated = $request->validate([
            'rejected_reason' => 'required|string|max:500',
            'notes'           => 'nullable|string|max:500',
        ], [
            'rejected_reason.required' => 'Alasan penolakan wajib diisi.',
            'rejected_reason.max'      => 'Alasan penolakan maksimal 500 karakter.',
        ]);

        DB::transaction(function () use ($withdrawal, $validated) {
            $wallet = $withdrawal->user->wallet;

            // Refund pending_balance back to balance
            if ($wallet) {
                $refundAmount = min((float) $wallet->pending_balance, (float) $withdrawal->amount);

                $wallet->decrement('pending_balance', $refundAmount);
                $wallet->increment('balance', $refundAmount);
                $wallet->refresh();

                // Create a wallet transaction record for the refund
                $wallet->transactions()->create([
                    'type'          => 'refund',
                    'amount'        => $refundAmount,
                    'balance_after' => $wallet->balance,
                    'description'   => "Pengembalian penarikan ditolak #WDR-{$withdrawal->id}",
                    'status'        => 'completed',
                ]);
            }

            // Update the withdrawal status
            $withdrawal->update([
                'status'          => 'rejected',
                'rejected_reason' => $validated['rejected_reason'],
                'notes'           => $validated['notes'] ?? null,
                'processed_by'    => auth()->id(),
            ]);
        });

        // Notify the user
        Notification::create([
            'user_id' => $withdrawal->user_id,
            'title'   => 'Penarikan Ditolak',
            'message' => "Penarikan sebesar Rp " . number_format($withdrawal->amount, 0, ',', '.') . " ditolak. Alasan: {$validated['rejected_reason']}",
            'type'    => 'withdrawal_rejected',
            'data'    => [
                'withdrawal_id'    => $withdrawal->id,
                'amount'           => (float) $withdrawal->amount,
                'rejected_reason'  => $validated['rejected_reason'],
            ],
        ]);

        $this->logActivity('withdrawal.rejected', "Penarikan #{$withdrawal->id} oleh {$withdrawal->user->name} ditolak: {$validated['rejected_reason']}.", [
            'withdrawal_id'     => $withdrawal->id,
            'rejected_reason'   => $validated['rejected_reason'],
        ]);

        return redirect()->route('admin.withdrawals.index')
            ->with('success', "Penarikan #{$withdrawal->id} berhasil ditolak.");
    }
}
