<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;
use App\Models\AgentArea;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Agent\AreaController
 *
 * Manages the agent's coverage areas. Allows the agent to define
 * geographic areas (city, province, coverage radius) where they
 * operate and serve customers.
 */
class AreaController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * Applies the 'role:agent' middleware to ensure only
     * agent users can access these routes.
     */
    public function __construct()
    {
        $this->middleware('role:agent');
    }

    /**
     * Display a listing of the agent's coverage areas.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $user = Auth::user();

        $areas = AgentArea::where('user_id', $user->id)
            ->latest()
            ->get();

        return view('agent.areas.index', compact('areas'));
    }

    /**
     * Store a newly created coverage area.
     *
     * Validates the city, province, and coverage radius. Prevents
     * duplicate area entries for the same agent. Wraps the creation
     * in a DB transaction for data integrity.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'city'               => 'required|string|max:100',
            'province'           => 'required|string|max:100',
            'coverage_radius_km' => 'required|numeric|min:0.1|max:100',
            'is_active'          => 'boolean',
        ], [
            'city.required'               => 'Kota wajib diisi.',
            'province.required'           => 'Provinsi wajib diisi.',
            'coverage_radius_km.required' => 'Radius cakupan wajib diisi.',
            'coverage_radius_km.min'      => 'Radius cakupan minimal 0.1 km.',
            'coverage_radius_km.max'      => 'Radius cakupan maksimal 100 km.',
        ]);

        // Check for duplicate area
        $exists = AgentArea::where('user_id', $user->id)
            ->where('city', $validated['city'])
            ->where('province', $validated['province'])
            ->exists();

        if ($exists) {
            return redirect()->route('agent.areas.index')
                ->with('error', "Area {$validated['city']}, {$validated['province']} sudah ditambahkan.");
        }

        DB::transaction(function () use ($validated, $user) {
            AgentArea::create([
                'user_id'            => $user->id,
                'city'               => $validated['city'],
                'province'           => $validated['province'],
                'coverage_radius_km' => $validated['coverage_radius_km'],
                'is_active'          => $validated['is_active'] ?? true,
            ]);
        });

        $this->logActivity('agent.area_added', "Area {$validated['city']}, {$validated['province']} ditambahkan.", [
            'city'     => $validated['city'],
            'province' => $validated['province'],
        ]);

        return redirect()->route('agent.areas.index')
            ->with('success', "Area {$validated['city']}, {$validated['province']} berhasil ditambahkan.");
    }

    /**
     * Update the specified coverage area.
     *
     * Validates the updated fields, prevents duplicate entries
     * (excluding the current record), and wraps the update in
     * a DB transaction for data integrity.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {
        $user = Auth::user();

        $area = AgentArea::where('user_id', $user->id)->findOrFail($id);

        $validated = $request->validate([
            'city'               => 'required|string|max:100',
            'province'           => 'required|string|max:100',
            'coverage_radius_km' => 'required|numeric|min:0.1|max:100',
            'is_active'          => 'boolean',
        ], [
            'city.required'               => 'Kota wajib diisi.',
            'province.required'           => 'Provinsi wajib diisi.',
            'coverage_radius_km.required' => 'Radius cakupan wajib diisi.',
            'coverage_radius_km.min'      => 'Radius cakupan minimal 0.1 km.',
            'coverage_radius_km.max'      => 'Radius cakupan maksimal 100 km.',
        ]);

        // Check for duplicate area (excluding current)
        $exists = AgentArea::where('user_id', $user->id)
            ->where('city', $validated['city'])
            ->where('province', $validated['province'])
            ->where('id', '!=', $id)
            ->exists();

        if ($exists) {
            return redirect()->route('agent.areas.index')
                ->with('error', "Area {$validated['city']}, {$validated['province']} sudah ada.");
        }

        DB::transaction(function () use ($area, $validated) {
            $area->update([
                'city'               => $validated['city'],
                'province'           => $validated['province'],
                'coverage_radius_km' => $validated['coverage_radius_km'],
                'is_active'          => $validated['is_active'] ?? $area->is_active,
            ]);
        });

        $this->logActivity('agent.area_updated', "Area #{$id} ({$validated['city']}, {$validated['province']}) diperbarui.", [
            'area_id'  => $id,
            'city'     => $validated['city'],
            'province' => $validated['province'],
        ]);

        return redirect()->route('agent.areas.index')
            ->with('success', "Area berhasil diperbarui.");
    }

    /**
     * Remove the specified coverage area.
     *
     * Wraps the deletion in a DB transaction for data integrity.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $user = Auth::user();

        $area = AgentArea::where('user_id', $user->id)->findOrFail($id);

        $areaCity = $area->city;
        $areaProvince = $area->province;

        DB::transaction(function () use ($area) {
            $area->delete();
        });

        $this->logActivity('agent.area_removed', "Area {$areaCity}, {$areaProvince} dihapus.", [
            'area_id' => $id,
        ]);

        return redirect()->route('agent.areas.index')
            ->with('success', "Area {$areaCity}, {$areaProvince} berhasil dihapus.");
    }
}
