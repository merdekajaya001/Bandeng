<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;
use App\Models\AgentBadge;
use App\Models\AgentLevel;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Stock;
use App\Models\WalletTransaction;
use Illuminate\Support\Facades\Auth;

/**
 * Agent\DashboardController
 *
 * Displays the agent dashboard with stock summary, incoming customer orders,
 * orders placed to stockist, commission earned, badge, level info,
 * wallet balance, and recent orders.
 */
class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * Applies the 'role:agent' middleware to ensure only
     * agent users can access these routes.
     */
    public function __construct()
    {
        $this->middleware('role:agent');
    }

    /**
     * Display the agent dashboard.
     *
     * Gathers the following statistics:
     * - Total stock quantity owned by the agent
     * - Number of low-stock product variants (available < 5)
     * - Number of stock variants with quantity > 0
     * - Incoming customer orders (pending)
     * - Incoming customer orders (processing: confirmed + processing)
     * - Total completed customer orders
     * - Orders placed to stockist (pending)
     * - Total orders placed to stockist
     * - Commission earned this month
     * - Total commission earned (all time)
     * - Total revenue from completed customer orders
     * - Agent level info (current + next)
     * - Agent badges
     * - Wallet balance and pending balance
     * - Unread notifications count
     * - Average rating from customers
     * - 5 most recent customer orders
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $user = Auth::user();

        // ── Stock Statistics ─────────────────────────────────────────────
        $totalStockQuantity = Stock::where('user_id', $user->id)
            ->where('type', 'agent')
            ->sum('quantity');

        $totalReservedQuantity = Stock::where('user_id', $user->id)
            ->where('type', 'agent')
            ->sum('reserved_quantity');

        $lowStockCount = Stock::where('user_id', $user->id)
            ->where('type', 'agent')
            ->lowStock(5)
            ->count();

        $stockVariantsCount = Stock::where('user_id', $user->id)
            ->where('type', 'agent')
            ->where('quantity', '>', 0)
            ->count();

        $stockItems = Stock::where('user_id', $user->id)
            ->where('type', 'agent')
            ->with(['productVariant.product'])
            ->get();

        // ── Incoming Customer Orders ─────────────────────────────────────
        $pendingOrders = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->where('status', 'pending')
            ->count();

        $processingOrders = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['confirmed', 'processing'])
            ->count();

        $totalCompletedOrders = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->where('status', 'completed')
            ->count();

        // ── Orders to Stockist ───────────────────────────────────────────
        $pendingStockistOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->where('status', 'pending')
            ->count();

        $totalStockistOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->count();

        // ── Commission Earned ────────────────────────────────────────────
        $commissionThisMonth = WalletTransaction::whereHas('wallet', function ($q) use ($user) {
            $q->where('user_id', $user->id);
        })
            ->where('type', 'commission')
            ->where('status', 'completed')
            ->whereYear('created_at', now()->year)
            ->whereMonth('created_at', now()->month)
            ->sum('amount');

        $totalCommission = WalletTransaction::whereHas('wallet', function ($q) use ($user) {
            $q->where('user_id', $user->id);
        })
            ->where('type', 'commission')
            ->where('status', 'completed')
            ->sum('amount');

        // ── Revenue ──────────────────────────────────────────────────────
        $totalRevenue = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->where('status', 'completed')
            ->sum('total');

        $revenueThisMonth = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->where('status', 'completed')
            ->whereYear('created_at', now()->year)
            ->whereMonth('created_at', now()->month)
            ->sum('total');

        // ── Agent Level Info ─────────────────────────────────────────────
        $currentLevel = $user->agentLevel()->first();
        $nextLevel = null;
        if ($currentLevel) {
            $nextLevel = AgentLevel::active()
                ->ordered()
                ->where('min_total_sales', '>', $currentLevel->min_total_sales ?? 0)
                ->first();
        }

        // ── Agent Badges ─────────────────────────────────────────────────
        $badges = $user->agentBadges()->get();

        // ── Recent Customer Orders ───────────────────────────────────────
        $recentOrders = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->with(['buyer', 'orderItems.productVariant'])
            ->recent()
            ->take(5)
            ->get();

        // ── Recent Orders to Stockist ────────────────────────────────────
        $recentStockistOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->with(['seller', 'orderItems.productVariant'])
            ->recent()
            ->take(5)
            ->get();

        // ── Wallet Info ──────────────────────────────────────────────────
        $wallet = $user->wallet;

        // ── Unread Notifications ─────────────────────────────────────────
        $unreadNotifications = Notification::where('user_id', $user->id)
            ->unread()
            ->count();

        // ── Rating Average ───────────────────────────────────────────────
        $avgRating = $user->receivedRatings()->avg('rating');

        // ── Compile Stats ────────────────────────────────────────────────
        $stats = [
            'total_stock_quantity'      => $totalStockQuantity,
            'total_reserved_quantity'   => $totalReservedQuantity,
            'low_stock_count'           => $lowStockCount,
            'stock_variants_count'      => $stockVariantsCount,
            'pending_orders'            => $pendingOrders,
            'processing_orders'         => $processingOrders,
            'total_completed_orders'    => $totalCompletedOrders,
            'pending_stockist_orders'   => $pendingStockistOrders,
            'total_stockist_orders'     => $totalStockistOrders,
            'commission_this_month'     => $commissionThisMonth,
            'total_commission'          => $totalCommission,
            'total_revenue'             => $totalRevenue,
            'revenue_this_month'        => $revenueThisMonth,
            'wallet_balance'            => $wallet ? $wallet->balance : 0,
            'wallet_pending_balance'    => $wallet ? $wallet->pending_balance : 0,
            'unread_notifications'      => $unreadNotifications,
            'avg_rating'                => $avgRating ? round($avgRating, 1) : 0,
        ];

        return view('agent.dashboard', compact(
            'stats',
            'stockItems',
            'recentOrders',
            'recentStockistOrders',
            'currentLevel',
            'nextLevel',
            'badges'
        ));
    }
}
