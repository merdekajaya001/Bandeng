<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Stock;
use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Agent\OrderController
 *
 * Handles customer orders received by the agent. Includes order listing
 * with filters, detail view, status updates with transition validation,
 * delivery confirmation, stock deduction/restoration, commission crediting,
 * and notification dispatch.
 */
class OrderController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * Applies the 'role:agent' middleware to ensure only
     * agent users can access these routes.
     */
    public function __construct()
    {
        $this->middleware('role:agent');
    }

    /**
     * Display a listing of customer orders for this agent.
     *
     * Supports filtering by:
     * - status (pending, confirmed, processing, shipped, delivered, completed, cancelled)
     * - date range (from_date, to_date)
     * - search (order number or customer name)
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        $query = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->with(['buyer', 'orderItems.productVariant']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        // Filter by date range
        if ($request->filled('from_date')) {
            $query->whereDate('created_at', '>=', $request->input('from_date'));
        }
        if ($request->filled('to_date')) {
            $query->whereDate('created_at', '<=', $request->input('to_date'));
        }

        // Search by order number or customer name
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('order_number', 'like', "%{$search}%")
                  ->orWhereHas('buyer', function ($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $orders = $query->recent()->paginate(20)->withQueryString();

        return view('agent.orders.index', compact('orders'));
    }

    /**
     * Display the specified order's details.
     *
     * Loads the order with all related data: buyer,
     * order items with product variants and products, payments,
     * ratings, and complaints.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $user = Auth::user();

        $order = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->with([
                'buyer',
                'orderItems.productVariant.product',
                'payments',
                'ratings',
                'complaints',
            ])
            ->findOrFail($id);

        return view('agent.orders.show', compact('order'));
    }

    /**
     * Update the status of the specified order with transition validation.
     *
     * Validates that the requested status transition is allowed based on
     * the current order status. Handles special cases such as:
     * - Deducting stock when confirming an order
     * - Setting shipped_at and tracking_number when status is 'shipped'
     * - Setting delivered_at when status is 'delivered'
     * - Processing completion (releasing reserved stock, crediting wallet with commission)
     * - Restoring stock on cancellation
     * - Sending notifications on status change
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStatus(Request $request, $id)
    {
        $user = Auth::user();

        $order = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->findOrFail($id);

        $validated = $request->validate([
            'status'              => 'required|in:confirmed,processing,shipped,delivered,completed,cancelled',
            'cancellation_reason' => 'nullable|string|max:500|required_if:status,cancelled',
            'tracking_number'     => 'nullable|string|max:100',
            'notes'               => 'nullable|string|max:500',
        ], [
            'status.required'                 => 'Status wajib dipilih.',
            'cancellation_reason.required_if' => 'Alasan pembatalan wajib diisi.',
        ]);

        $oldStatus = $order->getOriginal('status');

        // Validate the status transition is allowed
        $this->validateStatusTransition($oldStatus, $validated['status']);

        DB::transaction(function () use ($order, $validated, $user) {
            $updateData = [
                'status' => $validated['status'],
            ];

            switch ($validated['status']) {
                case 'confirmed':
                    // Deduct stock when confirming
                    $this->deductStock($order, $user);
                    break;

                case 'processing':
                    // No special stock operations for processing
                    break;

                case 'shipped':
                    $updateData['shipped_at'] = now();
                    if (!empty($validated['tracking_number'])) {
                        $updateData['tracking_number'] = $validated['tracking_number'];
                    }
                    break;

                case 'delivered':
                    $updateData['delivered_at'] = now();
                    break;

                case 'completed':
                    // Release reserved stock and credit agent wallet with commission
                    $this->processCompletion($order, $user);
                    break;

                case 'cancelled':
                    $updateData['cancelled_at'] = now();
                    $updateData['cancellation_reason'] = $validated['cancellation_reason'] ?? null;
                    // Restore stock if it was already confirmed
                    if (in_array($order->getOriginal('status'), ['confirmed', 'processing', 'shipped'])) {
                        $this->restoreStock($order, $user);
                    }
                    break;
            }

            if (!empty($validated['notes'])) {
                $updateData['notes'] = $validated['notes'];
            }

            $order->update($updateData);
        });

        // Notify the customer about the status change
        $this->notifyCustomer($order, $validated['status'], $user);

        $this->logActivity('agent.order_status_updated', "Status pesanan #{$order->order_number} diubah dari {$oldStatus} ke {$validated['status']}.", [
            'order_id'    => $order->id,
            'old_status'  => $oldStatus,
            'new_status'  => $validated['status'],
        ]);

        return redirect()->route('agent.orders.show', $order->id)
            ->with('success', "Status pesanan #{$order->order_number} berhasil diperbarui ke {$validated['status']}.");
    }

    /**
     * Mark the specified order as delivered.
     *
     * Convenience method for agents to quickly mark a shipped or
     * processing order as delivered without the full status update form.
     *
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function deliverOrder($id)
    {
        $user = Auth::user();

        $order = Order::where('seller_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['shipped', 'processing'])
            ->findOrFail($id);

        $oldStatus = $order->status;

        DB::transaction(function () use ($order) {
            $order->update([
                'status'       => 'delivered',
                'delivered_at' => now(),
            ]);
        });

        // Notify the customer
        $this->notifyCustomer($order, 'delivered', $user);

        $this->logActivity('agent.order_delivered', "Pesanan #{$order->order_number} ditandai sebagai diterima (dari status {$oldStatus}).", [
            'order_id'   => $order->id,
            'old_status' => $oldStatus,
        ]);

        return redirect()->route('agent.orders.show', $order->id)
            ->with('success', "Pesanan #{$order->order_number} ditandai sebagai diterima.");
    }

    // =========================================================================
    // Protected Helper Methods
    // =========================================================================

    /**
     * Validate that the status transition is allowed.
     *
     * Allowed transitions:
     * - pending    → confirmed, cancelled
     * - confirmed  → processing, shipped, cancelled
     * - processing → shipped, cancelled
     * - shipped    → delivered
     * - delivered  → completed
     * - completed  → (terminal)
     * - cancelled  → (terminal)
     *
     * @param  string  $from  Current status
     * @param  string  $to    Desired status
     * @return void
     * @throws \Exception
     */
    protected function validateStatusTransition(string $from, string $to): void
    {
        $allowedTransitions = [
            'pending'    => ['confirmed', 'cancelled'],
            'confirmed'  => ['processing', 'shipped', 'cancelled'],
            'processing' => ['shipped', 'cancelled'],
            'shipped'    => ['delivered'],
            'delivered'  => ['completed'],
            'completed'  => [],
            'cancelled'  => [],
        ];

        $allowed = $allowedTransitions[$from] ?? [];

        if (!in_array($to, $allowed)) {
            throw new \Exception("Transisi status dari '{$from}' ke '{$to}' tidak diizinkan.");
        }
    }

    /**
     * Deduct stock from the agent's inventory when confirming an order.
     *
     * For each order item, verifies that the agent has sufficient
     * available stock, then decrements the quantity and increments
     * the reserved_quantity to track the committed stock.
     *
     * @param  \App\Models\Order  $order
     * @param  \App\Models\User   $user  The agent
     * @return void
     * @throws \Exception
     */
    protected function deductStock(Order $order, $user): void
    {
        // Load order items if not already loaded
        if (!$order->relationLoaded('orderItems')) {
            $order->load('orderItems.productVariant');
        }

        foreach ($order->orderItems as $item) {
            $stock = Stock::where('user_id', $user->id)
                ->where('product_variant_id', $item->product_variant_id)
                ->where('type', 'agent')
                ->first();

            if (!$stock || $stock->available_quantity < $item->quantity) {
                $variantName = $item->productVariant->name ?? 'Unknown';
                $available = $stock ? $stock->available_quantity : 0;
                throw new \Exception(
                    "Stok tidak mencukupi untuk varian {$variantName}. Tersedia: {$available}, Diminta: {$item->quantity}."
                );
            }

            $stock->decrement('quantity', $item->quantity);
            $stock->increment('reserved_quantity', $item->quantity);
        }
    }

    /**
     * Process order completion: release reserved stock and credit agent wallet.
     *
     * For customer→agent orders:
     * - Releases the agent's reserved stock
     * - Credits the agent's wallet with the order total as commission/revenue
     *
     * @param  \App\Models\Order  $order
     * @param  \App\Models\User   $user  The agent
     * @return void
     */
    protected function processCompletion(Order $order, $user): void
    {
        // Load order items if not already loaded
        if (!$order->relationLoaded('orderItems')) {
            $order->load('orderItems');
        }

        foreach ($order->orderItems as $item) {
            // Release agent's reserved stock
            $stock = Stock::where('user_id', $user->id)
                ->where('product_variant_id', $item->product_variant_id)
                ->where('type', 'agent')
                ->first();

            if ($stock) {
                $stock->decrement('reserved_quantity', min($item->quantity, $stock->reserved_quantity));
            }
        }

        // Credit the agent's wallet with the order total
        $wallet = $user->wallet;
        if ($wallet) {
            $wallet->deposit(
                (float) $order->total,
                "Pembayaran pesanan #{$order->order_number} dari pelanggan"
            );
        }

        // Also credit commission if agent has a level with commission percentage
        $currentLevel = $user->agentLevel()->first();
        if ($currentLevel && $currentLevel->commission_percent > 0) {
            $commissionAmount = (float) $order->total * ((float) $currentLevel->commission_percent / 100);
            if ($commissionAmount > 0 && $wallet) {
                $wallet->deposit(
                    $commissionAmount,
                    "Komisi pesanan #{$order->order_number} ({$currentLevel->commission_percent}%)"
                );
            }
        }
    }

    /**
     * Restore stock to the agent's inventory when cancelling an order.
     *
     * For each order item that was previously deducted, decrements
     * the reserved_quantity and increments the quantity back.
     *
     * @param  \App\Models\Order  $order
     * @param  \App\Models\User   $user  The agent
     * @return void
     */
    protected function restoreStock(Order $order, $user): void
    {
        // Load order items if not already loaded
        if (!$order->relationLoaded('orderItems')) {
            $order->load('orderItems');
        }

        foreach ($order->orderItems as $item) {
            $stock = Stock::where('user_id', $user->id)
                ->where('product_variant_id', $item->product_variant_id)
                ->where('type', 'agent')
                ->first();

            if ($stock) {
                $stock->decrement('reserved_quantity', min($item->quantity, $stock->reserved_quantity));
                $stock->increment('quantity', $item->quantity);
            }
        }
    }

    /**
     * Send a notification to the customer about a status change.
     *
     * @param  \App\Models\Order  $order
     * @param  string             $newStatus
     * @param  \App\Models\User   $agent
     * @return void
     */
    protected function notifyCustomer(Order $order, string $newStatus, $agent): void
    {
        $statusLabels = [
            'pending'    => 'Menunggu',
            'confirmed'  => 'Dikonfirmasi',
            'processing' => 'Diproses',
            'shipped'    => 'Dikirim',
            'delivered'  => 'Diterima',
            'completed'  => 'Selesai',
            'cancelled'  => 'Dibatalkan',
        ];

        $label = $statusLabels[$newStatus] ?? ucfirst($newStatus);

        Notification::create([
            'user_id' => $order->buyer_id,
            'title'   => 'Status Pesanan Diperbarui',
            'message' => "Pesanan #{$order->order_number} statusnya diubah menjadi: {$label} oleh agen {$agent->name}.",
            'type'    => 'order_status_updated',
            'data'    => [
                'order_id' => $order->id,
                'status'   => $newStatus,
            ],
        ]);
    }
}
