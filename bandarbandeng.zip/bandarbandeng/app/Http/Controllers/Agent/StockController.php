<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\ProductVariant;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Agent\StockController
 *
 * Manages the agent's own stock inventory, allows ordering from stockist,
 * and provides stock quantity adjustments.
 */
class StockController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * Applies the 'role:agent' middleware to ensure only
     * agent users can access these routes.
     */
    public function __construct()
    {
        $this->middleware('role:agent');
    }

    /**
     * Display the agent's stock inventory.
     *
     * Lists all stock entries owned by the authenticated agent,
     * grouped by product variant with available quantities.
     * Supports filtering by product, low-stock status, and search.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        $query = Stock::where('user_id', $user->id)
            ->where('type', 'agent')
            ->with(['productVariant.product']);

        // Filter by product
        if ($request->filled('product_id')) {
            $query->whereHas('productVariant', function ($q) use ($request) {
                $q->where('product_id', $request->input('product_id'));
            });
        }

        // Filter by low stock (available quantity below threshold)
        if ($request->boolean('low_stock')) {
            $query->lowStock(5);
        }

        // Search by variant name
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->whereHas('productVariant', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }

        $stocks = $query->paginate(20)->withQueryString();

        // Load all active products for the filter dropdown
        $products = \App\Models\Product::active()->ordered()->get();

        return view('agent.stocks.index', compact('stocks', 'products'));
    }

    /**
     * Show the order form for ordering stock from a stockist.
     *
     * Displays all available stockist stock that the agent can order from,
     * grouped by stockist name for easy browsing.
     *
     * @return \Illuminate\View\View
     */
    public function orderFromStockist()
    {
        // Get all active stockists' stock with available quantity
        $stockistStocks = Stock::byType('stockist')
            ->available()
            ->with(['productVariant.product', 'user'])
            ->whereHas('user', function ($q) {
                $q->where('is_active', true);
            })
            ->get();

        // Group by stockist for display
        $stockistGroups = $stockistStocks->groupBy('user.name');

        return view('agent.stocks.order', compact('stockistStocks', 'stockistGroups'));
    }

    /**
     * Place an order to a stockist for stock replenishment.
     *
     * Validates the requested items, checks that the stockist has sufficient
     * stock for each variant, reserves the stockist stock, creates the order
     * with type 'agent_to_stockist', records all order items, and notifies
     * the stockist about the new order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function placeOrder(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'stockist_id'                => 'required|integer|exists:users,id',
            'items'                      => 'required|array|min:1',
            'items.*.product_variant_id'  => 'required|integer|exists:product_variants,id',
            'items.*.quantity'            => 'required|integer|min:1',
            'notes'                      => 'nullable|string|max:500',
        ], [
            'stockist_id.required'                 => 'Stockist wajib dipilih.',
            'stockist_id.exists'                   => 'Stockist tidak valid.',
            'items.required'                       => 'Minimal satu item harus dipilih.',
            'items.min'                            => 'Minimal satu item harus dipilih.',
            'items.*.product_variant_id.required'  => 'Varian produk wajib dipilih.',
            'items.*.product_variant_id.exists'    => 'Varian produk tidak valid.',
            'items.*.quantity.required'            => 'Jumlah wajib diisi.',
            'items.*.quantity.min'                 => 'Jumlah minimal 1.',
        ]);

        // Verify the stockist is valid
        $stockist = User::where('id', $validated['stockist_id'])
            ->where('role', 'stockist')
            ->where('is_active', true)
            ->firstOrFail();

        $order = null;

        DB::transaction(function () use ($validated, $user, $stockist, &$order) {
            $orderItems = [];
            $subtotal = 0;

            foreach ($validated['items'] as $item) {
                // Check stockist stock availability
                $stockistStock = Stock::where('user_id', $stockist->id)
                    ->where('product_variant_id', $item['product_variant_id'])
                    ->where('type', 'stockist')
                    ->first();

                if (!$stockistStock || $stockistStock->available_quantity < $item['quantity']) {
                    $variant = ProductVariant::find($item['product_variant_id']);
                    $variantName = $variant ? $variant->name : 'Unknown';
                    $available = $stockistStock ? $stockistStock->available_quantity : 0;
                    throw new \Exception(
                        "Stok stockist tidak mencukupi untuk varian {$variantName}. Tersedia: {$available}, Diminta: {$item['quantity']}."
                    );
                }

                // Reserve stockist stock
                $stockistStock->increment('reserved_quantity', $item['quantity']);

                // Calculate item price
                $variant = ProductVariant::findOrFail($item['product_variant_id']);
                $itemSubtotal = $variant->price * $item['quantity'];
                $subtotal += $itemSubtotal;

                $orderItems[] = new OrderItem([
                    'product_variant_id' => $item['product_variant_id'],
                    'quantity'           => $item['quantity'],
                    'price_per_unit'     => $variant->price,
                    'subtotal'           => $itemSubtotal,
                ]);
            }

            // Create the order
            $order = Order::create([
                'user_id'       => $user->id,
                'seller_id'     => $stockist->id,
                'order_type'    => 'agent_to_stockist',
                'status'        => 'pending',
                'subtotal'      => $subtotal,
                'shipping_cost' => 0,
                'total'         => $subtotal,
                'notes'         => $validated['notes'] ?? null,
            ]);

            // Save order items
            $order->orderItems()->saveMany($orderItems);
        });

        // Notify the stockist about the new order
        Notification::create([
            'user_id' => $stockist->id,
            'title'   => 'Pesanan Baru dari Agen',
            'message' => "Agen {$user->name} membuat pesanan baru #{$order->order_number}.",
            'type'    => 'agent_order_placed',
            'data'    => [
                'order_id'  => $order->id,
                'agent_id'  => $user->id,
            ],
        ]);

        $this->logActivity('agent.order_placed', "Agen {$user->name} melakukan pemesanan ke stockist {$stockist->name}. Pesanan #{$order->order_number}.", [
            'user_id'     => $user->id,
            'stockist_id' => $stockist->id,
            'order_id'    => $order->id,
        ]);

        return redirect()->route('agent.stocks.index')
            ->with('success', 'Pesanan ke stockist berhasil dibuat. Menunggu konfirmasi.');
    }

    /**
     * Adjust (update) the agent's stock quantity for a specific stock entry.
     *
     * Allows the agent to manually increase or decrease their stock quantity.
     * The new quantity must be >= the currently reserved quantity.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id  The stock entry ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStock(Request $request, $id)
    {
        $user = Auth::user();

        // Ensure the stock belongs to this agent
        $stock = Stock::where('id', $id)
            ->where('user_id', $user->id)
            ->where('type', 'agent')
            ->firstOrFail();

        $validated = $request->validate([
            'quantity'           => 'required|integer|min:0',
            'adjustment_reason'  => 'nullable|string|max:500',
        ], [
            'quantity.required'  => 'Jumlah stok wajib diisi.',
            'quantity.min'       => 'Jumlah stok tidak boleh negatif.',
            'quantity.integer'   => 'Jumlah stok harus berupa angka bulat.',
        ]);

        // Cannot set quantity below reserved_quantity
        if ($validated['quantity'] < $stock->reserved_quantity) {
            return redirect()->back()
                ->withInput()
                ->withErrors([
                    'quantity' => "Jumlah tidak boleh kurang dari stok yang terpesan ({$stock->reserved_quantity}).",
                ]);
        }

        $oldQuantity = $stock->quantity;
        $newQuantity = $validated['quantity'];
        $difference  = $newQuantity - $oldQuantity;

        DB::transaction(function () use ($stock, $newQuantity) {
            $stock->update(['quantity' => $newQuantity]);
        });

        $actionType = $difference > 0 ? 'penambahan' : ($difference < 0 ? 'pengurangan' : 'perubahan');
        $absDifference = abs($difference);

        $this->logActivity('agent.stock_updated', "Agen {$user->name} melakukan {$actionType} stok varian {$stock->productVariant->name}: {$oldQuantity} → {$newQuantity} (selisih: {$absDifference}).", [
            'stock_id'     => $stock->id,
            'variant_id'   => $stock->product_variant_id,
            'old_quantity' => $oldQuantity,
            'new_quantity' => $newQuantity,
            'difference'   => $difference,
            'reason'       => $validated['adjustment_reason'] ?? null,
        ]);

        $message = $difference > 0
            ? "Stok {$stock->productVariant->name} berhasil ditambah sebanyak {$absDifference}."
            : ($difference < 0
                ? "Stok {$stock->productVariant->name} berhasil dikurangi sebanyak {$absDifference}."
                : "Stok {$stock->productVariant->name} tidak berubah.");

        return redirect()->route('agent.stocks.index')
            ->with('success', $message);
    }
}
