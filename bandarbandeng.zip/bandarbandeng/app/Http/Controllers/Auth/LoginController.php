<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;

/**
 * Auth\LoginController
 *
 * Handles user authentication with a unified login page that supports
 * role-based tabs (admin, stockist, agent, customer). Redirects each
 * role to its respective dashboard path after successful authentication.
 */
class LoginController extends Controller
{
    /**
     * Role-to-dashboard path mapping.
     *
     * @var array<string, string>
     */
    protected array $dashboardRoutes = [
        'admin'     => '/admin',
        'stockist'  => '/stockist',
        'agent'     => '/agent',
        'customer'  => '/customer',
    ];

    /**
     * Show the unified login form with role tabs.
     *
     * Determines the active tab from the query string (default: customer).
     * Only valid roles are accepted; invalid values fall back to 'customer'.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function showLoginForm(Request $request)
    {
        $activeRole = $request->query('role', 'customer');

        if (!in_array($activeRole, ['admin', 'stockist', 'agent', 'customer'], true)) {
            $activeRole = 'customer';
        }

        return view('auth.login', compact('activeRole'));
    }

    /**
     * Handle a login request to the application.
     *
     * Validates email, password, and role. Authenticates the user,
     * checks role match and account status, then redirects to the
     * appropriate dashboard based on role.
     *
     * Throttle: 5 attempts per minute per email+IP combination.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function login(Request $request)
    {
        // Step 1: Validate the incoming request
        $request->validate([
            'email'    => 'required|email|max:255',
            'password' => 'required|string|min:6',
            'role'     => 'required|in:admin,stockist,agent,customer',
        ], [
            'email.required'    => 'Email wajib diisi.',
            'email.email'       => 'Format email tidak valid.',
            'email.max'         => 'Email maksimal 255 karakter.',
            'password.required' => 'Password wajib diisi.',
            'password.min'      => 'Password minimal 6 karakter.',
            'role.required'     => 'Role wajib dipilih.',
            'role.in'           => 'Role tidak valid.',
        ]);

        // Step 2: Throttle login attempts (5 per 60 seconds)
        $throttleKey = strtolower($request->input('email')) . '|' . $request->ip();

        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            $seconds = RateLimiter::availableIn($throttleKey);

            throw ValidationException::withMessages([
                'email' => ["Terlalu banyak percobaan login. Silakan coba lagi dalam {$seconds} detik."],
            ]);
        }

        // Step 3: Attempt authentication with credentials
        $credentials = [
            'email'    => $request->input('email'),
            'password' => $request->input('password'),
        ];

        if (!Auth::attempt($credentials, $request->boolean('remember'))) {
            RateLimiter::hit($throttleKey, 60);

            throw ValidationException::withMessages([
                'email' => ['Email atau password yang Anda masukkan salah.'],
            ]);
        }

        // Step 4: Clear throttle on successful authentication
        RateLimiter::clear($throttleKey);

        // Step 5: Regenerate session for security (prevents session fixation)
        $request->session()->regenerate();

        // Step 6: Verify the user's role matches the selected role tab
        $user = Auth::user();

        if ($user->role !== $request->input('role')) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            throw ValidationException::withMessages([
                'role' => ['Akun Anda tidak terdaftar sebagai ' . $this->getRoleLabel($request->input('role')) . '.'],
            ]);
        }

        // Step 7: Check if the account is active
        if (!$user->is_active) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            throw ValidationException::withMessages([
                'email' => ['Akun Anda telah dinonaktifkan. Silakan hubungi administrator.'],
            ]);
        }

        // Step 8: Update last login timestamp
        $user->update(['last_login_at' => now()]);

        // Step 9: Log the successful login activity
        $this->logActivity('login', "User {$user->name} ({$user->role}) logged in.", [
            'user_id' => $user->id,
            'role'    => $user->role,
            'ip'      => $request->ip(),
        ]);

        // Step 10: Redirect to the appropriate dashboard based on role
        $dashboardPath = $this->dashboardRoutes[$user->role] ?? '/';

        return redirect()->intended($dashboardPath)
            ->with('success', 'Selamat datang, ' . $user->name . '!');
    }

    /**
     * Log the user out of the application.
     *
     * Invalidates the session and regenerates the CSRF token,
     * then redirects to the home page.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function logout(Request $request)
    {
        $user = Auth::user();

        // Log the logout activity before the session is destroyed
        if ($user) {
            $this->logActivity('logout', "User {$user->name} ({$user->role}) logged out.", [
                'user_id' => $user->id,
                'role'    => $user->role,
            ]);
        }

        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/')
            ->with('success', 'Anda telah berhasil logout.');
    }

    /**
     * Get the human-readable label for a role.
     *
     * @param  string  $role
     * @return string
     */
    protected function getRoleLabel(string $role): string
    {
        return match ($role) {
            'admin'     => 'Administrator',
            'stockist'  => 'Stockist',
            'agent'     => 'Agen',
            'customer'  => 'Pelanggan',
            default     => ucfirst($role),
        };
    }
}
