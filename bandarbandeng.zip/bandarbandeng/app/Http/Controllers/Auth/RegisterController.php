<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\AgentLevel;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

/**
 * Auth\RegisterController
 *
 * Handles user registration. Customers register by default.
 * Agents can register with an invitation/referral code.
 * Stockist and admin accounts are created by admin only —
 * self-registration is not allowed for those roles.
 */
class RegisterController extends Controller
{
    /**
     * Show the registration form.
     *
     * For customers, show the standard registration form.
     * For agents, an invitation code field is also displayed.
     * Only 'customer' and 'agent' roles are allowed for self-registration.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function showRegistrationForm(Request $request)
    {
        $role = $request->query('role', 'customer');

        if (!in_array($role, ['customer', 'agent'], true)) {
            $role = 'customer';
        }

        $invitationCode = $request->query('code');

        return view('auth.register', compact('role', 'invitationCode'));
    }

    /**
     * Handle a registration request for the application.
     *
     * Creates the user with the specified role (customer or agent),
     * creates a wallet, assigns default agent level if applicable,
     * auto-logs them in, and redirects to their dashboard.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function register(Request $request)
    {
        // Step 1: Determine the role (only customer and agent can self-register)
        $role = $request->input('role', 'customer');

        if (!in_array($role, ['customer', 'agent'], true)) {
            return redirect()->route('register')
                ->with('error', 'Role tidak valid untuk pendaftaran mandiri.')
                ->withInput();
        }

        // Step 2: Validate the request
        $rules = [
            'name'                  => 'required|string|max:255',
            'email'                 => 'required|email|max:255|unique:users,email',
            'password'              => ['required', 'confirmed', Password::min(8)->mixedCase()->numbers()],
            'phone'                 => 'required|string|max:20',
            'address'               => 'nullable|string|max:500',
            'city'                  => 'nullable|string|max:100',
            'province'              => 'nullable|string|max:100',
            'postal_code'           => 'nullable|string|max:10',
            'role'                  => 'required|in:customer,agent',
        ];

        // Agent-specific validation: invitation/referral code is required
        if ($role === 'agent') {
            $rules['invitation_code'] = 'required|string|max:50';
            $rules['latitude']        = 'nullable|numeric|between:-90,90';
            $rules['longitude']       = 'nullable|numeric|between:-180,180';
        }

        $messages = [
            'name.required'             => 'Nama wajib diisi.',
            'name.max'                  => 'Nama maksimal 255 karakter.',
            'email.required'            => 'Email wajib diisi.',
            'email.email'               => 'Format email tidak valid.',
            'email.unique'              => 'Email sudah terdaftar.',
            'password.required'         => 'Password wajib diisi.',
            'password.confirmed'        => 'Konfirmasi password tidak cocok.',
            'phone.required'            => 'Nomor telepon wajib diisi.',
            'phone.max'                 => 'Nomor telepon maksimal 20 karakter.',
            'address.max'               => 'Alamat maksimal 500 karakter.',
            'city.max'                  => 'Kota maksimal 100 karakter.',
            'province.max'              => 'Provinsi maksimal 100 karakter.',
            'postal_code.max'           => 'Kode pos maksimal 10 karakter.',
            'role.required'             => 'Role wajib dipilih.',
            'role.in'                   => 'Role tidak valid.',
            'invitation_code.required'  => 'Kode undangan wajib diisi untuk pendaftaran agen.',
            'latitude.numeric'          => 'Latitude harus berupa angka.',
            'latitude.between'          => 'Latitude harus antara -90 dan 90.',
            'longitude.numeric'         => 'Longitude harus berupa angka.',
            'longitude.between'         => 'Longitude harus antara -180 dan 180.',
        ];

        $validated = $request->validate($rules, $messages);

        // Step 3: For agents, verify the invitation/referral code
        if ($role === 'agent') {
            $validCode = config('app.agent_invitation_code', 'AGENT2024');

            if ($validated['invitation_code'] !== $validCode) {
                return redirect()->back()
                    ->with('error', 'Kode undangan tidak valid. Silakan hubungi administrator untuk mendapatkan kode yang benar.')
                    ->withInput();
            }
        }

        // Step 4: Create the user within a database transaction
        $user = DB::transaction(function () use ($validated, $role) {
            // Create the user account
            $user = User::create([
                'name'        => $validated['name'],
                'email'       => $validated['email'],
                'password'    => Hash::make($validated['password']),
                'role'        => $role,
                'phone'       => $validated['phone'],
                'address'     => $validated['address'] ?? null,
                'city'        => $validated['city'] ?? null,
                'province'    => $validated['province'] ?? null,
                'postal_code' => $validated['postal_code'] ?? null,
                'latitude'    => $validated['latitude'] ?? null,
                'longitude'   => $validated['longitude'] ?? null,
                'is_active'   => true,
            ]);

            // Create a wallet for the user
            $user->createWallet();

            // If the user is an agent, assign the default agent level
            if ($role === 'agent') {
                $defaultLevel = AgentLevel::active()
                    ->ordered()
                    ->first();

                if ($defaultLevel) {
                    $user->agentLevel()->attach($defaultLevel->id, [
                        'current_monthly_sales' => 0,
                        'assigned_at'           => now(),
                    ]);
                }
            }

            return $user;
        });

        // Step 5: Log the registration activity
        $this->logActivity('register', "New {$role} registered: {$user->name} ({$user->email})", [
            'user_id' => $user->id,
            'role'    => $role,
            'email'   => $user->email,
        ]);

        // Step 6: Auto-login the newly registered user
        Auth::login($user);

        // Step 7: Regenerate the session for security
        $request->session()->regenerate();

        // Step 8: Redirect to the appropriate dashboard
        $dashboardPaths = [
            'customer' => '/customer',
            'agent'    => '/agent',
        ];

        $dashboardPath = $dashboardPaths[$role] ?? '/';

        return redirect($dashboardPath)
            ->with('success', 'Pendaftaran berhasil! Selamat datang, ' . $user->name . '.');
    }
}
