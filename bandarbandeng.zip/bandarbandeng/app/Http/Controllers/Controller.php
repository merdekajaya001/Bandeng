<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\JsonResponse;
use Illuminate\Routing\Controller as BaseController;

/**
 * Base Controller
 *
 * Provides shared helper methods for JSON responses and activity logging
 * that all other controllers in the Bandar Bandeng Kalimantan application
 * can use.
 */
class Controller extends BaseController
{
    use AuthorizesRequests;
    use ValidatesRequests;

    // =========================================================================
    // JSON Response Helpers
    // =========================================================================

    /**
     * Return a generic JSON response.
     *
     * @param  mixed   $data     Data payload to return
     * @param  string  $message  Human-readable message
     * @param  int     $status   HTTP status code
     * @return \Illuminate\Http\JsonResponse
     */
    protected function jsonResponse(mixed $data = null, string $message = '', int $status = 200): JsonResponse
    {
        $response = [
            'success' => $status >= 200 && $status < 300,
            'message' => $message,
        ];

        if ($data !== null) {
            $response['data'] = $data;
        }

        return response()->json($response, $status);
    }

    /**
     * Return a success JSON response.
     *
     * @param  string  $message  Success message
     * @param  mixed   $data     Optional data payload
     * @param  int     $status   HTTP status code (default: 200)
     * @return \Illuminate\Http\JsonResponse
     */
    protected function successResponse(string $message = 'Berhasil', mixed $data = null, int $status = 200): JsonResponse
    {
        return $this->jsonResponse($data, $message, $status);
    }

    /**
     * Return an error JSON response.
     *
     * @param  string  $message  Error message
     * @param  int     $status   HTTP status code (default: 400)
     * @return \Illuminate\Http\JsonResponse
     */
    protected function errorResponse(string $message = 'Terjadi kesalahan', int $status = 400): JsonResponse
    {
        return response()->json([
            'success' => false,
            'message' => $message,
        ], $status);
    }

    // =========================================================================
    // Activity Logging
    // =========================================================================

    /**
     * Log an activity for the currently authenticated user.
     *
     * @param  string      $action       A short action identifier (e.g., 'login', 'order.created')
     * @param  string|null $description  A human-readable description of the activity
     * @param  array|null  $properties   Additional contextual data to store as JSON
     * @return \App\Models\ActivityLog
     */
    protected function logActivity(string $action, ?string $description = null, ?array $properties = null): ActivityLog
    {
        return ActivityLog::create([
            'user_id'     => auth()->id(),
            'action'      => $action,
            'description' => $description,
            'properties'  => $properties,
            'ip_address'  => request()->ip(),
            'user_agent'  => request()->userAgent(),
        ]);
    }
}
