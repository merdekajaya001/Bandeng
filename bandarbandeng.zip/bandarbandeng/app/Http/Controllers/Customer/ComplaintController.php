<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/**
 * Customer\ComplaintController
 *
 * Handles customer complaint submission for orders.
 */
class ComplaintController extends Controller
{
    /**
     * Show the complaint form for the specified order.
     *
     * @param  int  $orderId
     * @return \Illuminate\View\View
     */
    public function create($orderId)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['delivered', 'completed'])
            ->with(['seller', 'orderItems.productVariant.product'])
            ->findOrFail($orderId);

        return view('customer.complaints.create', compact('order'));
    }

    /**
     * Submit a complaint for the specified order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $orderId
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request, $orderId)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['delivered', 'completed'])
            ->findOrFail($orderId);

        $validated = $request->validate([
            'type'        => 'required|in:product_damage,wrong_item,late_delivery,other',
            'description' => 'required|string|max:2000',
            'images'      => 'nullable|array|max:5',
            'images.*'    => 'image|max:2048',
        ], [
            'type.required'        => 'Jenis keluhan wajib dipilih.',
            'type.in'              => 'Jenis keluhan tidak valid.',
            'description.required' => 'Deskripsi keluhan wajib diisi.',
            'description.max'      => 'Deskripsi maksimal 2000 karakter.',
            'images.max'           => 'Maksimal 5 gambar dapat diunggah.',
            'images.*.image'       => 'File harus berupa gambar.',
            'images.*.max'         => 'Ukuran gambar maksimal 2MB.',
        ]);

        DB::transaction(function () use ($validated, $request, $order, $user) {
            // Handle image uploads
            $imagePaths = [];
            if ($request->hasFile('images')) {
                foreach ($request->file('images') as $image) {
                    $imagePaths[] = $image->store('complaints', 'public');
                }
            }

            // Create the complaint
            Complaint::create([
                'order_id'    => $order->id,
                'user_id'     => $user->id,
                'type'        => $validated['type'],
                'description' => $validated['description'],
                'images'      => !empty($imagePaths) ? $imagePaths : null,
                'status'      => 'open',
            ]);
        });

        $this->logActivity('customer.complaint_submitted', "Keluhan diajukan untuk pesanan #{$order->order_number}.", [
            'order_id'        => $order->id,
            'complaint_type'  => $validated['type'],
        ]);

        return redirect()->route('customer.orders.show', $order->id)
            ->with('success', 'Keluhan berhasil diajukan. Tim kami akan segera menindaklanjuti.');
    }
}
