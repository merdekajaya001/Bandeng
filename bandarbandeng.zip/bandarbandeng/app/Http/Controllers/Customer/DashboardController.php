<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

/**
 * Customer\DashboardController
 *
 * Displays the customer dashboard with recent orders and nearest agents.
 */
class DashboardController extends Controller
{
    /**
     * Display the customer dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $user = Auth::user();

        // Recent orders
        $recentOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->with(['seller', 'orderItems.productVariant.product'])
            ->recent()
            ->take(5)
            ->get();

        // Order stats
        $totalOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->count();

        $pendingOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->where('status', 'pending')
            ->count();

        $activeOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['confirmed', 'processing', 'shipped'])
            ->count();

        // Nearest agents
        $nearestAgents = collect();
        if ($user->latitude && $user->longitude) {
            $nearestAgents = User::getNearestAgents(
                (float) $user->latitude,
                (float) $user->longitude,
                5
            );
        }

        // Wallet info
        $wallet = $user->wallet;

        $stats = [
            'total_orders'   => $totalOrders,
            'pending_orders' => $pendingOrders,
            'active_orders'  => $activeOrders,
            'wallet_balance' => $wallet ? $wallet->balance : 0,
        ];

        return view('customer.dashboard', compact('stats', 'recentOrders', 'nearestAgents'));
    }
}
