<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Customer\OrderController
 *
 * Handles customer order creation, viewing, and cancellation.
 * Orders are placed to the nearest available agent.
 */
class OrderController extends Controller
{
    /**
     * Display a listing of the customer's orders.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        $query = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->with(['seller', 'orderItems.productVariant']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        $orders = $query->recent()->paginate(15)->withQueryString();

        return view('customer.orders.index', compact('orders'));
    }

    /**
     * Show the order creation form.
     *
     * Auto-finds the nearest agent based on the customer's location.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function create(Request $request)
    {
        $user = Auth::user();

        // Find the nearest agent
        $nearestAgent = null;
        if ($user->latitude && $user->longitude) {
            $nearestAgent = User::nearbyAgents(
                (float) $user->latitude,
                (float) $user->longitude,
                50
            )->first();
        }

        // If no agent found by location, try to find any active agent
        if (!$nearestAgent) {
            $nearestAgent = User::agents()->active()->first();
        }

        // Get the agent's available stock
        $agentStocks = collect();
        if ($nearestAgent) {
            $agentStocks = Stock::where('user_id', $nearestAgent->id)
                ->where('type', 'agent')
                ->available()
                ->with(['productVariant.product'])
                ->get();
        }

        // Get available products for reference
        $products = \App\Models\Product::active()
            ->with(['variants' => function ($q) {
                $q->active()->ordered();
            }])
            ->ordered()
            ->get();

        return view('customer.orders.create', compact('nearestAgent', 'agentStocks', 'products'));
    }

    /**
     * Store a newly created order.
     *
     * Creates an order to the nearest agent with the selected items.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'agent_id'                    => 'required|integer|exists:users,id',
            'items'                       => 'required|array|min:1',
            'items.*.product_variant_id'   => 'required|integer|exists:product_variants,id',
            'items.*.quantity'             => 'required|integer|min:1',
            'shipping_address'             => 'nullable|string|max:500',
            'shipping_city'                => 'nullable|string|max:100',
            'shipping_province'            => 'nullable|string|max:100',
            'shipping_postal_code'         => 'nullable|string|max:10',
            'recipient_name'               => 'nullable|string|max:255',
            'recipient_phone'              => 'nullable|string|max:20',
            'notes'                        => 'nullable|string|max:500',
        ], [
            'agent_id.required'                   => 'Agen wajib dipilih.',
            'items.required'                      => 'Minimal satu item harus dipilih.',
            'items.*.product_variant_id.required'  => 'Varian produk wajib dipilih.',
            'items.*.quantity.required'            => 'Jumlah wajib diisi.',
            'items.*.quantity.min'                 => 'Jumlah minimal 1.',
        ]);

        // Verify the agent is valid
        $agent = User::where('id', $validated['agent_id'])
            ->where('role', 'agent')
            ->where('is_active', true)
            ->firstOrFail();

        $order = DB::transaction(function () use ($validated, $user, $agent) {
            $orderItems = [];
            $subtotal = 0;

            foreach ($validated['items'] as $item) {
                // Check agent stock availability
                $agentStock = Stock::where('user_id', $agent->id)
                    ->where('product_variant_id', $item['product_variant_id'])
                    ->where('type', 'agent')
                    ->first();

                if (!$agentStock || $agentStock->available_quantity < $item['quantity']) {
                    $variant = \App\Models\ProductVariant::find($item['product_variant_id']);
                    throw new \Exception("Stok agen tidak mencukupi untuk varian {$variant->name}.");
                }

                // Calculate item price
                $variant = \App\Models\ProductVariant::findOrFail($item['product_variant_id']);
                $itemSubtotal = $variant->price * $item['quantity'];
                $subtotal += $itemSubtotal;

                $orderItems[] = new OrderItem([
                    'product_variant_id' => $item['product_variant_id'],
                    'quantity'           => $item['quantity'],
                    'price_per_unit'     => $variant->price,
                    'subtotal'           => $itemSubtotal,
                ]);
            }

            // Determine shipping info
            $shippingAddress  = $validated['shipping_address'] ?? $user->address;
            $shippingCity     = $validated['shipping_city'] ?? $user->city;
            $shippingProvince = $validated['shipping_province'] ?? $user->province;
            $shippingPostal   = $validated['shipping_postal_code'] ?? $user->postal_code;
            $recipientName    = $validated['recipient_name'] ?? $user->name;
            $recipientPhone   = $validated['recipient_phone'] ?? $user->phone;

            // Create the order
            $order = Order::create([
                'user_id'             => $user->id,
                'seller_id'           => $agent->id,
                'order_type'          => 'customer_to_agent',
                'status'              => 'pending',
                'subtotal'            => $subtotal,
                'shipping_cost'       => 0,
                'total'               => $subtotal,
                'notes'               => $validated['notes'] ?? null,
                'shipping_address'    => $shippingAddress,
                'shipping_city'       => $shippingCity,
                'shipping_province'   => $shippingProvince,
                'shipping_postal_code' => $shippingPostal,
                'recipient_name'      => $recipientName,
                'recipient_phone'     => $recipientPhone,
            ]);

            // Save order items
            $order->orderItems()->saveMany($orderItems);

            return $order;
        });

        $this->logActivity('customer.order_placed', "Pelanggan {$user->name} membuat pesanan #{$order->order_number}.", [
            'order_id' => $order->id,
            'agent_id' => $agent->id,
        ]);

        return redirect()->route('customer.orders.show', $order->id)
            ->with('success', "Pesanan #{$order->order_number} berhasil dibuat. Silakan lakukan pembayaran.");
    }

    /**
     * Display the specified order's details.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->with([
                'seller',
                'orderItems.productVariant.product',
                'payments',
                'ratings',
                'complaints',
            ])
            ->findOrFail($id);

        return view('customer.orders.show', compact('order'));
    }

    /**
     * Cancel a pending order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function cancel(Request $request, $id)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['pending', 'confirmed'])
            ->findOrFail($id);

        $validated = $request->validate([
            'cancellation_reason' => 'nullable|string|max:500',
        ]);

        DB::transaction(function () use ($order, $validated) {
            // Restore stock if order was confirmed
            if ($order->status === 'confirmed') {
                foreach ($order->orderItems as $item) {
                    $stock = Stock::where('user_id', $order->seller_id)
                        ->where('product_variant_id', $item->product_variant_id)
                        ->where('type', 'agent')
                        ->first();

                    if ($stock) {
                        $stock->decrement('reserved_quantity', min($item->quantity, $stock->reserved_quantity));
                        $stock->increment('quantity', $item->quantity);
                    }
                }
            }

            $order->update([
                'status'             => 'cancelled',
                'cancelled_at'       => now(),
                'cancellation_reason' => $validated['cancellation_reason'] ?? 'Dibatalkan oleh pelanggan',
            ]);
        });

        $this->logActivity('customer.order_cancelled', "Pesanan #{$order->order_number} dibatalkan.", [
            'order_id' => $order->id,
        ]);

        return redirect()->route('customer.orders.show', $order->id)
            ->with('success', "Pesanan #{$order->order_number} berhasil dibatalkan.");
    }
}
