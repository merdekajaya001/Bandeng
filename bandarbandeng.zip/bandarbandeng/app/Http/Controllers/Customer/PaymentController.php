<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Wallet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/**
 * Customer\PaymentController
 *
 * Handles customer payment for orders: viewing payment page,
 * uploading transfer proof, and paying with wallet deposit.
 */
class PaymentController extends Controller
{
    /**
     * Show the payment page for the specified order.
     *
     * @param  int  $orderId
     * @return \Illuminate\View\View
     */
    public function show($orderId)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->with(['orderItems.productVariant.product', 'payments', 'seller'])
            ->findOrFail($orderId);

        // Only allow payment for pending orders
        if (!in_array($order->status, ['pending', 'confirmed'])) {
            return redirect()->route('customer.orders.show', $order->id)
                ->with('error', 'Pesanan ini tidak memerlukan pembayaran.');
        }

        // Check if there's already a pending payment
        $pendingPayment = $order->payments()->where('status', 'pending')->first();

        // Wallet info for deposit payment option
        $wallet = $user->wallet;

        return view('customer.payments.show', compact('order', 'pendingPayment', 'wallet'));
    }

    /**
     * Upload bank transfer proof for the specified order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $orderId
     * @return \Illuminate\Http\RedirectResponse
     */
    public function uploadProof(Request $request, $orderId)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['pending', 'confirmed'])
            ->findOrFail($orderId);

        $validated = $request->validate([
            'bank_name'    => 'required|string|max:100',
            'bank_account' => 'required|string|max:50',
            'bank_holder'  => 'required|string|max:255',
            'proof_image'  => 'required|image|max:2048',
            'notes'        => 'nullable|string|max:500',
        ], [
            'bank_name.required'    => 'Nama bank wajib diisi.',
            'bank_account.required' => 'Nomor rekening wajib diisi.',
            'bank_holder.required'  => 'Nama pemilik rekening wajib diisi.',
            'proof_image.required'  => 'Bukti transfer wajib diunggah.',
            'proof_image.image'     => 'File harus berupa gambar.',
            'proof_image.max'       => 'Ukuran file maksimal 2MB.',
        ]);

        DB::transaction(function () use ($validated, $request, $order, $user) {
            // Upload proof image
            $proofPath = $request->file('proof_image')->store('payment-proofs', 'public');

            // Create payment record
            Payment::create([
                'order_id'        => $order->id,
                'payment_method'  => 'bank_transfer',
                'amount'          => $order->total,
                'status'          => 'pending',
                'proof_image'     => $proofPath,
                'bank_name'       => $validated['bank_name'],
                'bank_account'    => $validated['bank_account'],
                'bank_holder'     => $validated['bank_holder'],
                'notes'           => $validated['notes'] ?? null,
            ]);
        });

        $this->logActivity('payment.proof_uploaded', "Bukti pembayaran diunggah untuk pesanan #{$order->order_number}.", [
            'order_id' => $order->id,
        ]);

        return redirect()->route('customer.orders.show', $order->id)
            ->with('success', 'Bukti pembayaran berhasil diunggah. Menunggu verifikasi.');
    }

    /**
     * Pay for an order using the customer's wallet deposit.
     *
     * Deducts the order total from the wallet and creates
     * a completed payment record.
     *
     * @param  int  $orderId
     * @return \Illuminate\Http\RedirectResponse
     */
    public function payWithDeposit($orderId)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['pending', 'confirmed'])
            ->findOrFail($orderId);

        $wallet = $user->wallet;

        if (!$wallet || !$wallet->hasSufficientBalance((float) $order->total)) {
            return redirect()->route('customer.payments.show', $order->id)
                ->with('error', 'Saldo dompet tidak mencukupi untuk pembayaran ini.');
        }

        DB::transaction(function () use ($order, $wallet, $user) {
            // Deduct from wallet
            $wallet->withdraw((float) $order->total, "Pembayaran pesanan #{$order->order_number}");

            // Create completed payment record
            Payment::create([
                'order_id'       => $order->id,
                'payment_method' => 'wallet',
                'amount'         => $order->total,
                'status'         => 'verified',
                'verified_at'    => now(),
                'verified_by'    => $user->id,
                'notes'          => 'Pembayaran melalui saldo dompet',
            ]);

            // Confirm the order if still pending
            if ($order->status === 'pending') {
                $order->update(['status' => 'confirmed']);
            }
        });

        $this->logActivity('payment.deposit_paid', "Pembayaran deposit untuk pesanan #{$order->order_number}.", [
            'order_id' => $order->id,
            'amount'   => $order->total,
        ]);

        return redirect()->route('customer.orders.show', $order->id)
            ->with('success', 'Pembayaran berhasil menggunakan saldo dompet.');
    }
}
