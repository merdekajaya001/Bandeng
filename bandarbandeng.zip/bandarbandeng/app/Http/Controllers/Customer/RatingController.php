<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Rating;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

/**
 * Customer\RatingController
 *
 * Handles customer rating submission for completed orders.
 */
class RatingController extends Controller
{
    /**
     * Show the rating form for the specified order.
     *
     * @param  int  $orderId
     * @return \Illuminate\View\View
     */
    public function create($orderId)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['delivered', 'completed'])
            ->with(['seller', 'orderItems.productVariant.product'])
            ->findOrFail($orderId);

        // Check if the order has already been rated
        $existingRating = Rating::where('order_id', $order->id)
            ->where('user_id', $user->id)
            ->first();

        if ($existingRating) {
            return redirect()->route('customer.orders.show', $order->id)
                ->with('info', 'Anda sudah memberikan rating untuk pesanan ini.');
        }

        return view('customer.ratings.create', compact('order'));
    }

    /**
     * Submit a rating for the specified order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $orderId
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request, $orderId)
    {
        $user = Auth::user();

        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'customer_to_agent')
            ->whereIn('status', ['delivered', 'completed'])
            ->findOrFail($orderId);

        // Check for duplicate rating
        $existingRating = Rating::where('order_id', $order->id)
            ->where('user_id', $user->id)
            ->exists();

        if ($existingRating) {
            return redirect()->route('customer.orders.show', $order->id)
                ->with('error', 'Anda sudah memberikan rating untuk pesanan ini.');
        }

        $validated = $request->validate([
            'rating'       => 'required|integer|min:1|max:5',
            'review'       => 'nullable|string|max:1000',
            'is_anonymous' => 'boolean',
        ], [
            'rating.required' => 'Rating wajib diberikan.',
            'rating.min'      => 'Rating minimal 1.',
            'rating.max'      => 'Rating maksimal 5.',
            'review.max'      => 'Ulasan maksimal 1000 karakter.',
        ]);

        Rating::create([
            'order_id'      => $order->id,
            'user_id'       => $user->id,
            'rated_user_id' => $order->seller_id,
            'rating'        => $validated['rating'],
            'review'        => $validated['review'] ?? null,
            'is_anonymous'  => $validated['is_anonymous'] ?? false,
        ]);

        // If the order is delivered, mark it as completed after rating
        if ($order->status === 'delivered') {
            $order->update(['status' => 'completed']);
        }

        $this->logActivity('customer.rating_submitted', "Rating diberikan untuk pesanan #{$order->order_number}.", [
            'order_id' => $order->id,
            'rating'   => $validated['rating'],
        ]);

        return redirect()->route('customer.orders.show', $order->id)
            ->with('success', 'Rating berhasil diberikan. Terima kasih atas ulasan Anda!');
    }
}
