<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Testimonial;
use App\Models\User;

/**
 * LandingController
 *
 * Handles the public landing page that showcases products,
 * testimonials, agents, and key statistics for Bandar Bandeng Kalimantan.
 */
class LandingController extends Controller
{
    /**
     * Display the public landing page.
     *
     * Fetches:
     * - Active products with their active variants (max 8)
     * - Featured testimonials with user info (max 6)
     * - Active agents with their coverage areas (max 8)
     * - Platform statistics (orders, agents, stockists, customers)
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Fetch active products with their active variants
        $products = Product::active()
            ->with(['variants' => function ($query) {
                $query->active()->ordered();
            }])
            ->ordered()
            ->take(8)
            ->get();

        // Fetch featured testimonials (active + featured, with user relationship)
        $testimonials = Testimonial::active()
            ->featured()
            ->with('user')
            ->latest()
            ->take(6)
            ->get();

        // Fetch active agents with their coverage areas
        $agents = User::agents()
            ->active()
            ->with('agentAreas')
            ->latest()
            ->take(8)
            ->get();

        // Gather platform statistics
        $stats = [
            'total_orders'    => Order::count(),
            'total_agents'    => User::agents()->active()->count(),
            'total_stockists' => User::stockists()->active()->count(),
            'total_customers' => User::where('role', 'customer')->active()->count(),
        ];

        return view('landing.index', compact('products', 'testimonials', 'agents', 'stats'));
    }
}
