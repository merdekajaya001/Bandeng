<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rules\Password;

/**
 * ProfileController
 *
 * Handles the authenticated user's profile management:
 * - Viewing profile
 * - Updating profile information (name, phone, address, city, etc.)
 * - Changing password
 * - Uploading avatar image
 */
class ProfileController extends Controller
{
    /**
     * Display the authenticated user's profile.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $user = Auth::user()->load('wallet');

        return view('profile.index', compact('user'));
    }

    /**
     * Update the authenticated user's profile information.
     *
     * Validates and updates: name, phone, address, city, province,
     * postal_code. Uses a database transaction for safety.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'name'        => 'required|string|max:255',
            'phone'       => 'required|string|max:20',
            'address'     => 'nullable|string|max:500',
            'city'        => 'nullable|string|max:100',
            'province'    => 'nullable|string|max:100',
            'postal_code' => 'nullable|string|max:10',
        ], [
            'name.required'        => 'Nama wajib diisi.',
            'name.max'             => 'Nama maksimal 255 karakter.',
            'phone.required'       => 'Nomor telepon wajib diisi.',
            'phone.max'            => 'Nomor telepon maksimal 20 karakter.',
            'address.max'          => 'Alamat maksimal 500 karakter.',
            'city.max'             => 'Kota maksimal 100 karakter.',
            'province.max'         => 'Provinsi maksimal 100 karakter.',
            'postal_code.max'      => 'Kode pos maksimal 10 karakter.',
        ]);

        $user->update([
            'name'        => $validated['name'],
            'phone'       => $validated['phone'],
            'address'     => $validated['address'] ?? null,
            'city'        => $validated['city'] ?? null,
            'province'    => $validated['province'] ?? null,
            'postal_code' => $validated['postal_code'] ?? null,
        ]);

        $this->logActivity('profile.updated', "User {$user->name} updated their profile.", [
            'updated_fields' => array_keys($validated),
        ]);

        return redirect()->back()
            ->with('success', 'Profil berhasil diperbarui.');
    }

    /**
     * Update the authenticated user's password.
     *
     * Validates the current password, then updates to the new password.
     * The new password must meet minimum security requirements.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updatePassword(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'current_password'      => ['required', 'string'],
            'password'              => ['required', 'confirmed', Password::min(8)->mixedCase()->numbers()],
        ], [
            'current_password.required'   => 'Password saat ini wajib diisi.',
            'password.required'           => 'Password baru wajib diisi.',
            'password.confirmed'          => 'Konfirmasi password tidak cocok.',
        ]);

        // Verify the current password is correct
        if (!Hash::check($validated['current_password'], $user->password)) {
            return redirect()->back()
                ->withErrors(['current_password' => 'Password saat ini tidak sesuai.'])
                ->withInput();
        }

        // Prevent reusing the same password
        if (Hash::check($validated['password'], $user->password)) {
            return redirect()->back()
                ->withErrors(['password' => 'Password baru tidak boleh sama dengan password saat ini.'])
                ->withInput();
        }

        $user->update([
            'password' => Hash::make($validated['password']),
        ]);

        $this->logActivity('password.changed', "User {$user->name} changed their password.");

        return redirect()->back()
            ->with('success', 'Password berhasil diperbarui.');
    }

    /**
     * Upload or update the authenticated user's avatar image.
     *
     * Validates the uploaded image (max 2MB, jpg/png/webp), stores it
     * in the public disk under avatars/, and deletes the old avatar.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateAvatar(Request $request)
    {
        $user = Auth::user();

        $request->validate([
            'avatar' => 'required|image|mimes:jpeg,jpg,png,webp|max:2048',
        ], [
            'avatar.required' => 'Foto profil wajib diunggah.',
            'avatar.image'    => 'File harus berupa gambar.',
            'avatar.mimes'    => 'Format gambar harus JPG, PNG, atau WebP.',
            'avatar.max'      => 'Ukuran gambar maksimal 2MB.',
        ]);

        // Delete the old avatar if it exists
        if ($user->avatar && Storage::disk('public')->exists($user->avatar)) {
            Storage::disk('public')->delete($user->avatar);
        }

        // Store the new avatar
        $avatarPath = $request->file('avatar')->store('avatars', 'public');

        $user->update([
            'avatar' => $avatarPath,
        ]);

        $this->logActivity('avatar.updated', "User {$user->name} updated their avatar.", [
            'avatar_path' => $avatarPath,
        ]);

        return redirect()->back()
            ->with('success', 'Foto profil berhasil diperbarui.');
    }
}
