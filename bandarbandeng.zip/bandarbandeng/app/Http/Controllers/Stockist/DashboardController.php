<?php

namespace App\Http\Controllers\Stockist;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Stock;
use App\Models\Notification;
use Illuminate\Support\Facades\Auth;

/**
 * Stockist\DashboardController
 *
 * Displays the stockist dashboard with stock summary, incoming agent orders,
 * outgoing orders to admin, revenue this month, and wallet balance.
 */
class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * Applies the 'role:stockist' middleware to ensure only
     * stockist users can access these routes.
     */
    public function __construct()
    {
        $this->middleware('role:stockist');
    }

    /**
     * Display the stockist dashboard.
     *
     * Gathers the following statistics:
     * - Total stock quantity owned by the stockist
     * - Number of low-stock product variants (available < 10)
     * - Incoming orders from agents (pending/confirmed)
     * - Total incoming orders from agents (all statuses)
     * - Outgoing orders to admin (all statuses)
     * - Pending outgoing orders to admin
     * - Revenue for the current month (completed agent→stockist orders)
     * - Total all-time revenue
     * - Wallet balance
     * - Unread notifications count
     * - 5 most recent incoming agent orders
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $user = Auth::user();

        // ── Stock Statistics ─────────────────────────────────────────────
        $totalStockQuantity = Stock::where('user_id', $user->id)
            ->where('type', 'stockist')
            ->sum('quantity');

        $totalReservedQuantity = Stock::where('user_id', $user->id)
            ->where('type', 'stockist')
            ->sum('reserved_quantity');

        $lowStockCount = Stock::where('user_id', $user->id)
            ->where('type', 'stockist')
            ->lowStock(10)
            ->count();

        $stockVariantsCount = Stock::where('user_id', $user->id)
            ->where('type', 'stockist')
            ->where('quantity', '>', 0)
            ->count();

        // ── Incoming Agent Orders ────────────────────────────────────────
        $incomingPendingOrders = Order::where('seller_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->whereIn('status', ['pending', 'confirmed'])
            ->count();

        $totalIncomingOrders = Order::where('seller_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->count();

        // ── Outgoing Orders to Admin ─────────────────────────────────────
        $myOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'stockist_to_admin')
            ->count();

        $pendingMyOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'stockist_to_admin')
            ->where('status', 'pending')
            ->count();

        // ── Revenue ──────────────────────────────────────────────────────
        $revenueThisMonth = Order::where('seller_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->where('status', 'completed')
            ->whereYear('created_at', now()->year)
            ->whereMonth('created_at', now()->month)
            ->sum('total');

        $totalRevenue = Order::where('seller_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->where('status', 'completed')
            ->sum('total');

        // ── Recent Incoming Orders ───────────────────────────────────────
        $recentOrders = Order::where('seller_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->with(['buyer', 'orderItems.productVariant'])
            ->recent()
            ->take(5)
            ->get();

        // ── Recent Outgoing Orders to Admin ──────────────────────────────
        $recentMyOrders = Order::where('user_id', $user->id)
            ->where('order_type', 'stockist_to_admin')
            ->with(['orderItems.productVariant'])
            ->recent()
            ->take(5)
            ->get();

        // ── Wallet Info ──────────────────────────────────────────────────
        $wallet = $user->wallet;

        // ── Unread Notifications ─────────────────────────────────────────
        $unreadNotifications = Notification::where('user_id', $user->id)
            ->unread()
            ->count();

        // ── Compile Stats ────────────────────────────────────────────────
        $stats = [
            'total_stock_quantity'    => $totalStockQuantity,
            'total_reserved_quantity' => $totalReservedQuantity,
            'low_stock_count'         => $lowStockCount,
            'stock_variants_count'    => $stockVariantsCount,
            'incoming_pending_orders' => $incomingPendingOrders,
            'total_incoming_orders'   => $totalIncomingOrders,
            'my_orders'               => $myOrders,
            'pending_my_orders'       => $pendingMyOrders,
            'revenue_this_month'      => $revenueThisMonth,
            'total_revenue'           => $totalRevenue,
            'wallet_balance'          => $wallet ? $wallet->balance : 0,
            'unread_notifications'    => $unreadNotifications,
        ];

        return view('stockist.dashboard', compact('stats', 'recentOrders', 'recentMyOrders'));
    }
}
