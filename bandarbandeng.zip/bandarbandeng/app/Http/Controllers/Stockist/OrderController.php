<?php

namespace App\Http\Controllers\Stockist;

use App\Http\Controllers\Controller;
use App\Models\Notification;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/**
 * Stockist\OrderController
 *
 * Handles orders for the stockist: both incoming orders from agents
 * and the stockist's own orders to admin. Includes order listing,
 * detail view, processing agent orders, status updates with
 * transition validation, and payment proof upload.
 */
class OrderController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * Applies the 'role:stockist' middleware to ensure only
     * stockist users can access these routes.
     */
    public function __construct()
    {
        $this->middleware('role:stockist');
    }

    /**
     * Display a listing of orders (both incoming from agents and own orders to admin).
     *
     * Supports filtering by:
     * - status (pending, confirmed, processing, shipped, delivered, completed, cancelled)
     * - order_type (agent_to_stockist, stockist_to_admin)
     * - date range (from_date, to_date)
     * - search (order number or buyer/seller name)
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        // Build a unified query for orders where stockist is either buyer or seller
        $query = Order::where(function ($q) use ($user) {
            $q->where('seller_id', $user->id)
              ->where('order_type', 'agent_to_stockist');
        })->orWhere(function ($q) use ($user) {
            $q->where('user_id', $user->id)
              ->where('order_type', 'stockist_to_admin');
        });

        $query->with(['buyer', 'seller', 'orderItems.productVariant']);

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }

        // Filter by order type
        if ($request->filled('order_type')) {
            $query->where('order_type', $request->input('order_type'));
        }

        // Filter by date range
        if ($request->filled('from_date')) {
            $query->whereDate('created_at', '>=', $request->input('from_date'));
        }
        if ($request->filled('to_date')) {
            $query->whereDate('created_at', '<=', $request->input('to_date'));
        }

        // Search by order number or buyer/seller name
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->where(function ($q) use ($search) {
                $q->where('order_number', 'like', "%{$search}%")
                  ->orWhereHas('buyer', function ($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  })
                  ->orWhereHas('seller', function ($q2) use ($search) {
                      $q2->where('name', 'like', "%{$search}%");
                  });
            });
        }

        $orders = $query->recent()->paginate(20)->withQueryString();

        return view('stockist.orders.index', compact('orders'));
    }

    /**
     * Display the specified order's details.
     *
     * Loads the order with all related data: buyer, seller,
     * order items with product variants and products, payments,
     * and ratings.
     *
     * @param  int  $id
     * @return \Illuminate\View\View
     */
    public function show($id)
    {
        $user = Auth::user();

        // Ensure the order belongs to this stockist (either as buyer or seller)
        $order = Order::where(function ($q) use ($user) {
            $q->where('seller_id', $user->id)
              ->orWhere('user_id', $user->id);
        })
            ->with([
                'buyer',
                'seller',
                'orderItems.productVariant.product',
                'payments',
                'ratings',
            ])
            ->findOrFail($id);

        return view('stockist.orders.show', compact('order'));
    }

    /**
     * Process an incoming agent order.
     *
     * For agent→stockist orders in 'pending' status. This method:
     * 1. Verifies the stockist has enough stock for all items
     * 2. Deducts the quantity from stockist stock
     * 3. Increases the stockist's reserved_quantity
     * 4. Creates agent stock entries for each item
     * 5. Updates the order status to 'confirmed'
     * 6. Notifies the agent that their order has been processed
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id  The order ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function processAgentOrder(Request $request, $id)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'notes' => 'nullable|string|max:500',
        ]);

        $order = Order::where('seller_id', $user->id)
            ->where('order_type', 'agent_to_stockist')
            ->where('status', 'pending')
            ->with(['orderItems.productVariant', 'buyer'])
            ->findOrFail($id);

        DB::transaction(function () use ($order, $user, $validated) {
            // Step 1: Verify stock availability and deduct from stockist
            foreach ($order->orderItems as $item) {
                $stock = Stock::where('user_id', $user->id)
                    ->where('product_variant_id', $item->product_variant_id)
                    ->where('type', 'stockist')
                    ->first();

                if (!$stock || $stock->available_quantity < $item->quantity) {
                    $variantName = $item->productVariant->name ?? 'Unknown';
                    $available = $stock ? $stock->available_quantity : 0;
                    throw new \Exception(
                        "Stok tidak mencukupi untuk varian {$variantName}. Tersedia: {$available}, Diminta: {$item->quantity}."
                    );
                }

                // Deduct from stockist available stock and increase reserved
                $stock->decrement('quantity', $item->quantity);
                $stock->increment('reserved_quantity', $item->quantity);
            }

            // Step 2: Create agent stock entries for each item
            foreach ($order->orderItems as $item) {
                $agentStock = Stock::where('user_id', $order->buyer_id)
                    ->where('product_variant_id', $item->product_variant_id)
                    ->where('type', 'agent')
                    ->first();

                if ($agentStock) {
                    // Agent already has stock for this variant — increment
                    $agentStock->increment('quantity', $item->quantity);
                } else {
                    // Create new stock entry for the agent
                    Stock::create([
                        'product_variant_id' => $item->product_variant_id,
                        'user_id'            => $order->buyer_id,
                        'quantity'           => $item->quantity,
                        'reserved_quantity'  => 0,
                        'type'               => 'agent',
                    ]);
                }
            }

            // Step 3: Update order status
            $updateData = [
                'status' => 'confirmed',
            ];

            if (!empty($validated['notes'])) {
                $updateData['notes'] = $validated['notes'];
            }

            $order->update($updateData);
        });

        // Step 4: Notify the agent that their order has been confirmed
        Notification::create([
            'user_id' => $order->buyer_id,
            'title'   => 'Pesanan Dikonfirmasi',
            'message' => "Pesanan #{$order->order_number} telah dikonfirmasi dan diproses oleh stockist {$user->name}.",
            'type'    => 'order_confirmed',
            'data'    => [
                'order_id'     => $order->id,
                'stockist_id'  => $user->id,
            ],
        ]);

        $this->logActivity('stockist.order_processed', "Pesanan agen #{$order->order_number} diproses oleh stockist {$user->name}.", [
            'order_id'  => $order->id,
            'agent_id'  => $order->buyer_id,
            'seller_id' => $user->id,
        ]);

        return redirect()->route('stockist.orders.show', $order->id)
            ->with('success', "Pesanan agen #{$order->order_number} berhasil diproses. Stok telah ditransfer ke agen.");
    }

    /**
     * Update the status of the specified order with transition validation.
     *
     * Validates that the requested status transition is allowed based on
     * the current order status. Handles special cases such as:
     * - Setting shipped_at and tracking_number when status is 'shipped'
     * - Setting delivered_at when status is 'delivered'
     * - Processing completion (releasing reserved stock, crediting wallet)
     * - Restoring stock on cancellation
     * - Sending notifications on status change
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStatus(Request $request, $id)
    {
        $user = Auth::user();

        // Find the order — stockist can update both incoming and outgoing orders
        $order = Order::where(function ($q) use ($user) {
            $q->where('seller_id', $user->id)
              ->orWhere('user_id', $user->id);
        })->findOrFail($id);

        $validated = $request->validate([
            'status'              => 'required|in:confirmed,processing,shipped,delivered,completed,cancelled',
            'cancellation_reason' => 'nullable|string|max:500|required_if:status,cancelled',
            'tracking_number'     => 'nullable|string|max:100',
            'notes'               => 'nullable|string|max:500',
        ], [
            'status.required'                  => 'Status wajib dipilih.',
            'cancellation_reason.required_if'  => 'Alasan pembatalan wajib diisi.',
        ]);

        $oldStatus = $order->getOriginal('status');

        // Validate the status transition is allowed
        $this->validateStatusTransition($oldStatus, $validated['status']);

        DB::transaction(function () use ($order, $validated, $user) {
            $updateData = [
                'status' => $validated['status'],
            ];

            switch ($validated['status']) {
                case 'confirmed':
                    // For incoming agent orders, deduct stockist stock and create agent stock
                    if ($order->order_type === 'agent_to_stockist' && $order->seller_id === $user->id) {
                        $this->deductStockForConfirmation($order, $user);
                    }
                    break;

                case 'processing':
                    // No special stock operations for processing
                    break;

                case 'shipped':
                    $updateData['shipped_at'] = now();
                    if (!empty($validated['tracking_number'])) {
                        $updateData['tracking_number'] = $validated['tracking_number'];
                    }
                    break;

                case 'delivered':
                    $updateData['delivered_at'] = now();
                    break;

                case 'completed':
                    // Release reserved stock and credit seller wallet
                    $this->processCompletion($order, $user);
                    break;

                case 'cancelled':
                    $updateData['cancelled_at'] = now();
                    $updateData['cancellation_reason'] = $validated['cancellation_reason'] ?? null;
                    // Restore stock if it was already confirmed
                    if (in_array($order->getOriginal('status'), ['confirmed', 'processing', 'shipped'])) {
                        $this->restoreStock($order, $user);
                    }
                    break;
            }

            if (!empty($validated['notes'])) {
                $updateData['notes'] = $validated['notes'];
            }

            $order->update($updateData);
        });

        // Notify the other party about the status change
        $this->notifyStatusChange($order, $validated['status'], $user);

        $this->logActivity('stockist.order_status_updated', "Status pesanan #{$order->order_number} diubah dari {$oldStatus} ke {$validated['status']}.", [
            'order_id'    => $order->id,
            'old_status'  => $oldStatus,
            'new_status'  => $validated['status'],
        ]);

        return redirect()->route('stockist.orders.show', $order->id)
            ->with('success', "Status pesanan #{$order->order_number} berhasil diperbarui ke {$validated['status']}.");
    }

    /**
     * Upload bank transfer payment proof for a stockist→admin order.
     *
     * Only applicable for orders of type 'stockist_to_admin'.
     * Validates the uploaded image, stores it, and creates a
     * Payment record with 'pending' status.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id  The order ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function uploadPaymentProof(Request $request, $id)
    {
        $user = Auth::user();

        // Only allow payment proof upload for own outgoing orders to admin
        $order = Order::where('user_id', $user->id)
            ->where('order_type', 'stockist_to_admin')
            ->whereIn('status', ['pending', 'confirmed'])
            ->findOrFail($id);

        $validated = $request->validate([
            'proof_image'   => 'required|image|mimes:jpeg,png,jpg|max:5120',
            'bank_name'     => 'required|string|max:100',
            'bank_account'  => 'required|string|max:50',
            'bank_holder'   => 'required|string|max:100',
            'payment_notes' => 'nullable|string|max:500',
        ], [
            'proof_image.required' => 'Bukti pembayaran wajib diunggah.',
            'proof_image.image'    => 'File harus berupa gambar.',
            'proof_image.mimes'    => 'Format gambar harus jpeg, png, atau jpg.',
            'proof_image.max'      => 'Ukuran gambar maksimal 5MB.',
            'bank_name.required'   => 'Nama bank wajib diisi.',
            'bank_account.required' => 'Nomor rekening wajib diisi.',
            'bank_holder.required'  => 'Nama pemilik rekening wajib diisi.',
        ]);

        DB::transaction(function () use ($order, $validated, $user) {
            // Store the proof image
            $proofPath = $validated['proof_image']->store('payment_proofs', 'public');

            // Create payment record
            Payment::create([
                'order_id'        => $order->id,
                'payment_method'  => 'bank_transfer',
                'amount'          => $order->total,
                'status'          => 'pending',
                'proof_image'     => $proofPath,
                'bank_name'       => $validated['bank_name'],
                'bank_account'    => $validated['bank_account'],
                'bank_holder'     => $validated['bank_holder'],
                'notes'           => $validated['payment_notes'] ?? null,
            ]);

            // Update order status to confirmed if still pending
            if ($order->status === 'pending') {
                $order->update(['status' => 'confirmed']);
            }
        });

        // Notify admin users about the payment
        $adminUsers = \App\Models\User::byRole('admin')->active()->get();
        foreach ($adminUsers as $admin) {
            Notification::create([
                'user_id' => $admin->id,
                'title'   => 'Bukti Pembayaran Diterima',
                'message' => "Stockist {$user->name} mengunggah bukti pembayaran untuk pesanan #{$order->order_number}.",
                'type'    => 'payment_proof_uploaded',
                'data'    => [
                    'order_id'    => $order->id,
                    'stockist_id' => $user->id,
                ],
            ]);
        }

        $this->logActivity('stockist.payment_proof_uploaded', "Stockist {$user->name} mengunggah bukti pembayaran untuk pesanan #{$order->order_number}.", [
            'order_id'    => $order->id,
            'stockist_id' => $user->id,
        ]);

        return redirect()->route('stockist.orders.show', $order->id)
            ->with('success', "Bukti pembayaran untuk pesanan #{$order->order_number} berhasil diunggah. Menunggu verifikasi admin.");
    }

    // =========================================================================
    // Protected Helper Methods
    // =========================================================================

    /**
     * Validate that the status transition is allowed.
     *
     * Allowed transitions:
     * - pending    → confirmed, cancelled
     * - confirmed  → processing, shipped, cancelled
     * - processing → shipped, cancelled
     * - shipped    → delivered
     * - delivered  → completed
     * - completed  → (terminal)
     * - cancelled  → (terminal)
     *
     * @param  string  $from  Current status
     * @param  string  $to    Desired status
     * @return void
     * @throws \Exception
     */
    protected function validateStatusTransition(string $from, string $to): void
    {
        $allowedTransitions = [
            'pending'    => ['confirmed', 'cancelled'],
            'confirmed'  => ['processing', 'shipped', 'cancelled'],
            'processing' => ['shipped', 'cancelled'],
            'shipped'    => ['delivered'],
            'delivered'  => ['completed'],
            'completed'  => [],
            'cancelled'  => [],
        ];

        $allowed = $allowedTransitions[$from] ?? [];

        if (!in_array($to, $allowed)) {
            throw new \Exception("Transisi status dari '{$from}' ke '{$to}' tidak diizinkan.");
        }
    }

    /**
     * Deduct stock from the stockist's inventory when confirming an agent order.
     *
     * Also creates agent stock entries for each item.
     *
     * @param  \App\Models\Order  $order
     * @param  \App\Models\User   $user  The stockist
     * @return void
     * @throws \Exception
     */
    protected function deductStockForConfirmation(Order $order, $user): void
    {
        // Load order items if not already loaded
        if (!$order->relationLoaded('orderItems')) {
            $order->load('orderItems.productVariant');
        }

        foreach ($order->orderItems as $item) {
            $stock = Stock::where('user_id', $user->id)
                ->where('product_variant_id', $item->product_variant_id)
                ->where('type', 'stockist')
                ->first();

            if (!$stock || $stock->available_quantity < $item->quantity) {
                $variantName = $item->productVariant->name ?? 'Unknown';
                $available = $stock ? $stock->available_quantity : 0;
                throw new \Exception(
                    "Stok tidak mencukupi untuk varian {$variantName}. Tersedia: {$available}, Diminta: {$item->quantity}."
                );
            }

            // Deduct from stockist stock and increase reserved
            $stock->decrement('quantity', $item->quantity);
            $stock->increment('reserved_quantity', $item->quantity);

            // Create or update agent stock
            $agentStock = Stock::where('user_id', $order->buyer_id)
                ->where('product_variant_id', $item->product_variant_id)
                ->where('type', 'agent')
                ->first();

            if ($agentStock) {
                $agentStock->increment('quantity', $item->quantity);
            } else {
                Stock::create([
                    'product_variant_id' => $item->product_variant_id,
                    'user_id'            => $order->buyer_id,
                    'quantity'           => $item->quantity,
                    'reserved_quantity'  => 0,
                    'type'               => 'agent',
                ]);
            }
        }
    }

    /**
     * Process order completion: release reserved stock and credit seller wallet.
     *
     * For agent→stockist orders:
     * - Releases the stockist's reserved stock
     * - Credits the stockist's wallet with the order total
     *
     * For stockist→admin orders:
     * - Releases the admin's reserved stock
     *
     * @param  \App\Models\Order  $order
     * @param  \App\Models\User   $user  The stockist
     * @return void
     */
    protected function processCompletion(Order $order, $user): void
    {
        // Load order items if not already loaded
        if (!$order->relationLoaded('orderItems')) {
            $order->load('orderItems');
        }

        foreach ($order->orderItems as $item) {
            // Determine which stock type to release based on order type
            if ($order->order_type === 'agent_to_stockist' && $order->seller_id === $user->id) {
                // Release stockist's reserved stock
                $stock = Stock::where('user_id', $user->id)
                    ->where('product_variant_id', $item->product_variant_id)
                    ->where('type', 'stockist')
                    ->first();

                if ($stock) {
                    $stock->decrement('reserved_quantity', min($item->quantity, $stock->reserved_quantity));
                }
            } elseif ($order->order_type === 'stockist_to_admin' && $order->user_id === $user->id) {
                // Release admin's reserved stock
                $adminStock = Stock::byType('admin')
                    ->where('product_variant_id', $item->product_variant_id)
                    ->first();

                if ($adminStock) {
                    $adminStock->decrement('reserved_quantity', min($item->quantity, $adminStock->reserved_quantity));
                }
            }
        }

        // Credit the seller's wallet for agent→stockist orders
        if ($order->order_type === 'agent_to_stockist' && $order->seller_id === $user->id) {
            $wallet = $user->wallet;
            if ($wallet) {
                $wallet->deposit(
                    (float) $order->total,
                    "Pembayaran pesanan #{$order->order_number} dari agen"
                );
            }
        }
    }

    /**
     * Restore stock when an order is cancelled.
     *
     * For agent→stockist orders:
     * - Restores stockist stock (decrement reserved, increment quantity)
     * - Removes the stock from agent (decrement agent stock)
     *
     * For stockist→admin orders:
     * - Releases admin's reserved stock back to available
     *
     * @param  \App\Models\Order  $order
     * @param  \App\Models\User   $user  The stockist
     * @return void
     */
    protected function restoreStock(Order $order, $user): void
    {
        // Load order items if not already loaded
        if (!$order->relationLoaded('orderItems')) {
            $order->load('orderItems');
        }

        foreach ($order->orderItems as $item) {
            if ($order->order_type === 'agent_to_stockist' && $order->seller_id === $user->id) {
                // Restore stockist stock
                $stockistStock = Stock::where('user_id', $user->id)
                    ->where('product_variant_id', $item->product_variant_id)
                    ->where('type', 'stockist')
                    ->first();

                if ($stockistStock) {
                    $stockistStock->decrement('reserved_quantity', min($item->quantity, $stockistStock->reserved_quantity));
                    $stockistStock->increment('quantity', $item->quantity);
                }

                // Remove stock from agent
                $agentStock = Stock::where('user_id', $order->buyer_id)
                    ->where('product_variant_id', $item->product_variant_id)
                    ->where('type', 'agent')
                    ->first();

                if ($agentStock) {
                    $agentStock->decrement('quantity', min($item->quantity, $agentStock->quantity));
                }
            } elseif ($order->order_type === 'stockist_to_admin' && $order->user_id === $user->id) {
                // Release admin reserved stock
                $adminStock = Stock::byType('admin')
                    ->where('product_variant_id', $item->product_variant_id)
                    ->first();

                if ($adminStock) {
                    $adminStock->decrement('reserved_quantity', min($item->quantity, $adminStock->reserved_quantity));
                    $adminStock->increment('quantity', $item->quantity);
                }
            }
        }
    }

    /**
     * Send notifications about a status change to the relevant parties.
     *
     * @param  \App\Models\Order  $order
     * @param  string             $newStatus
     * @param  \App\Models\User   $stockist
     * @return void
     */
    protected function notifyStatusChange(Order $order, string $newStatus, $stockist): void
    {
        $statusLabels = [
            'pending'    => 'Menunggu',
            'confirmed'  => 'Dikonfirmasi',
            'processing' => 'Diproses',
            'shipped'    => 'Dikirim',
            'delivered'  => 'Diterima',
            'completed'  => 'Selesai',
            'cancelled'  => 'Dibatalkan',
        ];

        $label = $statusLabels[$newStatus] ?? ucfirst($newStatus);

        // For agent→stockist orders, notify the agent (buyer)
        if ($order->order_type === 'agent_to_stockist' && $order->buyer_id !== $stockist->id) {
            Notification::create([
                'user_id' => $order->buyer_id,
                'title'   => 'Status Pesanan Diperbarui',
                'message' => "Pesanan #{$order->order_number} statusnya diubah menjadi: {$label} oleh stockist.",
                'type'    => 'order_status_updated',
                'data'    => [
                    'order_id' => $order->id,
                    'status'   => $newStatus,
                ],
            ]);
        }

        // For stockist→admin orders, notify admin users
        if ($order->order_type === 'stockist_to_admin') {
            $adminUsers = \App\Models\User::byRole('admin')->active()->get();
            foreach ($adminUsers as $admin) {
                Notification::create([
                    'user_id' => $admin->id,
                    'title'   => 'Status Pesanan Diperbarui',
                    'message' => "Pesanan #{$order->order_number} dari stockist {$stockist->name} statusnya diubah menjadi: {$label}.",
                    'type'    => 'order_status_updated',
                    'data'    => [
                        'order_id' => $order->id,
                        'status'   => $newStatus,
                    ],
                ]);
            }
        }
    }
}
