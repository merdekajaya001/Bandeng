<?php

namespace App\Http\Controllers\Stockist;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\Notification;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\ProductVariant;
use App\Models\Stock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * Stockist\StockController
 *
 * Manages the stockist's own stock inventory and allows ordering
 * stock replenishment from the admin.
 */
class StockController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * Applies the 'role:stockist' middleware to ensure only
     * stockist users can access these routes.
     */
    public function __construct()
    {
        $this->middleware('role:stockist');
    }

    /**
     * Display the stockist's stock inventory.
     *
     * Lists all stock entries owned by the authenticated stockist,
     * grouped by product variant with available quantities.
     * Supports filtering by product and low-stock status.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        $query = Stock::where('user_id', $user->id)
            ->where('type', 'stockist')
            ->with(['productVariant.product']);

        // Filter by product
        if ($request->filled('product_id')) {
            $query->whereHas('productVariant', function ($q) use ($request) {
                $q->where('product_id', $request->input('product_id'));
            });
        }

        // Filter by low stock (available quantity below threshold)
        if ($request->boolean('low_stock')) {
            $query->lowStock(10);
        }

        // Search by variant name
        if ($request->filled('search')) {
            $search = $request->input('search');
            $query->whereHas('productVariant', function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%");
            });
        }

        $stocks = $query->paginate(20)->withQueryString();

        // Load all active products for the filter dropdown
        $products = \App\Models\Product::active()->ordered()->get();

        return view('stockist.stocks.index', compact('stocks', 'products'));
    }

    /**
     * Show the order form for ordering stock from admin.
     *
     * Displays all available admin stock that the stockist can order from,
     * grouped by product name for easy browsing.
     *
     * @return \Illuminate\View\View
     */
    public function orderFromAdmin()
    {
        // Get all admin stock with available quantity
        $adminStocks = Stock::byType('admin')
            ->available()
            ->with(['productVariant.product'])
            ->get()
            ->groupBy('productVariant.product.name');

        return view('stockist.stocks.order', compact('adminStocks'));
    }

    /**
     * Place an order to the admin for stock replenishment.
     *
     * Validates the requested items, checks that the admin has sufficient
     * stock for each variant, reserves the admin stock, creates the order
     * with type 'stockist_to_admin', and records all order items.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function placeOrder(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'items'                      => 'required|array|min:1',
            'items.*.product_variant_id'  => 'required|integer|exists:product_variants,id',
            'items.*.quantity'            => 'required|integer|min:1',
            'notes'                      => 'nullable|string|max:500',
        ], [
            'items.required'                        => 'Minimal satu item harus dipilih.',
            'items.min'                             => 'Minimal satu item harus dipilih.',
            'items.*.product_variant_id.required'   => 'Varian produk wajib dipilih.',
            'items.*.product_variant_id.exists'     => 'Varian produk tidak valid.',
            'items.*.quantity.required'             => 'Jumlah wajib diisi.',
            'items.*.quantity.min'                  => 'Jumlah minimal 1.',
        ]);

        $order = null;

        DB::transaction(function () use ($validated, $user, &$order) {
            $orderItems = [];
            $subtotal = 0;

            foreach ($validated['items'] as $item) {
                // Find the product variant
                $variant = ProductVariant::findOrFail($item['product_variant_id']);

                // Check admin stock availability
                $adminStock = Stock::byType('admin')
                    ->where('product_variant_id', $item['product_variant_id'])
                    ->first();

                if (!$adminStock || $adminStock->available_quantity < $item['quantity']) {
                    $available = $adminStock ? $adminStock->available_quantity : 0;
                    throw new \Exception(
                        "Stok admin tidak mencukupi untuk varian {$variant->name}. Tersedia: {$available}, Diminta: {$item['quantity']}."
                    );
                }

                // Reserve the stock on admin side
                $adminStock->increment('reserved_quantity', $item['quantity']);

                // Calculate item subtotal
                $itemSubtotal = $variant->price * $item['quantity'];
                $subtotal += $itemSubtotal;

                $orderItems[] = new OrderItem([
                    'product_variant_id' => $item['product_variant_id'],
                    'quantity'           => $item['quantity'],
                    'price_per_unit'     => $variant->price,
                    'subtotal'           => $itemSubtotal,
                ]);
            }

            // Create the order
            $order = Order::create([
                'user_id'       => $user->id,
                'seller_id'     => 0, // Admin (system user)
                'order_type'    => 'stockist_to_admin',
                'status'        => 'pending',
                'subtotal'      => $subtotal,
                'shipping_cost' => 0,
                'total'         => $subtotal,
                'notes'         => $validated['notes'] ?? null,
            ]);

            // Save order items
            $order->orderItems()->saveMany($orderItems);
        });

        // Notify admin users about the new order
        $adminUsers = \App\Models\User::byRole('admin')->active()->get();
        foreach ($adminUsers as $admin) {
            Notification::create([
                'user_id' => $admin->id,
                'title'   => 'Pesanan Baru dari Stockist',
                'message' => "Stockist {$user->name} membuat pesanan baru #{$order->order_number}.",
                'type'    => 'stockist_order_placed',
                'data'    => [
                    'order_id'  => $order->id,
                    'stockist_id' => $user->id,
                ],
            ]);
        }

        $this->logActivity('stockist.order_placed', "Stockist {$user->name} melakukan pemesanan ke admin. Pesanan #{$order->order_number}.", [
            'user_id'  => $user->id,
            'order_id' => $order->id,
        ]);

        return redirect()->route('stockist.orders.show', $order->id)
            ->with('success', 'Pesanan ke admin berhasil dibuat. Menunggu persetujuan admin.');
    }

    /**
     * Adjust (update) the stockist's stock quantity for a specific stock entry.
     *
     * Allows the stockist to manually increase or decrease their stock quantity.
     * The new quantity must be >= the currently reserved quantity.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id  The stock entry ID
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStock(Request $request, $id)
    {
        $user = Auth::user();

        // Ensure the stock belongs to this stockist
        $stock = Stock::where('id', $id)
            ->where('user_id', $user->id)
            ->where('type', 'stockist')
            ->firstOrFail();

        $validated = $request->validate([
            'quantity'   => 'required|integer|min:0',
            'adjustment_reason' => 'nullable|string|max:500',
        ], [
            'quantity.required' => 'Jumlah stok wajib diisi.',
            'quantity.min'      => 'Jumlah stok tidak boleh negatif.',
            'quantity.integer'  => 'Jumlah stok harus berupa angka bulat.',
        ]);

        // Cannot set quantity below reserved_quantity
        if ($validated['quantity'] < $stock->reserved_quantity) {
            return redirect()->back()
                ->withInput()
                ->withErrors([
                    'quantity' => "Jumlah tidak boleh kurang dari stok yang terpesan ({$stock->reserved_quantity}).",
                ]);
        }

        $oldQuantity = $stock->quantity;
        $newQuantity = $validated['quantity'];
        $difference  = $newQuantity - $oldQuantity;

        DB::transaction(function () use ($stock, $newQuantity) {
            $stock->update(['quantity' => $newQuantity]);
        });

        $actionType = $difference > 0 ? 'penambahan' : ($difference < 0 ? 'pengurangan' : 'perubahan');
        $absDifference = abs($difference);

        $this->logActivity('stockist.stock_updated', "Stockist {$user->name} melakukan {$actionType} stok varian {$stock->productVariant->name}: {$oldQuantity} → {$newQuantity} (selisih: {$absDifference}).", [
            'stock_id'     => $stock->id,
            'variant_id'   => $stock->product_variant_id,
            'old_quantity' => $oldQuantity,
            'new_quantity' => $newQuantity,
            'difference'   => $difference,
            'reason'       => $validated['adjustment_reason'] ?? null,
        ]);

        $message = $difference > 0
            ? "Stok {$stock->productVariant->name} berhasil ditambah sebanyak {$absDifference}."
            : ($difference < 0
                ? "Stok {$stock->productVariant->name} berhasil dikurangi sebanyak {$absDifference}."
                : "Stok {$stock->productVariant->name} tidak berubah.");

        return redirect()->route('stockist.stocks.index')
            ->with('success', $message);
    }
}
