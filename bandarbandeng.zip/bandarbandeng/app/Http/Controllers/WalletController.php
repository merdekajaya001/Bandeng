<?php

namespace App\Http\Controllers;

use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/**
 * WalletController
 *
 * Handles the authenticated user's wallet operations:
 * - Viewing wallet balance and recent transactions
 * - Creating top-up requests with proof of payment
 * - Browsing full transaction history with filters
 */
class WalletController extends Controller
{
    /**
     * Display the authenticated user's wallet with recent transactions.
     *
     * Shows the wallet balance, pending balance, and the latest
     * 10 transactions for quick overview.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $user = Auth::user();
        $wallet = $user->wallet;

        // If the user somehow doesn't have a wallet, create one
        if (!$wallet) {
            $wallet = $user->createWallet();
        }

        $recentTransactions = $wallet->transactions()
            ->recent()
            ->take(10)
            ->get();

        return view('wallet.index', compact('wallet', 'recentTransactions'));
    }

    /**
     * Create a top-up request with proof of payment.
     *
     * Validates the amount and proof image, then creates a pending
     * deposit transaction. The balance will be credited once an
     * admin approves the top-up.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function topUp(Request $request)
    {
        $user = Auth::user();
        $wallet = $user->wallet;

        if (!$wallet) {
            $wallet = $user->createWallet();
        }

        $validated = $request->validate([
            'amount'      => 'required|numeric|min:10000',
            'proof_image' => 'required|image|mimes:jpeg,jpg,png,webp|max:2048',
            'notes'       => 'nullable|string|max:500',
        ], [
            'amount.required'      => 'Jumlah top-up wajib diisi.',
            'amount.numeric'       => 'Jumlah top-up harus berupa angka.',
            'amount.min'           => 'Jumlah top-up minimal Rp 10.000.',
            'proof_image.required' => 'Bukti pembayaran wajib diunggah.',
            'proof_image.image'    => 'Bukti pembayaran harus berupa gambar.',
            'proof_image.mimes'    => 'Format gambar harus JPG, PNG, atau WebP.',
            'proof_image.max'      => 'Ukuran gambar maksimal 2MB.',
            'notes.max'            => 'Catatan maksimal 500 karakter.',
        ]);

        DB::transaction(function () use ($validated, $wallet, $user) {
            // Store the proof image
            $proofPath = null;
            if (isset($validated['proof_image'])) {
                $proofPath = $validated['proof_image']->store('topup-proofs', 'public');
            }

            // Create a pending deposit transaction
            // The balance_after stays at current balance until admin approves
            $wallet->transactions()->create([
                'type'          => 'deposit',
                'amount'        => $validated['amount'],
                'balance_after' => $wallet->balance,
                'description'   => 'Permintaan top-up saldo' . ($validated['notes'] ? ': ' . $validated['notes'] : ''),
                'status'        => 'pending',
                'reference_type' => 'App\Models\WalletTransaction',
                'reference_id'  => null,
            ]);

            // Store the proof path in the wallet's latest transaction metadata
            // We update the transaction record with proof info
            $latestTransaction = $wallet->transactions()->latest()->first();
            if ($latestTransaction && $proofPath) {
                // Use the description or a separate column to track the proof
                // Since WalletTransaction doesn't have a proof_image column,
                // we store it in the reference_type pattern or update description
                $latestTransaction->update([
                    'description' => $latestTransaction->description . ' [bukti: ' . $proofPath . ']',
                ]);
            }
        });

        $this->logActivity('wallet.topup', "User {$user->name} requested top-up of Rp " . number_format($validated['amount'], 0, ',', '.'), [
            'amount' => $validated['amount'],
            'wallet_id' => $wallet->id,
        ]);

        return redirect()->route('wallet.index')
            ->with('success', 'Permintaan top-up sebesar Rp ' . number_format($validated['amount'], 0, ',', '.') . ' berhasil dikirim. Menunggu konfirmasi admin.');
    }

    /**
     * Display the full transaction history with filters.
     *
     * Supports filtering by:
     * - type (deposit, withdrawal, payment, refund, commission)
     * - status (pending, completed, failed, cancelled)
     * - date_from / date_to (date range)
     *
     * Results are paginated (15 per page).
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function history(Request $request)
    {
        $user = Auth::user();
        $wallet = $user->wallet;

        if (!$wallet) {
            $wallet = $user->createWallet();
        }

        // Build the query with optional filters
        $query = $wallet->transactions()->recent();

        // Filter by transaction type
        if ($request->filled('type')) {
            $query->byType($request->input('type'));
        }

        // Filter by transaction status
        if ($request->filled('status')) {
            $query->byStatus($request->input('status'));
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->where('created_at', '>=', $request->input('date_from') . ' 00:00:00');
        }

        if ($request->filled('date_to')) {
            $query->where('created_at', '<=', $request->input('date_to') . ' 23:59:59');
        }

        $transactions = $query->paginate(15)->withQueryString();

        // Pass current filter values for form persistence
        $filters = [
            'type'      => $request->input('type', ''),
            'status'    => $request->input('status', ''),
            'date_from' => $request->input('date_from', ''),
            'date_to'   => $request->input('date_to', ''),
        ];

        return view('wallet.history', compact('wallet', 'transactions', 'filters'));
    }
}
