<?php

namespace App\Http\Controllers;

use App\Models\Withdrawal;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

/**
 * WithdrawalController
 *
 * Handles the authenticated user's withdrawal requests:
 * - Displaying the withdrawal form
 * - Submitting a withdrawal request with bank details
 *
 * Minimum withdrawal amount is Rp 50.000. Upon submission,
 * the amount is moved from the wallet's balance to pending_balance
 * and a withdrawal record is created with 'pending' status.
 * The funds will be released once an admin processes the request.
 */
class WithdrawalController extends Controller
{
    /**
     * Show the withdrawal form.
     *
     * Passes the user's wallet info so the view can display
     * the available balance and pre-fill bank details if
     * the user has previously made a withdrawal.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $user = Auth::user();
        $wallet = $user->wallet;

        if (!$wallet) {
            $wallet = $user->createWallet();
        }

        // Get the user's most recent withdrawal to pre-fill bank details
        $lastWithdrawal = $user->withdrawals()->latest()->first();

        return view('withdrawal.create', compact('wallet', 'lastWithdrawal'));
    }

    /**
     * Store a new withdrawal request.
     *
     * Validates the amount (minimum Rp 50.000), bank details, and
     * checks that the wallet has sufficient balance. Within a DB
     * transaction:
     * 1. Deducts the amount from wallet balance
     * 2. Adds the amount to wallet pending_balance
     * 3. Creates a pending withdrawal record
     * 4. Creates a wallet transaction record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $user = Auth::user();
        $wallet = $user->wallet;

        if (!$wallet) {
            $wallet = $user->createWallet();
        }

        // Validate the request
        $validated = $request->validate([
            'amount'       => 'required|numeric|min:50000',
            'bank_name'    => 'required|string|max:100',
            'bank_account' => 'required|string|max:50',
            'bank_holder'  => 'required|string|max:255',
            'notes'        => 'nullable|string|max:500',
        ], [
            'amount.required'       => 'Jumlah penarikan wajib diisi.',
            'amount.numeric'        => 'Jumlah penarikan harus berupa angka.',
            'amount.min'            => 'Jumlah penarikan minimal Rp 50.000.',
            'bank_name.required'    => 'Nama bank wajib diisi.',
            'bank_name.max'         => 'Nama bank maksimal 100 karakter.',
            'bank_account.required' => 'Nomor rekening wajib diisi.',
            'bank_account.max'      => 'Nomor rekening maksimal 50 karakter.',
            'bank_holder.required'  => 'Nama pemilik rekening wajib diisi.',
            'bank_holder.max'       => 'Nama pemilik rekening maksimal 255 karakter.',
            'notes.max'             => 'Catatan maksimal 500 karakter.',
        ]);

        // Check for sufficient wallet balance
        if (!$wallet->hasSufficientBalance($validated['amount'])) {
            return redirect()->back()
                ->withErrors(['amount' => 'Saldo tidak mencukupi. Saldo tersedia: Rp ' . number_format($wallet->balance, 0, ',', '.')])
                ->withInput();
        }

        // Check for existing pending withdrawals (only one pending at a time)
        $hasPendingWithdrawal = $user->withdrawals()->pending()->exists();

        if ($hasPendingWithdrawal) {
            return redirect()->back()
                ->withErrors(['amount' => 'Anda masih memiliki permintaan penarikan yang sedang diproses. Harap tunggu hingga selesai.'])
                ->withInput();
        }

        // Execute the withdrawal within a database transaction
        DB::transaction(function () use ($validated, $user, $wallet) {
            // Step 1: Deduct the amount from wallet balance
            $wallet->decrement('balance', $validated['amount']);

            // Step 2: Add the amount to pending_balance
            $wallet->increment('pending_balance', $validated['amount']);

            // Refresh to get the updated values
            $wallet->refresh();

            // Step 3: Create the withdrawal record
            $withdrawal = Withdrawal::create([
                'user_id'      => $user->id,
                'amount'       => $validated['amount'],
                'bank_name'    => $validated['bank_name'],
                'bank_account' => $validated['bank_account'],
                'bank_holder'  => $validated['bank_holder'],
                'status'       => 'pending',
                'notes'        => $validated['notes'] ?? null,
            ]);

            // Step 4: Create a wallet transaction record for the withdrawal
            $wallet->transactions()->create([
                'type'           => 'withdrawal',
                'amount'         => $validated['amount'],
                'balance_after'  => $wallet->balance,
                'description'    => 'Permintaan penarikan ke ' . $validated['bank_name'] . ' (' . $validated['bank_account'] . ')',
                'status'         => 'pending',
                'reference_type' => Withdrawal::class,
                'reference_id'   => $withdrawal->id,
            ]);
        });

        // Log the withdrawal activity
        $this->logActivity('withdrawal.requested', "User {$user->name} requested withdrawal of Rp " . number_format($validated['amount'], 0, ',', '.'), [
            'amount'       => $validated['amount'],
            'bank_name'    => $validated['bank_name'],
            'bank_account' => $validated['bank_account'],
            'bank_holder'  => $validated['bank_holder'],
        ]);

        return redirect()->route('wallet.index')
            ->with('success', 'Permintaan penarikan sebesar Rp ' . number_format($validated['amount'], 0, ',', '.') . ' berhasil dikirim. Dana telah dipotong dari saldo dan sedang menunggu proses admin.');
    }
}
