<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * Middleware: CheckStatusMiddleware
 *
 * Checks if the authenticated user's account is active (is_active = true).
 * If the account is inactive, the user is logged out and redirected
 * to the login page with an informational message.
 */
class CheckStatusMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Only check if the user is authenticated
        if (Auth::check()) {
            $user = Auth::user();

            // If the user's account is not active, log them out and redirect
            if (!$user->is_active) {
                Auth::logout();

                // Invalidate the session and regenerate the CSRF token
                $request->session()->invalidate();
                $request->session()->regenerateToken();

                if ($request->expectsJson()) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Akun Anda telah dinonaktifkan. Silakan hubungi administrator.',
                    ], 403);
                }

                return redirect()->route('login')
                    ->with('error', 'Akun Anda telah dinonaktifkan. Silakan hubungi administrator.');
            }
        }

        return $next($request);
    }
}
