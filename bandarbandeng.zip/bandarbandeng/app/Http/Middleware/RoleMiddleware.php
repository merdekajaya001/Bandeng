<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * Middleware: RoleMiddleware
 *
 * Checks if the authenticated user has the required role(s).
 * Supports: admin, stockist, agent, customer.
 * Redirects to the appropriate login page if not authenticated
 * or to the home page if the user lacks the required role.
 */
class RoleMiddleware
{
    /**
     * Role-based login route mapping.
     *
     * @var array<string, string>
     */
    protected array $loginRoutes = [
        'admin'     => 'admin.login',
        'stockist'  => 'stockist.login',
        'agent'     => 'agent.login',
        'customer'  => 'login',
    ];

    /**
     * Role-based dashboard route mapping.
     *
     * @var array<string, string>
     */
    protected array $dashboardRoutes = [
        'admin'     => 'admin.dashboard',
        'stockist'  => 'stockist.dashboard',
        'agent'     => 'agent.dashboard',
        'customer'  => 'customer.dashboard',
    ];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     * @param  string  ...$roles  One or more roles to check against (e.g., 'admin', 'stockist')
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        // Step 1: Check if the user is authenticated
        if (!Auth::check()) {
            // Determine which login page to redirect to based on the required roles
            $loginRoute = $this->resolveLoginRoute($roles);

            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Silakan login terlebih dahulu.',
                ], 401);
            }

            return redirect()->route($loginRoute)
                ->with('error', 'Silakan login terlebih dahulu.')
                ->withInput();
        }

        $user = Auth::user();

        // Step 2: Check if the user's role matches any of the required roles
        if (empty($roles)) {
            // No specific role required, just needs to be authenticated
            return $next($request);
        }

        if (!in_array($user->role, $roles, true)) {
            // User is authenticated but does not have the required role
            if ($request->expectsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Anda tidak memiliki akses ke halaman ini.',
                ], 403);
            }

            // Redirect the user to their own dashboard with an error message
            $dashboardRoute = $this->dashboardRoutes[$user->role] ?? 'home';

            return redirect()->route($dashboardRoute)
                ->with('error', 'Anda tidak memiliki akses ke halaman ini.');
        }

        return $next($request);
    }

    /**
     * Resolve the appropriate login route based on the required roles.
     *
     * @param  array<int, string>  $roles
     * @return string
     */
    protected function resolveLoginRoute(array $roles): string
    {
        foreach ($roles as $role) {
            if (isset($this->loginRoutes[$role])) {
                return $this->loginRoutes[$role];
            }
        }

        // Default to the generic login route
        return 'login';
    }
}
