<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

/**
 * Middleware: SetLocaleMiddleware
 *
 * Sets the application locale based on the session value.
 * Defaults to 'id' (Indonesian) if no session value is present.
 * Supports locale switching via a query parameter (?locale=id).
 */
class SetLocaleMiddleware
{
    /**
     * The session key used to store the locale preference.
     *
     * @var string
     */
    protected string $sessionKey = 'locale';

    /**
     * The default locale for the application.
     *
     * @var string
     */
    protected string $defaultLocale = 'id';

    /**
     * Supported locales for the application.
     *
     * @var array<int, string>
     */
    protected array $supportedLocales = ['id', 'en'];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Step 1: Check for a locale query parameter and persist it in the session
        if ($request->has($this->sessionKey)) {
            $requestedLocale = $request->input($this->sessionKey);

            if (in_array($requestedLocale, $this->supportedLocales, true)) {
                session([$this->sessionKey => $requestedLocale]);
            }
        }

        // Step 2: Retrieve the locale from the session (or use the default)
        $locale = session($this->sessionKey, $this->defaultLocale);

        // Step 3: Set the application locale
        App::setLocale($locale);

        return $next($request);
    }
}
