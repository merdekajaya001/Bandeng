<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Symfony\Component\HttpFoundation\Response;

/**
 * Middleware: ThemeMiddleware
 *
 * Detects and sets the theme preference for the application.
 * Supports three modes:
 *   - auto:  Determines light/dark based on time of day (6am–6pm = light, else dark)
 *   - light: Forces the light theme
 *   - dark:  Forces the dark theme
 *
 * The resolved theme is shared with all views via View::share('theme', ...).
 * Theme preference is stored in the session under the key 'theme'.
 */
class ThemeMiddleware
{
    /**
     * The session key used to store the theme preference.
     *
     * @var string
     */
    protected string $sessionKey = 'theme';

    /**
     * The default theme mode.
     *
     * @var string
     */
    protected string $defaultMode = 'auto';

    /**
     * Valid theme modes.
     *
     * @var array<int, string>
     */
    protected array $validModes = ['auto', 'light', 'dark'];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Step 1: Check for a theme query parameter and persist it in the session
        if ($request->has($this->sessionKey)) {
            $requestedMode = $request->input($this->sessionKey);

            if (in_array($requestedMode, $this->validModes, true)) {
                session([$this->sessionKey => $requestedMode]);
            }
        }

        // Step 2: Retrieve the theme mode from the session (or use the default)
        $mode = session($this->sessionKey, $this->defaultMode);

        // Step 3: Resolve the actual theme based on the mode
        $theme = $this->resolveTheme($mode);

        // Step 4: Determine is_dark flag
        $isDark = $theme === 'dark';

        // Step 5: Share the theme, mode, and is_dark with all views
        View::share('theme', $theme);
        View::share('themeMode', $mode);
        View::share('is_dark', $isDark);

        return $next($request);
    }

    /**
     * Resolve the actual theme ('light' or 'dark') based on the mode.
     *
     * In 'auto' mode, the theme is determined by the current hour:
     *   - 06:00 to 17:59 (6am to before 6pm) → light
     *   - 18:00 to 05:59 (6pm to before 6am) → dark
     *
     * @param  string  $mode  One of: auto, light, dark
     * @return string  The resolved theme: 'light' or 'dark'
     */
    protected function resolveTheme(string $mode): string
    {
        return match ($mode) {
            'light' => 'light',
            'dark'  => 'dark',
            'auto'  => $this->resolveAutoTheme(),
            default => $this->resolveAutoTheme(),
        };
    }

    /**
     * Determine the theme based on the time of day.
     *
     * @return string  'light' or 'dark'
     */
    protected function resolveAutoTheme(): string
    {
        $hour = now()->hour;

        // 6am (inclusive) to 6pm (exclusive) → light
        // Everything else → dark
        return ($hour >= 6 && $hour < 18) ? 'light' : 'dark';
    }
}
