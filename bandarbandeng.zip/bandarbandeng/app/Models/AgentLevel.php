<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/**
 * App\Models\AgentLevel
 *
 * @property int $id
 * @property string $name
 * @property string $slug
 * @property string|null $description
 * @property string $min_total_sales
 * @property string $discount_percent
 * @property string $commission_percent
 * @property string|null $icon
 * @property string|null $color
 * @property bool $is_active
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class AgentLevel extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'slug',
        'description',
        'min_total_sales',
        'discount_percent',
        'commission_percent',
        'icon',
        'color',
        'is_active',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'min_total_sales' => 'decimal:2',
        'discount_percent' => 'decimal:2',
        'commission_percent' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * The users that belong to the agent level (via user_agent_levels pivot).
     */
    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'user_agent_levels', 'agent_level_id', 'user_id')
            ->withPivot(['current_monthly_sales', 'assigned_at'])
            ->withTimestamps();
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter only active agent levels.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope: Order agent levels by minimum total sales ascending.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOrdered($query)
    {
        return $query->orderBy('min_total_sales')->orderBy('name');
    }
}
