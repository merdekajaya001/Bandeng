<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * App\Models\Complaint
 *
 * @property int $id
 * @property int $order_id
 * @property int $user_id
 * @property string $type
 * @property string $description
 * @property array|null $images
 * @property string $status
 * @property string|null $resolution
 * @property \Illuminate\Support\Carbon|null $resolved_at
 * @property int|null $resolved_by
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class Complaint extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'order_id',
        'user_id',
        'type',
        'description',
        'images',
        'status',
        'resolution',
        'resolved_at',
        'resolved_by',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'images' => 'array',
        'resolved_at' => 'datetime',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the order that the complaint belongs to.
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get the user who filed the complaint.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the user who resolved the complaint.
     */
    public function resolvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'resolved_by');
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter complaints by status.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $status  One of: open, in_progress, resolved, closed
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope: Filter complaints by type.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $type  One of: product_damage, wrong_item, late_delivery, other
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByType($query, string $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Scope: Filter only open complaints (not yet resolved or closed).
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOpen($query)
    {
        return $query->whereIn('status', ['open', 'in_progress']);
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    /**
     * Get the human-readable type label.
     *
     * @return string
     */
    public function getTypeLabelAttribute(): string
    {
        return match ($this->type) {
            'product_damage' => 'Produk Rusak',
            'wrong_item' => 'Barang Salah',
            'late_delivery' => 'Pengiriman Terlambat',
            'other' => 'Lainnya',
            default => ucfirst(str_replace('_', ' ', $this->type)),
        };
    }

    /**
     * Get the human-readable status label.
     *
     * @return string
     */
    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'open' => 'Terbuka',
            'in_progress' => 'Sedang Ditangani',
            'resolved' => 'Terselesaikan',
            'closed' => 'Ditutup',
            default => ucfirst(str_replace('_', ' ', $this->status)),
        };
    }

    /**
     * Get the status color for UI display.
     *
     * @return string
     */
    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'open' => 'red',
            'in_progress' => 'yellow',
            'resolved' => 'green',
            'closed' => 'gray',
            default => 'gray',
        };
    }

    /**
     * Get the images as an array of full URLs.
     *
     * @return array<int, string>
     */
    public function getImagesArrayAttribute(): array
    {
        if (empty($this->images) || !is_array($this->images)) {
            return [];
        }

        return collect($this->images)
            ->filter(fn ($image) => \Illuminate\Support\Facades\Storage::disk('public')->exists($image))
            ->map(fn ($image) => \Illuminate\Support\Facades\Storage::disk('public')->url($image))
            ->values()
            ->toArray();
    }
}
