<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Str;

/**
 * App\Models\Order
 *
 * @property int $id
 * @property string $order_number
 * @property int $user_id
 * @property int $seller_id
 * @property string $order_type
 * @property string $status
 * @property string $subtotal
 * @property string $shipping_cost
 * @property string $total
 * @property string|null $notes
 * @property string|null $shipping_address
 * @property string|null $shipping_city
 * @property string|null $shipping_province
 * @property string|null $shipping_postal_code
 * @property string|null $recipient_name
 * @property string|null $recipient_phone
 * @property string|null $tracking_number
 * @property \Illuminate\Support\Carbon|null $shipped_at
 * @property \Illuminate\Support\Carbon|null $delivered_at
 * @property \Illuminate\Support\Carbon|null $cancelled_at
 * @property string|null $cancellation_reason
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class Order extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'order_number',
        'user_id',
        'seller_id',
        'order_type',
        'status',
        'subtotal',
        'shipping_cost',
        'total',
        'notes',
        'shipping_address',
        'shipping_city',
        'shipping_province',
        'shipping_postal_code',
        'recipient_name',
        'recipient_phone',
        'tracking_number',
        'shipped_at',
        'delivered_at',
        'cancelled_at',
        'cancellation_reason',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'subtotal' => 'decimal:2',
        'shipping_cost' => 'decimal:2',
        'total' => 'decimal:2',
        'shipped_at' => 'datetime',
        'delivered_at' => 'datetime',
        'cancelled_at' => 'datetime',
    ];

    // =========================================================================
    // Boot
    // =========================================================================

    /**
     * Boot the model and set up auto-generating order_number on creating.
     */
    protected static function boot(): void
    {
        parent::boot();

        static::creating(function (Order $order) {
            if (empty($order->order_number)) {
                $order->order_number = static::generateOrderNumber();
            }
        });
    }

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the buyer (user) that owns the order.
     */
    public function buyer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Get the seller (user) that owns the order.
     */
    public function seller(): BelongsTo
    {
        return $this->belongsTo(User::class, 'seller_id');
    }

    /**
     * Get all order items for the order.
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Get all payments for the order.
     */
    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    /**
     * Get all ratings for the order.
     */
    public function ratings(): HasMany
    {
        return $this->hasMany(Rating::class);
    }

    /**
     * Get all complaints for the order.
     */
    public function complaints(): HasMany
    {
        return $this->hasMany(Complaint::class);
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter orders by status.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $status
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope: Filter orders by order type.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $type
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByType($query, string $type)
    {
        return $query->where('order_type', $type);
    }

    /**
     * Scope: Order by most recent first.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeRecent($query)
    {
        return $query->orderBy('created_at', 'desc');
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    /**
     * Get the human-readable status label.
     *
     * @return string
     */
    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'Menunggu',
            'confirmed' => 'Dikonfirmasi',
            'processing' => 'Diproses',
            'shipped' => 'Dikirim',
            'delivered' => 'Diterima',
            'completed' => 'Selesai',
            'cancelled' => 'Dibatalkan',
            'refunded' => 'Dikembalikan',
            default => ucfirst($this->status),
        };
    }

    /**
     * Get the status color for UI display.
     *
     * @return string
     */
    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'yellow',
            'confirmed' => 'blue',
            'processing' => 'indigo',
            'shipped' => 'purple',
            'delivered' => 'teal',
            'completed' => 'green',
            'cancelled' => 'red',
            'refunded' => 'orange',
            default => 'gray',
        };
    }

    /**
     * Get the human-readable order type label.
     *
     * @return string
     */
    public function getOrderTypeLabelAttribute(): string
    {
        return match ($this->order_type) {
            'stockist_to_admin' => 'Stockist → Admin',
            'agent_to_stockist' => 'Agen → Stockist',
            'customer_to_agent' => 'Pelanggan → Agen',
            default => ucfirst(str_replace('_', ' ', $this->order_type)),
        };
    }

    /**
     * Determine if the order can be cancelled.
     *
     * @return bool
     */
    public function getCanCancelAttribute(): bool
    {
        return in_array($this->status, ['pending', 'confirmed']);
    }

    /**
     * Determine if the order can be confirmed.
     *
     * @return bool
     */
    public function getCanConfirmAttribute(): bool
    {
        return $this->status === 'pending';
    }

    /**
     * Determine if the order can be shipped.
     *
     * @return bool
     */
    public function getCanShipAttribute(): bool
    {
        return in_array($this->status, ['confirmed', 'processing']);
    }

    /**
     * Determine if the order can be marked as completed.
     *
     * @return bool
     */
    public function getCanCompleteAttribute(): bool
    {
        return in_array($this->status, ['shipped', 'delivered']);
    }

    // =========================================================================
    // Methods
    // =========================================================================

    /**
     * Generate a unique order number.
     *
     * Format: ORD-YYYYMMDD-XXXXXX (e.g., ORD-20240115-A3F2K9)
     *
     * @return string
     */
    public static function generateOrderNumber(): string
    {
        $prefix = 'ORD-' . now()->format('Ymd') . '-';

        do {
            $random = strtoupper(Str::random(6));
            $orderNumber = $prefix . $random;
        } while (static::where('order_number', $orderNumber)->exists());

        return $orderNumber;
    }

    /**
     * Calculate and return the total from order items.
     *
     * @return string
     */
    public function calculateTotal(): string
    {
        $subtotal = $this->orderItems->sum('subtotal');

        $this->subtotal = $subtotal;
        $this->total = $subtotal + $this->shipping_cost;
        $this->save();

        return $this->total;
    }
}
