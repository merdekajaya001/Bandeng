<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Storage;

/**
 * App\Models\Payment
 *
 * @property int $id
 * @property int $order_id
 * @property string $payment_method
 * @property string $amount
 * @property string $status
 * @property string|null $proof_image
 * @property string|null $bank_name
 * @property string|null $bank_account
 * @property string|null $bank_holder
 * @property \Illuminate\Support\Carbon|null $verified_at
 * @property int|null $verified_by
 * @property string|null $rejected_reason
 * @property string|null $notes
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class Payment extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'order_id',
        'payment_method',
        'amount',
        'status',
        'proof_image',
        'bank_name',
        'bank_account',
        'bank_holder',
        'verified_at',
        'verified_by',
        'rejected_reason',
        'notes',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'amount' => 'decimal:2',
        'verified_at' => 'datetime',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the order that owns the payment.
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get the user who verified the payment.
     */
    public function verifiedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'verified_by');
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter payments with pending status.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    /**
     * Scope: Filter payments with verified status.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeVerified($query)
    {
        return $query->where('status', 'verified');
    }

    /**
     * Scope: Filter payments by payment method.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $method
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByMethod($query, string $method)
    {
        return $query->where('payment_method', $method);
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    /**
     * Get the human-readable status label.
     *
     * @return string
     */
    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'Menunggu Verifikasi',
            'verified' => 'Terverifikasi',
            'rejected' => 'Ditolak',
            'refunded' => 'Dikembalikan',
            default => ucfirst($this->status),
        };
    }

    /**
     * Get the status color for UI display.
     *
     * @return string
     */
    public function getStatusColorAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'yellow',
            'verified' => 'green',
            'rejected' => 'red',
            'refunded' => 'orange',
            default => 'gray',
        };
    }

    /**
     * Get the full URL for the payment proof image.
     *
     * @return string|null
     */
    public function getProofImageUrlAttribute(): ?string
    {
        if ($this->proof_image && Storage::disk('public')->exists($this->proof_image)) {
            return Storage::disk('public')->url($this->proof_image);
        }

        return null;
    }
}
