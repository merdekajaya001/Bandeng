<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Storage;

/**
 * App\Models\ProductVariant
 *
 * @property int $id
 * @property int $product_id
 * @property string $name
 * @property string $slug
 * @property string|null $description
 * @property int $fish_count
 * @property string $price
 * @property string $weight_kg
 * @property string|null $image
 * @property bool $is_active
 * @property int $sort_order
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class ProductVariant extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'product_id',
        'name',
        'slug',
        'description',
        'fish_count',
        'price',
        'weight_kg',
        'image',
        'is_active',
        'sort_order',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'is_active' => 'boolean',
        'price' => 'decimal:2',
        'weight_kg' => 'decimal:2',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the product that owns the variant.
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Get all stocks for this variant.
     */
    public function stocks(): HasMany
    {
        return $this->hasMany(Stock::class);
    }

    /**
     * Get all order items for this variant.
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter only active variants.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope: Order variants by sort_order.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order')->orderBy('name');
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    /**
     * Get the full URL for the variant image.
     *
     * @return string
     */
    public function getImageUrlAttribute(): string
    {
        if ($this->image && Storage::disk('public')->exists($this->image)) {
            return Storage::disk('public')->url($this->image);
        }

        // Fallback to parent product image
        if ($this->product && $this->product->image) {
            return $this->product->image_url;
        }

        return asset('images/default-product.png');
    }

    /**
     * Get the human-readable fish count label.
     *
     * Examples:
     *   fish_count = 5 → "5 Ekor/kg"
     *   fish_count = 1 → "Per Ekor"
     *   fish_count = 2 → "2 Ekor/kg"
     *
     * @return string
     */
    public function getFishCountLabelAttribute(): string
    {
        if ($this->fish_count === 1) {
            return 'Per Ekor';
        }

        return "{$this->fish_count} Ekor/kg";
    }
}
