<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * App\Models\Stock
 *
 * @property int $id
 * @property int $product_variant_id
 * @property int $user_id
 * @property int $quantity
 * @property int $reserved_quantity
 * @property string $type
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class Stock extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'product_variant_id',
        'user_id',
        'quantity',
        'reserved_quantity',
        'type',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'quantity' => 'integer',
        'reserved_quantity' => 'integer',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the product variant that owns the stock.
     */
    public function productVariant(): BelongsTo
    {
        return $this->belongsTo(ProductVariant::class);
    }

    /**
     * Get the user (owner) that owns the stock.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter stocks by owner type.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $type  One of: admin, stockist, agent
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByType($query, string $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Scope: Filter stocks that have available quantity.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeAvailable($query)
    {
        return $query->whereColumn('quantity', '>', 'reserved_quantity');
    }

    /**
     * Scope: Filter stocks with low available quantity (below threshold).
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  int  $threshold  The low stock threshold (default: 10)
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeLowStock($query, int $threshold = 10)
    {
        return $query->whereRaw('(quantity - reserved_quantity) < ?', [$threshold]);
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    /**
     * Get the available quantity (quantity minus reserved).
     *
     * @return int
     */
    public function getAvailableQuantityAttribute(): int
    {
        return max(0, $this->quantity - $this->reserved_quantity);
    }
}
