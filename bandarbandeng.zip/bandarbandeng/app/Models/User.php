<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Storage;

/**
 * App\Models\User
 *
 * @property int $id
 * @property string $name
 * @property string $email
 * @property \Illuminate\Support\Carbon|null $email_verified_at
 * @property string $password
 * @property string $role
 * @property string|null $phone
 * @property string|null $address
 * @property string|null $city
 * @property string|null $province
 * @property string|null $postal_code
 * @property string|null $latitude
 * @property string|null $longitude
 * @property string|null $avatar
 * @property bool $is_active
 * @property \Illuminate\Support\Carbon|null $last_login_at
 * @property string|null $remember_token
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class User extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'phone',
        'address',
        'city',
        'province',
        'postal_code',
        'latitude',
        'longitude',
        'avatar',
        'is_active',
        'last_login_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'last_login_at' => 'datetime',
        'is_active' => 'boolean',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the user's wallet.
     */
    public function wallet(): HasOne
    {
        return $this->hasOne(Wallet::class);
    }

    /**
     * Get the orders where the user is the buyer.
     */
    public function buyerOrders(): HasMany
    {
        return $this->hasMany(Order::class, 'user_id');
    }

    /**
     * Get the orders where the user is the seller.
     */
    public function sellerOrders(): HasMany
    {
        return $this->hasMany(Order::class, 'seller_id');
    }

    /**
     * Get all stocks owned by the user.
     */
    public function stocks(): HasMany
    {
        return $this->hasMany(Stock::class);
    }

    /**
     * Get the user's withdrawals.
     */
    public function withdrawals(): HasMany
    {
        return $this->hasMany(Withdrawal::class);
    }

    /**
     * Get the ratings given by the user.
     */
    public function givenRatings(): HasMany
    {
        return $this->hasMany(Rating::class, 'user_id');
    }

    /**
     * Get the ratings received by the user.
     */
    public function receivedRatings(): HasMany
    {
        return $this->hasMany(Rating::class, 'rated_user_id');
    }

    /**
     * Get the complaints filed by the user.
     */
    public function complaints(): HasMany
    {
        return $this->hasMany(Complaint::class);
    }

    /**
     * Get the user's notifications.
     */
    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class);
    }

    /**
     * Get the user's activity logs.
     */
    public function activityLogs(): HasMany
    {
        return $this->hasMany(ActivityLog::class);
    }

    /**
     * Get the agent areas covered by the user.
     */
    public function agentAreas(): HasMany
    {
        return $this->hasMany(AgentArea::class);
    }

    /**
     * The badges that belong to the user.
     */
    public function agentBadges(): BelongsToMany
    {
        return $this->belongsToMany(AgentBadge::class, 'user_badges', 'user_id', 'agent_badge_id')
            ->withPivot('earned_at')
            ->withTimestamps();
    }

    /**
     * Get the agent level associated with the user via user_agent_levels pivot.
     */
    public function agentLevel()
    {
        return $this->belongsToMany(AgentLevel::class, 'user_agent_levels', 'user_id', 'agent_level_id')
            ->withPivot(['current_monthly_sales', 'assigned_at'])
            ->withTimestamps();
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter users by role.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $role
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByRole($query, string $role)
    {
        return $query->where('role', $role);
    }

    /**
     * Scope: Filter only active users.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope: Filter only agent users.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeAgents($query)
    {
        return $query->where('role', 'agent');
    }

    /**
     * Scope: Filter only stockist users.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeStockists($query)
    {
        return $query->where('role', 'stockist');
    }

    /**
     * Scope: Find nearby agents within a given radius (in kilometers).
     *
     * Uses the Haversine formula for geographic distance calculation.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  float  $lat  Latitude of the center point
     * @param  float  $lng  Longitude of the center point
     * @param  float  $radius  Radius in kilometers (default: 10)
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeNearbyAgents($query, float $lat, float $lng, float $radius = 10)
    {
        $haversine = "(6371 * acos(cos(radians({$lat}))
            * cos(radians(latitude))
            * cos(radians(longitude) - radians({$lng}))
            + sin(radians({$lat}))
            * sin(radians(latitude))))";

        return $query
            ->where('role', 'agent')
            ->where('is_active', true)
            ->whereNotNull('latitude')
            ->whereNotNull('longitude')
            ->selectRaw("*, {$haversine} AS distance")
            ->having('distance', '<=', $radius)
            ->orderBy('distance');
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    /**
     * Get the human-readable role label.
     *
     * @return string
     */
    public function getRoleLabelAttribute(): string
    {
        return match ($this->role) {
            'admin' => 'Administrator',
            'stockist' => 'Stockist',
            'agent' => 'Agen',
            'customer' => 'Pelanggan',
            default => ucfirst($this->role),
        };
    }

    /**
     * Get the full address as a formatted string.
     *
     * @return string
     */
    public function getFullAddressAttribute(): string
    {
        $parts = array_filter([
            $this->address,
            $this->city,
            $this->province,
            $this->postal_code,
        ]);

        return implode(', ', $parts) ?: '-';
    }

    /**
     * Get the full URL for the user's avatar.
     *
     * @return string
     */
    public function getAvatarUrlAttribute(): string
    {
        if ($this->avatar && Storage::disk('public')->exists($this->avatar)) {
            return Storage::disk('public')->url($this->avatar);
        }

        return asset('images/default-avatar.png');
    }

    /**
     * Determine if the user is an admin.
     *
     * @return bool
     */
    public function getIsAdminAttribute(): bool
    {
        return $this->role === 'admin';
    }

    /**
     * Determine if the user is a stockist.
     *
     * @return bool
     */
    public function getIsStockistAttribute(): bool
    {
        return $this->role === 'stockist';
    }

    /**
     * Determine if the user is an agent.
     *
     * @return bool
     */
    public function getIsAgentAttribute(): bool
    {
        return $this->role === 'agent';
    }

    /**
     * Determine if the user is a customer.
     *
     * @return bool
     */
    public function getIsCustomerAttribute(): bool
    {
        return $this->role === 'customer';
    }

    // =========================================================================
    // Methods
    // =========================================================================

    /**
     * Check if the user has the given role(s).
     *
     * @param  string|array  $role  A single role or an array of roles to check against
     * @return bool
     */
    public function hasRole(string|array $role): bool
    {
        if (is_array($role)) {
            return in_array($this->role, $role);
        }

        return $this->role === $role;
    }

    /**
     * Create a wallet for the user.
     *
     * @return \App\Models\Wallet
     */
    public function createWallet(): Wallet
    {
        return $this->wallet()->create([
            'balance' => 0,
            'pending_balance' => 0,
        ]);
    }

    /**
     * Get the nearest agents from a given location.
     *
     * @param  float  $lat   Latitude of the center point
     * @param  float  $lng   Longitude of the center point
     * @param  int    $limit Maximum number of agents to return
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public static function getNearestAgents(float $lat, float $lng, int $limit = 5)
    {
        return static::nearbyAgents($lat, $lng, 50)
            ->limit($limit)
            ->get();
    }
}
