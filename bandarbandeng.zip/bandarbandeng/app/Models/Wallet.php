<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

/**
 * App\Models\Wallet
 *
 * @property int $id
 * @property int $user_id
 * @property string $balance
 * @property string $pending_balance
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class Wallet extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'balance',
        'pending_balance',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'balance' => 'decimal:2',
        'pending_balance' => 'decimal:2',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the user that owns the wallet.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get all transactions for the wallet.
     */
    public function transactions(): HasMany
    {
        return $this->hasMany(WalletTransaction::class);
    }

    // =========================================================================
    // Methods
    // =========================================================================

    /**
     * Deposit (add) funds to the wallet.
     *
     * Creates a completed deposit transaction and increments the balance.
     *
     * @param  float  $amount
     * @param  string|null  $description
     * @return \App\Models\WalletTransaction
     */
    public function deposit(float $amount, ?string $description = null): WalletTransaction
    {
        $this->increment('balance', $amount);
        $this->refresh();

        return $this->transactions()->create([
            'type' => 'deposit',
            'amount' => $amount,
            'balance_after' => $this->balance,
            'description' => $description ?? 'Deposit saldo',
            'status' => 'completed',
        ]);
    }

    /**
     * Withdraw (subtract) funds from the wallet.
     *
     * Creates a completed withdrawal transaction and decrements the balance.
     * Throws an exception if insufficient balance.
     *
     * @param  float  $amount
     * @param  string|null  $description
     * @return \App\Models\WalletTransaction
     * @throws \Exception
     */
    public function withdraw(float $amount, ?string $description = null): WalletTransaction
    {
        if (!$this->hasSufficientBalance($amount)) {
            throw new \Exception('Saldo tidak mencukupi untuk melakukan penarikan.');
        }

        $this->decrement('balance', $amount);
        $this->refresh();

        return $this->transactions()->create([
            'type' => 'withdrawal',
            'amount' => $amount,
            'balance_after' => $this->balance,
            'description' => $description ?? 'Penarikan saldo',
            'status' => 'completed',
        ]);
    }

    /**
     * Check if the wallet has sufficient balance for the given amount.
     *
     * @param  float  $amount
     * @return bool
     */
    public function hasSufficientBalance(float $amount): bool
    {
        return $this->balance >= $amount;
    }

    /**
     * Get the current wallet balance.
     *
     * @return string
     */
    public function getBalance(): string
    {
        return $this->balance;
    }
}
