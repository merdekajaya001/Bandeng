<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

/**
 * App\Models\WalletTransaction
 *
 * @property int $id
 * @property int $wallet_id
 * @property string $type
 * @property string $amount
 * @property string $balance_after
 * @property string|null $description
 * @property string|null $reference_type
 * @property int|null $reference_id
 * @property string $status
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 */
class WalletTransaction extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'wallet_id',
        'type',
        'amount',
        'balance_after',
        'description',
        'reference_type',
        'reference_id',
        'status',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'amount' => 'decimal:2',
        'balance_after' => 'decimal:2',
    ];

    // =========================================================================
    // Relationships
    // =========================================================================

    /**
     * Get the wallet that owns the transaction.
     */
    public function wallet(): BelongsTo
    {
        return $this->belongsTo(Wallet::class);
    }

    /**
     * Get the polymorphic reference model (e.g., Order, Payment, Withdrawal).
     */
    public function reference(): MorphTo
    {
        return $this->morphTo();
    }

    // =========================================================================
    // Scopes
    // =========================================================================

    /**
     * Scope: Filter transactions by type.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $type  One of: deposit, withdrawal, payment, refund, commission
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByType($query, string $type)
    {
        return $query->where('type', $type);
    }

    /**
     * Scope: Filter transactions by status.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @param  string  $status  One of: pending, completed, failed, cancelled
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeByStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope: Order by most recent first.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeRecent($query)
    {
        return $query->orderBy('created_at', 'desc');
    }

    // =========================================================================
    // Accessors
    // =========================================================================

    /**
     * Get the human-readable type label.
     *
     * @return string
     */
    public function getTypeLabelAttribute(): string
    {
        return match ($this->type) {
            'deposit' => 'Deposit',
            'withdrawal' => 'Penarikan',
            'payment' => 'Pembayaran',
            'refund' => 'Pengembalian',
            'commission' => 'Komisi',
            default => ucfirst($this->type),
        };
    }

    /**
     * Get the human-readable status label.
     *
     * @return string
     */
    public function getStatusLabelAttribute(): string
    {
        return match ($this->status) {
            'pending' => 'Menunggu',
            'completed' => 'Selesai',
            'failed' => 'Gagal',
            'cancelled' => 'Dibatalkan',
            default => ucfirst($this->status),
        };
    }
}
