<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        /**
         * Set the default currency for the application.
         * Bandar Bandeng uses Indonesian Rupiah (IDR).
         */
        config([
            'app.company_name' => env('COMPANY_NAME', 'Bandar Bandeng Kalimantan'),
            'app.company_tagline' => env('COMPANY_TAGLINE', 'Bandeng Tanpa Duri Segar dari Kalimantan'),
            'app.wa_number' => env('WA_NUMBER', '082243922576'),
        ]);
    }
}
