<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        // 'App\Models\Model' => 'App\Policies\ModelPolicy',
        'App\Models\Product' => 'App\Policies\ProductPolicy',
        'App\Models\Order' => 'App\Policies\OrderPolicy',
        'App\Models\Stock' => 'App\Policies\StockPolicy',
        'App\Models\Agent' => 'App\Policies\AgentPolicy',
        'App\Models\Stockist' => 'App\Policies\StockistPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        /**
         * Define a gate that checks if the authenticated user is an admin.
         */
        Gate::define('admin-access', function ($user) {
            return $user->hasRole('admin');
        });

        /**
         * Define a gate that checks if the authenticated user is a stockist.
         */
        Gate::define('stockist-access', function ($user) {
            return $user->hasRole('stockist');
        });

        /**
         * Define a gate that checks if the authenticated user is an agent.
         */
        Gate::define('agent-access', function ($user) {
            return $user->hasRole('agent');
        });

        /**
         * Define a gate that checks if the authenticated user is a customer.
         */
        Gate::define('customer-access', function ($user) {
            return $user->hasRole('customer');
        });

        /**
         * Define a gate that allows admin and stockist to manage products.
         */
        Gate::define('manage-products', function ($user) {
            return $user->hasRole(['admin', 'stockist']);
        });

        /**
         * Define a gate that allows admin and stockist to manage stock/inventory.
         */
        Gate::define('manage-stock', function ($user) {
            return $user->hasRole(['admin', 'stockist']);
        });

        /**
         * Define a gate that allows admin and stockist to manage orders.
         */
        Gate::define('manage-orders', function ($user) {
            return $user->hasRole(['admin', 'stockist', 'agent']);
        });
    }
}
