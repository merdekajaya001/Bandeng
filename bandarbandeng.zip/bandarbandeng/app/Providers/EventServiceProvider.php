<?php

namespace App\Providers;

use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event to listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],

        \App\Events\OrderPlaced::class => [
            \App\Listeners\SendOrderConfirmationNotification::class,
            \App\Listeners\UpdateStockAfterOrder::class,
        ],

        \App\Events\OrderStatusUpdated::class => [
            \App\Listeners\SendOrderStatusNotification::class,
        ],

        \App\Events\PaymentConfirmed::class => [
            \App\Listeners\ProcessPaymentConfirmation::class,
            \App\Listeners\SendPaymentConfirmationNotification::class,
        ],

        \App\Events\LowStockAlert::class => [
            \App\Listeners\SendLowStockNotification::class,
        ],

        \App\Events\AgentRegistered::class => [
            \App\Listeners\SendAgentWelcomeNotification::class,
            \App\Listeners\NotifyAdminNewAgent::class,
        ],
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Determine if events and listeners should be automatically discovered.
     *
     * @return bool
     */
    public function shouldDiscoverEvents()
    {
        return false;
    }
}
