<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    /**
     * The path to the "home" route for your application.
     *
     * Typically, users are redirected here after authentication.
     *
     * @var string
     */
    public const HOME = '/home';

    /**
     * The home routes per role for the Bandar Bandeng application.
     *
     * After login, each role is redirected to their respective dashboard.
     *
     * @var array<string, string>
     */
    public const ROLE_HOMES = [
        'admin' => '/admin/dashboard',
        'stockist' => '/stockist/dashboard',
        'agent' => '/agent/dashboard',
        'customer' => '/customer/dashboard',
    ];

    /**
     * Define your route model bindings, pattern filters, and other route configuration.
     *
     * @return void
     */
    public function boot()
    {
        $this->configureRateLimiting();

        $this->routes(function () {
            Route::middleware('api')
                ->prefix('api')
                ->group(base_path('routes/api.php'));

            Route::middleware('web')
                ->group(base_path('routes/web.php'));
        });

        /**
         * Custom route model bindings for Bandar Bandeng.
         */
        Route::bind('product', function ($value) {
            return \App\Models\Product::where('slug', $value)->firstOrFail();
        });

        Route::bind('category', function ($value) {
            return \App\Models\Category::where('slug', $value)->firstOrFail();
        });

        Route::bind('order', function ($value) {
            return \App\Models\Order::where('order_number', $value)->firstOrFail();
        });
    }

    /**
     * Configure the rate limiters for the application.
     *
     * @return void
     */
    protected function configureRateLimiting()
    {
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
        });

        RateLimiter::for('web', function (Request $request) {
            return Limit::perMinute(120)->by($request->user()?->id ?: $request->ip());
        });

        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)->by($request->ip());
        });

        RateLimiter::for('checkout', function (Request $request) {
            return Limit::perMinute(10)->by($request->user()?->id ?: $request->ip());
        });
    }
}
