<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_variants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained('products')->cascadeOnDelete()->cascadeOnUpdate();
            $table->string('name');
            $table->string('slug');
            $table->text('description')->nullable();
            $table->integer('fish_count')->default(1)->comment('Number of fish per kg: 5, 4, 3, or 1 (per ekor)');
            $table->decimal('price', 15, 2)->default(0);
            $table->decimal('weight_kg', 8, 2)->default(1)->comment('Weight in kg per unit');
            $table->string('image')->nullable();
            $table->boolean('is_active')->default(true);
            $table->integer('sort_order')->default(0);
            $table->timestamps();

            // Unique slug per product
            $table->unique(['product_id', 'slug']);

            // Indexes for frequently queried columns
            $table->index('is_active');
            $table->index('sort_order');
            $table->index('fish_count');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('product_variants');
    }
};
