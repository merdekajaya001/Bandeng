<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('stocks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_variant_id')->constrained('product_variants')->cascadeOnDelete()->cascadeOnUpdate();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete()->cascadeOnUpdate()->comment('Owner of the stock');
            $table->integer('quantity')->default(0);
            $table->integer('reserved_quantity')->default(0);
            $table->enum('type', ['admin', 'stockist', 'agent'])->comment('Type of stock owner');
            $table->timestamps();

            // Unique constraint: one stock record per variant per user
            $table->unique(['product_variant_id', 'user_id', 'type'], 'stocks_variant_user_type_unique');

            // Indexes for frequently queried columns
            $table->index('user_id');
            $table->index('type');
            $table->index('quantity');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('stocks');
    }
};
