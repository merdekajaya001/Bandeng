<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete()->cascadeOnUpdate();
            $table->enum('payment_method', ['deposit', 'bank_transfer']);
            $table->decimal('amount', 15, 2)->default(0);
            $table->enum('status', ['pending', 'verified', 'rejected', 'refunded'])->default('pending');
            $table->string('proof_image')->nullable();
            $table->string('bank_name')->nullable();
            $table->string('bank_account')->nullable();
            $table->string('bank_holder')->nullable();
            $table->timestamp('verified_at')->nullable();
            $table->foreignId('verified_by')->nullable()->constrained('users')->nullOnDelete()->cascadeOnUpdate();
            $table->string('rejected_reason')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            // Indexes for frequently queried columns
            $table->index('order_id');
            $table->index('status');
            $table->index('payment_method');
            $table->index('verified_by');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
