<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ratings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete()->cascadeOnUpdate();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete()->cascadeOnUpdate()->comment('The user who gives the rating');
            $table->foreignId('rated_user_id')->constrained('users')->cascadeOnDelete()->cascadeOnUpdate()->comment('The user being rated');
            $table->tinyInteger('rating')->comment('Rating from 1 to 5');
            $table->text('review')->nullable();
            $table->boolean('is_anonymous')->default(false);
            $table->timestamps();

            // Indexes for frequently queried columns
            $table->index('order_id');
            $table->index('user_id');
            $table->index('rated_user_id');
            $table->index('rating');

            // A user can only rate once per order
            $table->unique(['order_id', 'user_id'], 'ratings_order_user_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ratings');
    }
};
