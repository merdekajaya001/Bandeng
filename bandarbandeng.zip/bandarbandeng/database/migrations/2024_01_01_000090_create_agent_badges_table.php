<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('agent_badges', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->string('icon')->nullable();
            $table->integer('min_orders')->default(0)->comment('Minimum number of orders to earn this badge');
            $table->decimal('min_rating', 3, 2)->default(0)->comment('Minimum average rating to earn this badge');
            $table->string('color')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            // Indexes for frequently queried columns
            $table->index('slug');
            $table->index('is_active');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('agent_badges');
    }
};
