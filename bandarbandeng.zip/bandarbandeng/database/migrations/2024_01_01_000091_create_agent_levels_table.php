<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('agent_levels', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->decimal('min_total_sales', 15, 2)->default(0)->comment('Minimum total sales to reach this level');
            $table->decimal('discount_percent', 5, 2)->default(0)->comment('Discount percentage for agents at this level');
            $table->decimal('commission_percent', 5, 2)->default(0)->comment('Commission percentage for agents at this level');
            $table->string('icon')->nullable();
            $table->string('color')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            // Indexes for frequently queried columns
            $table->index('slug');
            $table->index('is_active');
            $table->index('min_total_sales');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('agent_levels');
    }
};
