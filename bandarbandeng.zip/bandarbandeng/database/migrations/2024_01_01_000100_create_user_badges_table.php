<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_badges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete()->cascadeOnUpdate();
            $table->foreignId('agent_badge_id')->constrained('agent_badges')->cascadeOnDelete()->cascadeOnUpdate();
            $table->timestamp('earned_at')->useCurrent();

            // A user can only earn a specific badge once
            $table->unique(['user_id', 'agent_badge_id'], 'user_badges_user_badge_unique');

            // Indexes for frequently queried columns
            $table->index('user_id');
            $table->index('agent_badge_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_badges');
    }
};
