<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_agent_levels', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete()->cascadeOnUpdate();
            $table->foreignId('agent_level_id')->constrained('agent_levels')->cascadeOnDelete()->cascadeOnUpdate();
            $table->decimal('current_monthly_sales', 15, 2)->default(0);
            $table->timestamp('assigned_at')->useCurrent();

            // A user can only have one active level at a time
            $table->unique(['user_id'], 'user_agent_levels_user_unique');

            // Indexes for frequently queried columns
            $table->index('user_id');
            $table->index('agent_level_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_agent_levels');
    }
};
