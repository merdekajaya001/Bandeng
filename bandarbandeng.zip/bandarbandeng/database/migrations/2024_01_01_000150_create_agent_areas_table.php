<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('agent_areas', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete()->cascadeOnUpdate()->comment('The agent covering this area');
            $table->string('city');
            $table->string('province');
            $table->decimal('coverage_radius_km', 8, 2)->default(0)->comment('Coverage radius in kilometers');
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            // Indexes for frequently queried columns
            $table->index('user_id');
            $table->index('city');
            $table->index('province');
            $table->index('is_active');
            $table->index(['city', 'province', 'is_active']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('agent_areas');
    }
};
