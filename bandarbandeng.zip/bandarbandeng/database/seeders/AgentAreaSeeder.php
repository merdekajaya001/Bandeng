<?php

namespace Database\Seeders;

use App\Models\AgentArea;
use App\Models\User;
use Illuminate\Database\Seeder;

class AgentAreaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates coverage areas for each agent, defining their
     * service radius and the cities/provinces they cover.
     */
    public function run(): void
    {
        // ─── Define agent coverage areas ───────────────────────────────
        $areas = [
            [
                'email'              => 'agen@bandarbandeng.com',
                'city'               => 'Banjarmasin',
                'province'           => 'Kalimantan Selatan',
                'coverage_radius_km' => 15,
            ],
            [
                'email'              => 'agen2@bandarbandeng.com',
                'city'               => 'Martapura',
                'province'           => 'Kalimantan Selatan',
                'coverage_radius_km' => 10,
            ],
            [
                'email'              => 'agen3@bandarbandeng.com',
                'city'               => 'Samarinda',
                'province'           => 'Kalimantan Timur',
                'coverage_radius_km' => 20,
            ],
        ];

        foreach ($areas as $areaData) {
            $user = User::where('email', $areaData['email'])->first();

            if (! $user) {
                $this->command->warn("⚠ Agent not found: {$areaData['email']}. Skipping area creation.");
                continue;
            }

            AgentArea::create([
                'user_id'            => $user->id,
                'city'               => $areaData['city'],
                'province'           => $areaData['province'],
                'coverage_radius_km' => $areaData['coverage_radius_km'],
                'is_active'          => true,
            ]);
        }

        $this->command->info('🗺️ Created 3 agent coverage areas');
    }
}
