<?php

namespace Database\Seeders;

use App\Models\AgentBadge;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class AgentBadgeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates the agent badge tiers that agents can earn based on
     * their order count and rating performance.
     */
    public function run(): void
    {
        $badges = [
            [
                'name'        => 'Agen Pemula',
                'slug'        => 'agen-pemula',
                'description' => 'Badge awal untuk agen yang baru bergabung. Setiap agen yang terdaftar otomatis mendapatkan badge ini.',
                'icon'        => 'fa-seedling',
                'min_orders'  => 0,
                'min_rating'  => 0,
                'color'       => 'green',
                'is_active'   => true,
            ],
            [
                'name'        => 'Agen Andalan',
                'slug'        => 'agen-andalan',
                'description' => 'Badge untuk agen yang telah menyelesaikan minimal 50 pesanan dengan rating minimal 4.0. Menandakan keandalan dan konsistensi layanan.',
                'icon'        => 'fa-star',
                'min_orders'  => 50,
                'min_rating'  => 4.0,
                'color'       => 'blue',
                'is_active'   => true,
            ],
            [
                'name'        => 'Agen Utama',
                'slug'        => 'agen-utama',
                'description' => 'Badge prestisius untuk agen berpengalaman dengan minimal 200 pesanan dan rating 4.5. Hanya agen terbaik yang mencapai level ini.',
                'icon'        => 'fa-crown',
                'min_orders'  => 200,
                'min_rating'  => 4.5,
                'color'       => 'gold',
                'is_active'   => true,
            ],
            [
                'name'        => 'Agen Legenda',
                'slug'        => 'agen-legenda',
                'description' => 'Badge tertinggi untuk agen luar biasa dengan 500+ pesanan dan rating sempurna 4.8+. Agen legenda adalah simbol keunggulan layanan tertinggi.',
                'icon'        => 'fa-gem',
                'min_orders'  => 500,
                'min_rating'  => 4.8,
                'color'       => 'purple',
                'is_active'   => true,
            ],
        ];

        foreach ($badges as $badgeData) {
            AgentBadge::create($badgeData);
        }

        $this->command->info('🏅 Created 4 agent badge tiers');
    }
}
