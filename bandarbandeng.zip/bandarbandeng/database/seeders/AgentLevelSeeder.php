<?php

namespace Database\Seeders;

use App\Models\AgentLevel;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class AgentLevelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates the agent level tiers that determine discount and
     * commission rates based on cumulative sales performance.
     */
    public function run(): void
    {
        $levels = [
            [
                'name'               => 'Regular',
                'slug'               => 'regular',
                'description'        => 'Level awal untuk semua agen baru. Mendapatkan komisi dasar 5% tanpa diskon tambahan.',
                'min_total_sales'    => 0,
                'discount_percent'   => 0,
                'commission_percent' => 5,
                'icon'               => 'fa-user',
                'color'              => 'gray',
                'is_active'          => true,
            ],
            [
                'name'               => 'Silver',
                'slug'               => 'silver',
                'description'        => 'Level Silver untuk agen dengan penjualan kumulatif di atas Rp 5 juta. Mendapatkan diskon 2% dan komisi 7%.',
                'min_total_sales'    => 5000000,
                'discount_percent'   => 2,
                'commission_percent' => 7,
                'icon'               => 'fa-medal',
                'color'              => 'silver',
                'is_active'          => true,
            ],
            [
                'name'               => 'Gold',
                'slug'               => 'gold',
                'description'        => 'Level Gold untuk agen dengan penjualan kumulatif di atas Rp 20 juta. Mendapatkan diskon 5% dan komisi 10%.',
                'min_total_sales'    => 20000000,
                'discount_percent'   => 5,
                'commission_percent' => 10,
                'icon'               => 'fa-award',
                'color'              => 'gold',
                'is_active'          => true,
            ],
            [
                'name'               => 'Platinum',
                'slug'               => 'platinum',
                'description'        => 'Level tertinggi untuk agen elit dengan penjualan kumulatif di atas Rp 50 juta. Mendapatkan diskon 8% dan komisi 15%.',
                'min_total_sales'    => 50000000,
                'discount_percent'   => 8,
                'commission_percent' => 15,
                'icon'               => 'fa-gem',
                'color'              => 'purple',
                'is_active'          => true,
            ],
        ];

        foreach ($levels as $levelData) {
            AgentLevel::create($levelData);
        }

        $this->command->info('📊 Created 4 agent level tiers');
    }
}
