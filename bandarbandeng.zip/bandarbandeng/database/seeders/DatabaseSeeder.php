<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * Truncates all relevant tables (respecting foreign key constraints)
     * then runs each individual seeder in the correct dependency order.
     */
    public function run(): void
    {
        // ─── Disable foreign key checks for safe truncation ────────────
        Schema::disableForeignKeyConstraints();

        // Truncate all tables in reverse dependency order
        $tables = [
            'payments',
            'order_items',
            'orders',
            'wallet_transactions',
            'wallets',
            'stocks',
            'user_agent_levels',
            'user_badges',
            'agent_areas',
            'testimonials',
            'notifications',
            'activity_logs',
            'ratings',
            'complaints',
            'withdrawals',
            'product_variants',
            'products',
            'agent_levels',
            'agent_badges',
            'users',
            'password_resets',
            'failed_jobs',
        ];

        foreach ($tables as $table) {
            DB::table($table)->truncate();
        }

        Schema::enableForeignKeyConstraints();

        // ─── Run seeders in dependency order ───────────────────────────
        $this->call([
            UserSeeder::class,
            ProductSeeder::class,
            StockSeeder::class,
            WalletSeeder::class,
            AgentBadgeSeeder::class,
            AgentLevelSeeder::class,
            TestimonialSeeder::class,
            AgentAreaSeeder::class,
            OrderDemoSeeder::class,
        ]);

        $this->command->info('✅ All seeders executed successfully!');
    }
}
