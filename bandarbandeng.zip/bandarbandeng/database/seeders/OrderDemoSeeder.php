<?php

namespace Database\Seeders;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\ProductVariant;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class OrderDemoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates 8 demo orders demonstrating the full supply chain:
     *   - customer_to_agent: Customer → Agent
     *   - agent_to_stockist: Agent → Stockist
     *   - stockist_to_admin: Stockist → Admin
     *
     * Includes various statuses (completed, pending, processing, etc.)
     * and associated payments and order items.
     */
    public function run(): void
    {
        // ─── Fetch users ───────────────────────────────────────────────
        $admin      = User::where('email', 'admin@bandarbandeng.com')->first();
        $stockist1  = User::where('email', 'stockist@bandarbandeng.com')->first();
        $stockist2  = User::where('email', 'stockist2@bandarbandeng.com')->first();
        $agent1     = User::where('email', 'agen@bandarbandeng.com')->first();
        $agent2     = User::where('email', 'agen2@bandarbandeng.com')->first();
        $agent3     = User::where('email', 'agen3@bandarbandeng.com')->first();
        $customer1  = User::where('email', 'customer@bandarbandeng.com')->first();
        $customer2  = User::where('email', 'customer2@bandarbandeng.com')->first();
        $customer3  = User::where('email', 'customer3@bandarbandeng.com')->first();

        // ─── Fetch variants ────────────────────────────────────────────
        $variant5 = ProductVariant::where('slug', 'bandeng-5-ekor')->first();
        $variant4 = ProductVariant::where('slug', 'bandeng-4-ekor')->first();
        $variant3 = ProductVariant::where('slug', 'bandeng-3-ekor')->first();
        $variant1 = ProductVariant::where('slug', 'bandeng-per-ekor')->first();

        if (! $variant5 || ! $variant4 || ! $variant3 || ! $variant1) {
            $this->command->warn('⚠ Product variants not found. Run ProductSeeder first.');

            return;
        }

        // ═══════════════════════════════════════════════════════════════
        // ORDER 1: Stockist → Admin (completed)
        // Stockist Banjarmasin restocks 20 units of each variant from Admin
        // ═══════════════════════════════════════════════════════════════
        $order1 = Order::create([
            'user_id'          => $stockist1->id,
            'seller_id'        => $admin->id,
            'order_type'       => 'stockist_to_admin',
            'status'           => 'completed',
            'subtotal'         => 6600000,
            'shipping_cost'    => 50000,
            'total'            => 6650000,
            'notes'            => 'Restok bulanan - stok awal',
            'shipping_address' => 'Jl. A. Yani KM 5, Banjarmasin',
            'shipping_city'    => 'Banjarmasin',
            'shipping_province' => 'Kalimantan Selatan',
            'shipping_postal_code' => '70123',
            'recipient_name'   => 'Stockist Banjarmasin',
            'recipient_phone'  => $stockist1->phone,
            'delivered_at'     => Carbon::now()->subDays(25),
            'created_at'       => Carbon::now()->subDays(28),
        ]);

        $this->createOrderItems($order1, [
            [$variant5->id, 20, $variant5->price],   // 20 × 85000 = 1,700,000
            [$variant4->id, 20, $variant4->price],   // 20 × 95000 = 1,900,000
            [$variant3->id, 20, $variant3->price],   // 20 × 115000 = 2,300,000
            [$variant1->id, 20, $variant1->price],   // 20 × 35000 = 700,000
        ]);

        Payment::create([
            'order_id'       => $order1->id,
            'payment_method' => 'bank_transfer',
            'amount'         => $order1->total,
            'status'         => 'verified',
            'bank_name'      => 'Bank BRI',
            'bank_account'   => '0012345678',
            'bank_holder'    => 'Stockist Banjarmasin',
            'verified_at'    => Carbon::now()->subDays(27),
            'verified_by'    => $admin->id,
            'notes'          => 'Pembayaran restok bulanan',
        ]);

        // ═══════════════════════════════════════════════════════════════
        // ORDER 2: Stockist → Admin (completed)
        // Stockist Samarinda restocks from Admin
        // ═══════════════════════════════════════════════════════════════
        $order2 = Order::create([
            'user_id'          => $stockist2->id,
            'seller_id'        => $admin->id,
            'order_type'       => 'stockist_to_admin',
            'status'           => 'completed',
            'subtotal'         => 4900000,
            'shipping_cost'    => 75000,
            'total'            => 4975000,
            'notes'            => 'Restok awal Samarinda',
            'shipping_address' => 'Jl. P. Diponegoro No. 45, Samarinda',
            'shipping_city'    => 'Samarinda',
            'shipping_province' => 'Kalimantan Timur',
            'shipping_postal_code' => '75124',
            'recipient_name'   => 'Stockist Samarinda',
            'recipient_phone'  => $stockist2->phone,
            'delivered_at'     => Carbon::now()->subDays(20),
            'created_at'       => Carbon::now()->subDays(23),
        ]);

        $this->createOrderItems($order2, [
            [$variant5->id, 15, $variant5->price],   // 15 × 85000 = 1,275,000
            [$variant4->id, 15, $variant4->price],   // 15 × 95000 = 1,425,000
            [$variant3->id, 15, $variant3->price],   // 15 × 115000 = 1,725,000
            [$variant1->id, 15, $variant1->price],   // 15 × 35000 = 525,000 (sub=4,950,000 but let's fix)
        ]);

        // Recalculate total based on actual items
        $order2->calculateTotal();

        Payment::create([
            'order_id'       => $order2->id,
            'payment_method' => 'bank_transfer',
            'amount'         => $order2->total,
            'status'         => 'verified',
            'bank_name'      => 'Bank Mandiri',
            'bank_account'   => '1287654321',
            'bank_holder'    => 'Stockist Samarinda',
            'verified_at'    => Carbon::now()->subDays(22),
            'verified_by'    => $admin->id,
        ]);

        // ═══════════════════════════════════════════════════════════════
        // ORDER 3: Agent → Stockist (completed)
        // Agent Rizki restocks 10 units from Stockist Banjarmasin
        // ═══════════════════════════════════════════════════════════════
        $order3 = Order::create([
            'user_id'          => $agent1->id,
            'seller_id'        => $stockist1->id,
            'order_type'       => 'agent_to_stockist',
            'status'           => 'completed',
            'subtotal'         => 3300000,
            'shipping_cost'    => 0,
            'total'            => 3300000,
            'notes'            => 'Restok agen - ambil langsung',
            'shipping_address' => 'Jl. Gatot Subroto, Banjarmasin',
            'shipping_city'    => 'Banjarmasin',
            'shipping_province' => 'Kalimantan Selatan',
            'shipping_postal_code' => '70125',
            'recipient_name'   => 'Agen Rizki',
            'recipient_phone'  => $agent1->phone,
            'delivered_at'     => Carbon::now()->subDays(15),
            'created_at'       => Carbon::now()->subDays(17),
        ]);

        $this->createOrderItems($order3, [
            [$variant5->id, 10, $variant5->price],   // 10 × 85000 = 850,000
            [$variant4->id, 10, $variant4->price],   // 10 × 95000 = 950,000
            [$variant3->id, 10, $variant3->price],   // 10 × 115000 = 1,150,000
            [$variant1->id, 10, $variant1->price],   // 10 × 35000 = 350,000
        ]);

        Payment::create([
            'order_id'       => $order3->id,
            'payment_method' => 'wallet',
            'amount'         => $order3->total,
            'status'         => 'verified',
            'verified_at'    => Carbon::now()->subDays(17),
            'verified_by'    => $stockist1->id,
            'notes'          => 'Pembayaran via saldo wallet',
        ]);

        // ═══════════════════════════════════════════════════════════════
        // ORDER 4: Agent → Stockist (completed)
        // Agent Berkah restocks from Stockist Banjarmasin
        // ═══════════════════════════════════════════════════════════════
        $order4 = Order::create([
            'user_id'          => $agent2->id,
            'seller_id'        => $stockist1->id,
            'order_type'       => 'agent_to_stockist',
            'status'           => 'completed',
            'subtotal'         => 2640000,
            'shipping_cost'    => 25000,
            'total'            => 2665000,
            'notes'            => 'Restok agen Martapura',
            'shipping_address' => 'Jl. M. Yamin, Martapura',
            'shipping_city'    => 'Martapura',
            'shipping_province' => 'Kalimantan Selatan',
            'shipping_postal_code' => '70611',
            'recipient_name'   => 'Agen Berkah',
            'recipient_phone'  => $agent2->phone,
            'delivered_at'     => Carbon::now()->subDays(12),
            'created_at'       => Carbon::now()->subDays(14),
        ]);

        $this->createOrderItems($order4, [
            [$variant5->id, 8, $variant5->price],    // 8 × 85000 = 680,000
            [$variant4->id, 8, $variant4->price],    // 8 × 95000 = 760,000
            [$variant3->id, 8, $variant3->price],    // 8 × 115000 = 920,000
            [$variant1->id, 8, $variant1->price],    // 8 × 35000 = 280,000
        ]);

        $order4->calculateTotal();

        Payment::create([
            'order_id'       => $order4->id,
            'payment_method' => 'bank_transfer',
            'amount'         => $order4->total,
            'status'         => 'verified',
            'bank_name'      => 'Bank BSI',
            'bank_account'   => '7234567890',
            'bank_holder'    => 'Agen Berkah',
            'verified_at'    => Carbon::now()->subDays(13),
            'verified_by'    => $stockist1->id,
        ]);

        // ═══════════════════════════════════════════════════════════════
        // ORDER 5: Customer → Agent (completed)
        // Budi Santoso orders 3 kg of Bandeng 4 Ekor from Agen Rizki
        // ═══════════════════════════════════════════════════════════════
        $order5 = Order::create([
            'user_id'          => $customer1->id,
            'seller_id'        => $agent1->id,
            'order_type'       => 'customer_to_agent',
            'status'           => 'completed',
            'subtotal'         => 285000,
            'shipping_cost'    => 10000,
            'total'            => 295000,
            'notes'            => 'Tolong yang fresh ya, untuk acara keluarga',
            'shipping_address' => 'Jl. S. Parman No. 12, Banjarmasin',
            'shipping_city'    => 'Banjarmasin',
            'shipping_province' => 'Kalimantan Selatan',
            'shipping_postal_code' => '70115',
            'recipient_name'   => 'Budi Santoso',
            'recipient_phone'  => $customer1->phone,
            'delivered_at'     => Carbon::now()->subDays(7),
            'created_at'       => Carbon::now()->subDays(10),
        ]);

        $this->createOrderItems($order5, [
            [$variant4->id, 3, $variant4->price],    // 3 × 95000 = 285,000
        ]);

        Payment::create([
            'order_id'       => $order5->id,
            'payment_method' => 'wallet',
            'amount'         => $order5->total,
            'status'         => 'verified',
            'verified_at'    => Carbon::now()->subDays(10),
            'verified_by'    => $agent1->id,
            'notes'          => 'Pembayaran via saldo wallet',
        ]);

        // ═══════════════════════════════════════════════════════════════
        // ORDER 6: Customer → Agent (completed)
        // Siti Aminah orders from Agen Berkah
        // ═══════════════════════════════════════════════════════════════
        $order6 = Order::create([
            'user_id'          => $customer2->id,
            'seller_id'        => $agent2->id,
            'order_type'       => 'customer_to_agent',
            'status'           => 'completed',
            'subtotal'         => 230000,
            'shipping_cost'    => 15000,
            'total'            => 245000,
            'notes'            => 'Kirim sore ya kak',
            'shipping_address' => 'Jl. Pangeran Diponegoro, Martapura',
            'shipping_city'    => 'Martapura',
            'shipping_province' => 'Kalimantan Selatan',
            'shipping_postal_code' => '70614',
            'recipient_name'   => 'Siti Aminah',
            'recipient_phone'  => $customer2->phone,
            'delivered_at'     => Carbon::now()->subDays(5),
            'created_at'       => Carbon::now()->subDays(7),
        ]);

        $this->createOrderItems($order6, [
            [$variant5->id, 2, $variant5->price],    // 2 × 85000 = 170,000
            [$variant1->id, 2, $variant1->price],    // 2 × 35000 = 70,000  (sub=240,000)
        ]);

        $order6->calculateTotal();

        Payment::create([
            'order_id'       => $order6->id,
            'payment_method' => 'bank_transfer',
            'amount'         => $order6->total,
            'status'         => 'verified',
            'bank_name'      => 'Bank BRI',
            'bank_account'   => '9876543210',
            'bank_holder'    => 'Siti Aminah',
            'verified_at'    => Carbon::now()->subDays(7),
            'verified_by'    => $agent2->id,
        ]);

        // ═══════════════════════════════════════════════════════════════
        // ORDER 7: Customer → Agent (pending)
        // Ahmad Fauzi orders from Agen Jaya - awaiting payment
        // ═══════════════════════════════════════════════════════════════
        $order7 = Order::create([
            'user_id'          => $customer3->id,
            'seller_id'        => $agent3->id,
            'order_type'       => 'customer_to_agent',
            'status'           => 'pending',
            'subtotal'         => 345000,
            'shipping_cost'    => 20000,
            'total'            => 365000,
            'notes'            => 'Untuk pesta ulang tahun anak',
            'shipping_address' => 'Jl. Ahmad Yani No. 88, Samarinda',
            'shipping_city'    => 'Samarinda',
            'shipping_province' => 'Kalimantan Timur',
            'shipping_postal_code' => '75113',
            'recipient_name'   => 'Ahmad Fauzi',
            'recipient_phone'  => $customer3->phone,
            'created_at'       => Carbon::now()->subHours(5),
        ]);

        $this->createOrderItems($order7, [
            [$variant3->id, 3, $variant3->price],    // 3 × 115000 = 345,000
        ]);

        Payment::create([
            'order_id'       => $order7->id,
            'payment_method' => 'bank_transfer',
            'amount'         => $order7->total,
            'status'         => 'pending',
            'bank_name'      => 'Bank BCA',
            'bank_account'   => '4567890123',
            'bank_holder'    => 'Ahmad Fauzi',
            'notes'          => 'Menunggu konfirmasi pembayaran',
        ]);

        // ═══════════════════════════════════════════════════════════════
        // ORDER 8: Agent → Stockist (processing)
        // Agent Jaya orders from Stockist Samarinda - payment verified
        // ═══════════════════════════════════════════════════════════════
        $order8 = Order::create([
            'user_id'          => $agent3->id,
            'seller_id'        => $stockist2->id,
            'order_type'       => 'agent_to_stockist',
            'status'           => 'processing',
            'subtotal'         => 3300000,
            'shipping_cost'    => 30000,
            'total'            => 3330000,
            'notes'            => 'Restok bulan ini',
            'shipping_address' => 'Jl. Bhayangkara, Samarinda',
            'shipping_city'    => 'Samarinda',
            'shipping_province' => 'Kalimantan Timur',
            'shipping_postal_code' => '75121',
            'recipient_name'   => 'Agen Jaya',
            'recipient_phone'  => $agent3->phone,
            'created_at'       => Carbon::now()->subDays(2),
        ]);

        $this->createOrderItems($order8, [
            [$variant5->id, 10, $variant5->price],   // 10 × 85000 = 850,000
            [$variant4->id, 10, $variant4->price],   // 10 × 95000 = 950,000
            [$variant3->id, 10, $variant3->price],   // 10 × 115000 = 1,150,000
            [$variant1->id, 10, $variant1->price],   // 10 × 35000 = 350,000
        ]);

        Payment::create([
            'order_id'       => $order8->id,
            'payment_method' => 'bank_transfer',
            'amount'         => $order8->total,
            'status'         => 'verified',
            'bank_name'      => 'Bank Mandiri',
            'bank_account'   => '1357924680',
            'bank_holder'    => 'Agen Jaya',
            'verified_at'    => Carbon::now()->subDays(1),
            'verified_by'    => $stockist2->id,
        ]);

        $this->command->info('🛒 Created 8 demo orders with payments and order items');
    }

    /**
     * Helper: Create order items for a given order.
     *
     * @param  \App\Models\Order  $order
     * @param  array  $items  Array of [product_variant_id, quantity, price_per_unit]
     * @return void
     */
    private function createOrderItems(Order $order, array $items): void
    {
        foreach ($items as [$variantId, $quantity, $pricePerUnit]) {
            OrderItem::create([
                'order_id'           => $order->id,
                'product_variant_id' => $variantId,
                'quantity'           => $quantity,
                'price_per_unit'     => $pricePerUnit,
                'subtotal'           => $quantity * $pricePerUnit,
            ]);
        }
    }
}
