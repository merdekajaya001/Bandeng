<?php

namespace Database\Seeders;

use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates the main boneless milkfish product and its size-based variants.
     */
    public function run(): void
    {
        // ─── Main Product ──────────────────────────────────────────────
        $product = Product::create([
            'name'             => 'Ikan Bandeng Tanpa Duri',
            'slug'             => 'ikan-bandeng-tanpa-duri',
            'category'         => 'bandeng',
            'description'      => 'Ikan bandeng premium tanpa duri, diproses secara higienis',
            'long_description' => 'Ikan bandeng premium tanpa duri dari Kalimantan, diproses secara higienis dengan standar kualitas tinggi. '
                                . 'Dipilih langsung dari tambak-tambak terbaik di pesisir Kalimantan Selatan dan Timur. '
                                . 'Setiap ekor bandeng diolah dengan teliti untuk memastikan tidak ada duri yang tersisa, '
                                . 'sehingga aman dan nyaman dikonsumsi oleh semua kalangan, termasuk anak-anak.',
            'is_active'        => true,
            'sort_order'       => 1,
        ]);

        // ─── Variants ──────────────────────────────────────────────────
        $variants = [
            [
                'name'        => 'Ukuran 5 Ekor/kg',
                'slug'        => 'bandeng-5-ekor',
                'fish_count'  => 5,
                'price'       => 85000,
                'weight_kg'   => 1,
                'description' => 'Bandeng ukuran kecil, 5 ekor per kilogram. Cocok untuk keluarga kecil.',
                'sort_order'  => 1,
            ],
            [
                'name'        => 'Ukuran 4 Ekor/kg',
                'slug'        => 'bandeng-4-ekor',
                'fish_count'  => 4,
                'price'       => 95000,
                'weight_kg'   => 1,
                'description' => 'Bandeng ukuran sedang, 4 ekor per kilogram. Ukuran paling populer.',
                'sort_order'  => 2,
            ],
            [
                'name'        => 'Ukuran 3 Ekor/kg',
                'slug'        => 'bandeng-3-ekor',
                'fish_count'  => 3,
                'price'       => 115000,
                'weight_kg'   => 1,
                'description' => 'Bandeng ukuran besar, 3 ekor per kilogram. Daging tebal dan empuk.',
                'sort_order'  => 3,
            ],
            [
                'name'        => 'Per Ekor',
                'slug'        => 'bandeng-per-ekor',
                'fish_count'  => 1,
                'price'       => 35000,
                'weight_kg'   => 0.33,
                'description' => 'Bandeng ukuran sedang, dijual per ekor. Cocok untuk yang ingin mencoba dulu.',
                'sort_order'  => 4,
            ],
        ];

        foreach ($variants as $variantData) {
            $product->variants()->create([
                'product_id'  => $product->id,
                'name'        => $variantData['name'],
                'slug'        => $variantData['slug'],
                'description' => $variantData['description'],
                'fish_count'  => $variantData['fish_count'],
                'price'       => $variantData['price'],
                'weight_kg'   => $variantData['weight_kg'],
                'is_active'   => true,
                'sort_order'  => $variantData['sort_order'],
            ]);
        }

        $this->command->info('🐟 Created 1 product with 4 variants');
    }
}
