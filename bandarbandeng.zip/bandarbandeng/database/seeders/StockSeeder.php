<?php

namespace Database\Seeders;

use App\Models\ProductVariant;
use App\Models\Stock;
use App\Models\User;
use Illuminate\Database\Seeder;

class StockSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates stock records for each variant, distributed across
     * admin, stockists, and agents to represent the supply chain.
     */
    public function run(): void
    {
        // ─── Fetch all variants ────────────────────────────────────────
        $variants = ProductVariant::all();

        if ($variants->isEmpty()) {
            $this->command->warn('⚠ No product variants found. Run ProductSeeder first.');

            return;
        }

        // ─── Define stock distribution ─────────────────────────────────
        // Each entry: [email, quantity_per_variant, stock_type]
        $stockDistribution = [
            ['admin@bandarbandeng.com',      100, 'admin'],
            ['stockist@bandarbandeng.com',    30, 'stockist'],
            ['stockist2@bandarbandeng.com',   20, 'stockist'],
            ['agen@bandarbandeng.com',        10, 'agent'],
            ['agen2@bandarbandeng.com',        8, 'agent'],
            ['agen3@bandarbandeng.com',       10, 'agent'],
        ];

        foreach ($stockDistribution as [$email, $quantity, $type]) {
            $user = User::where('email', $email)->first();

            if (! $user) {
                $this->command->warn("⚠ User not found: {$email}. Skipping stock creation.");
                continue;
            }

            foreach ($variants as $variant) {
                Stock::create([
                    'product_variant_id' => $variant->id,
                    'user_id'            => $user->id,
                    'quantity'           => $quantity,
                    'reserved_quantity'  => 0,
                    'type'               => $type,
                ]);
            }
        }

        $this->command->info('📦 Created stocks for 6 users across 4 variants (24 stock records)');
    }
}
