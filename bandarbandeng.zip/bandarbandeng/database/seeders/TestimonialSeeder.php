<?php

namespace Database\Seeders;

use App\Models\Testimonial;
use App\Models\User;
use Illuminate\Database\Seeder;

class TestimonialSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates 8 positive testimonials with Indonesian names
     * about boneless milkfish quality.
     */
    public function run(): void
    {
        $testimonials = [
            [
                'name'        => 'Ibu Ratna Dewi',
                'content'     => 'Bandeng tanpa durinya benar-benar praktis! Anak-anak saya jadi suka makan ikan karena tidak takut duri lagi. Rasanya juga segar dan gurih, pasti pesan lagi.',
                'rating'      => 5,
                'is_featured' => true,
            ],
            [
                'name'        => 'Pak Haji Sulaiman',
                'content'     => 'Sudah beberapa kali pesan bandeng dari sini, kualitasnya selalu konsisten. Dagingnya tebal dan tidak berbau lumpur sama sekali. Cocok untuk hidangan keluarga dan acara syukuran.',
                'rating'      => 5,
                'is_featured' => true,
            ],
            [
                'name'        => 'Siti Rahmawati',
                'content'     => 'Pertama kali coba bandeng tanpa duri, ternyata memang beda sekali rasanya dengan bandeng biasa. Proses pemesanan juga mudah, agen nya ramah dan responsif.',
                'rating'      => 4,
                'is_featured' => false,
            ],
            [
                'name'        => 'Bapak Andi Pratama',
                'content'     => 'Saya jualan bandeng presto di Martapura, sejak pakai supply dari Bandar Bandeng pelanggan saya makin bertambah. Kualitas bandengnya memang juara, dagingnya empuk dan bersih.',
                'rating'      => 5,
                'is_featured' => true,
            ],
            [
                'name'        => 'Ibu Nurhasanah',
                'content'     => 'Harganya sangat terjangkau untuk kualitas segini. Bandeng ukuran 4 ekor per kg paling pas untuk keluarga saya. Pengiriman juga cepat sampai ke rumah.',
                'rating'      => 4,
                'is_featured' => false,
            ],
            [
                'name'        => 'Mas Rizal Firmansyah',
                'content'     => 'Bandeng tanpa duri ini game changer banget! Tinggal goreng langsung makan, tidak perlu pusing-pusing cari duri lagi. Pasti jadi langganan tetap.',
                'rating'      => 5,
                'is_featured' => true,
            ],
            [
                'name'        => 'Ibu Mariam',
                'content'     => 'Saya dari Samarinda, awalnya ragu pesan online. Tapi setelah coba, bandengnya benar-benar segar dan benar-benar tanpa duri. Anak balita saya lahap makan tanpa khawatir.',
                'rating'      => 5,
                'is_featured' => false,
            ],
            [
                'name'        => 'Pak Ahmad Yusuf',
                'content'     => 'Sebagai pelanggan setia, saya sangat puas dengan pelayanan Bandar Bandeng. Stok selalu tersedia, harga bersaing, dan yang paling penting kualitas bandengnya tidak pernah mengecewakan.',
                'rating'      => 4,
                'is_featured' => false,
            ],
        ];

        // Try to assign some testimonials to actual customer users
        $customer1 = User::where('email', 'customer@bandarbandeng.com')->first();
        $customer2 = User::where('email', 'customer2@bandarbandeng.com')->first();
        $customer3 = User::where('email', 'customer3@bandarbandeng.com')->first();

        $userAssignments = [0, 2, 4, 6]; // indices of testimonials to assign to users
        $userMap = [$customer1, $customer2, $customer3, $customer1];

        foreach ($testimonials as $index => $testimonialData) {
            $testimonialData['is_active'] = true;

            if (in_array($index, $userAssignments)) {
                $assignedUser = $userMap[array_search($index, $userAssignments)];
                $testimonialData['user_id'] = $assignedUser ? $assignedUser->id : null;
            }

            Testimonial::create($testimonialData);
        }

        $this->command->info('💬 Created 8 testimonials');
    }
}
