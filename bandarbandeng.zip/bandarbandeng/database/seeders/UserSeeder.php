<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates demo users for all roles: admin, stockist, agent, and customer.
     */
    public function run(): void
    {
        $now = now();

        // ─── Admin ─────────────────────────────────────────────────────
        $admin = User::create([
            'name'              => 'Admin Pusat',
            'email'             => 'admin@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'admin',
            'phone'             => '082243922576',
            'city'              => 'Banjarmasin',
            'province'          => 'Kalimantan Selatan',
            'is_active'         => true,
        ]);

        // ─── Stockists ─────────────────────────────────────────────────
        $stockist1 = User::create([
            'name'              => 'Stockist Banjarmasin',
            'email'             => 'stockist@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'stockist',
            'phone'             => '081234567001',
            'city'              => 'Banjarmasin',
            'province'          => 'Kalimantan Selatan',
            'is_active'         => true,
        ]);

        $stockist2 = User::create([
            'name'              => 'Stockist Samarinda',
            'email'             => 'stockist2@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'stockist',
            'phone'             => '081234567002',
            'city'              => 'Samarinda',
            'province'          => 'Kalimantan Timur',
            'is_active'         => true,
        ]);

        // ─── Agents ────────────────────────────────────────────────────
        $agent1 = User::create([
            'name'              => 'Agen Rizki',
            'email'             => 'agen@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'agent',
            'phone'             => '081234567003',
            'city'              => 'Banjarmasin',
            'province'          => 'Kalimantan Selatan',
            'latitude'          => '-3.3186',
            'longitude'         => '114.5944',
            'is_active'         => true,
        ]);

        $agent2 = User::create([
            'name'              => 'Agen Berkah',
            'email'             => 'agen2@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'agent',
            'phone'             => '081234567004',
            'city'              => 'Martapura',
            'province'          => 'Kalimantan Selatan',
            'latitude'          => '-3.4290',
            'longitude'         => '114.8390',
            'is_active'         => true,
        ]);

        $agent3 = User::create([
            'name'              => 'Agen Jaya',
            'email'             => 'agen3@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'agent',
            'phone'             => '081234567005',
            'city'              => 'Samarinda',
            'province'          => 'Kalimantan Timur',
            'latitude'          => '-0.4948',
            'longitude'         => '117.1436',
            'is_active'         => true,
        ]);

        // ─── Customers ─────────────────────────────────────────────────
        $customer1 = User::create([
            'name'              => 'Budi Santoso',
            'email'             => 'customer@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'customer',
            'phone'             => '081234567006',
            'city'              => 'Banjarmasin',
            'province'          => 'Kalimantan Selatan',
            'latitude'          => '-3.3186',
            'longitude'         => '114.5944',
            'is_active'         => true,
        ]);

        $customer2 = User::create([
            'name'              => 'Siti Aminah',
            'email'             => 'customer2@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'customer',
            'phone'             => '081234567007',
            'city'              => 'Martapura',
            'province'          => 'Kalimantan Selatan',
            'is_active'         => true,
        ]);

        $customer3 = User::create([
            'name'              => 'Ahmad Fauzi',
            'email'             => 'customer3@bandarbandeng.com',
            'email_verified_at' => $now,
            'password'          => Hash::make('password'),
            'role'              => 'customer',
            'phone'             => '081234567008',
            'city'              => 'Samarinda',
            'province'          => 'Kalimantan Timur',
            'is_active'         => true,
        ]);

        $this->command->info('👥 Created 9 demo users (1 admin, 2 stockists, 3 agents, 3 customers)');
    }
}
