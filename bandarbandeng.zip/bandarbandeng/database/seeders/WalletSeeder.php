<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Wallet;
use Illuminate\Database\Seeder;

class WalletSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * Creates wallets with initial balances for all demo users.
     */
    public function run(): void
    {
        // ─── Define wallet balances per user ───────────────────────────
        $walletBalances = [
            'admin@bandarbandeng.com'      => 5000000,
            'stockist@bandarbandeng.com'   => 2000000,
            'stockist2@bandarbandeng.com'  => 1500000,
            'agen@bandarbandeng.com'       => 500000,
            'agen2@bandarbandeng.com'      => 300000,
            'agen3@bandarbandeng.com'      => 400000,
            'customer@bandarbandeng.com'   => 100000,
            'customer2@bandarbandeng.com'  => 100000,
            'customer3@bandarbandeng.com'  => 100000,
        ];

        foreach ($walletBalances as $email => $balance) {
            $user = User::where('email', $email)->first();

            if (! $user) {
                $this->command->warn("⚠ User not found: {$email}. Skipping wallet creation.");
                continue;
            }

            Wallet::create([
                'user_id'         => $user->id,
                'balance'         => $balance,
                'pending_balance' => 0,
            ]);
        }

        $this->command->info('💰 Created 9 wallets with initial balances');
    }
}
