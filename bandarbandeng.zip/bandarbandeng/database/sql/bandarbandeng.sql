-- ============================================================
-- Bandar Bandeng Kalimantan — Database Dump
-- ============================================================
-- Kompatibel: MySQL 5.7+ / MariaDB 10.3+ / cPanel phpMyAdmin
-- Charset: utf8mb4, Collation: utf8mb4_unicode_ci
-- Engine: InnoDB
-- ============================================================
-- Cara Import:
--   1. Buat database via cPanel → MySQL Databases
--   2. Import via phpMyAdmin → Import → pilih file ini
--   3. Atau via CLI: mysql -u user -p dbname < bandarbandeng.sql
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+08:00";
SET NAMES utf8mb4;

-- ============================================================
-- DROP TABLES (urutan terbalik karena foreign key)
-- ============================================================
DROP TABLE IF EXISTS `role_has_permissions`;
DROP TABLE IF EXISTS `model_has_roles`;
DROP TABLE IF EXISTS `model_has_permissions`;
DROP TABLE IF EXISTS `agent_areas`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `activity_logs`;
DROP TABLE IF EXISTS `testimonials`;
DROP TABLE IF EXISTS `user_agent_levels`;
DROP TABLE IF EXISTS `user_badges`;
DROP TABLE IF EXISTS `agent_levels`;
DROP TABLE IF EXISTS `agent_badges`;
DROP TABLE IF EXISTS `complaints`;
DROP TABLE IF EXISTS `ratings`;
DROP TABLE IF EXISTS `withdrawals`;
DROP TABLE IF EXISTS `wallet_transactions`;
DROP TABLE IF EXISTS `wallets`;
DROP TABLE IF EXISTS `payments`;
DROP TABLE IF EXISTS `order_items`;
DROP TABLE IF EXISTS `orders`;
DROP TABLE IF EXISTS `stocks`;
DROP TABLE IF EXISTS `product_variants`;
DROP TABLE IF EXISTS `products`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `roles`;
DROP TABLE IF EXISTS `failed_jobs`;
DROP TABLE IF EXISTS `password_resets`;
DROP TABLE IF EXISTS `users`;

-- ============================================================
-- TABLE: users
-- ============================================================
CREATE TABLE `users` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `email_verified_at` TIMESTAMP NULL DEFAULT NULL,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('admin','stockist','agent','customer') NOT NULL DEFAULT 'customer',
    `phone` VARCHAR(255) NULL DEFAULT NULL,
    `address` TEXT NULL DEFAULT NULL,
    `city` VARCHAR(255) NULL DEFAULT NULL,
    `province` VARCHAR(255) NULL DEFAULT NULL,
    `postal_code` VARCHAR(255) NULL DEFAULT NULL,
    `latitude` DECIMAL(10,7) NULL DEFAULT NULL,
    `longitude` DECIMAL(10,7) NULL DEFAULT NULL,
    `avatar` VARCHAR(255) NULL DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login_at` TIMESTAMP NULL DEFAULT NULL,
    `remember_token` VARCHAR(100) NULL DEFAULT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `users_email_unique` (`email`),
    INDEX `users_role_index` (`role`),
    INDEX `users_is_active_index` (`is_active`),
    INDEX `users_city_index` (`city`),
    INDEX `users_province_index` (`province`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: password_resets
-- ============================================================
CREATE TABLE `password_resets` (
    `email` VARCHAR(255) NOT NULL,
    `token` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    INDEX `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: failed_jobs
-- ============================================================
CREATE TABLE `failed_jobs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `uuid` VARCHAR(255) NOT NULL,
    `connection` TEXT NOT NULL,
    `queue` TEXT NOT NULL,
    `payload` LONGTEXT NOT NULL,
    `exception` LONGTEXT NOT NULL,
    `failed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: permissions (Spatie)
-- ============================================================
CREATE TABLE `permissions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `guard_name` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: roles (Spatie)
-- ============================================================
CREATE TABLE `roles` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `guard_name` VARCHAR(255) NOT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: model_has_permissions (Spatie pivot)
-- ============================================================
CREATE TABLE `model_has_permissions` (
    `permission_id` BIGINT UNSIGNED NOT NULL,
    `model_type` VARCHAR(255) NOT NULL,
    `model_id` BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
    INDEX `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
    CONSTRAINT `model_has_permissions_permission_id_foreign`
        FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: model_has_roles (Spatie pivot)
-- ============================================================
CREATE TABLE `model_has_roles` (
    `role_id` BIGINT UNSIGNED NOT NULL,
    `model_type` VARCHAR(255) NOT NULL,
    `model_id` BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (`role_id`,`model_id`,`model_type`),
    INDEX `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
    CONSTRAINT `model_has_roles_role_id_foreign`
        FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: role_has_permissions (Spatie pivot)
-- ============================================================
CREATE TABLE `role_has_permissions` (
    `permission_id` BIGINT UNSIGNED NOT NULL,
    `role_id` BIGINT UNSIGNED NOT NULL,
    PRIMARY KEY (`permission_id`,`role_id`),
    CONSTRAINT `role_has_permissions_permission_id_foreign`
        FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
    CONSTRAINT `role_has_permissions_role_id_foreign`
        FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: products
-- ============================================================
CREATE TABLE `products` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(255) NOT NULL,
    `description` TEXT NULL DEFAULT NULL,
    `long_description` TEXT NULL DEFAULT NULL,
    `category` VARCHAR(255) NULL DEFAULT NULL,
    `image` VARCHAR(255) NULL DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `sort_order` INT NULL DEFAULT 0,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `products_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: product_variants
-- ============================================================
CREATE TABLE `product_variants` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `product_id` BIGINT UNSIGNED NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(255) NOT NULL,
    `description` TEXT NULL DEFAULT NULL,
    `fish_count` INT NOT NULL DEFAULT 0,
    `price` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `weight_kg` DECIMAL(8,2) NULL DEFAULT 1.00,
    `image` VARCHAR(255) NULL DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `sort_order` INT NULL DEFAULT 0,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `product_variants_slug_unique` (`slug`),
    INDEX `product_variants_product_id_index` (`product_id`),
    CONSTRAINT `product_variants_product_id_foreign`
        FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: stocks
-- ============================================================
CREATE TABLE `stocks` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `product_variant_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `quantity` INT NOT NULL DEFAULT 0,
    `reserved_quantity` INT NOT NULL DEFAULT 0,
    `type` ENUM('admin','stockist','agent') NOT NULL DEFAULT 'admin',
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `stocks_variant_user_type_unique` (`product_variant_id`,`user_id`,`type`),
    INDEX `stocks_user_id_index` (`user_id`),
    CONSTRAINT `stocks_product_variant_id_foreign`
        FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `stocks_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: orders
-- ============================================================
CREATE TABLE `orders` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_number` VARCHAR(255) NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'Buyer',
    `seller_id` BIGINT UNSIGNED NOT NULL COMMENT 'Seller',
    `order_type` ENUM('stockist_to_admin','agent_to_stockist','customer_to_agent') NOT NULL,
    `status` ENUM('pending','confirmed','processing','shipped','delivered','completed','cancelled','refunded') NOT NULL DEFAULT 'pending',
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `shipping_cost` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `total` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `notes` TEXT NULL DEFAULT NULL,
    `shipping_address` TEXT NULL DEFAULT NULL,
    `shipping_city` VARCHAR(255) NULL DEFAULT NULL,
    `shipping_province` VARCHAR(255) NULL DEFAULT NULL,
    `shipping_postal_code` VARCHAR(255) NULL DEFAULT NULL,
    `recipient_name` VARCHAR(255) NULL DEFAULT NULL,
    `recipient_phone` VARCHAR(255) NULL DEFAULT NULL,
    `tracking_number` VARCHAR(255) NULL DEFAULT NULL,
    `shipped_at` TIMESTAMP NULL DEFAULT NULL,
    `delivered_at` TIMESTAMP NULL DEFAULT NULL,
    `cancelled_at` TIMESTAMP NULL DEFAULT NULL,
    `cancellation_reason` VARCHAR(255) NULL DEFAULT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `orders_order_number_unique` (`order_number`),
    INDEX `orders_user_id_index` (`user_id`),
    INDEX `orders_seller_id_index` (`seller_id`),
    INDEX `orders_order_type_index` (`order_type`),
    INDEX `orders_status_index` (`status`),
    INDEX `orders_created_at_index` (`created_at`),
    INDEX `orders_user_id_status_index` (`user_id`,`status`),
    INDEX `orders_seller_id_status_index` (`seller_id`,`status`),
    CONSTRAINT `orders_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `orders_seller_id_foreign`
        FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: order_items
-- ============================================================
CREATE TABLE `order_items` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_id` BIGINT UNSIGNED NOT NULL,
    `product_variant_id` BIGINT UNSIGNED NOT NULL,
    `quantity` INT NOT NULL DEFAULT 0,
    `price_per_unit` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `subtotal` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `order_items_order_id_index` (`order_id`),
    INDEX `order_items_product_variant_id_index` (`product_variant_id`),
    CONSTRAINT `order_items_order_id_foreign`
        FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `order_items_product_variant_id_foreign`
        FOREIGN KEY (`product_variant_id`) REFERENCES `product_variants` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: payments
-- ============================================================
CREATE TABLE `payments` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_id` BIGINT UNSIGNED NOT NULL,
    `payment_method` ENUM('deposit','bank_transfer') NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `status` ENUM('pending','verified','rejected','refunded') NOT NULL DEFAULT 'pending',
    `proof_image` VARCHAR(255) NULL DEFAULT NULL,
    `bank_name` VARCHAR(255) NULL DEFAULT NULL,
    `bank_account` VARCHAR(255) NULL DEFAULT NULL,
    `bank_holder` VARCHAR(255) NULL DEFAULT NULL,
    `verified_at` TIMESTAMP NULL DEFAULT NULL,
    `verified_by` BIGINT UNSIGNED NULL DEFAULT NULL,
    `rejected_reason` TEXT NULL DEFAULT NULL,
    `notes` TEXT NULL DEFAULT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `payments_order_id_index` (`order_id`),
    INDEX `payments_verified_by_index` (`verified_by`),
    CONSTRAINT `payments_order_id_foreign`
        FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `payments_verified_by_foreign`
        FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: wallets
-- ============================================================
CREATE TABLE `wallets` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `balance` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `pending_balance` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `wallets_user_id_unique` (`user_id`),
    CONSTRAINT `wallets_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: wallet_transactions
-- ============================================================
CREATE TABLE `wallet_transactions` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `wallet_id` BIGINT UNSIGNED NOT NULL,
    `type` ENUM('deposit','withdrawal','payment','refund','commission') NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `balance_after` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `description` VARCHAR(255) NULL DEFAULT NULL,
    `reference_type` VARCHAR(255) NULL DEFAULT NULL,
    `reference_id` BIGINT UNSIGNED NULL DEFAULT NULL,
    `status` ENUM('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `wallet_transactions_wallet_id_index` (`wallet_id`),
    INDEX `wallet_transactions_type_index` (`type`),
    INDEX `wallet_transactions_status_index` (`status`),
    CONSTRAINT `wallet_transactions_wallet_id_foreign`
        FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: withdrawals
-- ============================================================
CREATE TABLE `withdrawals` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `amount` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `bank_name` VARCHAR(255) NOT NULL,
    `bank_account` VARCHAR(255) NOT NULL,
    `bank_holder` VARCHAR(255) NOT NULL,
    `status` ENUM('pending','approved','rejected','processed') NOT NULL DEFAULT 'pending',
    `rejected_reason` TEXT NULL DEFAULT NULL,
    `processed_at` TIMESTAMP NULL DEFAULT NULL,
    `processed_by` BIGINT UNSIGNED NULL DEFAULT NULL,
    `notes` TEXT NULL DEFAULT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `withdrawals_user_id_index` (`user_id`),
    INDEX `withdrawals_processed_by_index` (`processed_by`),
    CONSTRAINT `withdrawals_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `withdrawals_processed_by_foreign`
        FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: ratings
-- ============================================================
CREATE TABLE `ratings` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `rated_user_id` BIGINT UNSIGNED NOT NULL,
    `rating` TINYINT NOT NULL DEFAULT 5,
    `review` TEXT NULL DEFAULT NULL,
    `is_anonymous` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `ratings_order_id_user_id_unique` (`order_id`,`user_id`),
    INDEX `ratings_user_id_index` (`user_id`),
    INDEX `ratings_rated_user_id_index` (`rated_user_id`),
    CONSTRAINT `ratings_order_id_foreign`
        FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `ratings_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `ratings_rated_user_id_foreign`
        FOREIGN KEY (`rated_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: complaints
-- ============================================================
CREATE TABLE `complaints` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `order_id` BIGINT UNSIGNED NOT NULL,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `type` ENUM('product_damage','wrong_item','late_delivery','other') NOT NULL,
    `description` TEXT NOT NULL,
    `images` JSON NULL DEFAULT NULL,
    `status` ENUM('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
    `resolution` TEXT NULL DEFAULT NULL,
    `resolved_at` TIMESTAMP NULL DEFAULT NULL,
    `resolved_by` BIGINT UNSIGNED NULL DEFAULT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `complaints_order_id_index` (`order_id`),
    INDEX `complaints_user_id_index` (`user_id`),
    INDEX `complaints_resolved_by_index` (`resolved_by`),
    CONSTRAINT `complaints_order_id_foreign`
        FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `complaints_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `complaints_resolved_by_foreign`
        FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: agent_badges
-- ============================================================
CREATE TABLE `agent_badges` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(255) NOT NULL,
    `description` TEXT NULL DEFAULT NULL,
    `icon` VARCHAR(255) NULL DEFAULT NULL,
    `min_orders` INT NOT NULL DEFAULT 0,
    `min_rating` DECIMAL(3,2) NOT NULL DEFAULT 0.00,
    `color` VARCHAR(255) NULL DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `agent_badges_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: agent_levels
-- ============================================================
CREATE TABLE `agent_levels` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `slug` VARCHAR(255) NOT NULL,
    `description` TEXT NULL DEFAULT NULL,
    `min_total_sales` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `commission_percent` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `icon` VARCHAR(255) NULL DEFAULT NULL,
    `color` VARCHAR(255) NULL DEFAULT NULL,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `agent_levels_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: user_badges (pivot)
-- ============================================================
CREATE TABLE `user_badges` (
    `user_id` BIGINT UNSIGNED NOT NULL,
    `agent_badge_id` BIGINT UNSIGNED NOT NULL,
    `earned_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`,`agent_badge_id`),
    CONSTRAINT `user_badges_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `user_badges_agent_badge_id_foreign`
        FOREIGN KEY (`agent_badge_id`) REFERENCES `agent_badges` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: user_agent_levels
-- ============================================================
CREATE TABLE `user_agent_levels` (
    `user_id` BIGINT UNSIGNED NOT NULL,
    `agent_level_id` BIGINT UNSIGNED NOT NULL,
    `current_monthly_sales` DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    `assigned_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`),
    CONSTRAINT `user_agent_levels_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `user_agent_levels_agent_level_id_foreign`
        FOREIGN KEY (`agent_level_id`) REFERENCES `agent_levels` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: testimonials
-- ============================================================
CREATE TABLE `testimonials` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NULL DEFAULT NULL,
    `name` VARCHAR(255) NOT NULL,
    `content` TEXT NOT NULL,
    `rating` TINYINT NOT NULL DEFAULT 5,
    `image` VARCHAR(255) NULL DEFAULT NULL,
    `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `testimonials_user_id_index` (`user_id`),
    CONSTRAINT `testimonials_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: activity_logs
-- ============================================================
CREATE TABLE `activity_logs` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NULL DEFAULT NULL,
    `action` VARCHAR(255) NOT NULL,
    `description` TEXT NULL DEFAULT NULL,
    `properties` JSON NULL DEFAULT NULL,
    `ip_address` VARCHAR(45) NULL DEFAULT NULL,
    `user_agent` VARCHAR(500) NULL DEFAULT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `activity_logs_user_id_index` (`user_id`),
    CONSTRAINT `activity_logs_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: notifications
-- ============================================================
CREATE TABLE `notifications` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `type` VARCHAR(255) NULL DEFAULT NULL,
    `data` JSON NULL DEFAULT NULL,
    `read_at` TIMESTAMP NULL DEFAULT NULL,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `notifications_user_id_index` (`user_id`),
    INDEX `notifications_user_id_read_at_index` (`user_id`,`read_at`),
    CONSTRAINT `notifications_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: agent_areas
-- ============================================================
CREATE TABLE `agent_areas` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` BIGINT UNSIGNED NOT NULL,
    `city` VARCHAR(255) NOT NULL,
    `province` VARCHAR(255) NOT NULL,
    `coverage_radius_km` DECIMAL(8,2) NOT NULL DEFAULT 10.00,
    `is_active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` TIMESTAMP NULL DEFAULT NULL,
    `updated_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`id`),
    INDEX `agent_areas_user_id_index` (`user_id`),
    INDEX `agent_areas_city_index` (`city`),
    CONSTRAINT `agent_areas_user_id_foreign`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- SEED DATA
-- ============================================================

-- ----------------------------------------------------------
-- Roles (Spatie)
-- ----------------------------------------------------------
INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'web', NOW(), NOW()),
(2, 'stockist', 'web', NOW(), NOW()),
(3, 'agent', 'web', NOW(), NOW()),
(4, 'customer', 'web', NOW(), NOW());

-- ----------------------------------------------------------
-- Permissions (Spatie)
-- ----------------------------------------------------------
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin-access', 'web', NOW(), NOW()),
(2, 'stockist-access', 'web', NOW(), NOW()),
(3, 'agent-access', 'web', NOW(), NOW()),
(4, 'customer-access', 'web', NOW(), NOW()),
(5, 'manage-products', 'web', NOW(), NOW()),
(6, 'manage-stock', 'web', NOW(), NOW()),
(7, 'manage-orders', 'web', NOW(), NOW());

-- ----------------------------------------------------------
-- Role-Permission mappings
-- ----------------------------------------------------------
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(5, 1),
(6, 1),
(7, 1),
(2, 2),
(6, 2),
(7, 2),
(3, 3),
(7, 3),
(4, 4);

-- ----------------------------------------------------------
-- Users (password = 'password' = bcrypt hash)
-- ----------------------------------------------------------
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `role`, `phone`, `address`, `city`, `province`, `postal_code`, `latitude`, `longitude`, `avatar`, `is_active`, `last_login_at`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin Pusat', 'admin@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '082243922576', 'Jl. Bandeng Raya No. 1', 'Banjarmasin', 'Kalimantan Selatan', '70111', -3.3186000, 114.5944000, NULL, 1, NULL, NULL, NOW(), NOW()),
(2, 'Stockist Banjarmasin', 'stockist@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'stockist', '081234567890', 'Jl. Merdeka No. 10', 'Banjarmasin', 'Kalimantan Selatan', '70112', -3.3200000, 114.5900000, NULL, 1, NULL, NULL, NOW(), NOW()),
(3, 'Stockist Samarinda', 'stockist2@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'stockist', '081234567891', 'Jl. Pahlawan No. 5', 'Samarinda', 'Kalimantan Timur', '75111', -0.4948000, 117.1436000, NULL, 1, NULL, NULL, NOW(), NOW()),
(4, 'Agen Rizki', 'agen@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'agent', '085345678901', 'Jl. Pasar Baru No. 3', 'Banjarmasin', 'Kalimantan Selatan', '70113', -3.3186000, 114.5944000, NULL, 1, NULL, NULL, NOW(), NOW()),
(5, 'Agen Berkah', 'agen2@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'agent', '085345678902', 'Jl. Martapura Indah No. 7', 'Martapura', 'Kalimantan Selatan', '70611', -3.4290000, 114.8390000, NULL, 1, NULL, NULL, NOW(), NOW()),
(6, 'Agen Jaya', 'agen3@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'agent', '085345678903', 'Jl. Samarinda Kita No. 12', 'Samarinda', 'Kalimantan Timur', '75112', -0.4948000, 117.1436000, NULL, 1, NULL, NULL, NOW(), NOW()),
(7, 'Budi Santoso', 'customer@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', '087654321001', 'Jl. Sejahtera No. 8', 'Banjarmasin', 'Kalimantan Selatan', '70114', -3.3186000, 114.5944000, NULL, 1, NULL, NULL, NOW(), NOW()),
(8, 'Siti Aminah', 'customer2@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', '087654321002', 'Jl. Bahagia No. 15', 'Martapura', 'Kalimantan Selatan', '70612', NULL, NULL, NULL, 1, NULL, NULL, NOW(), NOW()),
(9, 'Ahmad Fauzi', 'customer3@bandarbandeng.com', NOW(), '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer', '087654321003', 'Jl. Kaltim Jaya No. 22', 'Samarinda', 'Kalimantan Timur', '75113', NULL, NULL, NULL, 1, NULL, NULL, NOW(), NOW());

-- ----------------------------------------------------------
-- Spatie: model_has_roles (assign user ke role)
-- ----------------------------------------------------------
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(2, 'App\\Models\\User', 3),
(3, 'App\\Models\\User', 4),
(3, 'App\\Models\\User', 5),
(3, 'App\\Models\\User', 6),
(4, 'App\\Models\\User', 7),
(4, 'App\\Models\\User', 8),
(4, 'App\\Models\\User', 9);

-- ----------------------------------------------------------
-- Products
-- ----------------------------------------------------------
INSERT INTO `products` (`id`, `name`, `slug`, `description`, `long_description`, `category`, `image`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Ikan Bandeng Tanpa Duri', 'ikan-bandeng-tanpa-duri', 'Ikan bandeng premium tanpa duri, diproses secara higienis langsung dari Kalimantan.', 'Ikan bandeng tanpa duri pilihan dari perairan Kalimantan. Diproses dengan standar higienis tinggi, dibersihkan durinya satu per satu oleh tenaga ahli berpengalaman. Dikemas vakum untuk menjaga kesegaran selama pengiriman.', 'bandeng', NULL, 1, 1, NOW(), NOW());

-- ----------------------------------------------------------
-- Product Variants
-- ----------------------------------------------------------
INSERT INTO `product_variants` (`id`, `product_id`, `name`, `slug`, `description`, `fish_count`, `price`, `weight_kg`, `image`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 1, 'Ukuran 5 Ekor/kg', 'bandeng-5-ekor-kg', '5 ekor ikan bandeng tanpa duri per kg, ukuran kecil', 5, 85000.00, 1.00, NULL, 1, 1, NOW(), NOW()),
(2, 1, 'Ukuran 4 Ekor/kg', 'bandeng-4-ekor-kg', '4 ekor ikan bandeng tanpa duri per kg, ukuran sedang', 4, 95000.00, 1.00, NULL, 1, 2, NOW(), NOW()),
(3, 1, 'Ukuran 3 Ekor/kg', 'bandeng-3-ekor-kg', '3 ekor ikan bandeng tanpa duri per kg, ukuran besar', 3, 115000.00, 1.00, NULL, 1, 3, NOW(), NOW()),
(4, 1, 'Per Ekor', 'bandeng-per-ekor', '1 ekor ikan bandeng tanpa duri, ukuran sedang', 1, 35000.00, 0.33, NULL, 1, 4, NOW(), NOW());

-- ----------------------------------------------------------
-- Stocks
-- ----------------------------------------------------------
INSERT INTO `stocks` (`product_variant_id`, `user_id`, `quantity`, `reserved_quantity`, `type`, `created_at`, `updated_at`) VALUES
-- Admin stock
(1, 1, 100, 0, 'admin', NOW(), NOW()),
(2, 1, 100, 0, 'admin', NOW(), NOW()),
(3, 1, 100, 0, 'admin', NOW(), NOW()),
(4, 1, 100, 0, 'admin', NOW(), NOW()),
-- Stockist Banjarmasin stock
(1, 2, 30, 2, 'stockist', NOW(), NOW()),
(2, 2, 30, 1, 'stockist', NOW(), NOW()),
(3, 2, 25, 0, 'stockist', NOW(), NOW()),
(4, 2, 30, 3, 'stockist', NOW(), NOW()),
-- Stockist Samarinda stock
(1, 3, 20, 0, 'stockist', NOW(), NOW()),
(2, 3, 20, 0, 'stockist', NOW(), NOW()),
(3, 3, 15, 0, 'stockist', NOW(), NOW()),
(4, 3, 20, 0, 'stockist', NOW(), NOW()),
-- Agen Rizki stock
(1, 4, 10, 1, 'agent', NOW(), NOW()),
(2, 4, 10, 0, 'agent', NOW(), NOW()),
(3, 4, 8, 0, 'agent', NOW(), NOW()),
(4, 4, 10, 2, 'agent', NOW(), NOW()),
-- Agen Berkah stock
(1, 5, 8, 0, 'agent', NOW(), NOW()),
(2, 5, 8, 0, 'agent', NOW(), NOW()),
(3, 5, 6, 0, 'agent', NOW(), NOW()),
(4, 5, 8, 0, 'agent', NOW(), NOW()),
-- Agen Jaya stock
(1, 6, 10, 0, 'agent', NOW(), NOW()),
(2, 6, 10, 0, 'agent', NOW(), NOW()),
(3, 6, 8, 0, 'agent', NOW(), NOW()),
(4, 6, 10, 0, 'agent', NOW(), NOW());

-- ----------------------------------------------------------
-- Wallets
-- ----------------------------------------------------------
INSERT INTO `wallets` (`user_id`, `balance`, `pending_balance`, `created_at`, `updated_at`) VALUES
(1, 5000000.00, 0.00, NOW(), NOW()),
(2, 2000000.00, 0.00, NOW(), NOW()),
(3, 1500000.00, 0.00, NOW(), NOW()),
(4, 500000.00, 0.00, NOW(), NOW()),
(5, 300000.00, 0.00, NOW(), NOW()),
(6, 400000.00, 0.00, NOW(), NOW()),
(7, 100000.00, 0.00, NOW(), NOW()),
(8, 100000.00, 0.00, NOW(), NOW()),
(9, 100000.00, 0.00, NOW(), NOW());

-- ----------------------------------------------------------
-- Agent Badges
-- ----------------------------------------------------------
INSERT INTO `agent_badges` (`id`, `name`, `slug`, `description`, `icon`, `min_orders`, `min_rating`, `color`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Agen Pemula', 'agen-pemula', 'Agen baru yang baru bergabung', 'fa-seedling', 0, 0.00, 'green', 1, NOW(), NOW()),
(2, 'Agen Andalan', 'agen-andalan', 'Agen dengan performa baik dan rating tinggi', 'fa-star', 50, 4.00, 'blue', 1, NOW(), NOW()),
(3, 'Agen Utama', 'agen-utama', 'Agen berpengalaman dengan banyak pesanan', 'fa-crown', 200, 4.50, 'gold', 1, NOW(), NOW()),
(4, 'Agen Legenda', 'agen-legenda', 'Agen top dengan rekam jejak luar biasa', 'fa-gem', 500, 4.80, 'purple', 1, NOW(), NOW());

-- ----------------------------------------------------------
-- Agent Levels
-- ----------------------------------------------------------
INSERT INTO `agent_levels` (`id`, `name`, `slug`, `description`, `min_total_sales`, `discount_percent`, `commission_percent`, `icon`, `color`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Regular', 'regular', 'Level awal untuk semua agen baru', 0.00, 0.00, 5.00, 'fa-user', 'gray', 1, NOW(), NOW()),
(2, 'Silver', 'silver', 'Agen dengan penjualan di atas 5 juta', 5000000.00, 2.00, 7.00, 'fa-medal', 'silver', 1, NOW(), NOW()),
(3, 'Gold', 'gold', 'Agen dengan penjualan di atas 20 juta', 20000000.00, 5.00, 10.00, 'fa-award', 'gold', 1, NOW(), NOW()),
(4, 'Platinum', 'platinum', 'Agen premium dengan penjualan di atas 50 juta', 50000000.00, 8.00, 15.00, 'fa-crown', 'platinum', 1, NOW(), NOW());

-- ----------------------------------------------------------
-- User-Agent Level assignments
-- ----------------------------------------------------------
INSERT INTO `user_agent_levels` (`user_id`, `agent_level_id`, `current_monthly_sales`, `assigned_at`) VALUES
(4, 1, 0.00, NOW()),
(5, 1, 0.00, NOW()),
(6, 2, 6500000.00, NOW());

-- ----------------------------------------------------------
-- User-Badges assignments
-- ----------------------------------------------------------
INSERT INTO `user_badges` (`user_id`, `agent_badge_id`, `earned_at`) VALUES
(4, 1, NOW()),
(5, 1, NOW()),
(6, 2, NOW());

-- ----------------------------------------------------------
-- Agent Areas
-- ----------------------------------------------------------
INSERT INTO `agent_areas` (`user_id`, `city`, `province`, `coverage_radius_km`, `is_active`, `created_at`, `updated_at`) VALUES
(4, 'Banjarmasin', 'Kalimantan Selatan', 15.00, 1, NOW(), NOW()),
(5, 'Martapura', 'Kalimantan Selatan', 10.00, 1, NOW(), NOW()),
(6, 'Samarinda', 'Kalimantan Timur', 20.00, 1, NOW(), NOW());

-- ----------------------------------------------------------
-- Testimonials
-- ----------------------------------------------------------
INSERT INTO `testimonials` (`user_id`, `name`, `content`, `rating`, `image`, `is_featured`, `is_active`, `created_at`, `updated_at`) VALUES
(NULL, 'Ibu Ratna', 'Ikan bandengnya benar-benar tanpa duri! Anak-anak saya suka sekali, tidak perlu khawatir tersedak lagi.', 5, NULL, 1, 1, NOW(), NOW()),
(7, 'Budi Santoso', 'Pengiriman cepat dan ikan masih fresh. Kualitas terjamin, sudah langganan 6 bulan.', 5, NULL, 1, 1, NOW(), NOW()),
(NULL, 'Ibu Sari', 'Harga sangat terjangkau untuk kualitas segini. Prosesnya higienis dan rasa bandengnya enak banget!', 5, NULL, 1, 1, NOW(), NOW()),
(8, 'Siti Aminah', 'Agen di Martapura ramah dan responsif. Bandeng tanpa durinya jadi andalan untuk lauk sehari-hari.', 4, NULL, 0, 1, NOW(), NOW()),
(NULL, 'Pak Hidayat', 'Saya awalnya ragu, tapi ternyata benar-benar tidak ada duri sama sekali. Mantap!', 5, NULL, 0, 1, NOW(), NOW()),
(NULL, 'Ibu Dewi', 'Kemasan vakumnya rapi, ikan tidak bau dan tahan lama di freezer. Recommended!', 4, NULL, 0, 1, NOW(), NOW()),
(9, 'Ahmad Fauzi', 'Sudah coba berbagai ukuran, yang 3 ekor per kg paling pas untuk keluarga besar.', 5, NULL, 0, 1, NOW(), NOW()),
(NULL, 'Pak Rizal', 'Bandeng prestonya juga enak! Tinggal goreng sebentar langsung siap makan.', 4, NULL, 0, 1, NOW(), NOW());

-- ----------------------------------------------------------
-- Demo Orders (contoh supply chain)
-- ----------------------------------------------------------
INSERT INTO `orders` (`id`, `order_number`, `user_id`, `seller_id`, `order_type`, `status`, `subtotal`, `shipping_cost`, `total`, `notes`, `shipping_address`, `shipping_city`, `shipping_province`, `shipping_postal_code`, `recipient_name`, `recipient_phone`, `tracking_number`, `shipped_at`, `delivered_at`, `cancelled_at`, `cancellation_reason`, `created_at`, `updated_at`) VALUES
(1, 'ORD-20240115-000001', 2, 1, 'stockist_to_admin', 'completed', 850000.00, 0.00, 850000.00, 'Restock bulanan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NOW(), NOW(), NULL, NULL, DATE_SUB(NOW(), INTERVAL 20 DAY), NOW()),
(2, 'ORD-20240118-000002', 4, 2, 'agent_to_stockist', 'completed', 425000.00, 0.00, 425000.00, 'Restok agen', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NOW(), NOW(), NULL, NULL, DATE_SUB(NOW(), INTERVAL 15 DAY), NOW()),
(3, 'ORD-20240120-000003', 7, 4, 'customer_to_agent', 'completed', 180000.00, 15000.00, 195000.00, 'Tolong pilih yang segar ya', 'Jl. Sejahtera No. 8', 'Banjarmasin', 'Kalimantan Selatan', '70114', 'Budi Santoso', '087654321001', 'JNE-123456', NOW(), NOW(), NULL, NULL, DATE_SUB(NOW(), INTERVAL 10 DAY), NOW()),
(4, 'ORD-20240122-000004', 3, 1, 'stockist_to_admin', 'shipped', 500000.00, 0.00, 500000.00, 'Restock mingguan', NULL, NULL, NULL, NULL, NULL, NULL, 'SICEPAT-789012', NOW(), NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 3 DAY), NOW()),
(5, 'ORD-20240124-000005', 5, 3, 'agent_to_stockist', 'confirmed', 280000.00, 0.00, 280000.00, 'Pesanan untuk pelanggan', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 2 DAY), NOW()),
(6, 'ORD-20240125-000006', 8, 5, 'customer_to_agent', 'pending', 135000.00, 10000.00, 145000.00, NULL, 'Jl. Bahagia No. 15', 'Martapura', 'Kalimantan Selatan', '70612', 'Siti Aminah', '087654321002', NULL, NULL, NULL, NULL, NULL, DATE_SUB(NOW(), INTERVAL 1 DAY), NOW());

-- ----------------------------------------------------------
-- Order Items
-- ----------------------------------------------------------
INSERT INTO `order_items` (`order_id`, `product_variant_id`, `quantity`, `price_per_unit`, `subtotal`, `created_at`, `updated_at`) VALUES
-- Order 1: Stockist Banjarmasin → Admin
(1, 1, 5, 85000.00, 425000.00, NOW(), NOW()),
(1, 2, 3, 95000.00, 285000.00, NOW(), NOW()),
(1, 3, 1, 115000.00, 115000.00, NOW(), NOW()),
-- Order 2: Agen Rizki → Stockist Banjarmasin
(2, 1, 3, 85000.00, 255000.00, NOW(), NOW()),
(2, 4, 4, 35000.00, 140000.00, NOW(), NOW()),
-- Order 3: Budi → Agen Rizki
(3, 2, 1, 95000.00, 95000.00, NOW(), NOW()),
(3, 4, 2, 35000.00, 70000.00, NOW(), NOW()),
-- Order 4: Stockist Samarinda → Admin
(4, 1, 3, 85000.00, 255000.00, NOW(), NOW()),
(4, 3, 2, 115000.00, 230000.00, NOW(), NOW()),
-- Order 5: Agen Berkah → Stockist Samarinda
(5, 2, 2, 95000.00, 190000.00, NOW(), NOW()),
(5, 4, 2, 35000.00, 70000.00, NOW(), NOW()),
-- Order 6: Siti → Agen Berkah
(6, 1, 1, 85000.00, 85000.00, NOW(), NOW()),
(6, 4, 1, 35000.00, 35000.00, NOW(), NOW());

-- ----------------------------------------------------------
-- Payments
-- ----------------------------------------------------------
INSERT INTO `payments` (`order_id`, `payment_method`, `amount`, `status`, `proof_image`, `bank_name`, `bank_account`, `bank_holder`, `verified_at`, `verified_by`, `rejected_reason`, `notes`, `created_at`, `updated_at`) VALUES
(1, 'bank_transfer', 850000.00, 'verified', 'payment_proofs/proof_1.jpg', 'BCA', '8720-3456-7890', 'Stockist Banjarmasin', NOW(), 1, NULL, NULL, NOW(), NOW()),
(2, 'deposit', 425000.00, 'verified', NULL, NULL, NULL, NULL, NOW(), 1, NULL, 'Dibayar dari saldo agen', NOW(), NOW()),
(3, 'bank_transfer', 195000.00, 'verified', 'payment_proofs/proof_3.jpg', 'Mandiri', '1234-5678-9012', 'Budi Santoso', NOW(), 1, NULL, NULL, NOW(), NOW()),
(4, 'bank_transfer', 500000.00, 'pending', 'payment_proofs/proof_4.jpg', 'BRI', '0012-3456-7890-12', 'Stockist Samarinda', NULL, NULL, NULL, NULL, NOW(), NOW()),
(6, 'deposit', 145000.00, 'pending', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Menunggu konfirmasi saldo', NOW(), NOW());


-- ============================================================
-- COMMIT
-- ============================================================
COMMIT;
