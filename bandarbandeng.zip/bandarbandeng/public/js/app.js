/*
 * ============================================================
 *  Bandar Bandeng Kalimantan — Main Application JavaScript
 * ============================================================
 *  Fitur:
 *    - Theme toggle (auto/light/dark)
 *    - Sidebar toggle (mobile)
 *    - Flash message auto-dismiss
 *    - Number formatting (Rupiah)
 *    - Form helpers (quantity +/-, confirmation)
 *    - Notification polling
 * ============================================================
 */

(function () {
    'use strict';

    /* ── Theme Toggle ──────────────────────────────────────── */
    const ThemeManager = {
        STORAGE_KEY: 'bbk_theme',

        init: function () {
            var saved = localStorage.getItem(this.STORAGE_KEY) || 'auto';
            this.apply(saved);
            this.bindEvents();
        },

        apply: function (mode) {
            localStorage.setItem(this.STORAGE_KEY, mode);

            var isDark = false;
            if (mode === 'dark') {
                isDark = true;
            } else if (mode === 'auto') {
                var hour = new Date().getHours();
                isDark = (hour < 6 || hour >= 18);
            }

            if (isDark) {
                document.documentElement.setAttribute('data-bs-theme', 'dark');
                document.body.classList.add('dark-mode');
            } else {
                document.documentElement.removeAttribute('data-bs-theme');
                document.body.classList.remove('dark-mode');
            }

            // Update icons
            var sunIcons = document.querySelectorAll('.theme-icon-sun');
            var moonIcons = document.querySelectorAll('.theme-icon-moon');
            var autoIcons = document.querySelectorAll('.theme-icon-auto');

            sunIcons.forEach(function (el) { el.classList.toggle('d-none', mode === 'dark' || mode === 'auto'); });
            moonIcons.forEach(function (el) { el.classList.toggle('d-none', mode === 'light' || mode === 'auto'); });
            autoIcons.forEach(function (el) { el.classList.toggle('d-none', mode !== 'auto'); });
        },

        bindEvents: function () {
            var self = this;
            document.querySelectorAll('[data-theme]').forEach(function (btn) {
                btn.addEventListener('click', function (e) {
                    e.preventDefault();
                    self.apply(this.getAttribute('data-theme'));

                    // Sync to server session
                    fetch('/theme', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
                        },
                        body: JSON.stringify({ theme: this.getAttribute('data-theme') })
                    }).catch(function () { /* silently fail */ });
                });
            });
        }
    };

    /* ── Sidebar Toggle (Mobile) ───────────────────────────── */
    function initSidebar() {
        var toggleBtns = document.querySelectorAll('[data-sidebar-toggle]');
        toggleBtns.forEach(function (btn) {
            btn.addEventListener('click', function () {
                var target = document.getElementById(this.getAttribute('data-sidebar-toggle'));
                var overlay = document.getElementById('sidebarOverlay');
                if (target) {
                    target.classList.toggle('show');
                }
                if (overlay) {
                    overlay.classList.toggle('show');
                }
            });
        });

        // Close sidebar on overlay click
        var overlay = document.getElementById('sidebarOverlay');
        if (overlay) {
            overlay.addEventListener('click', function () {
                document.querySelectorAll('.sidebar-bbk').forEach(function (s) {
                    s.classList.remove('show');
                });
                overlay.classList.remove('show');
            });
        }

        // Close sidebar on window resize to desktop
        window.addEventListener('resize', function () {
            if (window.innerWidth >= 992) {
                document.querySelectorAll('.sidebar-bbk').forEach(function (s) {
                    s.classList.remove('show');
                });
                var ov = document.getElementById('sidebarOverlay');
                if (ov) ov.classList.remove('show');
            }
        });
    }

    /* ── Flash Message Auto Dismiss ────────────────────────── */
    function initFlashMessages() {
        document.querySelectorAll('.alert[data-auto-dismiss]').forEach(function (alert) {
            var delay = parseInt(alert.getAttribute('data-auto-dismiss')) || 5000;
            setTimeout(function () {
                alert.style.transition = 'opacity 0.4s ease';
                alert.style.opacity = '0';
                setTimeout(function () {
                    alert.remove();
                }, 400);
            }, delay);
        });
    }

    /* ── Rupiah Formatter ──────────────────────────────────── */
    window.formatRupiah = function (number) {
        if (typeof number !== 'number') {
            number = parseInt(number) || 0;
        }
        return 'Rp ' + number.toLocaleString('id-ID');
    };

    window.parseRupiah = function (string) {
        return parseInt(string.replace(/[^0-9]/g, '')) || 0;
    };

    /* ── Quantity +/- Buttons ──────────────────────────────── */
    function initQuantityControls() {
        document.querySelectorAll('[data-qty-plus]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = document.getElementById(this.getAttribute('data-qty-plus'));
                if (input) {
                    var max = parseInt(input.getAttribute('max')) || 9999;
                    var val = parseInt(input.value) || 0;
                    if (val < max) {
                        input.value = val + 1;
                        input.dispatchEvent(new Event('change'));
                    }
                }
            });
        });

        document.querySelectorAll('[data-qty-minus]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var input = document.getElementById(this.getAttribute('data-qty-minus'));
                if (input) {
                    var min = parseInt(input.getAttribute('min')) || 0;
                    var val = parseInt(input.value) || 0;
                    if (val > min) {
                        input.value = val - 1;
                        input.dispatchEvent(new Event('change'));
                    }
                }
            });
        });
    }

    /* ── Confirmation Dialog ───────────────────────────────── */
    window.confirmAction = function (message) {
        return confirm(message || 'Apakah Anda yakin?');
    };

    /* ── Form Submit Prevention (Double Click) ─────────────── */
    function initFormProtection() {
        document.querySelectorAll('form[data-submit-once]').forEach(function (form) {
            form.addEventListener('submit', function () {
                var btn = form.querySelector('[type="submit"]');
                if (btn && !btn.disabled) {
                    btn.disabled = true;
                    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Memproses...';
                }
            });
        });
    }

    /* ── Image Preview on Upload ───────────────────────────── */
    window.previewImage = function (input, previewElementId) {
        var preview = document.getElementById(previewElementId);
        if (!preview || !input.files || !input.files[0]) return;

        var reader = new FileReader();
        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.classList.remove('d-none');
        };
        reader.readAsDataURL(input.files[0]);
    };

    /* ── Copy to Clipboard ─────────────────────────────────── */
    window.copyToClipboard = function (text, messageElId) {
        navigator.clipboard.writeText(text).then(function () {
            var el = document.getElementById(messageElId);
            if (el) {
                el.textContent = 'Tersalin!';
                el.classList.remove('d-none');
                setTimeout(function () { el.classList.add('d-none'); }, 2000);
            }
        }).catch(function () {
            // Fallback
            var ta = document.createElement('textarea');
            ta.value = text;
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            document.body.removeChild(ta);
        });
    };

    /* ── Scroll to Element ─────────────────────────────────── */
    window.scrollToElement = function (selector) {
        var el = document.querySelector(selector);
        if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };

    /* ── Active Nav Highlight ──────────────────────────────── */
    function highlightActiveNav() {
        var currentPath = window.location.pathname;

        document.querySelectorAll('.sidebar-bbk .nav-link').forEach(function (link) {
            var href = link.getAttribute('href');
            if (href && currentPath.startsWith(href) && href !== '/') {
                link.classList.add('active');
            }
        });

        document.querySelectorAll('.bottom-nav .nav-item-bottom').forEach(function (link) {
            var href = link.getAttribute('href');
            if (href && currentPath.startsWith(href) && href !== '/') {
                link.classList.add('active');
            }
        });
    }

    /* ── Notification Badge (Simple Polling) ───────────────── */
    var NotificationPoller = {
        interval: null,
        POLL_URL: '/api/notifications/unread-count',
        POLL_INTERVAL: 60000, // 1 minute

        start: function () {
            // Only poll if user is authenticated
            if (!document.querySelector('meta[name="user-auth"]')) return;

            var self = this;
            this.fetchCount();

            this.interval = setInterval(function () {
                self.fetchCount();
            }, this.POLL_INTERVAL);
        },

        fetchCount: function () {
            fetch(this.POLL_URL, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || ''
                }
            }).then(function (resp) {
                if (!resp.ok) throw new Error('Not OK');
                return resp.json();
            }).then(function (data) {
                var badges = document.querySelectorAll('.notification-badge');
                badges.forEach(function (badge) {
                    if (data.count > 0) {
                        badge.textContent = data.count > 99 ? '99+' : data.count;
                        badge.classList.remove('d-none');
                    } else {
                        badge.classList.add('d-none');
                    }
                });
            }).catch(function () {
                // Silently fail — notification polling is non-critical
            });
        },

        stop: function () {
            if (this.interval) {
                clearInterval(this.interval);
            }
        }
    };

    /* ── Initialize Everything ─────────────────────────────── */
    document.addEventListener('DOMContentLoaded', function () {
        ThemeManager.init();
        initSidebar();
        initFlashMessages();
        initQuantityControls();
        initFormProtection();
        highlightActiveNav();
        NotificationPoller.start();
    });

})();
