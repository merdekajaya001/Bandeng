/*
 * ============================================================
 *  Bandar Bandeng Kalimantan — Landing Page JavaScript
 * ============================================================
 *  Fitur:
 *    - Navbar scroll effect (transparent → solid)
 *    - AOS init
 *    - Smooth scroll for anchor links
 *    - Video play handler
 *    - Gallery lightbox
 *    - Agent search filter
 *    - Animated counters
 *    - Nutrition circle animation
 * ============================================================
 */

(function () {
    'use strict';

    /* ── Navbar Scroll Effect ──────────────────────────────── */
    function initNavbarScroll() {
        var navbar = document.querySelector('.navbar-landing');
        if (!navbar) return;

        function checkScroll() {
            if (window.scrollY > 50) {
                navbar.classList.add('navbar-scrolled');
                navbar.classList.remove('navbar-transparent');
            } else {
                navbar.classList.remove('navbar-scrolled');
                navbar.classList.add('navbar-transparent');
            }
        }

        window.addEventListener('scroll', checkScroll, { passive: true });
        checkScroll(); // Initial check
    }

    /* ── AOS (Animate On Scroll) Init ──────────────────────── */
    function initAOS() {
        if (typeof AOS !== 'undefined') {
            AOS.init({
                duration: 800,
                easing: 'ease-out-cubic',
                once: true,
                offset: 80,
                disable: function () {
                    return window.innerWidth < 768;
                }
            });
        }
    }

    /* ── Smooth Scroll for Anchor Links ────────────────────── */
    function initSmoothScroll() {
        document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
            anchor.addEventListener('click', function (e) {
                var targetId = this.getAttribute('href');
                if (targetId === '#' || targetId === '') return;

                var target = document.querySelector(targetId);
                if (target) {
                    e.preventDefault();
                    var offset = 80; // navbar height
                    var top = target.getBoundingClientRect().top + window.pageYOffset - offset;
                    window.scrollTo({ top: top, behavior: 'smooth' });
                }
            });
        });
    }

    /* ── Video Play Handler ────────────────────────────────── */
    function initVideoPlayer() {
        var playBtn = document.querySelector('.video-play-btn');
        var wrapper = document.querySelector('.video-wrapper');
        if (!playBtn || !wrapper) return;

        playBtn.addEventListener('click', function () {
            var videoId = wrapper.getAttribute('data-video-id') || 'dQw4w9WgXcQ';
            var iframe = document.createElement('iframe');
            iframe.src = 'https://www.youtube.com/embed/' + videoId + '?autoplay=1&rel=0';
            iframe.setAttribute('allowfullscreen', '');
            iframe.setAttribute('allow', 'autoplay; encrypted-media');
            iframe.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;';

            // Remove placeholder content
            var placeholder = wrapper.querySelector('.video-placeholder');
            if (placeholder) placeholder.remove();
            playBtn.remove();

            wrapper.appendChild(iframe);
        });
    }

    /* ── Gallery Lightbox ──────────────────────────────────── */
    function initLightbox() {
        document.querySelectorAll('.gallery-item').forEach(function (item) {
            item.addEventListener('click', function () {
                var img = this.querySelector('img');
                if (!img) return;

                var modal = document.createElement('div');
                modal.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.85);z-index:9999;display:flex;align-items:center;justify-content:center;cursor:pointer;animation:fadeIn 0.3s ease;';

                var bigImg = document.createElement('img');
                bigImg.src = img.src;
                bigImg.alt = img.alt || '';
                bigImg.style.cssText = 'max-width:90%;max-height:90%;border-radius:12px;box-shadow:0 8px 32px rgba(0,0,0,0.4);';

                modal.appendChild(bigImg);
                modal.addEventListener('click', function () { modal.remove(); });
                document.body.appendChild(modal);
            });
        });
    }

    /* ── Agent Search Filter ───────────────────────────────── */
    function initAgentSearch() {
        var searchInput = document.getElementById('agentSearch');
        if (!searchInput) return;

        searchInput.addEventListener('input', function () {
            var query = this.value.toLowerCase().trim();
            var cards = document.querySelectorAll('.agent-card-wrapper');

            cards.forEach(function (card) {
                var name = (card.getAttribute('data-agent-name') || '').toLowerCase();
                var city = (card.getAttribute('data-agent-city') || '').toLowerCase();
                var match = name.indexOf(query) !== -1 || city.indexOf(query) !== -1;
                card.style.display = match ? '' : 'none';
            });
        });
    }

    /* ── Animated Counters ─────────────────────────────────── */
    function initCounters() {
        var counters = document.querySelectorAll('[data-counter]');
        if (counters.length === 0) return;

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        counters.forEach(function (el) {
            observer.observe(el);
        });
    }

    function animateCounter(element) {
        var target = parseInt(element.getAttribute('data-counter')) || 0;
        var duration = 2000;
        var start = 0;
        var startTime = null;

        function step(timestamp) {
            if (!startTime) startTime = timestamp;
            var progress = Math.min((timestamp - startTime) / duration, 1);
            // Ease out cubic
            var eased = 1 - Math.pow(1 - progress, 3);
            var current = Math.floor(eased * target);
            element.textContent = current.toLocaleString('id-ID');
            if (progress < 1) {
                requestAnimationFrame(step);
            } else {
                element.textContent = target.toLocaleString('id-ID') + '+';
            }
        }

        requestAnimationFrame(step);
    }

    /* ── Nutrition Circle Animation ────────────────────────── */
    function initNutritionCircles() {
        var circles = document.querySelectorAll('.nutrition-circle .circle-fill');
        if (circles.length === 0) return;

        var observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    var circle = entry.target;
                    var percent = parseInt(circle.getAttribute('data-percent')) || 0;
                    var radius = circle.getAttribute('r') || 35;
                    var circumference = 2 * Math.PI * radius;
                    var offset = circumference - (percent / 100) * circumference;

                    circle.style.strokeDasharray = circumference;
                    circle.style.strokeDashoffset = circumference;

                    setTimeout(function () {
                        circle.style.strokeDashoffset = offset;
                    }, 200);

                    observer.unobserve(circle);
                }
            });
        }, { threshold: 0.5 });

        circles.forEach(function (c) {
            observer.observe(c);
        });
    }

    /* ── Testimonial Carousel (Bootstrap) ──────────────────── */
    function initTestimonialCarousel() {
        var carousel = document.getElementById('testimonialCarousel');
        if (!carousel || typeof bootstrap === 'undefined') return;

        new bootstrap.Carousel(carousel, {
            interval: 5000,
            wrap: true,
            ride: 'carousel'
        });
    }

    /* ── Active Nav Tracking on Scroll ─────────────────────── */
    function initScrollSpy() {
        var sections = document.querySelectorAll('section[id]');
        if (sections.length === 0) return;

        var navLinks = document.querySelectorAll('.navbar-landing .nav-link[href^="#"]');

        window.addEventListener('scroll', function () {
            var scrollY = window.scrollY + 100;

            sections.forEach(function (section) {
                var top = section.offsetTop;
                var height = section.offsetHeight;
                var id = section.getAttribute('id');

                if (scrollY >= top && scrollY < top + height) {
                    navLinks.forEach(function (link) {
                        link.classList.remove('active');
                        if (link.getAttribute('href') === '#' + id) {
                            link.classList.add('active');
                        }
                    });
                }
            });
        }, { passive: true });
    }

    /* ── Initialize Everything ─────────────────────────────── */
    document.addEventListener('DOMContentLoaded', function () {
        initNavbarScroll();
        initAOS();
        initSmoothScroll();
        initVideoPlayer();
        initLightbox();
        initAgentSearch();
        initCounters();
        initNutritionCircles();
        initTestimonialCarousel();
        initScrollSpy();
    });

})();
