@extends('layouts.admin')

@section('title', 'Dashboard Admin - Bandar Bandeng Kalimantan')

@section('page_title', 'Dashboard')

@push('styles')
<style>
    .stat-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    .stat-card .stat-icon {
        width: 56px;
        height: 56px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
    }
    .stat-card .stat-number {
        font-size: 1.75rem;
        font-weight: 800;
        line-height: 1.2;
    }
    .stat-card .stat-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 500;
    }
    .low-stock-item {
        border-left: 4px solid #dc3545;
        padding: 0.6rem 1rem;
        margin-bottom: 0.5rem;
        background: #fff5f5;
        border-radius: 0 8px 8px 0;
    }
    [data-bs-theme="dark"] .low-stock-item {
        background: rgba(220,53,69,0.1);
    }
    .quick-action-btn {
        border-radius: 12px;
        padding: 1rem;
        text-align: center;
        transition: all 0.2s;
        text-decoration: none;
        display: block;
    }
    .quick-action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.1);
    }
    .chart-placeholder {
        background: linear-gradient(135deg, rgba(12,75,142,0.05) 0%, rgba(212,160,23,0.05) 100%);
        border: 2px dashed rgba(12,75,142,0.2);
        border-radius: 12px;
        min-height: 300px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }
    [data-bs-theme="dark"] .chart-placeholder {
        background: linear-gradient(135deg, rgba(12,75,142,0.15) 0%, rgba(212,160,23,0.1) 100%);
        border-color: rgba(212,160,23,0.3);
    }
    .status-badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.3em 0.7em;
        border-radius: 50px;
    }
</style>
@endpush

@section('admin_content')

<!-- Stat Cards -->
<div class="row g-3 mb-4">
    <!-- Total Pesanan -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(12,75,142,0.12); color: #0C4B8E;">
                    <i class="fas fa-receipt"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #0C4B8E;">
                        {{ number_format($stats['total_orders'] ?? 0) }}
                    </div>
                    <div class="stat-label">Total Pesanan</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Pendapatan Bulan Ini -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                    <i class="fas fa-coins"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #D4A017;">
                        Rp {{ number_format($stats['monthly_revenue'] ?? 0, 0, ',', '.') }}
                    </div>
                    <div class="stat-label">Pendapatan Bulan Ini</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Total Pengguna -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(39,174,96,0.12); color: #27AE60;">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #27AE60;">
                        {{ number_format($stats['total_users'] ?? 0) }}
                    </div>
                    <div class="stat-label">Total Pengguna</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Produk Aktif -->
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(108,117,125,0.12); color: #6c757d;">
                    <i class="fas fa-box-open"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #495057;">
                        {{ number_format($stats['active_products'] ?? 0) }}
                    </div>
                    <div class="stat-label">Produk Aktif</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <a href="{{ route('admin.products.create') }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); color: white;">
            <i class="fas fa-plus-circle fa-2x mb-2"></i>
            <div class="fw-bold">Tambah Produk</div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="{{ route('admin.orders.index') }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #D4A017 0%, #F4D03F 100%); color: #333;">
            <i class="fas fa-clipboard-list fa-2x mb-2"></i>
            <div class="fw-bold">Kelola Pesanan</div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="{{ route('admin.payments.index', ['status' => 'pending']) }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #27AE60 0%, #2ECC71 100%); color: white;">
            <i class="fas fa-check-circle fa-2x mb-2"></i>
            <div class="fw-bold">Verifikasi Pembayaran</div>
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Recent Orders -->
    <div class="col-lg-8">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-clock me-2"></i>Pesanan Terbaru
                </h6>
                <a href="{{ route('admin.orders.index') }}" class="btn btn-sm btn-outline-primary" style="border-radius: 8px;">
                    Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="font-size: 0.8rem;">No. Pesanan</th>
                                <th style="font-size: 0.8rem;">Pembeli</th>
                                <th style="font-size: 0.8rem;">Tipe</th>
                                <th style="font-size: 0.8rem;">Status</th>
                                <th style="font-size: 0.8rem;" class="text-end">Total</th>
                                <th style="font-size: 0.8rem;" class="text-end pe-3">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($recentOrders ?? [] as $order)
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('admin.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                        #{{ $order->order_number ?? $order->id }}
                                    </a>
                                </td>
                                <td>{{ $order->buyer->name ?? '-' }}</td>
                                <td>
                                    @if(($order->type ?? '') === 'retail')
                                        <span class="badge bg-info bg-opacity-10 text-info">Retail</span>
                                    @else
                                        <span class="badge bg-warning bg-opacity-10 text-warning">Grosir</span>
                                    @endif
                                </td>
                                <td>
                                    @php
                                        $statusColors = [
                                            'pending' => 'secondary',
                                            'processing' => 'info',
                                            'shipped' => 'primary',
                                            'delivered' => 'success',
                                            'completed' => 'success',
                                            'cancelled' => 'danger',
                                        ];
                                        $statusColor = $statusColors[$order->status ?? 'pending'] ?? 'secondary';
                                    @endphp
                                    <span class="status-badge badge bg-{{ $statusColor }} bg-opacity-10 text-{{ $statusColor }}">
                                        {{ ucfirst($order->status ?? 'pending') }}
                                    </span>
                                </td>
                                <td class="text-end fw-semibold">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                                <td class="text-end pe-3 text-muted" style="font-size: 0.85rem;">
                                    {{ $order->created_at ? $order->created_at->format('d M Y') : '-' }}
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox fa-2x mb-2 d-block opacity-50"></i>
                                    Belum ada pesanan
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Low Stock Alerts -->
    <div class="col-lg-4">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0 text-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>Stok Rendah
                </h6>
                <a href="{{ route('admin.stock.index') }}" class="btn btn-sm btn-outline-danger" style="border-radius: 8px;">
                    Kelola
                </a>
            </div>
            <div class="card-body">
                @forelse($lowStocks ?? [] as $stock)
                <div class="low-stock-item">
                    <div class="fw-semibold" style="font-size: 0.9rem;">{{ $stock->productVariant->product->name ?? $stock->name ?? '-' }}</div>
                    <div class="d-flex justify-content-between align-items-center mt-1">
                        <small class="text-muted">{{ $stock->productVariant->name ?? $stock->variant_name ?? '-' }}</small>
                        <span class="badge bg-danger">
                            {{ $stock->available_stock ?? $stock->stock ?? 0 }} tersisa
                        </span>
                    </div>
                </div>
                @empty
                <div class="text-center text-muted py-4">
                    <i class="fas fa-check-circle fa-2x mb-2 d-block text-success opacity-50"></i>
                    Semua stok aman
                </div>
                @endforelse
            </div>
        </div>
    </div>
</div>

<!-- Sales Trend Chart Placeholder -->
<div class="row g-4">
    <div class="col-12">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-chart-line me-2"></i>Tren Penjualan
                </h6>
            </div>
            <div class="card-body">
                <div class="chart-placeholder">
                    <i class="fas fa-chart-area fa-3x mb-3" style="color: rgba(12,75,142,0.25);"></i>
                    <p class="mb-1 fw-semibold" style="color: rgba(12,75,142,0.5);">Grafik Tren Penjualan</p>
                    <small class="text-muted">Integrasikan dengan Chart.js atau library grafik lainnya</small>
                    <div class="mt-3 d-flex gap-2">
                        <button class="btn btn-sm btn-outline-primary" style="border-radius: 8px;">7 Hari</button>
                        <button class="btn btn-sm btn-outline-primary active" style="border-radius: 8px;">30 Hari</button>
                        <button class="btn btn-sm btn-outline-primary" style="border-radius: 8px;">90 Hari</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
