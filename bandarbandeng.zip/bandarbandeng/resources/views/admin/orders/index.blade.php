@extends('layouts.admin')

@section('title', 'Kelola Pesanan - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Pesanan</li>
@endsection

@section('page_title', 'Kelola Pesanan')

@push('styles')
<style>
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .status-badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.35em 0.75em;
        border-radius: 50px;
    }
    .filter-input {
        border-radius: 10px;
        border: 2px solid #e9ecef;
    }
    .filter-input:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.1);
    }
</style>
@endpush

@section('admin_content')

<!-- Filters -->
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('admin.orders.index') }}" class="row g-2 align-items-end">
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Status</label>
                <select name="status" class="form-select filter-input">
                    <option value="">Semua Status</option>
                    <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Pending</option>
                    <option value="processing" {{ request('status') === 'processing' ? 'selected' : '' }}>Processing</option>
                    <option value="shipped" {{ request('status') === 'shipped' ? 'selected' : '' }}>Dikirim</option>
                    <option value="delivered" {{ request('status') === 'delivered' ? 'selected' : '' }}>Diterima</option>
                    <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Selesai</option>
                    <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>Dibatalkan</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Tipe</label>
                <select name="type" class="form-select filter-input">
                    <option value="">Semua Tipe</option>
                    <option value="retail" {{ request('type') === 'retail' ? 'selected' : '' }}>Retail</option>
                    <option value="wholesale" {{ request('type') === 'wholesale' ? 'selected' : '' }}>Grosir</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Dari Tanggal</label>
                <input type="date" name="date_from" class="form-control filter-input" value="{{ request('date_from') }}">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Sampai Tanggal</label>
                <input type="date" name="date_to" class="form-control filter-input" value="{{ request('date_to') }}">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Cari</label>
                <input type="text" name="search" class="form-control filter-input"
                       placeholder="No. pesanan / nama pembeli..." value="{{ request('search') }}">
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Orders Table -->
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">No. Pesanan</th>
                        <th>Pembeli</th>
                        <th>Tipe</th>
                        <th class="text-center">Status</th>
                        <th class="text-end">Total</th>
                        <th>Tanggal</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($orders ?? [] as $order)
                    @php
                        $statusConfig = [
                            'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
                            'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Processing'],
                            'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                            'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                            'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                            'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                        ];
                        $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
                    @endphp
                    <tr>
                        <td class="ps-3">
                            <a href="{{ route('admin.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                #{{ $order->order_number ?? $order->id }}
                            </a>
                        </td>
                        <td>
                            <div class="fw-semibold">{{ $order->buyer->name ?? '-' }}</div>
                            <small class="text-muted">{{ $order->buyer->email ?? '' }}</small>
                        </td>
                        <td>
                            @if(($order->type ?? '') === 'retail')
                                <span class="badge bg-info bg-opacity-10 text-info">
                                    <i class="fas fa-shopping-bag me-1"></i>Retail
                                </span>
                            @else
                                <span class="badge bg-warning bg-opacity-10 text-warning">
                                    <i class="fas fa-boxes me-1"></i>Grosir
                                </span>
                            @endif
                        </td>
                        <td class="text-center">
                            <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                                <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                            </span>
                        </td>
                        <td class="text-end fw-semibold">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                        <td>
                            <div style="font-size: 0.88rem;">{{ $order->created_at ? $order->created_at->format('d M Y') : '-' }}</div>
                            <small class="text-muted">{{ $order->created_at ? $order->created_at->format('H:i') : '' }}</small>
                        </td>
                        <td class="text-center pe-3">
                            <a href="{{ route('admin.orders.show', $order->id) }}"
                               class="btn btn-sm btn-outline-primary" style="border-radius: 8px;" title="Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted py-5">
                            <i class="fas fa-receipt fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada pesanan</p>
                            <small>Pesanan yang masuk akan tampil di sini</small>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
@if(isset($orders) && method_exists($orders, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $orders->links() }}
</div>
@endif

@endsection
