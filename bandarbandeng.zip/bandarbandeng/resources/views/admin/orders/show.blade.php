@extends('layouts.admin')

@section('title', 'Detail Pesanan - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.orders.index') }}">Pesanan</a></li>
    <li class="breadcrumb-item active" aria-current="page">#{{ $order->order_number ?? $order->id }}</li>
@endsection

@section('page_title', 'Detail Pesanan')

@push('styles')
<style>
    .detail-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.2rem;
    }
    .detail-value {
        font-size: 0.95rem;
        font-weight: 500;
    }
    .status-badge {
        font-size: 0.82rem;
        font-weight: 600;
        padding: 0.4em 1em;
        border-radius: 50px;
    }
    .info-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
    }
    .info-card .card-header {
        font-weight: 700;
        font-size: 0.95rem;
        border-bottom: 2px solid rgba(12,75,142,0.1);
    }
    .proof-image {
        max-width: 250px;
        max-height: 250px;
        border-radius: 10px;
        border: 2px solid #e9ecef;
        cursor: pointer;
        transition: transform 0.2s;
    }
    .proof-image:hover {
        transform: scale(1.02);
    }
</style>
@endpush

@section('admin_content')

@php
    $statusConfig = [
        'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
        'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Processing'],
        'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
        'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
        'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
        'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
    ];
    $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
@endphp

<div class="row g-4">
    <!-- Order Info -->
    <div class="col-lg-8">
        <!-- Order Details Card -->
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <span style="color: #0C4B8E;"><i class="fas fa-receipt me-2"></i>Informasi Pesanan</span>
                <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                    <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                </span>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="detail-label">No. Pesanan</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">#{{ $order->order_number ?? $order->id }}</div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Tanggal Pesanan</div>
                        <div class="detail-value">{{ $order->created_at ? $order->created_at->format('d F Y, H:i') : '-' }}</div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Tipe Pesanan</div>
                        <div class="detail-value">
                            @if(($order->type ?? '') === 'retail')
                                <span class="badge bg-info bg-opacity-10 text-info"><i class="fas fa-shopping-bag me-1"></i>Retail</span>
                            @else
                                <span class="badge bg-warning bg-opacity-10 text-warning"><i class="fas fa-boxes me-1"></i>Grosir</span>
                            @endif
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Pembeli</div>
                        <div class="detail-value">
                            <a href="{{ route('admin.users.show', $order->buyer_id ?? 0) }}" class="text-decoration-none" style="color: #0C4B8E;">
                                {{ $order->buyer->name ?? '-' }}
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Penjual / Agen</div>
                        <div class="detail-value">
                            <a href="{{ route('admin.users.show', $order->seller_id ?? 0) }}" class="text-decoration-none" style="color: #0C4B8E;">
                                {{ $order->seller->name ?? '-' }}
                            </a>
                        </div>
                    </div>
                    @if($order->shipping_address ?? null)
                    <div class="col-md-4">
                        <div class="detail-label">Alamat Pengiriman</div>
                        <div class="detail-value" style="font-size: 0.88rem;">{{ $order->shipping_address }}</div>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Items Table -->
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-box me-2"></i>Item Pesanan
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="font-size: 0.8rem;">Produk / Varian</th>
                                <th class="text-center" style="font-size: 0.8rem;">Qty</th>
                                <th class="text-end" style="font-size: 0.8rem;">Harga</th>
                                <th class="text-end pe-3" style="font-size: 0.8rem;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->items ?? [] as $item)
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-semibold">{{ $item->productVariant->product->name ?? $item->product_name ?? '-' }}</div>
                                    <small class="text-muted">{{ $item->productVariant->name ?? $item->variant_name ?? '' }}</small>
                                </td>
                                <td class="text-center fw-semibold">{{ $item->quantity ?? 1 }}</td>
                                <td class="text-end">Rp {{ number_format($item->price ?? 0, 0, ',', '.') }}</td>
                                <td class="text-end fw-semibold pe-3">Rp {{ number_format($item->subtotal ?? ($item->price * $item->quantity) ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr style="border-top: 2px solid #dee2e6;">
                                <td colspan="3" class="text-end pe-3 pt-3"><strong>Subtotal</strong></td>
                                <td class="text-end pe-3 pt-3 fw-semibold">Rp {{ number_format($order->subtotal ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @if(($order->shipping_cost ?? 0) > 0)
                            <tr>
                                <td colspan="3" class="text-end pe-3"><strong>Ongkos Kirim</strong></td>
                                <td class="text-end pe-3 fw-semibold">Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</td>
                            </tr>
                            @endif
                            @if(($order->discount ?? 0) > 0)
                            <tr>
                                <td colspan="3" class="text-end pe-3 text-danger"><strong>Diskon</strong></td>
                                <td class="text-end pe-3 fw-semibold text-danger">- Rp {{ number_format($order->discount, 0, ',', '.') }}</td>
                            </tr>
                            @endif
                            <tr>
                                <td colspan="3" class="text-end pe-3 pb-3">
                                    <strong style="font-size: 1.1rem; color: #0C4B8E;">Total</strong>
                                </td>
                                <td class="text-end pe-3 pb-3">
                                    <strong style="font-size: 1.1rem; color: #0C4B8E;">
                                        Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}
                                    </strong>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- Payment Info Card -->
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #D4A017;">
                <i class="fas fa-credit-card me-2"></i>Informasi Pembayaran
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="detail-label">Metode</div>
                        <div class="detail-value">{{ $order->payment->method_label ?? $order->payment->method ?? '-' }}</div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Jumlah</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">
                            Rp {{ number_format($order->payment->amount ?? $order->total ?? 0, 0, ',', '.') }}
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Status Bayar</div>
                        <div class="detail-value">
                            @php
                                $payStatusConfig = [
                                    'pending'  => ['color' => 'secondary', 'label' => 'Menunggu'],
                                    'paid'     => ['color' => 'success', 'label' => 'Dibayar'],
                                    'verified' => ['color' => 'success', 'label' => 'Terverifikasi'],
                                    'rejected' => ['color' => 'danger', 'label' => 'Ditolak'],
                                    'failed'   => ['color' => 'danger', 'label' => 'Gagal'],
                                ];
                                $psc = $payStatusConfig[$order->payment->status ?? 'pending'] ?? $payStatusConfig['pending'];
                            @endphp
                            <span class="badge bg-{{ $psc['color'] }} bg-opacity-10 text-{{ $psc['color'] }} status-badge">
                                {{ $psc['label'] }}
                            </span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Tanggal Bayar</div>
                        <div class="detail-value" style="font-size: 0.88rem;">
                            {{ ($order->payment->paid_at ?? null) ? $order->payment->paid_at->format('d M Y, H:i') : '-' }}
                        </div>
                    </div>
                </div>

                @if($order->payment->proof_image ?? null)
                <div class="mt-3">
                    <div class="detail-label mb-2">Bukti Pembayaran</div>
                    <img src="{{ asset('storage/' . $order->payment->proof_image) }}"
                         alt="Bukti Pembayaran" class="proof-image"
                         onclick="window.open(this.src, '_blank')">
                </div>
                @endif
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-cogs me-2"></i>Aksi
            </div>
            <div class="card-body">
                @auth
                @if(auth()->user()->hasRole('admin'))
                    <!-- Approve Payment -->
                    @if(($order->payment->status ?? '') === 'pending' || ($order->payment->status ?? '') === 'paid')
                    <form action="{{ route('admin.payments.verify', $order->payment->id ?? $order->id) }}" method="POST" class="mb-2">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="verified">
                        <button type="submit" class="btn btn-success w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-check-circle me-2"></i>Setujui Pembayaran
                        </button>
                    </form>
                    <form action="{{ route('admin.payments.verify', $order->payment->id ?? $order->id) }}" method="POST" class="mb-3">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="rejected">
                        <button type="submit" class="btn btn-outline-danger w-100 fw-bold" style="border-radius: 10px;"
                                onclick="return confirm('Yakin ingin menolak pembayaran ini?')">
                            <i class="fas fa-times-circle me-2"></i>Tolak Pembayaran
                        </button>
                    </form>
                    @endif

                    <!-- Update Order Status -->
                    <div class="mb-2">
                        <label class="form-label fw-semibold small">Ubah Status Pesanan</label>
                        <form action="{{ route('admin.orders.update', $order->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="input-group">
                                <select name="status" class="form-select" style="border-radius: 10px 0 0 10px;">
                                    @foreach($statusConfig as $key => $config)
                                    <option value="{{ $key }}" {{ $order->status === $key ? 'selected' : '' }}>
                                        {{ $config['label'] }}
                                    </option>
                                    @endforeach
                                </select>
                                <button type="submit" class="btn text-white fw-bold" style="background: #0C4B8E; border-radius: 0 10px 10px 0;">
                                    <i class="fas fa-save"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                @endif
                @endauth

                <hr>

                <!-- Print / Notes -->
                <a href="javascript:window.print()" class="btn btn-outline-secondary w-100 mb-2" style="border-radius: 10px;">
                    <i class="fas fa-print me-2"></i>Cetak
                </a>
            </div>
        </div>

        <!-- Order Notes -->
        @if($order->notes ?? null)
        <div class="card info-card shadow-sm">
            <div class="card-header bg-white py-3" style="color: #6c757d;">
                <i class="fas fa-sticky-note me-2"></i>Catatan
            </div>
            <div class="card-body">
                <p class="mb-0" style="font-size: 0.9rem;">{{ $order->notes }}</p>
            </div>
        </div>
        @endif
    </div>
</div>

@endsection
