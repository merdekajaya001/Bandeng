@extends('layouts.admin')

@section('title', 'Verifikasi Pembayaran - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Pembayaran</li>
@endsection

@section('page_title', 'Verifikasi Pembayaran')

@push('styles')
<style>
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .status-badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.35em 0.75em;
        border-radius: 50px;
    }
    .proof-thumb {
        width: 45px;
        height: 45px;
        object-fit: cover;
        border-radius: 8px;
        border: 2px solid #e9ecef;
        cursor: pointer;
        transition: transform 0.2s;
    }
    .proof-thumb:hover {
        transform: scale(1.1);
    }
</style>
@endpush

@section('admin_content')

<!-- Filters -->
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('admin.payments.index') }}" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Status Pembayaran</label>
                <select name="status" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Status</option>
                    <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Menunggu Verifikasi</option>
                    <option value="paid" {{ request('status') === 'paid' ? 'selected' : '' }}>Dibayar</option>
                    <option value="verified" {{ request('status') === 'verified' ? 'selected' : '' }}>Terverifikasi</option>
                    <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>Ditolak</option>
                    <option value="failed" {{ request('status') === 'failed' ? 'selected' : '' }}>Gagal</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Metode Pembayaran</label>
                <select name="method" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Metode</option>
                    <option value="bank_transfer" {{ request('method') === 'bank_transfer' ? 'selected' : '' }}>Transfer Bank</option>
                    <option value="ewallet" {{ request('method') === 'ewallet' ? 'selected' : '' }}>E-Wallet</option>
                    <option value="cod" {{ request('method') === 'cod' ? 'selected' : '' }}>COD</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold small mb-1">Cari</label>
                <input type="text" name="search" class="form-control" style="border-radius: 10px;"
                       placeholder="No. pesanan..." value="{{ request('search') }}">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Summary Stats -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-body text-center py-3">
                <div class="fw-bold text-secondary" style="font-size: 1.5rem;">{{ $pendingCount ?? 0 }}</div>
                <small class="text-muted">Menunggu Verifikasi</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-body text-center py-3">
                <div class="fw-bold text-success" style="font-size: 1.5rem;">{{ $verifiedCount ?? 0 }}</div>
                <small class="text-muted">Terverifikasi</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-body text-center py-3">
                <div class="fw-bold text-danger" style="font-size: 1.5rem;">{{ $rejectedCount ?? 0 }}</div>
                <small class="text-muted">Ditolak</small>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-body text-center py-3">
                <div class="fw-bold" style="font-size: 1.5rem; color: #0C4B8E;">Rp {{ number_format($totalAmount ?? 0, 0, ',', '.') }}</div>
                <small class="text-muted">Total Terverifikasi</small>
            </div>
        </div>
    </div>
</div>

<!-- Payments Table -->
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">No. Pesanan</th>
                        <th>Metode</th>
                        <th class="text-end">Jumlah</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Bukti</th>
                        <th>Tanggal</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($payments ?? [] as $payment)
                    @php
                        $payStatusConfig = [
                            'pending'  => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Menunggu'],
                            'paid'     => ['color' => 'info', 'icon' => 'money-bill', 'label' => 'Dibayar'],
                            'verified' => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Terverifikasi'],
                            'rejected' => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Ditolak'],
                            'failed'   => ['color' => 'danger', 'icon' => 'exclamation-circle', 'label' => 'Gagal'],
                        ];
                        $psc = $payStatusConfig[$payment->status ?? 'pending'] ?? $payStatusConfig['pending'];

                        $methodLabels = [
                            'bank_transfer' => 'Transfer Bank',
                            'ewallet' => 'E-Wallet',
                            'cod' => 'COD',
                        ];
                    @endphp
                    <tr>
                        <td class="ps-3">
                            <a href="{{ route('admin.orders.show', $payment->order_id ?? $payment->id) }}"
                               class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                #{{ $payment->order->order_number ?? $payment->order_id ?? '-' }}
                            </a>
                        </td>
                        <td>
                            <span class="badge bg-light text-dark border">
                                @if(($payment->method ?? '') === 'bank_transfer')
                                    <i class="fas fa-university me-1"></i>
                                @elseif(($payment->method ?? '') === 'ewallet')
                                    <i class="fas fa-mobile-alt me-1"></i>
                                @else
                                    <i class="fas fa-hand-holding-usd me-1"></i>
                                @endif
                                {{ $methodLabels[$payment->method ?? ''] ?? $payment->method ?? '-' }}
                            </span>
                        </td>
                        <td class="text-end fw-semibold">Rp {{ number_format($payment->amount ?? 0, 0, ',', '.') }}</td>
                        <td class="text-center">
                            <span class="status-badge badge bg-{{ $psc['color'] }} bg-opacity-10 text-{{ $psc['color'] }}">
                                <i class="fas fa-{{ $psc['icon'] }} me-1"></i>{{ $psc['label'] }}
                            </span>
                        </td>
                        <td class="text-center">
                            @if($payment->proof_image ?? null)
                                <img src="{{ asset('storage/' . $payment->proof_image) }}" alt="Bukti"
                                     class="proof-thumb" onclick="window.open(this.src, '_blank')">
                            @else
                                <span class="text-muted"><i class="fas fa-image"></i></span>
                            @endif
                        </td>
                        <td>
                            <div style="font-size: 0.88rem;">{{ $payment->created_at ? $payment->created_at->format('d M Y') : '-' }}</div>
                            <small class="text-muted">{{ $payment->created_at ? $payment->created_at->format('H:i') : '' }}</small>
                        </td>
                        <td class="text-center pe-3">
                            @if(in_array($payment->status ?? '', ['pending', 'paid']))
                            <div class="btn-group btn-group-sm">
                                <form action="{{ route('admin.payments.verify', $payment->id) }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <input type="hidden" name="status" value="verified">
                                    <button type="submit" class="btn btn-success" style="border-radius: 8px 0 0 8px;" title="Verifikasi">
                                        <i class="fas fa-check"></i>
                                    </button>
                                </form>
                                <form action="{{ route('admin.payments.verify', $payment->id) }}" method="POST"
                                      onsubmit="return confirm('Yakin menolak pembayaran ini?')">
                                    @csrf
                                    @method('PUT')
                                    <input type="hidden" name="status" value="rejected">
                                    <button type="submit" class="btn btn-outline-danger" style="border-radius: 0 8px 8px 0;" title="Tolak">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </form>
                            </div>
                            @else
                            <a href="{{ route('admin.orders.show', $payment->order_id ?? $payment->id) }}"
                               class="btn btn-sm btn-outline-primary" style="border-radius: 8px;" title="Lihat Pesanan">
                                <i class="fas fa-eye"></i>
                            </a>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted py-5">
                            <i class="fas fa-credit-card fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada pembayaran</p>
                            <small>Data pembayaran akan muncul di sini</small>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
@if(isset($payments) && method_exists($payments, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $payments->links() }}
</div>
@endif

@endsection
