@extends('layouts.admin')

@section('title', 'Tambah Produk - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.products.index') }}">Produk</a></li>
    <li class="breadcrumb-item active" aria-current="page">Tambah</li>
@endsection

@section('page_title', 'Tambah Produk Baru')

@push('styles')
<style>
    .form-control:focus, .form-select:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.12);
    }
    .variant-card {
        border: 2px solid #e9ecef;
        border-radius: 12px;
        transition: border-color 0.2s;
    }
    .variant-card:hover {
        border-color: rgba(12,75,142,0.3);
    }
    .variant-card .card-header {
        background: rgba(12,75,142,0.04);
        border-bottom: 1px solid #e9ecef;
        border-radius: 10px 10px 0 0;
    }
    .section-title {
        color: #0C4B8E;
        font-weight: 700;
        font-size: 1.05rem;
        border-bottom: 2px solid #D4A017;
        padding-bottom: 0.5rem;
        margin-bottom: 1rem;
    }
    .image-preview {
        width: 100%;
        max-height: 200px;
        object-fit: cover;
        border-radius: 8px;
        border: 2px dashed #e9ecef;
        display: none;
    }
</style>
@endpush

@section('admin_content')

<form action="{{ route('admin.products.store') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="row g-4">
        <!-- Product Info -->
        <div class="col-lg-8">
            <div class="card shadow-sm" style="border-radius: 12px; border: none;">
                <div class="card-body p-4">
                    <h6 class="section-title"><i class="fas fa-info-circle me-2"></i>Informasi Produk</h6>

                    <div class="mb-3">
                        <label for="name" class="form-label fw-semibold">Nama Produk <span class="text-danger">*</span></label>
                        <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror"
                               value="{{ old('name') }}" placeholder="Masukkan nama produk" required autofocus>
                        @error('name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="slug" class="form-label fw-semibold">Slug</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light text-muted" style="font-size: 0.85rem;">/produk/</span>
                            <input type="text" name="slug" id="slug" class="form-control @error('slug') is-invalid @enderror"
                                   value="{{ old('slug') }}" placeholder="auto-generate dari nama">
                            @error('slug')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <small class="text-muted">Kosongkan untuk auto-generate dari nama produk</small>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label fw-semibold">Deskripsi</label>
                        <textarea name="description" id="description" rows="4"
                                  class="form-control @error('description') is-invalid @enderror"
                                  placeholder="Deskripsi produk...">{{ old('description') }}</textarea>
                        @error('description')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="category_id" class="form-label fw-semibold">Kategori <span class="text-danger">*</span></label>
                            <select name="category_id" id="category_id" class="form-select @error('category_id') is-invalid @enderror" required>
                                <option value="">Pilih Kategori</option>
                                @foreach($categories ?? [] as $category)
                                <option value="{{ $category->id ?? $category }}" {{ old('category_id') == ($category->id ?? $category) ? 'selected' : '' }}>
                                    {{ $category->name ?? $category }}
                                </option>
                                @endforeach
                            </select>
                            @error('category_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label for="status" class="form-label fw-semibold">Status</label>
                            <select name="status" id="status" class="form-select @error('status') is-invalid @enderror">
                                <option value="active" {{ old('status', 'active') === 'active' ? 'selected' : '' }}>Aktif</option>
                                <option value="inactive" {{ old('status') === 'inactive' ? 'selected' : '' }}>Nonaktif</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Product Image -->
        <div class="col-lg-4">
            <div class="card shadow-sm" style="border-radius: 12px; border: none;">
                <div class="card-body p-4">
                    <h6 class="section-title"><i class="fas fa-image me-2"></i>Gambar Produk</h6>

                    <div class="text-center">
                        <img id="imagePreview" class="image-preview mb-3 mx-auto d-block" alt="Preview">
                        <label for="image" class="btn btn-outline-primary w-100" style="border-radius: 10px; border: 2px dashed #0C4B8E;">
                            <i class="fas fa-cloud-upload-alt me-2"></i> Pilih Gambar
                        </label>
                        <input type="file" name="image" id="image" class="d-none" accept="image/*">
                        <small class="text-muted d-block mt-2">Format: JPG, PNG, WebP. Maks 2MB.</small>
                    </div>

                    @error('image')
                        <div class="text-danger small mt-2">{{ $message }}</div>
                    @enderror
                </div>
            </div>
        </div>
    </div>

    <!-- Variants Section -->
    <div class="mt-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="section-title mb-0"><i class="fas fa-layer-group me-2"></i>Varian Produk</h6>
            <button type="button" class="btn btn-sm text-white fw-bold" style="background: #0C4B8E; border-radius: 8px;"
                    onclick="addVariant()">
                <i class="fas fa-plus me-1"></i> Tambah Varian
            </button>
        </div>

        <div id="variantsContainer">
            <!-- Default Variant -->
            <div class="variant-card card mb-3" data-variant-index="0">
                <div class="card-header d-flex justify-content-between align-items-center py-2">
                    <span class="fw-bold" style="color: #0C4B8E; font-size: 0.9rem;">
                        <i class="fas fa-cube me-1"></i> Varian #1
                    </span>
                    <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeVariant(this)" title="Hapus Varian">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Nama Varian <span class="text-danger">*</span></label>
                            <input type="text" name="variants[0][name]" class="form-control form-control-sm"
                                   value="{{ old('variants.0.name') }}" placeholder="cth: Reguler, Premium" required>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label fw-semibold small">Jumlah Ikan</label>
                            <input type="number" name="variants[0][fish_count]" class="form-control form-control-sm"
                                   value="{{ old('variants.0.fish_count') }}" placeholder="0" min="0">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Harga (Rp) <span class="text-danger">*</span></label>
                            <input type="number" name="variants[0][price]" class="form-control form-control-sm"
                                   value="{{ old('variants.0.price') }}" placeholder="0" min="0" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label fw-semibold small">Berat (Kg)</label>
                            <input type="number" name="variants[0][weight_kg]" class="form-control form-control-sm"
                                   value="{{ old('variants.0.weight_kg') }}" placeholder="0" min="0" step="0.1">
                        </div>
                        <div class="col-md-8">
                            <label class="form-label fw-semibold small">Gambar Varian</label>
                            <input type="file" name="variants[0][image]" class="form-control form-control-sm" accept="image/*">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label fw-semibold small">Stok Awal</label>
                            <input type="number" name="variants[0][stock]" class="form-control form-control-sm"
                                   value="{{ old('variants.0.stock', 0) }}" placeholder="0" min="0">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Submit -->
    <div class="mt-4 d-flex gap-2">
        <button type="submit" class="btn btn-lg text-white fw-bold px-5" style="background: #0C4B8E; border-radius: 10px;">
            <i class="fas fa-save me-2"></i> Simpan Produk
        </button>
        <a href="{{ route('admin.products.index') }}" class="btn btn-lg btn-outline-secondary px-4" style="border-radius: 10px;">
            Batal
        </a>
    </div>
</form>

@endsection

@push('scripts')
<script>
    let variantIndex = 1;

    // Auto-generate slug from name
    document.getElementById('name').addEventListener('input', function () {
        const slugInput = document.getElementById('slug');
        if (!slugInput.value || slugInput.dataset.auto === 'true') {
            const slug = this.value
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim();
            slugInput.value = slug;
            slugInput.dataset.auto = 'true';
        }
    });

    document.getElementById('slug').addEventListener('input', function () {
        this.dataset.auto = 'false';
    });

    // Image preview
    document.getElementById('image').addEventListener('change', function (e) {
        const preview = document.getElementById('imagePreview');
        if (e.target.files && e.target.files[0]) {
            const reader = new FileReader();
            reader.onload = function (ev) {
                preview.src = ev.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    });

    // Add variant
    function addVariant() {
        const container = document.getElementById('variantsContainer');
        const html = `
        <div class="variant-card card mb-3" data-variant-index="${variantIndex}">
            <div class="card-header d-flex justify-content-between align-items-center py-2">
                <span class="fw-bold" style="color: #0C4B8E; font-size: 0.9rem;">
                    <i class="fas fa-cube me-1"></i> Varian #${variantIndex + 1}
                </span>
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeVariant(this)" title="Hapus Varian">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold small">Nama Varian <span class="text-danger">*</span></label>
                        <input type="text" name="variants[${variantIndex}][name]" class="form-control form-control-sm"
                               placeholder="cth: Reguler, Premium" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label fw-semibold small">Jumlah Ikan</label>
                        <input type="number" name="variants[${variantIndex}][fish_count]" class="form-control form-control-sm"
                               placeholder="0" min="0">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold small">Harga (Rp) <span class="text-danger">*</span></label>
                        <input type="number" name="variants[${variantIndex}][price]" class="form-control form-control-sm"
                               placeholder="0" min="0" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold small">Berat (Kg)</label>
                        <input type="number" name="variants[${variantIndex}][weight_kg]" class="form-control form-control-sm"
                               placeholder="0" min="0" step="0.1">
                    </div>
                    <div class="col-md-8">
                        <label class="form-label fw-semibold small">Gambar Varian</label>
                        <input type="file" name="variants[${variantIndex}][image]" class="form-control form-control-sm" accept="image/*">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold small">Stok Awal</label>
                        <input type="number" name="variants[${variantIndex}][stock]" class="form-control form-control-sm"
                               value="0" placeholder="0" min="0">
                    </div>
                </div>
            </div>
        </div>`;
        container.insertAdjacentHTML('beforeend', html);
        variantIndex++;
    }

    // Remove variant
    function removeVariant(btn) {
        const card = btn.closest('.variant-card');
        card.style.transition = 'opacity 0.2s, transform 0.2s';
        card.style.opacity = '0';
        card.style.transform = 'translateX(-20px)';
        setTimeout(() => card.remove(), 200);
    }
</script>
@endpush
