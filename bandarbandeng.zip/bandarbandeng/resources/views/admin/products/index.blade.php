@extends('layouts.admin')

@section('title', 'Kelola Produk - Bandar Bandeng Kalimantan')

@section('page_title', 'Kelola Produk')

@section('page_actions')
<a href="{{ route('admin.products.create') }}" class="btn btn-sm fw-bold text-white" style="background: #0C4B8E; border-radius: 8px;">
    <i class="fas fa-plus me-1"></i> Tambah Produk
</a>
@endsection

@push('styles')
<style>
    .product-img {
        width: 50px;
        height: 50px;
        object-fit: cover;
        border-radius: 8px;
        border: 2px solid #e9ecef;
    }
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .table td {
        vertical-align: middle;
        font-size: 0.9rem;
    }
    .search-box {
        border-radius: 10px;
        border: 2px solid #e9ecef;
        transition: border-color 0.2s;
    }
    .search-box:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.1);
    }
</style>
@endpush

@section('admin_content')

<!-- Search & Filters -->
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('admin.products.index') }}" class="row g-2 align-items-center">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0" style="border-radius: 10px 0 0 10px; border: 2px solid #e9ecef; border-right: 0;">
                        <i class="fas fa-search text-muted"></i>
                    </span>
                    <input type="text" name="search" class="form-control search-box border-start-0"
                           placeholder="Cari produk..." value="{{ request('search') }}"
                           style="border-left: 0; border-radius: 0 10px 10px 0;">
                </div>
            </div>
            <div class="col-md-3">
                <select name="category" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Kategori</option>
                    @foreach($categories ?? [] as $category)
                    <option value="{{ $category->id ?? $category }}" {{ request('category') == ($category->id ?? $category) ? 'selected' : '' }}>
                        {{ $category->name ?? $category }}
                    </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-2">
                <select name="status" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Status</option>
                    <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Aktif</option>
                    <option value="inactive" {{ request('status') === 'inactive' ? 'selected' : '' }}>Nonaktif</option>
                </select>
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Products Table -->
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Gambar</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th class="text-center">Varian</th>
                        <th class="text-center">Status</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($products ?? [] as $product)
                    <tr>
                        <td class="ps-3">
                            @if($product->image ?? null)
                                <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="product-img">
                            @else
                                <div class="product-img bg-light d-flex align-items-center justify-content-center">
                                    <i class="fas fa-fish text-muted"></i>
                                </div>
                            @endif
                        </td>
                        <td>
                            <div class="fw-semibold" style="color: #0C4B8E;">{{ $product->name }}</div>
                            <small class="text-muted">{{ $product->slug }}</small>
                        </td>
                        <td>
                            <span class="badge" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                                {{ $product->category->name ?? $product->category ?? '-' }}
                            </span>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold">{{ $product->variants->count() ?? $product->variant_count ?? 0 }}</span>
                        </td>
                        <td class="text-center">
                            @if(($product->status ?? 'active') === 'active')
                                <span class="badge bg-success bg-opacity-10 text-success" style="font-size: 0.78rem;">
                                    <i class="fas fa-check-circle me-1"></i>Aktif
                                </span>
                            @else
                                <span class="badge bg-secondary bg-opacity-10 text-secondary" style="font-size: 0.78rem;">
                                    <i class="fas fa-minus-circle me-1"></i>Nonaktif
                                </span>
                            @endif
                        </td>
                        <td class="text-center pe-3">
                            <div class="btn-group btn-group-sm">
                                <a href="{{ route('admin.products.edit', $product->id) }}"
                                   class="btn btn-outline-primary" style="border-radius: 8px 0 0 8px;" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form action="{{ route('admin.products.destroy', $product->id) }}" method="POST"
                                      onsubmit="return confirm('Yakin ingin menghapus produk ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-outline-danger" style="border-radius: 0 8px 8px 0;" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            <i class="fas fa-box-open fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada produk</p>
                            <a href="{{ route('admin.products.create') }}" class="btn btn-sm text-white" style="background: #0C4B8E; border-radius: 8px;">
                                <i class="fas fa-plus me-1"></i> Tambah Produk Pertama
                            </a>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
@if(isset($products) && method_exists($products, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $products->links() }}
</div>
@endif

@endsection
