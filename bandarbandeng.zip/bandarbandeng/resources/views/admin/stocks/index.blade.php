@extends('layouts.admin')

@section('title', 'Manajemen Stok - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.products.index') }}">Produk</a></li>
    <li class="breadcrumb-item active" aria-current="page">Stok</li>
@endsection

@section('page_title', 'Manajemen Stok')

@push('styles')
<style>
    .stock-indicator {
        height: 6px;
        border-radius: 3px;
        background: #e9ecef;
        overflow: hidden;
    }
    .stock-indicator .fill {
        height: 100%;
        border-radius: 3px;
        transition: width 0.5s ease;
    }
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .stock-input {
        width: 90px;
        border-radius: 8px;
        text-align: center;
        font-weight: 700;
    }
    .stock-input:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.12);
    }
</style>
@endpush

@section('admin_content')

<!-- Filters -->
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('admin.stock.index') }}" class="row g-2 align-items-center">
            <div class="col-md-6">
                <label class="form-label fw-semibold small mb-1">Filter Produk</label>
                <select name="product_id" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Produk</option>
                    @foreach($products ?? [] as $product)
                    <option value="{{ $product->id }}" {{ request('product_id') == $product->id ? 'selected' : '' }}>
                        {{ $product->name }}
                    </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Stok</label>
                <select name="stock_filter" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua</option>
                    <option value="low" {{ request('stock_filter') === 'low' ? 'selected' : '' }}>Stok Rendah</option>
                    <option value="out" {{ request('stock_filter') === 'out' ? 'selected' : '' }}>Habis</option>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Stock Table -->
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Produk</th>
                        <th>Varian</th>
                        <th class="text-center">Stok Tersedia</th>
                        <th class="text-center">Stok Terpesan</th>
                        <th class="text-center">Level Stok</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($stocks ?? [] as $stock)
                    @php
                        $available = $stock->available_stock ?? $stock->stock ?? 0;
                        $reserved = $stock->reserved_stock ?? 0;
                        $maxStock = 100;
                        $percentage = min(($available / $maxStock) * 100, 100);
                        $barColor = $available <= 5 ? 'danger' : ($available <= 20 ? 'warning' : 'success');
                    @endphp
                    <tr>
                        <td class="ps-3">
                            <div class="fw-semibold" style="color: #0C4B8E;">
                                {{ $stock->productVariant->product->name ?? $stock->product_name ?? '-' }}
                            </div>
                        </td>
                        <td>
                            <span class="badge" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                                {{ $stock->productVariant->name ?? $stock->variant_name ?? '-' }}
                            </span>
                        </td>
                        <td class="text-center">
                            <form action="{{ route('admin.stock.update', $stock->id ?? 0) }}" method="POST" class="d-inline">
                                @csrf
                                @method('PUT')
                                <div class="input-group input-group-sm justify-content-center">
                                    <input type="number" name="available_stock" class="form-control stock-input"
                                           value="{{ $available }}" min="0">
                                    <button type="submit" class="btn btn-sm btn-outline-primary" title="Simpan">
                                        <i class="fas fa-save"></i>
                                    </button>
                                </div>
                            </form>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold text-muted">{{ $reserved }}</span>
                        </td>
                        <td class="text-center" style="min-width: 120px;">
                            <div class="d-flex align-items-center justify-content-center gap-2">
                                <div class="stock-indicator flex-grow-1">
                                    <div class="fill bg-{{ $barColor }}" style="width: {{ $percentage }}%;"></div>
                                </div>
                                <small class="fw-bold text-{{ $barColor }}">{{ $available }}</small>
                            </div>
                        </td>
                        <td class="text-center pe-3">
                            <div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-outline-success" title="Tambah Stok"
                                        onclick="addStock({{ $stock->id ?? 0 }}, '{{ $stock->productVariant->name ?? $stock->variant_name ?? '' }}')">
                                    <i class="fas fa-plus"></i>
                                </button>
                                <a href="{{ route('admin.products.edit', $stock->productVariant->product->id ?? $stock->product_id ?? 0) }}"
                                   class="btn btn-outline-primary" title="Edit Produk">
                                    <i class="fas fa-edit"></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            <i class="fas fa-cubes fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada data stok</p>
                            <a href="{{ route('admin.products.create') }}" class="btn btn-sm text-white" style="background: #0C4B8E; border-radius: 8px;">
                                <i class="fas fa-plus me-1"></i> Tambah Produk Terlebih Dahulu
                            </a>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
@if(isset($stocks) && method_exists($stocks, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $stocks->links() }}
</div>
@endif

<!-- Add Stock Modal -->
<div class="modal fade" id="addStockModal" tabindex="-1" aria-labelledby="addStockModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius: 12px; border: none;">
            <div class="modal-header border-0 pb-0">
                <h6 class="modal-title fw-bold" style="color: #0C4B8E;" id="addStockModalLabel">
                    <i class="fas fa-plus-circle me-2"></i>Tambah Stok
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('admin.stock.update', 0) }}" method="POST" id="addStockForm">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <p class="text-muted mb-3">Tambah stok untuk varian: <strong id="variantNameDisplay">-</strong></p>
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Jumlah Tambah Stok</label>
                        <input type="number" name="add_stock" class="form-control" min="1" value="10" required
                               style="border-radius: 10px;">
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 8px;">Batal</button>
                    <button type="submit" class="btn text-white fw-bold" style="background: #27AE60; border-radius: 8px;">
                        <i class="fas fa-plus me-1"></i> Tambah Stok
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    function addStock(stockId, variantName) {
        const form = document.getElementById('addStockForm');
        form.action = '{{ route('admin.stock.update', '__ID__') }}'.replace('__ID__', stockId);
        document.getElementById('variantNameDisplay').textContent = variantName || '-';
        document.getElementById('addStockForm').querySelector('[name="add_stock"]').value = 10;

        const modal = new bootstrap.Modal(document.getElementById('addStockModal'));
        modal.show();
    }
</script>
@endpush
