@extends('layouts.admin')

@section('title', 'Kelola Testimoni - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Testimoni</li>
@endsection

@section('page_title', 'Kelola Testimoni')

@push('styles')
<style>
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .star-rating {
        color: #D4A017;
        font-size: 0.9rem;
    }
    .star-rating .empty {
        color: #e0e0e0;
    }
    .testimonial-content {
        max-width: 300px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        font-size: 0.88rem;
    }
    .toggle-btn {
        cursor: pointer;
        transition: all 0.2s;
    }
    .toggle-btn:hover {
        transform: scale(1.1);
    }
    [data-bs-theme="dark"] .star-rating .empty {
        color: #4a5568;
    }
</style>
@endpush

@section('admin_content')

<!-- Filters -->
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('admin.testimonials.index') }}" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Rating</label>
                <select name="rating" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Rating</option>
                    <option value="5" {{ request('rating') === '5' ? 'selected' : '' }}>5 Bintang</option>
                    <option value="4" {{ request('rating') === '4' ? 'selected' : '' }}>4 Bintang</option>
                    <option value="3" {{ request('rating') === '3' ? 'selected' : '' }}>3 Bintang</option>
                    <option value="2" {{ request('rating') === '2' ? 'selected' : '' }}>2 Bintang</option>
                    <option value="1" {{ request('rating') === '1' ? 'selected' : '' }}>1 Bintang</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Status</label>
                <select name="status" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua</option>
                    <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Aktif</option>
                    <option value="inactive" {{ request('status') === 'inactive' ? 'selected' : '' }}>Nonaktif</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold small mb-1">Cari</label>
                <input type="text" name="search" class="form-control" style="border-radius: 10px;"
                       placeholder="Nama / isi testimoni..." value="{{ request('search') }}">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Testimonials Table -->
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Nama</th>
                        <th>Rating</th>
                        <th>Isi Testimoni</th>
                        <th class="text-center">Featured</th>
                        <th class="text-center">Aktif</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($testimonials ?? [] as $testimonial)
                    <tr>
                        <td class="ps-3">
                            <div class="fw-semibold" style="color: #0C4B8E;">{{ $testimonial->user->name ?? $testimonial->name ?? '-' }}</div>
                            <small class="text-muted">{{ $testimonial->created_at ? $testimonial->created_at->format('d M Y') : '' }}</small>
                        </td>
                        <td>
                            <div class="star-rating">
                                @for($i = 1; $i <= 5; $i++)
                                    @if($i <= ($testimonial->rating ?? 0))
                                        <i class="fas fa-star"></i>
                                    @else
                                        <i class="fas fa-star empty"></i>
                                    @endif
                                @endfor
                            </div>
                        </td>
                        <td>
                            <div class="testimonial-content" title="{{ $testimonial->content ?? '' }}">
                                {{ $testimonial->content ?? '-' }}
                            </div>
                        </td>
                        <td class="text-center">
                            <form action="{{ route('admin.testimonials.update', $testimonial->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="action" value="toggle_featured">
                                <button type="submit" class="btn btn-sm toggle-btn {{ ($testimonial->is_featured ?? false) ? 'btn-warning' : 'btn-outline-secondary' }}"
                                        title="{{ ($testimonial->is_featured ?? false) ? 'Hapus dari Featured' : 'Jadikan Featured' }}"
                                        style="border-radius: 50%; width: 32px; height: 32px; padding: 0;">
                                    <i class="fas fa-star" style="font-size: 0.75rem;"></i>
                                </button>
                            </form>
                        </td>
                        <td class="text-center">
                            <form action="{{ route('admin.testimonials.update', $testimonial->id) }}" method="POST" class="d-inline">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="action" value="toggle_active">
                                <button type="submit" class="btn btn-sm toggle-btn {{ ($testimonial->is_active ?? true) ? 'btn-success' : 'btn-outline-secondary' }}"
                                        title="{{ ($testimonial->is_active ?? true) ? 'Nonaktifkan' : 'Aktifkan' }}"
                                        style="border-radius: 50%; width: 32px; height: 32px; padding: 0;">
                                    <i class="fas fa-{{ ($testimonial->is_active ?? true) ? 'check' : 'times' }}" style="font-size: 0.75rem;"></i>
                                </button>
                            </form>
                        </td>
                        <td class="text-center pe-3">
                            <form action="{{ route('admin.testimonials.destroy', $testimonial->id) }}" method="POST"
                                  onsubmit="return confirm('Yakin ingin menghapus testimoni ini?')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-outline-danger" style="border-radius: 8px;" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            <i class="fas fa-star fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada testimoni</p>
                            <small>Testimoni dari pelanggan akan tampil di sini</small>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
@if(isset($testimonials) && method_exists($testimonials, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $testimonials->links() }}
</div>
@endif

@endsection
