@extends('layouts.admin')

@section('title', 'Kelola Pengguna - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Pengguna</li>
@endsection

@section('page_title', 'Kelola Pengguna')

@push('styles')
<style>
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        border: 2px solid #e9ecef;
    }
    .user-avatar-placeholder {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 0.85rem;
        color: white;
    }
    .role-badge {
        font-size: 0.72rem;
        font-weight: 600;
        padding: 0.3em 0.7em;
        border-radius: 50px;
    }
</style>
@endpush

@section('admin_content')

<!-- Filters -->
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('admin.users.index') }}" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Role</label>
                <select name="role" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Role</option>
                    <option value="admin" {{ request('role') === 'admin' ? 'selected' : '' }}>Admin</option>
                    <option value="stockist" {{ request('role') === 'stockist' ? 'selected' : '' }}>Stockist</option>
                    <option value="agent" {{ request('role') === 'agent' ? 'selected' : '' }}>Agen</option>
                    <option value="customer" {{ request('role') === 'customer' ? 'selected' : '' }}>Pelanggan</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Status</label>
                <select name="status" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Status</option>
                    <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Aktif</option>
                    <option value="inactive" {{ request('status') === 'inactive' ? 'selected' : '' }}>Nonaktif</option>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label fw-semibold small mb-1">Cari</label>
                <input type="text" name="search" class="form-control" style="border-radius: 10px;"
                       placeholder="Nama / email pengguna..." value="{{ request('search') }}">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-search me-1"></i> Cari
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Users Table -->
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Nama</th>
                        <th>Email</th>
                        <th class="text-center">Role</th>
                        <th>Kota</th>
                        <th class="text-center">Status</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users ?? [] as $user)
                    @php
                        $roleColors = [
                            'admin' => 'danger',
                            'stockist' => 'primary',
                            'agent' => 'warning',
                            'customer' => 'info',
                        ];
                        $roleLabels = [
                            'admin' => 'Admin',
                            'stockist' => 'Stockist',
                            'agent' => 'Agen',
                            'customer' => 'Pelanggan',
                        ];
                        $roleColor = $roleColors[$user->role ?? 'customer'] ?? 'info';
                        $roleLabel = $roleLabels[$user->role ?? 'customer'] ?? ucfirst($user->role ?? 'Pelanggan');
                    @endphp
                    <tr>
                        <td class="ps-3">
                            <div class="d-flex align-items-center gap-2">
                                @if($user->avatar ?? null)
                                    <img src="{{ $user->avatar_url ?? asset('storage/' . $user->avatar) }}"
                                         alt="{{ $user->name }}" class="user-avatar">
                                @else
                                    <div class="user-avatar-placeholder" style="background: #0C4B8E;">
                                        {{ strtoupper(substr($user->name ?? '?', 0, 1)) }}
                                    </div>
                                @endif
                                <div>
                                    <div class="fw-semibold">{{ $user->name }}</div>
                                    <small class="text-muted">ID: {{ $user->id }}</small>
                                </div>
                            </div>
                        </td>
                        <td style="font-size: 0.9rem;">{{ $user->email }}</td>
                        <td class="text-center">
                            <span class="role-badge badge bg-{{ $roleColor }} bg-opacity-10 text-{{ $roleColor }}">
                                {{ $roleLabel }}
                            </span>
                        </td>
                        <td>{{ $user->city ?? $user->address ?? '-' }}</td>
                        <td class="text-center">
                            @if(($user->status ?? 'active') === 'active')
                                <span class="badge bg-success bg-opacity-10 text-success" style="font-size: 0.78rem;">
                                    <i class="fas fa-check-circle me-1"></i>Aktif
                                </span>
                            @else
                                <span class="badge bg-secondary bg-opacity-10 text-secondary" style="font-size: 0.78rem;">
                                    <i class="fas fa-minus-circle me-1"></i>Nonaktif
                                </span>
                            @endif
                        </td>
                        <td class="text-center pe-3">
                            <div class="btn-group btn-group-sm">
                                <a href="{{ route('admin.users.show', $user->id) }}"
                                   class="btn btn-outline-primary" style="border-radius: 8px 0 0 8px;" title="Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                                @auth
                                @if(auth()->user()->hasRole('admin') && !$user->hasRole('admin'))
                                    <form action="{{ route('admin.users.update', $user->id) }}" method="POST">
                                        @csrf
                                        @method('PUT')
                                        <input type="hidden" name="action" value="toggle_status">
                                        <button type="submit" class="btn btn-outline-{{ ($user->status ?? 'active') === 'active' ? 'warning' : 'success' }}"
                                                style="border-radius: 0;" title="{{ ($user->status ?? 'active') === 'active' ? 'Nonaktifkan' : 'Aktifkan' }}">
                                            <i class="fas fa-{{ ($user->status ?? 'active') === 'active' ? 'ban' : 'check' }}"></i>
                                        </button>
                                    </form>
                                @endif
                                @endauth
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            <i class="fas fa-users fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada pengguna</p>
                            <small>Pengguna yang terdaftar akan tampil di sini</small>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
@if(isset($users) && method_exists($users, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $users->links() }}
</div>
@endif

@endsection
