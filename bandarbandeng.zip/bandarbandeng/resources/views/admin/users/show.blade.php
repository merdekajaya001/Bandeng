@extends('layouts.admin')

@section('title', 'Detail Pengguna - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('admin.users.index') }}">Pengguna</a></li>
    <li class="breadcrumb-item active" aria-current="page">{{ $user->name }}</li>
@endsection

@section('page_title', 'Detail Pengguna')

@push('styles')
<style>
    .profile-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        object-fit: cover;
        border: 4px solid #e9ecef;
    }
    .profile-avatar-placeholder {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        font-size: 1.8rem;
        color: white;
        background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%);
    }
    .info-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
    }
    .info-card .card-header {
        font-weight: 700;
        font-size: 0.95rem;
        border-bottom: 2px solid rgba(12,75,142,0.1);
    }
    .detail-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.2rem;
    }
    .detail-value {
        font-size: 0.95rem;
        font-weight: 500;
    }
    .stat-mini {
        text-align: center;
        padding: 1rem 0.5rem;
        border-radius: 10px;
        background: rgba(12,75,142,0.04);
    }
    .stat-mini .number {
        font-size: 1.5rem;
        font-weight: 800;
        color: #0C4B8E;
    }
    .stat-mini .label {
        font-size: 0.75rem;
        color: #6c757d;
        font-weight: 600;
    }
    .activity-item {
        padding: 0.75rem 0;
        border-bottom: 1px solid #f0f0f0;
    }
    .activity-item:last-child {
        border-bottom: none;
    }
    .wallet-balance {
        background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%);
        border-radius: 12px;
        color: white;
        padding: 1.5rem;
    }
    [data-bs-theme="dark"] .stat-mini {
        background: rgba(12,75,142,0.15);
    }
</style>
@endpush

@section('admin_content')

@php
    $roleColors = [
        'admin' => 'danger',
        'stockist' => 'primary',
        'agent' => 'warning',
        'customer' => 'info',
    ];
    $roleLabels = [
        'admin' => 'Admin',
        'stockist' => 'Stockist',
        'agent' => 'Agen',
        'customer' => 'Pelanggan',
    ];
    $roleColor = $roleColors[$user->role ?? 'customer'] ?? 'info';
    $roleLabel = $roleLabels[$user->role ?? 'customer'] ?? ucfirst($user->role ?? 'Pelanggan');
@endphp

<div class="row g-4">
    <!-- Profile Info -->
    <div class="col-lg-4">
        <!-- Profile Card -->
        <div class="card info-card shadow-sm mb-4">
            <div class="card-body text-center p-4">
                @if($user->avatar ?? null)
                    <img src="{{ $user->avatar_url ?? asset('storage/' . $user->avatar) }}"
                         alt="{{ $user->name }}" class="profile-avatar mb-3">
                @else
                    <div class="profile-avatar-placeholder mx-auto mb-3">
                        {{ strtoupper(substr($user->name ?? '?', 0, 1)) }}
                    </div>
                @endif
                <h5 class="fw-bold mb-1" style="color: #0C4B8E;">{{ $user->name }}</h5>
                <p class="text-muted mb-2" style="font-size: 0.9rem;">{{ $user->email }}</p>
                <span class="badge bg-{{ $roleColor }} bg-opacity-10 text-{{ $roleColor }} px-3 py-2" style="border-radius: 50px; font-weight: 600;">
                    <i class="fas fa-shield-alt me-1"></i>{{ $roleLabel }}
                </span>
                <div class="mt-3">
                    @if(($user->status ?? 'active') === 'active')
                        <span class="badge bg-success bg-opacity-10 text-success px-3 py-2" style="border-radius: 50px;">
                            <i class="fas fa-check-circle me-1"></i>Aktif
                        </span>
                    @else
                        <span class="badge bg-secondary bg-opacity-10 text-secondary px-3 py-2" style="border-radius: 50px;">
                            <i class="fas fa-minus-circle me-1"></i>Nonaktif
                        </span>
                    @endif
                </div>
            </div>
        </div>

        <!-- Wallet Balance -->
        <div class="wallet-balance shadow-sm mb-4">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <div>
                    <small class="opacity-75"><i class="fas fa-wallet me-1"></i>Saldo Dompet</small>
                </div>
                <a href="#" class="text-white text-decoration-none" style="font-size: 0.85rem;">
                    <i class="fas fa-history me-1"></i>Riwayat
                </a>
            </div>
            <div class="fs-4 fw-bold">Rp {{ number_format($user->wallet->balance ?? 0, 0, ',', '.') }}</div>
        </div>

        <!-- Profile Details -->
        <div class="card info-card shadow-sm">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-id-card me-2"></i>Informasi Profil
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <div class="detail-label">Nomor Telepon</div>
                    <div class="detail-value">{{ $user->phone ?? '-' }}</div>
                </div>
                <div class="mb-3">
                    <div class="detail-label">Kota</div>
                    <div class="detail-value">{{ $user->city ?? '-' }}</div>
                </div>
                <div class="mb-3">
                    <div class="detail-label">Alamat</div>
                    <div class="detail-value" style="font-size: 0.88rem;">{{ $user->address ?? '-' }}</div>
                </div>
                <div class="mb-3">
                    <div class="detail-label">Terdaftar Sejak</div>
                    <div class="detail-value">{{ $user->created_at ? $user->created_at->format('d F Y') : '-' }}</div>
                </div>
                @if($user->role === 'agent' || $user->role === 'stockist')
                <div class="mb-0">
                    <div class="detail-label">Bank</div>
                    <div class="detail-value" style="font-size: 0.88rem;">
                        {{ $user->bank_name ?? '-' }} - {{ $user->bank_account_number ?? '-' }}
                        <br><small class="text-muted">a/n {{ $user->bank_account_name ?? '-' }}</small>
                    </div>
                </div>
                @endif
            </div>
        </div>
    </div>

    <!-- Right Column -->
    <div class="col-lg-8">
        <!-- Order Stats -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="stat-mini">
                    <div class="number">{{ $user->orders()->count() ?? $orderStats['total'] ?? 0 }}</div>
                    <div class="label">Total Pesanan</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-mini">
                    <div class="number" style="color: #27AE60;">{{ $orderStats['completed'] ?? 0 }}</div>
                    <div class="label">Selesai</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-mini">
                    <div class="number" style="color: #D4A017;">{{ $orderStats['processing'] ?? 0 }}</div>
                    <div class="label">Diproses</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-mini">
                    <div class="number" style="color: #dc3545;">{{ $orderStats['cancelled'] ?? 0 }}</div>
                    <div class="label">Dibatalkan</div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                <span style="color: #0C4B8E;"><i class="fas fa-history me-2"></i>Aktivitas Terbaru</span>
            </div>
            <div class="card-body p-0">
                @forelse($recentActivities ?? $user->orders()->latest()->take(10)->get() ?? [] as $activity)
                <div class="activity-item px-3">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <div class="fw-semibold" style="font-size: 0.9rem;">
                                @if(($activity->status ?? '') === 'completed')
                                    <i class="fas fa-check-circle text-success me-2"></i>
                                @elseif(($activity->status ?? '') === 'cancelled')
                                    <i class="fas fa-times-circle text-danger me-2"></i>
                                @else
                                    <i class="fas fa-shopping-cart text-primary me-2"></i>
                                @endif
                                Pesanan #{{ $activity->order_number ?? $activity->id }}
                            </div>
                            <small class="text-muted ms-4">
                                {{ $activity->created_at ? $activity->created_at->format('d M Y, H:i') : '-' }}
                            </small>
                        </div>
                        <div class="text-end">
                            <div class="fw-bold" style="font-size: 0.9rem; color: #0C4B8E;">
                                Rp {{ number_format($activity->total ?? 0, 0, ',', '.') }}
                            </div>
                            @php
                                $actStatusConfig = [
                                    'pending' => 'secondary', 'processing' => 'info',
                                    'shipped' => 'primary', 'delivered' => 'success',
                                    'completed' => 'success', 'cancelled' => 'danger',
                                ];
                            @endphp
                            <span class="badge bg-{{ $actStatusConfig[$activity->status ?? 'pending'] ?? 'secondary' }} bg-opacity-10 text-{{ $actStatusConfig[$activity->status ?? 'pending'] ?? 'secondary' }}"
                                  style="font-size: 0.7rem;">
                                {{ ucfirst($activity->status ?? 'pending') }}
                            </span>
                        </div>
                    </div>
                </div>
                @empty
                <div class="text-center text-muted py-4">
                    <i class="fas fa-inbox fa-2x mb-2 d-block opacity-50"></i>
                    Belum ada aktivitas
                </div>
                @endforelse
            </div>
        </div>

        <!-- Admin Actions -->
        @auth
        @if(auth()->user()->hasRole('admin') && !$user->hasRole('admin'))
        <div class="card info-card shadow-sm">
            <div class="card-header bg-white py-3" style="color: #dc3545;">
                <i class="fas fa-shield-alt me-2"></i>Aksi Admin
            </div>
            <div class="card-body">
                <div class="row g-2">
                    <div class="col-md-4">
                        <form action="{{ route('admin.users.update', $user->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <input type="hidden" name="action" value="toggle_status">
                            <button type="submit" class="btn w-100 {{ ($user->status ?? 'active') === 'active' ? 'btn-outline-warning' : 'btn-outline-success' }}" style="border-radius: 10px;">
                                <i class="fas fa-{{ ($user->status ?? 'active') === 'active' ? 'ban' : 'check' }} me-2"></i>
                                {{ ($user->status ?? 'active') === 'active' ? 'Nonaktifkan' : 'Aktifkan' }}
                            </button>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <form action="{{ route('admin.users.update', $user->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <input type="hidden" name="action" value="change_role">
                            <input type="hidden" name="role" value="{{ $user->role === 'agent' ? 'customer' : 'agent' }}">
                            <button type="submit" class="btn w-100 btn-outline-primary" style="border-radius: 10px;"
                                    onclick="return confirm('Ubah role pengguna ini?')">
                                <i class="fas fa-user-tag me-2"></i>
                                Ubah Role
                            </button>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST"
                              onsubmit="return confirm('PERINGATAN: Yakin ingin menghapus pengguna ini? Tindakan ini tidak dapat dibatalkan.')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn w-100 btn-outline-danger" style="border-radius: 10px;">
                                <i class="fas fa-trash me-2"></i>Hapus
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        @endif
        @endauth
    </div>
</div>

@endsection
