@extends('layouts.admin')

@section('title', 'Penarikan Dana - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Penarikan Dana</li>
@endsection

@section('page_title', 'Permintaan Penarikan Dana')

@push('styles')
<style>
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .status-badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.35em 0.75em;
        border-radius: 50px;
    }
    .bank-icon {
        width: 36px;
        height: 36px;
        border-radius: 8px;
        background: rgba(12,75,142,0.08);
        display: flex;
        align-items: center;
        justify-content: center;
        color: #0C4B8E;
        font-weight: 800;
        font-size: 0.7rem;
    }
</style>
@endpush

@section('admin_content')

<!-- Filters -->
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('admin.withdrawals.index') }}" class="row g-2 align-items-end">
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Status</label>
                <select name="status" class="form-select" style="border-radius: 10px;">
                    <option value="">Semua Status</option>
                    <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Menunggu</option>
                    <option value="processing" {{ request('status') === 'processing' ? 'selected' : '' }}>Diproses</option>
                    <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Selesai</option>
                    <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>Ditolak</option>
                </select>
            </div>
            <div class="col-md-5">
                <label class="form-label fw-semibold small mb-1">Cari</label>
                <input type="text" name="search" class="form-control" style="border-radius: 10px;"
                       placeholder="Nama pengguna / bank..." value="{{ request('search') }}">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-filter me-1"></i> Filter
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Withdrawals Table -->
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Pengguna</th>
                        <th class="text-end">Jumlah</th>
                        <th>Bank</th>
                        <th class="text-center">Status</th>
                        <th>Tanggal</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($withdrawals ?? [] as $withdrawal)
                    @php
                        $wdStatusConfig = [
                            'pending'    => ['color' => 'warning', 'icon' => 'clock', 'label' => 'Menunggu'],
                            'processing' => ['color' => 'info', 'icon' => 'spinner', 'label' => 'Diproses'],
                            'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                            'rejected'   => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Ditolak'],
                        ];
                        $wsc = $wdStatusConfig[$withdrawal->status ?? 'pending'] ?? $wdStatusConfig['pending'];
                    @endphp
                    <tr>
                        <td class="ps-3">
                            <a href="{{ route('admin.users.show', $withdrawal->user_id ?? 0) }}" class="text-decoration-none">
                                <div class="fw-semibold" style="color: #0C4B8E;">{{ $withdrawal->user->name ?? '-' }}</div>
                            </a>
                            <small class="text-muted">{{ $withdrawal->user->email ?? '' }}</small>
                        </td>
                        <td class="text-end">
                            <span class="fw-bold" style="color: #0C4B8E;">
                                Rp {{ number_format($withdrawal->amount ?? 0, 0, ',', '.') }}
                            </span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="bank-icon">
                                    {{ strtoupper(substr($withdrawal->bank_name ?? 'BNK', 0, 3)) }}
                                </div>
                                <div>
                                    <div class="fw-semibold" style="font-size: 0.88rem;">{{ $withdrawal->bank_name ?? '-' }}</div>
                                    <small class="text-muted">{{ $withdrawal->bank_account_number ?? '-' }} a/n {{ $withdrawal->bank_account_name ?? '-' }}</small>
                                </div>
                            </div>
                        </td>
                        <td class="text-center">
                            <span class="status-badge badge bg-{{ $wsc['color'] }} bg-opacity-10 text-{{ $wsc['color'] }}">
                                <i class="fas fa-{{ $wsc['icon'] }} me-1"></i>{{ $wsc['label'] }}
                            </span>
                        </td>
                        <td>
                            <div style="font-size: 0.88rem;">{{ $withdrawal->created_at ? $withdrawal->created_at->format('d M Y') : '-' }}</div>
                            <small class="text-muted">{{ $withdrawal->created_at ? $withdrawal->created_at->format('H:i') : '' }}</small>
                        </td>
                        <td class="text-center pe-3">
                            @if(($withdrawal->status ?? '') === 'pending')
                            <div class="btn-group btn-group-sm">
                                <form action="{{ route('admin.withdrawals.update', $withdrawal->id) }}" method="POST">
                                    @csrf
                                    @method('PUT')
                                    <input type="hidden" name="status" value="completed">
                                    <button type="submit" class="btn btn-success" style="border-radius: 8px 0 0 8px;" title="Setujui">
                                        <i class="fas fa-check"></i>
                                    </button>
                                </form>
                                <form action="{{ route('admin.withdrawals.update', $withdrawal->id) }}" method="POST"
                                      onsubmit="return confirm('Yakin menolak penarikan ini? Dana akan dikembalikan ke saldo pengguna.')">
                                    @csrf
                                    @method('PUT')
                                    <input type="hidden" name="status" value="rejected">
                                    <button type="submit" class="btn btn-outline-danger" style="border-radius: 0 8px 8px 0;" title="Tolak">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </form>
                            </div>
                            @elseif(($withdrawal->status ?? '') === 'processing')
                            <form action="{{ route('admin.withdrawals.update', $withdrawal->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                <input type="hidden" name="status" value="completed">
                                <button type="submit" class="btn btn-sm btn-success" style="border-radius: 8px;" title="Tandai Selesai">
                                    <i class="fas fa-check me-1"></i>Selesai
                                </button>
                            </form>
                            @else
                            <span class="text-muted"><i class="fas fa-minus"></i></span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            <i class="fas fa-money-bill-wave fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada permintaan penarikan</p>
                            <small>Permintaan penarikan dari pengguna akan tampil di sini</small>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Pagination -->
@if(isset($withdrawals) && method_exists($withdrawals, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $withdrawals->links() }}
</div>
@endif

@endsection
