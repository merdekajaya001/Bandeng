@extends('layouts.agent')

@section('title', 'Wilayah Jangkauan - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Wilayah Jangkauan</li>
@endsection

@section('page_title', 'Wilayah Jangkauan')

@section('page_actions')
    <button type="button" class="btn text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;"
            data-bs-toggle="modal" data-bs-target="#addAreaModal">
        <i class="fas fa-plus me-1"></i> Tambah Wilayah
    </button>
@endsection

@push('styles')
<style>
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .area-card {
        border: none;
        border-radius: 12px;
        border-left: 4px solid #0C4B8E;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .area-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.08);
    }
    .form-input {
        border-radius: 10px;
        border: 2px solid #e9ecef;
    }
    .form-input:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.12);
    }
    .radius-badge {
        font-size: 0.78rem;
        padding: 0.3em 0.65em;
        border-radius: 6px;
        font-weight: 600;
    }
    .map-placeholder {
        background: linear-gradient(135deg, rgba(12,75,142,0.05) 0%, rgba(212,160,23,0.05) 100%);
        border: 2px dashed rgba(12,75,142,0.2);
        border-radius: 12px;
        min-height: 250px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }
    [data-bs-theme="dark"] .map-placeholder {
        background: linear-gradient(135deg, rgba(12,75,142,0.15) 0%, rgba(212,160,23,0.1) 100%);
        border-color: rgba(212,160,23,0.3);
    }
</style>
@endpush

@section('agent_content')

@include('partials.flash-messages')

<div class="row g-4">
    {{-- Area List --}}
    <div class="col-lg-8">
        {{-- Current Areas Table --}}
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-map-marked-alt me-2"></i>Daftar Wilayah
                </h6>
                <span class="badge" style="background: rgba(12,75,142,0.1); color: #0C4B8E; font-size: 0.85rem; padding: 0.5em 1em; border-radius: 8px;">
                    {{ ($areas ?? collect())->count() }} wilayah
                </span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">Kota</th>
                                <th>Provinsi</th>
                                <th class="text-center">Radius (km)</th>
                                <th class="text-center">Status</th>
                                <th class="text-center pe-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($areas ?? [] as $area)
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-semibold" style="color: #0C4B8E;">
                                        <i class="fas fa-map-pin me-1 text-danger"></i>
                                        {{ $area->city ?? $area->city_name ?? '-' }}
                                    </div>
                                </td>
                                <td>{{ $area->province ?? $area->province_name ?? '-' }}</td>
                                <td class="text-center">
                                    <span class="radius-badge" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                                        <i class="fas fa-bullseye me-1"></i>{{ $area->radius ?? 0 }} km
                                    </span>
                                </td>
                                <td class="text-center">
                                    @if($area->is_active ?? true)
                                    <span class="badge bg-success bg-opacity-10 text-success" style="font-size: 0.78rem; border-radius: 6px;">
                                        <i class="fas fa-check-circle me-1"></i>Aktif
                                    </span>
                                    @else
                                    <span class="badge bg-secondary bg-opacity-10 text-secondary" style="font-size: 0.78rem; border-radius: 6px;">
                                        <i class="fas fa-pause-circle me-1"></i>Nonaktif
                                    </span>
                                    @endif
                                </td>
                                <td class="text-center pe-3">
                                    <div class="d-flex justify-content-center gap-1">
                                        {{-- Edit Button --}}
                                        <button type="button" class="btn btn-sm btn-outline-primary" style="border-radius: 8px;"
                                                title="Edit Wilayah"
                                                onclick="openEditModal({{ $area->id }}, '{{ $area->city ?? $area->city_name ?? '' }}', '{{ $area->province ?? $area->province_name ?? '' }}', {{ $area->radius ?? 0 }}, {{ ($area->is_active ?? true) ? 1 : 0 }})">
                                            <i class="fas fa-edit"></i>
                                        </button>

                                        {{-- Toggle Active/Inactive --}}
                                        <form action="{{ route('agent.areas.toggle', $area->id) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('PUT')
                                            <button type="submit" class="btn btn-sm btn-outline-{{ ($area->is_active ?? true) ? 'warning' : 'success' }}" style="border-radius: 8px;"
                                                    title="{{ ($area->is_active ?? true) ? 'Nonaktifkan' : 'Aktifkan' }}">
                                                <i class="fas fa-{{ ($area->is_active ?? true) ? 'pause' : 'play' }}"></i>
                                            </button>
                                        </form>

                                        {{-- Delete Button --}}
                                        <form action="{{ route('agent.areas.destroy', $area->id) }}" method="POST" class="d-inline"
                                              onsubmit="return confirm('Yakin ingin menghapus wilayah {{ $area->city ?? $area->city_name ?? '' }}?')">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger" style="border-radius: 8px;"
                                                    title="Hapus Wilayah">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted py-5">
                                    <i class="fas fa-map-marked-alt fa-3x mb-3 d-block opacity-50"></i>
                                    <p class="mb-1 fw-semibold">Belum ada wilayah jangkauan</p>
                                    <small>Tambahkan wilayah untuk mulai menerima pesanan</small>
                                    <div class="mt-3">
                                        <button type="button" class="btn btn-sm text-white" style="background: #0C4B8E; border-radius: 8px;"
                                                data-bs-toggle="modal" data-bs-target="#addAreaModal">
                                            <i class="fas fa-plus me-1"></i> Tambah Wilayah Pertama
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- Area Cards View --}}
        @if(count($areas ?? []) > 0)
        <div class="mt-4">
            <h6 class="fw-bold mb-3" style="color: #0C4B8E;">
                <i class="fas fa-th-large me-2"></i>Tampilan Kartu
            </h6>
            <div class="row g-3">
                @foreach($areas ?? [] as $area)
                <div class="col-md-6">
                    <div class="card area-card shadow-sm">
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                                        <i class="fas fa-map-pin me-1 text-danger"></i>
                                        {{ $area->city ?? $area->city_name ?? '-' }}
                                    </h6>
                                    <small class="text-muted">{{ $area->province ?? $area->province_name ?? '-' }}</small>
                                </div>
                                @if($area->is_active ?? true)
                                <span class="badge bg-success bg-opacity-10 text-success" style="font-size: 0.72rem; border-radius: 6px;">
                                    Aktif
                                </span>
                                @else
                                <span class="badge bg-secondary bg-opacity-10 text-secondary" style="font-size: 0.72rem; border-radius: 6px;">
                                    Nonaktif
                                </span>
                                @endif
                            </div>
                            <div class="d-flex align-items-center gap-3">
                                <div>
                                    <div class="text-muted small">Radius</div>
                                    <div class="fw-bold" style="color: #D4A017;">{{ $area->radius ?? 0 }} km</div>
                                </div>
                                <div class="ms-auto">
                                    <button type="button" class="btn btn-sm btn-outline-primary me-1" style="border-radius: 8px;"
                                            onclick="openEditModal({{ $area->id }}, '{{ $area->city ?? $area->city_name ?? '' }}', '{{ $area->province ?? $area->province_name ?? '' }}', {{ $area->radius ?? 0 }}, {{ ($area->is_active ?? true) ? 1 : 0 }})">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <form action="{{ route('agent.areas.destroy', $area->id) }}" method="POST" class="d-inline"
                                          onsubmit="return confirm('Yakin ingin menghapus wilayah ini?')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-outline-danger" style="border-radius: 8px;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>

    {{-- Map & Info Sidebar --}}
    <div class="col-lg-4">
        {{-- Map Placeholder --}}
        <div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-map me-2"></i>Peta Wilayah
                </h6>
            </div>
            <div class="card-body">
                <div class="map-placeholder">
                    <i class="fas fa-map-marked-alt fa-3x mb-3" style="color: rgba(12,75,142,0.25);"></i>
                    <p class="mb-1 fw-semibold" style="color: rgba(12,75,142,0.5);">Peta Wilayah Jangkauan</p>
                    <small class="text-muted">Integrasikan dengan Google Maps atau Leaflet</small>
                </div>
            </div>
        </div>

        {{-- Area Statistics --}}
        <div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #D4A017;">
                    <i class="fas fa-chart-pie me-2"></i>Statistik Wilayah
                </h6>
            </div>
            <div class="card-body">
                <div class="row g-2">
                    <div class="col-6">
                        <div class="text-center p-3 rounded" style="background: rgba(12,75,142,0.06);">
                            <div class="fw-bold fs-4" style="color: #0C4B8E;">
                                {{ ($areas ?? collect())->count() }}
                            </div>
                            <small class="text-muted">Total Wilayah</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-center p-3 rounded" style="background: rgba(39,174,96,0.06);">
                            <div class="fw-bold fs-4" style="color: #27AE60;">
                                {{ ($areas ?? collect())->where('is_active', true)->count() }}
                            </div>
                            <small class="text-muted">Wilayah Aktif</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-center p-3 rounded" style="background: rgba(212,160,23,0.06);">
                            <div class="fw-bold fs-4" style="color: #D4A017;">
                                {{ ($areas ?? collect())->where('is_active', false)->count() }}
                            </div>
                            <small class="text-muted">Nonaktif</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-center p-3 rounded" style="background: rgba(108,117,125,0.06);">
                            <div class="fw-bold fs-4" style="color: #6c757d;">
                                {{ number_format(($areas ?? collect())->avg('radius') ?? 0, 1) }}
                            </div>
                            <small class="text-muted">Rata-rata Radius</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Tips --}}
        <div class="card shadow-sm" style="border-radius: 12px; border: none; border-left: 4px solid #D4A017;">
            <div class="card-body">
                <h6 class="fw-bold mb-2" style="color: #D4A017;">
                    <i class="fas fa-lightbulb me-2"></i>Tips
                </h6>
                <ul class="mb-0 ps-3 small">
                    <li class="mb-1">Tambahkan kota-kota di sekitar lokasi Anda sebagai wilayah jangkauan</li>
                    <li class="mb-1">Radius menentukan seberapa jauh area pengiriman dari pusat kota</li>
                    <li class="mb-1">Nonaktifkan wilayah yang tidak bisa dilayani sementara</li>
                    <li>Pelanggan hanya dapat memesan jika berada di wilayah yang aktif</li>
                </ul>
            </div>
        </div>
    </div>
</div>

{{-- Add Area Modal --}}
<div class="modal fade" id="addAreaModal" tabindex="-1" aria-labelledby="addAreaModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="border-radius: 12px; border: none;">
            <div class="modal-header" style="border-bottom: 2px solid rgba(12,75,142,0.1);">
                <h5 class="modal-title fw-bold" id="addAreaModalLabel" style="color: #0C4B8E;">
                    <i class="fas fa-plus-circle me-2"></i>Tambah Wilayah Baru
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('agent.areas.store') }}" method="POST">
                @csrf
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="addCity" class="form-label fw-semibold">Kota <span class="text-danger">*</span></label>
                        <input type="text" name="city" id="addCity" class="form-control form-input"
                               placeholder="Contoh: Banjarmasin" required>
                    </div>
                    <div class="mb-3">
                        <label for="addProvince" class="form-label fw-semibold">Provinsi <span class="text-danger">*</span></label>
                        <input type="text" name="province" id="addProvince" class="form-control form-input"
                               placeholder="Contoh: Kalimantan Selatan" required>
                    </div>
                    <div class="mb-3">
                        <label for="addRadius" class="form-label fw-semibold">Radius (km) <span class="text-danger">*</span></label>
                        <input type="number" name="radius" id="addRadius" class="form-control form-input"
                               placeholder="Contoh: 25" min="1" max="500" required>
                        <div class="form-text">Jangkauan pengiriman dari pusat kota dalam kilometer</div>
                    </div>
                    <div class="mb-3">
                        <label for="addLatitude" class="form-label fw-semibold">Latitude (opsional)</label>
                        <input type="number" step="any" name="latitude" id="addLatitude" class="form-control form-input"
                               placeholder="Contoh: -3.3186">
                    </div>
                    <div class="mb-3">
                        <label for="addLongitude" class="form-label fw-semibold">Longitude (opsional)</label>
                        <input type="number" step="any" name="longitude" id="addLongitude" class="form-control form-input"
                               placeholder="Contoh: 114.5944">
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="is_active" id="addIsActive" value="1" checked>
                        <label class="form-check-label fw-semibold" for="addIsActive">
                            Aktifkan wilayah ini segera
                        </label>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid #e9ecef;">
                    <button type="button" class="btn btn-outline-secondary" style="border-radius: 10px;" data-bs-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn text-white fw-bold" style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); border-radius: 10px;">
                        <i class="fas fa-plus me-1"></i> Tambah Wilayah
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

{{-- Edit Area Modal --}}
<div class="modal fade" id="editAreaModal" tabindex="-1" aria-labelledby="editAreaModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="border-radius: 12px; border: none;">
            <div class="modal-header" style="border-bottom: 2px solid rgba(12,75,142,0.1);">
                <h5 class="modal-title fw-bold" id="editAreaModalLabel" style="color: #0C4B8E;">
                    <i class="fas fa-edit me-2"></i>Edit Wilayah
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('agent.areas.update', 0) }}" method="POST" id="editAreaForm">
                @csrf
                @method('PUT')
                <div class="modal-body">
                    <input type="hidden" name="area_id" id="editAreaId">
                    <div class="mb-3">
                        <label for="editCity" class="form-label fw-semibold">Kota <span class="text-danger">*</span></label>
                        <input type="text" name="city" id="editCity" class="form-control form-input" required>
                    </div>
                    <div class="mb-3">
                        <label for="editProvince" class="form-label fw-semibold">Provinsi <span class="text-danger">*</span></label>
                        <input type="text" name="province" id="editProvince" class="form-control form-input" required>
                    </div>
                    <div class="mb-3">
                        <label for="editRadius" class="form-label fw-semibold">Radius (km) <span class="text-danger">*</span></label>
                        <input type="number" name="radius" id="editRadius" class="form-control form-input"
                               min="1" max="500" required>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="is_active" id="editIsActive" value="1">
                        <label class="form-check-label fw-semibold" for="editIsActive">
                            Wilayah Aktif
                        </label>
                    </div>
                </div>
                <div class="modal-footer" style="border-top: 1px solid #e9ecef;">
                    <button type="button" class="btn btn-outline-secondary" style="border-radius: 10px;" data-bs-dismiss="modal">
                        Batal
                    </button>
                    <button type="submit" class="btn text-white fw-bold" style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); border-radius: 10px;">
                        <i class="fas fa-save me-1"></i> Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script>
    function openEditModal(areaId, city, province, radius, isActive) {
        document.getElementById('editAreaId').value = areaId;
        document.getElementById('editCity').value = city;
        document.getElementById('editProvince').value = province;
        document.getElementById('editRadius').value = radius;
        document.getElementById('editIsActive').checked = (isActive === 1);

        // Update form action
        var form = document.getElementById('editAreaForm');
        form.action = '{{ route('agent.areas.update', 0) }}'.replace(/0$/, areaId);

        var modal = new bootstrap.Modal(document.getElementById('editAreaModal'));
        modal.show();
    }
</script>
@endpush
