@extends('layouts.agent')

@section('title', 'Dashboard Agen - Bandar Bandeng Kalimantan')

@section('page_title', 'Dashboard')

@push('styles')
<style>
    .stat-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    .stat-card .stat-icon {
        width: 56px;
        height: 56px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
    }
    .stat-card .stat-number {
        font-size: 1.75rem;
        font-weight: 800;
        line-height: 1.2;
    }
    .stat-card .stat-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 500;
    }
    .badge-card {
        border: none;
        border-radius: 12px;
        background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%);
        color: white;
        overflow: hidden;
    }
    .badge-card .badge-icon {
        width: 64px;
        height: 64px;
        border-radius: 50%;
        background: rgba(255,255,255,0.15);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
    }
    .level-card {
        border: none;
        border-radius: 12px;
        border-left: 5px solid #D4A017;
        overflow: hidden;
    }
    .progress-bbk {
        height: 10px;
        border-radius: 5px;
        background: #e9ecef;
        overflow: hidden;
    }
    .progress-bbk .fill {
        height: 100%;
        border-radius: 5px;
        transition: width 0.6s ease;
    }
    .status-badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.3em 0.7em;
        border-radius: 50px;
    }
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .quick-action-btn {
        border-radius: 12px;
        padding: 1.25rem;
        text-align: center;
        transition: all 0.2s;
        text-decoration: none;
        display: block;
    }
    .quick-action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        color: white;
    }
</style>
@endpush

@section('agent_content')

{{-- Flash Messages --}}
@include('partials.flash-messages')

{{-- Badge & Level Row --}}
<div class="row g-3 mb-4">
    {{-- Current Badge --}}
    <div class="col-lg-6">
        <div class="card badge-card shadow-sm">
            <div class="card-body d-flex align-items-center p-4">
                <div class="badge-icon me-4">
                    <i class="fas {{ $badge->icon ?? 'fa-medal' }}"></i>
                </div>
                <div class="flex-grow-1">
                    <div class="small opacity-75 mb-1">Badge Saat Ini</div>
                    <div class="fw-bold fs-5">{{ $badge->name ?? 'Agen Pemula' }}</div>
                    @if($badge->description ?? null)
                    <div class="small opacity-80 mt-1">{{ $badge->description }}</div>
                    @endif
                </div>
                <div>
                    @if($nextBadge ?? null)
                    <span class="badge" style="background: rgba(255,255,255,0.2); color: white; border-radius: 8px; font-size: 0.78rem;">
                        <i class="fas fa-arrow-up me-1"></i>Selanjutnya: {{ $nextBadge->name }}
                    </span>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- Current Level --}}
    <div class="col-lg-6">
        <div class="card level-card shadow-sm">
            <div class="card-body p-4">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <div>
                        <div class="small text-muted mb-1">Level Agen</div>
                        <div class="fw-bold fs-5" style="color: #0C4B8E;">
                            Level {{ $level->level ?? 1 }} — {{ $level->name ?? 'Agen Dasar' }}
                        </div>
                    </div>
                    <div class="text-center">
                        <div class="fw-bold fs-4" style="color: #D4A017;">{{ $level->discount ?? 0 }}%</div>
                        <div class="small text-muted">Diskon</div>
                    </div>
                    <div class="text-center">
                        <div class="fw-bold fs-4" style="color: #27AE60;">{{ $level->commission ?? 0 }}%</div>
                        <div class="small text-muted">Komisi</div>
                    </div>
                </div>
                @if($level->next_level_target ?? null)
                <div class="mt-2">
                    <div class="d-flex justify-content-between small mb-1">
                        <span class="text-muted">Menuju level berikutnya</span>
                        <span class="fw-bold" style="color: #D4A017;">{{ $levelProgress ?? 0 }}%</span>
                    </div>
                    <div class="progress-bbk">
                        <div class="fill" style="width: {{ min($levelProgress ?? 0, 100) }}%; background: linear-gradient(90deg, #D4A017, #F4D03F);"></div>
                    </div>
                    <small class="text-muted">Target: Rp {{ number_format($level->next_level_target, 0, ',', '.') }}</small>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

{{-- Stat Cards --}}
<div class="row g-3 mb-4">
    {{-- Stok Saya --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(12,75,142,0.12); color: #0C4B8E;">
                    <i class="fas fa-cubes"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #0C4B8E;">
                        {{ number_format($stats['total_stock'] ?? 0) }}
                    </div>
                    <div class="stat-label">Stok Saya</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Pesanan Pelanggan --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #D4A017;">
                        {{ number_format($stats['customer_orders'] ?? 0) }}
                    </div>
                    <div class="stat-label">Pesanan Pelanggan</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Pesanan ke Stockist --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(39,174,96,0.12); color: #27AE60;">
                    <i class="fas fa-truck"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #27AE60;">
                        {{ number_format($stats['stockist_orders'] ?? 0) }}
                    </div>
                    <div class="stat-label">Pesanan ke Stockist</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Saldo Dompet --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(108,117,125,0.12); color: #6c757d;">
                    <i class="fas fa-wallet"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #495057; font-size: 1.35rem;">
                        Rp {{ number_format($stats['wallet_balance'] ?? 0, 0, ',', '.') }}
                    </div>
                    <div class="stat-label">Saldo Dompet</div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Quick Actions --}}
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <a href="{{ route('agent.stock.order') }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); color: white;">
            <i class="fas fa-cart-plus fa-2x mb-2"></i>
            <div class="fw-bold">Pesan ke Stockist</div>
            <small style="opacity: 0.8;">Pesan stok produk dari stockist</small>
        </a>
    </div>
    <div class="col-md-4">
        <a href="{{ route('agent.orders.index') }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #D4A017 0%, #F4D03F 100%); color: #333;">
            <i class="fas fa-clipboard-list fa-2x mb-2"></i>
            <div class="fw-bold">Pesanan Pelanggan</div>
            <small style="opacity: 0.8;">Kelola pesanan dari pelanggan</small>
        </a>
    </div>
    <div class="col-md-4">
        <a href="{{ route('agent.areas.index') }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #27AE60 0%, #2ECC71 100%); color: white;">
            <i class="fas fa-map-marked-alt fa-2x mb-2"></i>
            <div class="fw-bold">Wilayah Jangkauan</div>
            <small style="opacity: 0.8;">Kelola area penjualan</small>
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    {{-- Monthly Sales Progress --}}
    <div class="col-lg-5">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-chart-bar me-2"></i>Progress Penjualan Bulan Ini
                </h6>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <span class="fw-bold" style="font-size: 2rem; color: #0C4B8E;">
                        Rp {{ number_format($monthlySales['current'] ?? 0, 0, ',', '.') }}
                    </span>
                    <div class="text-muted small">dari target Rp {{ number_format($monthlySales['target'] ?? 0, 0, ',', '.') }}</div>
                </div>
                @php
                    $salesTarget = $monthlySales['target'] ?? 1;
                    $salesCurrent = $monthlySales['current'] ?? 0;
                    $salesPercent = $salesTarget > 0 ? min(($salesCurrent / $salesTarget) * 100, 100) : 0;
                    $barColor = $salesPercent >= 80 ? '#27AE60' : ($salesPercent >= 50 ? '#D4A017' : '#0C4B8E');
                @endphp
                <div class="progress-bbk mb-2">
                    <div class="fill" style="width: {{ $salesPercent }}%; background: {{ $barColor }};"></div>
                </div>
                <div class="d-flex justify-content-between">
                    <small class="fw-bold" style="color: {{ $barColor }};">{{ number_format($salesPercent, 1) }}%</small>
                    <small class="text-muted">
                        Sisa: Rp {{ number_format(max($salesTarget - $salesCurrent, 0), 0, ',', '.') }}
                    </small>
                </div>

                <hr>

                <div class="row g-2 mt-1">
                    <div class="col-6">
                        <div class="text-center p-2 rounded" style="background: rgba(12,75,142,0.06);">
                            <div class="fw-bold" style="color: #0C4B8E;">{{ $monthlySales['orders_count'] ?? 0 }}</div>
                            <small class="text-muted">Pesanan</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="text-center p-2 rounded" style="background: rgba(212,160,23,0.06);">
                            <div class="fw-bold" style="color: #D4A017;">{{ $monthlySales['customers_count'] ?? 0 }}</div>
                            <small class="text-muted">Pelanggan</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Recent Customer Orders --}}
    <div class="col-lg-7">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #D4A017;">
                    <i class="fas fa-receipt me-2"></i>Pesanan Pelanggan Terbaru
                </h6>
                <a href="{{ route('agent.orders.index') }}" class="btn btn-sm btn-outline-primary" style="border-radius: 8px;">
                    Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="font-size: 0.8rem;">No. Pesanan</th>
                                <th style="font-size: 0.8rem;">Pelanggan</th>
                                <th style="font-size: 0.8rem;" class="text-center">Status</th>
                                <th style="font-size: 0.8rem;" class="text-end">Total</th>
                                <th style="font-size: 0.8rem;" class="text-end pe-3">Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($recentOrders ?? [] as $order)
                            @php
                                $statusConfig = [
                                    'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
                                    'confirmed'  => ['color' => 'info', 'icon' => 'check', 'label' => 'Dikonfirmasi'],
                                    'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
                                    'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                                    'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                                    'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                                    'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                                ];
                                $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
                            @endphp
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('agent.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                        #{{ $order->order_number ?? $order->id }}
                                    </a>
                                </td>
                                <td>
                                    <div class="fw-semibold">{{ $order->customer->name ?? $order->buyer->name ?? '-' }}</div>
                                    <small class="text-muted">{{ $order->customer->phone ?? '' }}</small>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                                        <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                                    </span>
                                </td>
                                <td class="text-end fw-semibold">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                                <td class="text-end pe-3 text-muted" style="font-size: 0.85rem;">
                                    {{ $order->created_at ? $order->created_at->format('d M Y') : '-' }}
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox fa-2x mb-2 d-block opacity-50"></i>
                                    Belum ada pesanan pelanggan
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
