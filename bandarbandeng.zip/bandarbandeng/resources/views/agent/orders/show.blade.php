@extends('layouts.agent')

@section('title', 'Detail Pesanan - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('agent.orders.index') }}">Pesanan Pelanggan</a></li>
    <li class="breadcrumb-item active" aria-current="page">#{{ $order->order_number ?? $order->id }}</li>
@endsection

@section('page_title', 'Detail Pesanan')

@push('styles')
<style>
    .detail-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.2rem;
    }
    .detail-value {
        font-size: 0.95rem;
        font-weight: 500;
    }
    .status-badge {
        font-size: 0.82rem;
        font-weight: 600;
        padding: 0.4em 1em;
        border-radius: 50px;
    }
    .info-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
    }
    .info-card .card-header {
        font-weight: 700;
        font-size: 0.95rem;
        border-bottom: 2px solid rgba(12,75,142,0.1);
    }
    .proof-image {
        max-width: 250px;
        max-height: 250px;
        border-radius: 10px;
        border: 2px solid #e9ecef;
        cursor: pointer;
        transition: transform 0.2s;
    }
    .proof-image:hover {
        transform: scale(1.02);
    }
    .timeline-item {
        position: relative;
        padding-left: 30px;
        padding-bottom: 1.5rem;
        border-left: 2px solid #e9ecef;
        margin-left: 8px;
    }
    .timeline-item:last-child {
        border-left: 2px solid transparent;
        padding-bottom: 0;
    }
    .timeline-item .timeline-dot {
        position: absolute;
        left: -7px;
        top: 2px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #0C4B8E;
        border: 2px solid white;
    }
    .timeline-item .timeline-dot.inactive {
        background: #e9ecef;
    }
    .action-btn {
        border-radius: 10px;
        font-weight: 700;
        padding: 0.6rem 1rem;
        transition: all 0.2s;
    }
    .action-btn:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
</style>
@endpush

@section('agent_content')

@include('partials.flash-messages')

@php
    $statusConfig = [
        'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
        'confirmed'  => ['color' => 'info', 'icon' => 'check', 'label' => 'Dikonfirmasi'],
        'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
        'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
        'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
        'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
        'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
    ];
    $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
    $payStatusConfig = [
        'pending'  => ['color' => 'secondary', 'label' => 'Menunggu'],
        'paid'     => ['color' => 'success', 'label' => 'Dibayar'],
        'verified' => ['color' => 'success', 'label' => 'Terverifikasi'],
        'rejected' => ['color' => 'danger', 'label' => 'Ditolak'],
    ];
    $psc = $payStatusConfig[$order->payment->status ?? 'pending'] ?? $payStatusConfig['pending'];
@endphp

<div class="row g-4">
    {{-- Main Content --}}
    <div class="col-lg-8">
        {{-- Order Info Card --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span style="color: #0C4B8E;"><i class="fas fa-receipt me-2"></i>Informasi Pesanan</span>
                <div class="d-flex gap-2 align-items-center">
                    <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                        <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="detail-label">No. Pesanan</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">#{{ $order->order_number ?? $order->id }}</div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Tanggal Pesanan</div>
                        <div class="detail-value">{{ $order->created_at ? $order->created_at->format('d F Y, H:i') : '-' }}</div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Metode Pembayaran</div>
                        <div class="detail-value">{{ $order->payment->method_label ?? $order->payment->method ?? 'Transfer Bank' }}</div>
                    </div>

                    @if($order->shipping_address ?? null)
                    <div class="col-md-6">
                        <div class="detail-label">Alamat Pengiriman</div>
                        <div class="detail-value" style="font-size: 0.88rem;">{{ $order->shipping_address }}</div>
                    </div>
                    @endif

                    @if($order->shipping_method ?? null)
                    <div class="col-md-3">
                        <div class="detail-label">Kurir</div>
                        <div class="detail-value">{{ $order->shipping_method }}</div>
                    </div>
                    @endif

                    @if($order->tracking_number ?? null)
                    <div class="col-md-3">
                        <div class="detail-label">No. Resi</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">{{ $order->tracking_number }}</div>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        {{-- Items Table --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-box me-2"></i>Item Pesanan
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="font-size: 0.8rem;">Produk / Varian</th>
                                <th class="text-center" style="font-size: 0.8rem;">Qty</th>
                                <th class="text-end" style="font-size: 0.8rem;">Harga</th>
                                <th class="text-end pe-3" style="font-size: 0.8rem;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->items ?? [] as $item)
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-semibold">{{ $item->productVariant->product->name ?? $item->product_name ?? '-' }}</div>
                                    <small class="text-muted">
                                        <span class="badge" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                                            {{ $item->productVariant->name ?? $item->variant_name ?? '' }}
                                        </span>
                                    </small>
                                </td>
                                <td class="text-center fw-semibold">{{ $item->quantity ?? 1 }}</td>
                                <td class="text-end">Rp {{ number_format($item->price ?? 0, 0, ',', '.') }}</td>
                                <td class="text-end fw-semibold pe-3">Rp {{ number_format($item->subtotal ?? ($item->price * $item->quantity) ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr style="border-top: 2px solid #dee2e6;">
                                <td colspan="3" class="text-end pe-3 pt-3"><strong>Subtotal</strong></td>
                                <td class="text-end pe-3 pt-3 fw-semibold">Rp {{ number_format($order->subtotal ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @if(($order->shipping_cost ?? 0) > 0)
                            <tr>
                                <td colspan="3" class="text-end pe-3"><strong>Ongkos Kirim</strong></td>
                                <td class="text-end pe-3 fw-semibold">Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</td>
                            </tr>
                            @endif
                            @if(($order->discount ?? 0) > 0)
                            <tr>
                                <td colspan="3" class="text-end pe-3 text-danger"><strong>Diskon</strong></td>
                                <td class="text-end pe-3 fw-semibold text-danger">- Rp {{ number_format($order->discount, 0, ',', '.') }}</td>
                            </tr>
                            @endif
                            <tr>
                                <td colspan="3" class="text-end pe-3 pb-3">
                                    <strong style="font-size: 1.1rem; color: #0C4B8E;">Total</strong>
                                </td>
                                <td class="text-end pe-3 pb-3">
                                    <strong style="font-size: 1.1rem; color: #0C4B8E;">
                                        Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}
                                    </strong>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        {{-- Order Notes --}}
        @if($order->notes ?? null)
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #6c757d;">
                <i class="fas fa-sticky-note me-2"></i>Catatan Pesanan
            </div>
            <div class="card-body">
                <p class="mb-0" style="font-size: 0.9rem;">{{ $order->notes }}</p>
            </div>
        </div>
        @endif
    </div>

    {{-- Sidebar --}}
    <div class="col-lg-4">
        {{-- Customer Info Card --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #D4A017;">
                <i class="fas fa-user me-2"></i>Informasi Pelanggan
            </div>
            <div class="card-body">
                <div class="d-flex align-items-center mb-3">
                    <div class="rounded-circle d-flex align-items-center justify-content-center me-3"
                         style="width: 48px; height: 48px; background: rgba(12,75,142,0.1); color: #0C4B8E; font-weight: 700; font-size: 1.2rem;">
                        {{ strtoupper(substr($order->customer->name ?? $order->buyer->name ?? 'A', 0, 1)) }}
                    </div>
                    <div>
                        <div class="fw-bold">{{ $order->customer->name ?? $order->buyer->name ?? '-' }}</div>
                        <small class="text-muted">Pelanggan</small>
                    </div>
                </div>
                <div class="row g-3">
                    <div class="col-12">
                        <div class="detail-label">Email</div>
                        <div class="detail-value" style="font-size: 0.88rem;">{{ $order->customer->email ?? $order->buyer->email ?? '-' }}</div>
                    </div>
                    <div class="col-12">
                        <div class="detail-label">Telepon</div>
                        <div class="detail-value" style="font-size: 0.88rem;">{{ $order->customer->phone ?? '-' }}</div>
                    </div>
                    <div class="col-12">
                        <div class="detail-label">Alamat</div>
                        <div class="detail-value" style="font-size: 0.85rem;">{{ $order->customer->address ?? $order->shipping_address ?? '-' }}</div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Payment Info Card --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-credit-card me-2"></i>Informasi Pembayaran
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="detail-label">Metode</div>
                        <div class="detail-value">{{ $order->payment->method_label ?? $order->payment->method ?? 'Transfer Bank' }}</div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Jumlah</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">
                            Rp {{ number_format($order->payment->amount ?? $order->total ?? 0, 0, ',', '.') }}
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Status Bayar</div>
                        <div class="detail-value">
                            <span class="badge bg-{{ $psc['color'] }} bg-opacity-10 text-{{ $psc['color'] }} status-badge">
                                {{ $psc['label'] }}
                            </span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Tanggal Bayar</div>
                        <div class="detail-value" style="font-size: 0.88rem;">
                            {{ ($order->payment->paid_at ?? null) ? $order->payment->paid_at->format('d M Y, H:i') : '-' }}
                        </div>
                    </div>
                </div>

                @if($order->payment->proof_image ?? null)
                <div class="mt-3">
                    <div class="detail-label mb-2">Bukti Pembayaran</div>
                    <img src="{{ asset('storage/' . $order->payment->proof_image) }}"
                         alt="Bukti Pembayaran" class="proof-image"
                         onclick="window.open(this.src, '_blank')">
                </div>
                @endif
            </div>
        </div>

        {{-- Action Buttons --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-cogs me-2"></i>Aksi Pesanan
            </div>
            <div class="card-body">
                {{-- Confirm --}}
                @if(($order->status ?? '') === 'pending')
                <form action="{{ route('agent.orders.confirm', $order->id) }}" method="POST" class="mb-2">
                    @csrf
                    <button type="submit" class="btn btn-success w-100 action-btn">
                        <i class="fas fa-check me-2"></i>Konfirmasi Pesanan
                    </button>
                </form>
                @endif

                {{-- Process --}}
                @if(($order->status ?? '') === 'confirmed')
                <form action="{{ route('agent.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="status" value="processing">
                    <button type="submit" class="btn btn-info w-100 action-btn text-white">
                        <i class="fas fa-cog me-2"></i>Proses Pesanan
                    </button>
                </form>
                @endif

                {{-- Ship --}}
                @if(($order->status ?? '') === 'processing')
                <form action="{{ route('agent.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="status" value="shipped">
                    <div class="mb-2">
                        <label class="form-label fw-semibold small">No. Resi (opsional)</label>
                        <input type="text" name="tracking_number" class="form-control" placeholder="Masukkan nomor resi..."
                               style="border-radius: 10px;">
                    </div>
                    <button type="submit" class="btn btn-primary w-100 action-btn">
                        <i class="fas fa-truck me-2"></i>Kirim Pesanan
                    </button>
                </form>
                @endif

                {{-- Deliver --}}
                @if(($order->status ?? '') === 'shipped')
                <form action="{{ route('agent.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="status" value="delivered">
                    <button type="submit" class="btn btn-info w-100 action-btn text-white">
                        <i class="fas fa-check-double me-2"></i>Tandai Diterima Pelanggan
                    </button>
                </form>
                @endif

                {{-- Complete --}}
                @if(($order->status ?? '') === 'delivered')
                <form action="{{ route('agent.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="status" value="completed">
                    <button type="submit" class="btn btn-success w-100 action-btn">
                        <i class="fas fa-check-circle me-2"></i>Selesaikan Pesanan
                    </button>
                </form>
                @endif

                {{-- Cancel --}}
                @if(in_array($order->status ?? '', ['pending', 'confirmed', 'processing']))
                <form action="{{ route('agent.orders.update-status', $order->id) }}" method="POST" class="mb-2"
                      onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?')">
                    @csrf
                    @method('PUT')
                    <input type="hidden" name="status" value="cancelled">
                    <button type="submit" class="btn btn-outline-danger w-100 action-btn">
                        <i class="fas fa-times-circle me-2"></i>Batalkan Pesanan
                    </button>
                </form>
                @endif

                <hr>

                {{-- Manual Status Update --}}
                <div class="mb-2">
                    <label class="form-label fw-semibold small">Ubah Status Manual</label>
                    <form action="{{ route('agent.orders.update-status', $order->id) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="input-group">
                            <select name="status" class="form-select" style="border-radius: 10px 0 0 10px;">
                                @foreach($statusConfig as $key => $config)
                                <option value="{{ $key }}" {{ ($order->status ?? '') === $key ? 'selected' : '' }}>
                                    {{ $config['label'] }}
                                </option>
                                @endforeach
                            </select>
                            <button type="submit" class="btn text-white fw-bold" style="background: #0C4B8E; border-radius: 0 10px 10px 0;"
                                    onclick="return confirm('Yakin ingin mengubah status pesanan?')">
                                <i class="fas fa-save"></i>
                            </button>
                        </div>
                    </form>
                </div>

                <hr>

                <a href="javascript:window.print()" class="btn btn-outline-secondary w-100 mb-2" style="border-radius: 10px;">
                    <i class="fas fa-print me-2"></i>Cetak
                </a>

                <a href="{{ route('agent.orders.index') }}" class="btn btn-outline-primary w-100" style="border-radius: 10px;">
                    <i class="fas fa-arrow-left me-2"></i>Kembali ke Daftar
                </a>
            </div>
        </div>

        {{-- Order Timeline --}}
        <div class="card info-card shadow-sm">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-history me-2"></i>Riwayat Status
            </div>
            <div class="card-body">
                @if($order->statusHistories ?? null)
                    @foreach($order->statusHistories as $history)
                    <div class="timeline-item">
                        <div class="timeline-dot {{ $loop->last ? 'inactive' : '' }}"></div>
                        <div class="fw-semibold" style="font-size: 0.9rem;">
                            {{ $statusConfig[$history->status]['label'] ?? ucfirst($history->status) }}
                        </div>
                        <small class="text-muted">
                            {{ $history->created_at ? $history->created_at->format('d M Y, H:i') : '-' }}
                        </small>
                        @if($history->note ?? null)
                        <div class="text-muted mt-1" style="font-size: 0.82rem;">{{ $history->note }}</div>
                        @endif
                    </div>
                    @endforeach
                @else
                <div class="timeline-item">
                    <div class="timeline-dot"></div>
                    <div class="fw-semibold" style="font-size: 0.9rem;">Pesanan Dibuat</div>
                    <small class="text-muted">
                        {{ $order->created_at ? $order->created_at->format('d M Y, H:i') : '-' }}
                    </small>
                </div>
                <div class="timeline-item">
                    <div class="timeline-dot inactive"></div>
                    <div class="fw-semibold" style="font-size: 0.9rem; color: #6c757d;">
                        Status: {{ $sc['label'] }}
                    </div>
                    <small class="text-muted">Status saat ini</small>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

@endsection
