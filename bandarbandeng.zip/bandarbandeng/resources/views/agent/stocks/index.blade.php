@extends('layouts.agent')

@section('title', 'Stok Saya - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Stok Saya</li>
@endsection

@section('page_title', 'Stok Saya')

@section('page_actions')
    <a href="{{ route('agent.stock.order') }}" class="btn text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
        <i class="fas fa-cart-plus me-1"></i> Pesan ke Stockist
    </a>
@endsection

@push('styles')
<style>
    .stock-indicator {
        height: 8px;
        border-radius: 4px;
        background: #e9ecef;
        overflow: hidden;
    }
    .stock-indicator .fill {
        height: 100%;
        border-radius: 4px;
        transition: width 0.5s ease;
    }
    .stock-indicator-lg {
        height: 12px;
        border-radius: 6px;
        background: #e9ecef;
        overflow: hidden;
    }
    .stock-indicator-lg .fill {
        height: 100%;
        border-radius: 6px;
        transition: width 0.5s ease;
    }
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .low-stock-item {
        border-left: 4px solid #dc3545;
        padding: 0.6rem 1rem;
        margin-bottom: 0.5rem;
        background: #fff5f5;
        border-radius: 0 8px 8px 0;
    }
    [data-bs-theme="dark"] .low-stock-item {
        background: rgba(220,53,69,0.1);
    }
    .stock-level-green { background-color: #27AE60; }
    .stock-level-yellow { background-color: #F39C12; }
    .stock-level-red { background-color: #E74C3C; }
</style>
@endpush

@section('agent_content')

@include('partials.flash-messages')

{{-- Low Stock Alerts --}}
@if(count($lowStocks ?? []) > 0)
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
        <h6 class="fw-bold mb-0 text-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>Stok Rendah
        </h6>
        <a href="{{ route('agent.stock.order') }}" class="btn btn-sm btn-outline-danger" style="border-radius: 8px;">
            <i class="fas fa-cart-plus me-1"></i> Pesan Sekarang
        </a>
    </div>
    <div class="card-body">
        @foreach($lowStocks as $stock)
        @php
            $lowTotal = $stock->stock ?? 0;
            $lowReserved = $stock->reserved_stock ?? 0;
            $lowAvailable = $stock->available_stock ?? ($lowTotal - $lowReserved);
        @endphp
        <div class="low-stock-item">
            <div class="fw-semibold" style="font-size: 0.9rem;">
                {{ $stock->productVariant->product->name ?? $stock->product_name ?? '-' }}
            </div>
            <div class="d-flex justify-content-between align-items-center mt-1">
                <small class="text-muted">{{ $stock->productVariant->name ?? $stock->variant_name ?? '-' }}</small>
                <span class="badge bg-danger">
                    {{ $lowAvailable }} tersisa
                </span>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

{{-- Stock Table --}}
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
        <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
            <i class="fas fa-cubes me-2"></i>Daftar Stok
        </h6>
        <span class="badge" style="background: rgba(12,75,142,0.1); color: #0C4B8E; font-size: 0.85rem; padding: 0.5em 1em; border-radius: 8px;">
            {{ ($stocks ?? collect())->count() }} varian
        </span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Varian Produk</th>
                        <th class="text-center">Jumlah Stok</th>
                        <th class="text-center">Stok Terpesan</th>
                        <th class="text-center">Tersedia</th>
                        <th class="text-center" style="min-width: 160px;">Level Stok</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($stocks ?? [] as $stock)
                    @php
                        $total = $stock->stock ?? 0;
                        $reserved = $stock->reserved_stock ?? 0;
                        $available = $stock->available_stock ?? ($total - $reserved);
                        $maxStock = max($total, 50);
                        $percentage = $maxStock > 0 ? min(($available / $maxStock) * 100, 100) : 0;

                        // Color: green > 50%, yellow 20-50%, red < 20%
                        if ($percentage > 50) {
                            $barClass = 'stock-level-green';
                            $textColor = 'success';
                        } elseif ($percentage >= 20) {
                            $barClass = 'stock-level-yellow';
                            $textColor = 'warning';
                        } else {
                            $barClass = 'stock-level-red';
                            $textColor = 'danger';
                        }
                    @endphp
                    <tr>
                        <td class="ps-3">
                            <div class="fw-semibold" style="color: #0C4B8E;">
                                {{ $stock->productVariant->product->name ?? $stock->product_name ?? '-' }}
                            </div>
                            <small class="text-muted">
                                <span class="badge" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                                    {{ $stock->productVariant->name ?? $stock->variant_name ?? '-' }}
                                </span>
                            </small>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold">{{ number_format($total) }}</span>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold text-warning">{{ number_format($reserved) }}</span>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold" style="color: {{ $percentage > 50 ? '#27AE60' : ($percentage >= 20 ? '#F39C12' : '#E74C3C') }};">
                                {{ number_format($available) }}
                            </span>
                        </td>
                        <td class="text-center">
                            <div class="d-flex align-items-center justify-content-center gap-2">
                                <div class="stock-indicator-lg flex-grow-1">
                                    <div class="fill {{ $barClass }}" style="width: {{ $percentage }}%;"></div>
                                </div>
                                <small class="fw-bold text-{{ $textColor }}" style="min-width: 40px;">{{ number_format($percentage, 0) }}%</small>
                            </div>
                        </td>
                        <td class="text-center pe-3">
                            @if($percentage < 20)
                            <a href="{{ route('agent.stock.order') }}" class="btn btn-sm btn-outline-danger" title="Stok Kritis - Pesan Sekarang" style="border-radius: 8px;">
                                <i class="fas fa-cart-plus"></i>
                            </a>
                            @elseif($percentage < 50)
                            <a href="{{ route('agent.stock.order') }}" class="btn btn-sm btn-outline-warning" title="Stok Menipis" style="border-radius: 8px;">
                                <i class="fas fa-cart-plus"></i>
                            </a>
                            @else
                            <button type="button" class="btn btn-sm btn-outline-success" title="Stok Aman" disabled style="border-radius: 8px;">
                                <i class="fas fa-check"></i>
                            </button>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            <i class="fas fa-cubes fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada data stok</p>
                            <a href="{{ route('agent.stock.order') }}" class="btn btn-sm text-white" style="background: #0C4B8E; border-radius: 8px;">
                                <i class="fas fa-cart-plus me-1"></i> Pesan Stok dari Stockist
                            </a>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- Stock Legend --}}
<div class="card shadow-sm mt-3" style="border-radius: 12px; border: none;">
    <div class="card-body py-2">
        <div class="d-flex align-items-center gap-4 flex-wrap">
            <span class="small fw-semibold text-muted">Keterangan Level Stok:</span>
            <span class="d-flex align-items-center gap-1 small">
                <span class="d-inline-block rounded" style="width: 14px; height: 14px; background: #27AE60;"></span>
                Aman (> 50%)
            </span>
            <span class="d-flex align-items-center gap-1 small">
                <span class="d-inline-block rounded" style="width: 14px; height: 14px; background: #F39C12;"></span>
                Menipis (20%–50%)
            </span>
            <span class="d-flex align-items-center gap-1 small">
                <span class="d-inline-block rounded" style="width: 14px; height: 14px; background: #E74C3C;"></span>
                Kritis (< 20%)
            </span>
        </div>
    </div>
</div>

{{-- Pagination --}}
@if(isset($stocks) && method_exists($stocks, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $stocks->links() }}
</div>
@endif

@endsection
