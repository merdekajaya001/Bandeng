@extends('layouts.auth')

@section('title', 'Masuk - Bandar Bandeng Kalimantan')

@push('styles')
<style>
    /* ── Role Tabs ─────────────────────────────────────── */
    .role-tabs {
        display: flex;
        gap: 6px;
        margin-bottom: 1.25rem;
        background: #f0f4f8;
        border-radius: 12px;
        padding: 5px;
    }

    [data-bs-theme="dark"] .role-tabs {
        background: rgba(255, 255, 255, 0.08);
    }

    .role-tab {
        flex: 1;
        text-align: center;
        padding: 8px 4px;
        border-radius: 9px;
        cursor: pointer;
        transition: all 0.25s ease;
        font-size: 0.78rem;
        font-weight: 600;
        color: #6c757d;
        border: 2px solid transparent;
        user-select: none;
    }

    .role-tab i {
        display: block;
        font-size: 1.15rem;
        margin-bottom: 3px;
    }

    .role-tab:hover {
        background: rgba(12, 75, 142, 0.08);
        color: var(--bbk-blue);
    }

    .role-tab.active {
        background: var(--bbk-blue);
        color: #fff;
        box-shadow: 0 4px 12px rgba(12, 75, 142, 0.35);
    }

    [data-bs-theme="dark"] .role-tab.active {
        background: var(--bbk-blue-light);
    }

    /* ── Form Inputs ──────────────────────────────────── */
    .input-icon-group {
        position: relative;
    }

    .input-icon-group .input-icon {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #adb5bd;
        font-size: 0.95rem;
        pointer-events: none;
        transition: color 0.2s;
    }

    .input-icon-group input:focus ~ .input-icon,
    .input-icon-group input:focus + .input-icon {
        color: var(--bbk-blue);
    }

    .input-icon-group input {
        padding-left: 42px;
    }

    .password-toggle {
        position: absolute;
        right: 14px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #adb5bd;
        cursor: pointer;
        font-size: 0.95rem;
        padding: 0;
        transition: color 0.2s;
    }

    .password-toggle:hover {
        color: var(--bbk-blue);
    }

    .input-icon-group input[type="password"],
    .input-icon-group input[type="text"].password-field {
        padding-right: 44px;
    }

    .form-control:focus {
        border-color: var(--bbk-blue);
        box-shadow: 0 0 0 0.2rem rgba(12, 75, 142, 0.15);
    }

    /* ── Submit Button ─────────────────────────────────── */
    .btn-bbk-login {
        background: linear-gradient(135deg, var(--bbk-blue) 0%, var(--bbk-blue-light) 100%);
        border: none;
        color: #fff;
        font-weight: 700;
        padding: 12px;
        border-radius: 10px;
        letter-spacing: 0.3px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .btn-bbk-login::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s ease;
    }

    .btn-bbk-login:hover {
        background: linear-gradient(135deg, var(--bbk-blue-light) 0%, var(--bbk-blue) 100%);
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(12, 75, 142, 0.4);
        color: #fff;
    }

    .btn-bbk-login:hover::before {
        left: 100%;
    }

    .btn-bbk-login:active {
        transform: translateY(0);
    }

    /* ── Links ─────────────────────────────────────────── */
    .auth-links a {
        color: var(--bbk-blue-light);
        text-decoration: none;
        font-weight: 500;
        transition: color 0.2s;
    }

    .auth-links a:hover {
        color: var(--bbk-gold);
    }

    [data-bs-theme="dark"] .auth-links a {
        color: #93c5fd;
    }

    [data-bs-theme="dark"] .auth-links a:hover {
        color: var(--bbk-gold-light);
    }

    /* ── Custom Checkbox ───────────────────────────────── */
    .form-check-input:checked {
        background-color: var(--bbk-blue);
        border-color: var(--bbk-blue);
    }

    /* ── Validation ────────────────────────────────────── */
    .invalid-feedback.d-block {
        display: block !important;
    }
</style>
@endpush

@section('content')
<form method="POST" action="{{ route('login.post') }}" id="loginForm" novalidate>
    @csrf

    {{-- Hidden role input --}}
    <input type="hidden" name="role" id="roleInput" value="{{ $activeRole ?? 'customer' }}">

    {{-- ── Role Tabs ──────────────────────────────────────── --}}
    <div class="role-tabs" role="tablist" aria-label="Pilih peran login">
        <div class="role-tab {{ ($activeRole ?? 'customer') === 'admin' ? 'active' : '' }}"
             data-role="admin" role="tab" tabindex="0"
             aria-selected="{{ ($activeRole ?? 'customer') === 'admin' ? 'true' : 'false' }}">
            <i class="fas fa-shield-halved"></i>
            Admin
        </div>
        <div class="role-tab {{ ($activeRole ?? 'customer') === 'stockist' ? 'active' : '' }}"
             data-role="stockist" role="tab" tabindex="0"
             aria-selected="{{ ($activeRole ?? 'customer') === 'stockist' ? 'true' : 'false' }}">
            <i class="fas fa-warehouse"></i>
            Stockist
        </div>
        <div class="role-tab {{ ($activeRole ?? 'customer') === 'agent' ? 'active' : '' }}"
             data-role="agent" role="tab" tabindex="0"
             aria-selected="{{ ($activeRole ?? 'customer') === 'agent' ? 'true' : 'false' }}">
            <i class="fas fa-user-tie"></i>
            Agen
        </div>
        <div class="role-tab {{ ($activeRole ?? 'customer') === 'customer' ? 'active' : '' }}"
             data-role="customer" role="tab" tabindex="0"
             aria-selected="{{ ($activeRole ?? 'customer') === 'customer' ? 'true' : 'false' }}">
            <i class="fas fa-user"></i>
            Pelanggan
        </div>
    </div>

    {{-- ── Email ──────────────────────────────────────────── --}}
    <div class="mb-3">
        <label for="email" class="form-label fw-semibold" style="font-size: 0.88rem;">
            Alamat Email
        </label>
        <div class="input-icon-group">
            <input type="email"
                   class="form-control form-control-lg @error('email') is-invalid @enderror"
                   id="email"
                   name="email"
                   value="{{ old('email') }}"
                   placeholder="nama@email.com"
                   required
                   autocomplete="email"
                   autofocus>
            <i class="fas fa-envelope input-icon"></i>
        </div>
        @error('email')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </div>

    {{-- ── Password ───────────────────────────────────────── --}}
    <div class="mb-3">
        <div class="d-flex justify-content-between align-items-center">
            <label for="password" class="form-label fw-semibold" style="font-size: 0.88rem;">
                Password
            </label>
            <a href="#" onclick="alert('Fitur reset password akan segera tersedia.'); return false;"
               class="text-decoration-none" style="font-size: 0.82rem; color: var(--bbk-blue-light);">
                Lupa Password?
            </a>
        </div>
        <div class="input-icon-group">
            <input type="password"
                   class="form-control form-control-lg password-field @error('password') is-invalid @enderror"
                   id="password"
                   name="password"
                   placeholder="Masukkan password"
                   required
                   autocomplete="current-password">
            <i class="fas fa-lock input-icon"></i>
            <button type="button" class="password-toggle" id="togglePassword" aria-label="Tampilkan password">
                <i class="fas fa-eye"></i>
            </button>
        </div>
        @error('password')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </div>

    {{-- ── Role Validation Error ───────────────────────────── --}}
    @error('role')
        <div class="alert alert-danger py-2 px-3 mb-3" style="border-radius: 8px; font-size: 0.88rem;">
            <i class="fas fa-exclamation-triangle me-1"></i> {{ $message }}
        </div>
    @enderror

    {{-- ── Remember Me ─────────────────────────────────────── --}}
    <div class="mb-4">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="remember" id="remember"
                   {{ old('remember') ? 'checked' : '' }}>
            <label class="form-check-label" for="remember" style="font-size: 0.88rem; color: #6c757d;">
                Ingat saya
            </label>
        </div>
    </div>

    {{-- ── Submit Button ───────────────────────────────────── --}}
    <button type="submit" class="btn btn-bbk-login w-100 mb-3" id="btnLogin">
        <i class="fas fa-sign-in-alt me-2"></i> Masuk
    </button>

    {{-- ── Links ───────────────────────────────────────────── --}}
    <div class="auth-links text-center" style="font-size: 0.9rem;">
        Belum punya akun?
        <a href="{{ route('register') }}" class="fw-semibold">Daftar</a>
    </div>
</form>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {

    // ── Role Tab Switching ──────────────────────────────────
    const roleInput = document.getElementById('roleInput');
    const roleTabs  = document.querySelectorAll('.role-tab');

    function activateTab(tab) {
        // Deactivate all tabs
        roleTabs.forEach(function (t) {
            t.classList.remove('active');
            t.setAttribute('aria-selected', 'false');
        });

        // Activate the clicked tab
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');

        // Update hidden input
        roleInput.value = tab.dataset.role;
    }

    roleTabs.forEach(function (tab) {
        tab.addEventListener('click', function () {
            activateTab(tab);
        });

        // Keyboard accessibility: Enter and Space
        tab.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                activateTab(tab);
            }
        });
    });

    // ── Password Show / Hide Toggle ─────────────────────────
    const passwordField   = document.getElementById('password');
    const toggleBtn       = document.getElementById('togglePassword');
    const toggleIcon      = toggleBtn.querySelector('i');

    toggleBtn.addEventListener('click', function () {
        if (passwordField.type === 'password') {
            passwordField.type = 'text';
            toggleIcon.classList.remove('fa-eye');
            toggleIcon.classList.add('fa-eye-slash');
            toggleBtn.setAttribute('aria-label', 'Sembunyikan password');
        } else {
            passwordField.type = 'password';
            toggleIcon.classList.remove('fa-eye-slash');
            toggleIcon.classList.add('fa-eye');
            toggleBtn.setAttribute('aria-label', 'Tampilkan password');
        }
    });

    // ── Form Submission: disable button to prevent double-click ──
    const loginForm = document.getElementById('loginForm');
    const btnLogin  = document.getElementById('btnLogin');

    loginForm.addEventListener('submit', function () {
        btnLogin.disabled = true;
        btnLogin.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Memproses...';
    });

});
</script>
@endpush
