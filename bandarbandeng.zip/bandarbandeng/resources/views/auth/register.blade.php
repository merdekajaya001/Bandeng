@extends('layouts.auth')

@section('title', 'Daftar Akun Baru - Bandar Bandeng Kalimantan')

@push('styles')
<style>
    /* Widen the auth card for the registration form */
    .auth-wrapper {
        max-width: 540px !important;
    }

    .auth-card {
        padding: 2rem 1.75rem !important;
    }

    /* ── Role Selection Cards ──────────────────────────── */
    .role-selector {
        display: flex;
        gap: 12px;
        margin-bottom: 1.25rem;
    }

    .role-card {
        flex: 1;
        text-align: center;
        padding: 16px 10px;
        border: 2px solid #dee2e6;
        border-radius: 12px;
        cursor: pointer;
        transition: all 0.25s ease;
        user-select: none;
    }

    .role-card:hover {
        border-color: var(--bbk-blue-light);
        background: rgba(12, 75, 142, 0.04);
    }

    .role-card.selected {
        border-color: var(--bbk-blue);
        background: rgba(12, 75, 142, 0.08);
        box-shadow: 0 0 0 3px rgba(12, 75, 142, 0.15);
    }

    [data-bs-theme="dark"] .role-card {
        border-color: #4b5563;
    }

    [data-bs-theme="dark"] .role-card:hover {
        border-color: var(--bbk-blue-light);
        background: rgba(26, 111, 181, 0.1);
    }

    [data-bs-theme="dark"] .role-card.selected {
        border-color: var(--bbk-blue-light);
        background: rgba(26, 111, 181, 0.15);
        box-shadow: 0 0 0 3px rgba(26, 111, 181, 0.2);
    }

    .role-card-icon {
        font-size: 1.8rem;
        margin-bottom: 6px;
        color: #adb5bd;
        transition: color 0.25s;
    }

    .role-card.selected .role-card-icon {
        color: var(--bbk-blue);
    }

    [data-bs-theme="dark"] .role-card.selected .role-card-icon {
        color: var(--bbk-blue-light);
    }

    .role-card-title {
        font-weight: 700;
        font-size: 0.92rem;
        color: #495057;
        margin-bottom: 2px;
    }

    .role-card.selected .role-card-title {
        color: var(--bbk-blue);
    }

    [data-bs-theme="dark"] .role-card-title {
        color: #d1d5db;
    }

    [data-bs-theme="dark"] .role-card.selected .role-card-title {
        color: #93c5fd;
    }

    .role-card-desc {
        font-size: 0.75rem;
        color: #adb5bd;
        margin: 0;
    }

    .role-check {
        width: 20px;
        height: 20px;
        border: 2px solid #dee2e6;
        border-radius: 50%;
        margin: 8px auto 0;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.25s;
    }

    .role-card.selected .role-check {
        border-color: var(--bbk-blue);
        background: var(--bbk-blue);
    }

    .role-check i {
        color: #fff;
        font-size: 0.65rem;
        opacity: 0;
        transition: opacity 0.2s;
    }

    .role-card.selected .role-check i {
        opacity: 1;
    }

    /* ── Input Icons ───────────────────────────────────── */
    .input-icon-group {
        position: relative;
    }

    .input-icon-group .input-icon {
        position: absolute;
        left: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: #adb5bd;
        font-size: 0.95rem;
        pointer-events: none;
        transition: color 0.2s;
    }

    .input-icon-group.textarea-group .input-icon {
        top: 18px;
        transform: none;
    }

    .input-icon-group input:focus ~ .input-icon,
    .input-icon-group input:focus + .input-icon,
    .input-icon-group textarea:focus ~ .input-icon {
        color: var(--bbk-blue);
    }

    .input-icon-group input,
    .input-icon-group select {
        padding-left: 42px;
    }

    .input-icon-group textarea {
        padding-left: 42px;
    }

    .password-toggle {
        position: absolute;
        right: 14px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #adb5bd;
        cursor: pointer;
        font-size: 0.95rem;
        padding: 0;
        transition: color 0.2s;
    }

    .password-toggle:hover {
        color: var(--bbk-blue);
    }

    .input-icon-group input.password-field {
        padding-right: 44px;
    }

    .form-control:focus,
    .form-select:focus {
        border-color: var(--bbk-blue);
        box-shadow: 0 0 0 0.2rem rgba(12, 75, 142, 0.15);
    }

    /* ── Password Strength Meter ──────────────────────── */
    .password-strength {
        margin-top: 6px;
    }

    .strength-bar-track {
        height: 5px;
        background: #e9ecef;
        border-radius: 3px;
        overflow: hidden;
    }

    [data-bs-theme="dark"] .strength-bar-track {
        background: #374151;
    }

    .strength-bar-fill {
        height: 100%;
        width: 0%;
        border-radius: 3px;
        transition: width 0.35s ease, background-color 0.35s ease;
    }

    .strength-text {
        font-size: 0.75rem;
        margin-top: 3px;
        font-weight: 600;
    }

    /* Strength levels */
    .strength-weak .strength-bar-fill   { width: 25%;  background: #e74c3c; }
    .strength-weak .strength-text        { color: #e74c3c; }

    .strength-fair .strength-bar-fill    { width: 50%;  background: #f39c12; }
    .strength-fair .strength-text         { color: #f39c12; }

    .strength-good .strength-bar-fill    { width: 75%;  background: var(--bbk-blue); }
    .strength-good .strength-text         { color: var(--bbk-blue); }

    .strength-strong .strength-bar-fill  { width: 100%; background: #27AE60; }
    .strength-strong .strength-text       { color: #27AE60; }

    /* ── Submit Button ─────────────────────────────────── */
    .btn-bbk-register {
        background: linear-gradient(135deg, var(--bbk-blue) 0%, var(--bbk-blue-light) 100%);
        border: none;
        color: #fff;
        font-weight: 700;
        padding: 12px;
        border-radius: 10px;
        letter-spacing: 0.3px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .btn-bbk-register::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
        transition: left 0.5s ease;
    }

    .btn-bbk-register:hover {
        background: linear-gradient(135deg, var(--bbk-blue-light) 0%, var(--bbk-blue) 100%);
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(12, 75, 142, 0.4);
        color: #fff;
    }

    .btn-bbk-register:hover::before {
        left: 100%;
    }

    .btn-bbk-register:active {
        transform: translateY(0);
    }

    /* ── Links ─────────────────────────────────────────── */
    .auth-links a {
        color: var(--bbk-blue-light);
        text-decoration: none;
        font-weight: 500;
        transition: color 0.2s;
    }

    .auth-links a:hover {
        color: var(--bbk-gold);
    }

    [data-bs-theme="dark"] .auth-links a {
        color: #93c5fd;
    }

    [data-bs-theme="dark"] .auth-links a:hover {
        color: var(--bbk-gold-light);
    }

    /* ── Custom Checkbox ───────────────────────────────── */
    .form-check-input:checked {
        background-color: var(--bbk-blue);
        border-color: var(--bbk-blue);
    }

    /* ── Validation ────────────────────────────────────── */
    .invalid-feedback.d-block {
        display: block !important;
    }

    /* ── Invitation Code Section ───────────────────────── */
    .invitation-section {
        display: none;
    }

    .invitation-section.show {
        display: block;
    }

    /* ── Section divider ──────────────────────────────── */
    .section-divider {
        display: flex;
        align-items: center;
        gap: 10px;
        margin: 1.25rem 0 1rem;
        color: #adb5bd;
        font-size: 0.78rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .section-divider::before,
    .section-divider::after {
        content: '';
        flex: 1;
        height: 1px;
        background: #dee2e6;
    }

    [data-bs-theme="dark"] .section-divider::before,
    [data-bs-theme="dark"] .section-divider::after {
        background: #4b5563;
    }

    [data-bs-theme="dark"] .section-divider {
        color: #6b7280;
    }

    /* ── Form row spacing ─────────────────────────────── */
    .form-row {
        margin-bottom: 0.85rem;
    }
</style>
@endpush

@section('content')
<form method="POST" action="{{ route('register.post') }}" id="registerForm" novalidate>
    @csrf

    {{-- Hidden role input --}}
    <input type="hidden" name="role" id="roleInput" value="{{ $role ?? 'customer' }}">

    {{-- ── Page Title ──────────────────────────────────────── --}}
    <h5 class="text-center fw-bold mb-1" style="color: var(--bbk-blue);">Daftar Akun Baru</h5>
    <p class="text-center mb-3" style="font-size: 0.85rem; color: #6c757d;">
        Bergabung bersama Bandar Bandeng Kalimantan
    </p>

    {{-- ── Role Selection ──────────────────────────────────── --}}
    <div class="role-selector" role="radiogroup" aria-label="Pilih tipe akun">
        {{-- Customer Card --}}
        <div class="role-card {{ ($role ?? 'customer') === 'customer' ? 'selected' : '' }}"
             data-role="customer"
             role="radio"
             tabindex="0"
             aria-checked="{{ ($role ?? 'customer') === 'customer' ? 'true' : 'false' }}">
            <div class="role-card-icon">
                <i class="fas fa-user"></i>
            </div>
            <div class="role-card-title">Pelanggan</div>
            <p class="role-card-desc">Beli ikan bandeng</p>
            <div class="role-check"><i class="fas fa-check"></i></div>
        </div>

        {{-- Agent Card --}}
        <div class="role-card {{ ($role ?? 'customer') === 'agent' ? 'selected' : '' }}"
             data-role="agent"
             role="radio"
             tabindex="0"
             aria-checked="{{ ($role ?? 'customer') === 'agent' ? 'true' : 'false' }}">
            <div class="role-card-icon">
                <i class="fas fa-user-tie"></i>
            </div>
            <div class="role-card-title">Agen</div>
            <p class="role-card-desc">Jual & distribusi</p>
            <div class="role-check"><i class="fas fa-check"></i></div>
        </div>
    </div>

    {{-- ── Invitation Code (Agent Only) ────────────────────── --}}
    <div class="invitation-section {{ ($role ?? 'customer') === 'agent' ? 'show' : '' }}" id="invitationSection">
        <div class="form-row">
            <label for="invitation_code" class="form-label fw-semibold" style="font-size: 0.88rem;">
                Kode Undangan / Referral
            </label>
            <div class="input-icon-group">
                <input type="text"
                       class="form-control @error('invitation_code') is-invalid @enderror"
                       id="invitation_code"
                       name="invitation_code"
                       value="{{ old('invitation_code', $invitationCode ?? '') }}"
                       placeholder="Masukkan kode undangan dari admin">
                <i class="fas fa-key input-icon"></i>
            </div>
            @error('invitation_code')
                <div class="invalid-feedback d-block">{{ $message }}</div>
            @enderror
            <div class="form-text" style="font-size: 0.78rem;">
                <i class="fas fa-info-circle me-1"></i>
                Diperlukan kode undangan untuk mendaftar sebagai Agen.
            </div>
        </div>
    </div>

    {{-- ── Section: Data Pribadi ────────────────────────────── --}}
    <div class="section-divider">Data Pribadi</div>

    {{-- Name --}}
    <div class="form-row">
        <label for="name" class="form-label fw-semibold" style="font-size: 0.88rem;">
            Nama Lengkap
        </label>
        <div class="input-icon-group">
            <input type="text"
                   class="form-control @error('name') is-invalid @enderror"
                   id="name"
                   name="name"
                   value="{{ old('name') }}"
                   placeholder="Masukkan nama lengkap"
                   required
                   autocomplete="name">
            <i class="fas fa-user input-icon"></i>
        </div>
        @error('name')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </div>

    {{-- Email --}}
    <div class="form-row">
        <label for="email" class="form-label fw-semibold" style="font-size: 0.88rem;">
            Alamat Email
        </label>
        <div class="input-icon-group">
            <input type="email"
                   class="form-control @error('email') is-invalid @enderror"
                   id="email"
                   name="email"
                   value="{{ old('email') }}"
                   placeholder="nama@email.com"
                   required
                   autocomplete="email">
            <i class="fas fa-envelope input-icon"></i>
        </div>
        @error('email')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </div>

    {{-- Phone --}}
    <div class="form-row">
        <label for="phone" class="form-label fw-semibold" style="font-size: 0.88rem;">
            Nomor Telepon
        </label>
        <div class="input-icon-group">
            <input type="tel"
                   class="form-control @error('phone') is-invalid @enderror"
                   id="phone"
                   name="phone"
                   value="{{ old('phone') }}"
                   placeholder="08xxxxxxxxxx"
                   required
                   autocomplete="tel"
                   maxlength="15">
            <i class="fas fa-phone input-icon"></i>
        </div>
        @error('phone')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
        <div class="form-text" style="font-size: 0.78rem;">
            <i class="fas fa-info-circle me-1"></i>
            Format: 08xxxxxxxxxx atau +628xxxxxxxxx
        </div>
    </div>

    {{-- ── Section: Alamat ──────────────────────────────────── --}}
    <div class="section-divider">Alamat</div>

    {{-- Address --}}
    <div class="form-row">
        <label for="address" class="form-label fw-semibold" style="font-size: 0.88rem;">
            Alamat Lengkap
        </label>
        <div class="input-icon-group textarea-group">
            <textarea class="form-control @error('address') is-invalid @enderror"
                      id="address"
                      name="address"
                      rows="2"
                      placeholder="Jl. Contoh No. 123, RT/RW"
                      autocomplete="street-address">{{ old('address') }}</textarea>
            <i class="fas fa-map-marker-alt input-icon"></i>
        </div>
        @error('address')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </div>

    {{-- City --}}
    <div class="row g-2">
        <div class="col-sm-6">
            <div class="form-row">
                <label for="city" class="form-label fw-semibold" style="font-size: 0.88rem;">
                    Kota / Kabupaten
                </label>
                <div class="input-icon-group">
                    <input type="text"
                           class="form-control @error('city') is-invalid @enderror"
                           id="city"
                           name="city"
                           value="{{ old('city') }}"
                           placeholder="Banjarmasin"
                           autocomplete="address-level2">
                    <i class="fas fa-city input-icon"></i>
                </div>
                @error('city')
                    <div class="invalid-feedback d-block">{{ $message }}</div>
                @enderror
            </div>
        </div>

        {{-- Province --}}
        <div class="col-sm-6">
            <div class="form-row">
                <label for="province" class="form-label fw-semibold" style="font-size: 0.88rem;">
                    Provinsi
                </label>
                <div class="input-icon-group">
                    <select class="form-select @error('province') is-invalid @enderror"
                            id="province"
                            name="province"
                            autocomplete="address-level1">
                        <option value="" selected disabled>Pilih provinsi</option>
                        <option value="Kalimantan Selatan"  {{ old('province') === 'Kalimantan Selatan' ? 'selected' : '' }}>Kalimantan Selatan</option>
                        <option value="Kalimantan Timur"    {{ old('province') === 'Kalimantan Timur' ? 'selected' : '' }}>Kalimantan Timur</option>
                        <option value="Kalimantan Tengah"   {{ old('province') === 'Kalimantan Tengah' ? 'selected' : '' }}>Kalimantan Tengah</option>
                        <option value="Kalimantan Barat"    {{ old('province') === 'Kalimantan Barat' ? 'selected' : '' }}>Kalimantan Barat</option>
                        <option value="Kalimantan Utara"    {{ old('province') === 'Kalimantan Utara' ? 'selected' : '' }}>Kalimantan Utara</option>
                    </select>
                    <i class="fas fa-map input-icon"></i>
                </div>
                @error('province')
                    <div class="invalid-feedback d-block">{{ $message }}</div>
                @enderror
            </div>
        </div>
    </div>

    {{-- ── Section: Keamanan ────────────────────────────────── --}}
    <div class="section-divider">Keamanan</div>

    {{-- Password --}}
    <div class="form-row">
        <label for="password" class="form-label fw-semibold" style="font-size: 0.88rem;">
            Password
        </label>
        <div class="input-icon-group">
            <input type="password"
                   class="form-control password-field @error('password') is-invalid @enderror"
                   id="password"
                   name="password"
                   placeholder="Minimal 8 karakter"
                   required
                   autocomplete="new-password">
            <i class="fas fa-lock input-icon"></i>
            <button type="button" class="password-toggle" id="togglePassword" aria-label="Tampilkan password">
                <i class="fas fa-eye"></i>
            </button>
        </div>
        @error('password')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror

        {{-- Password Strength Indicator --}}
        <div class="password-strength" id="passwordStrength">
            <div class="strength-bar-track">
                <div class="strength-bar-fill"></div>
            </div>
            <div class="strength-text" id="strengthText"></div>
        </div>
    </div>

    {{-- Password Confirmation --}}
    <div class="form-row">
        <label for="password_confirmation" class="form-label fw-semibold" style="font-size: 0.88rem;">
            Konfirmasi Password
        </label>
        <div class="input-icon-group">
            <input type="password"
                   class="form-control password-field @error('password_confirmation') is-invalid @enderror"
                   id="password_confirmation"
                   name="password_confirmation"
                   placeholder="Ulangi password"
                   required
                   autocomplete="new-password">
            <i class="fas fa-lock input-icon"></i>
            <button type="button" class="password-toggle" id="toggleConfirmPassword" aria-label="Tampilkan konfirmasi password">
                <i class="fas fa-eye"></i>
            </button>
        </div>
        @error('password_confirmation')
            <div class="invalid-feedback d-block">{{ $message }}</div>
        @enderror
    </div>

    {{-- ── Terms & Conditions ───────────────────────────────── --}}
    <div class="mb-3">
        <div class="form-check">
            <input class="form-check-input" type="checkbox" name="terms" id="terms"
                   required {{ old('terms') ? 'checked' : '' }}>
            <label class="form-check-label" for="terms" style="font-size: 0.85rem; color: #6c757d;">
                Saya menyetujui
                <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal"
                   style="color: var(--bbk-blue-light); text-decoration: underline;">
                    Syarat & Ketentuan
                </a>
                serta
                <a href="#" data-bs-toggle="modal" data-bs-target="#privacyModal"
                   style="color: var(--bbk-blue-light); text-decoration: underline;">
                    Kebijakan Privasi
                </a>
                Bandar Bandeng Kalimantan.
            </label>
        </div>
    </div>

    {{-- ── Submit Button ────────────────────────────────────── --}}
    <button type="submit" class="btn btn-bbk-register w-100 mb-3" id="btnRegister">
        <i class="fas fa-user-plus me-2"></i> Daftar Sekarang
    </button>

    {{-- ── Links ────────────────────────────────────────────── --}}
    <div class="auth-links text-center" style="font-size: 0.9rem;">
        Sudah punya akun?
        <a href="{{ route('login') }}" class="fw-semibold">Masuk</a>
    </div>
</form>

{{-- ── Terms Modal ──────────────────────────────────────────── --}}
<div class="modal fade" id="termsModal" tabindex="-1" aria-labelledby="termsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header" style="background: var(--bbk-blue); color: #fff;">
                <h6 class="modal-title" id="termsModalLabel">
                    <i class="fas fa-file-contract me-2"></i>Syarat & Ketentuan
                </h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body" style="font-size: 0.88rem;">
                <h6 class="fw-bold">1. Ketentuan Umum</h6>
                <p>Dengan mendaftar dan menggunakan platform Bandar Bandeng Kalimantan, Anda menyetujui seluruh syarat dan ketentuan yang berlaku. Platform ini menyediakan layanan penjualan dan distribusi ikan bandeng tanpa duri di wilayah Kalimantan.</p>

                <h6 class="fw-bold">2. Akun Pengguna</h6>
                <p>Anda bertanggung jawab atas keamanan akun yang terdaftar. Informasi yang diberikan harus benar dan akurat. Penyalahgunaan akun dapat mengakibatkan penangguhan akses.</p>

                <h6 class="fw-bold">3. Transaksi</h6>
                <p>Seluruh transaksi yang dilakukan melalui platform ini tunduk pada kebijakan harga, pembayaran, dan pengiriman yang berlaku. Pembatalan pesanan mengikuti kebijakan yang ditetapkan.</p>

                <h6 class="fw-bold">4. Agen & Distributor</h6>
                <p>Pendaftaran sebagai Agen memerlukan kode undangan yang sah. Agen bertanggung jawab atas distribusi produk di wilayah yang telah ditentukan.</p>

                <h6 class="fw-bold">5. Perubahan Ketentuan</h6>
                <p>Bandar Bandeng Kalimantan berhak mengubah syarat dan ketentuan sewaktu-waktu tanpa pemberitahuan terlebih dahulu.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm px-4" style="background: var(--bbk-blue); color: #fff; border-radius: 8px;" data-bs-dismiss="modal">
                    Saya Mengerti
                </button>
            </div>
        </div>
    </div>
</div>

{{-- ── Privacy Modal ────────────────────────────────────────── --}}
<div class="modal fade" id="privacyModal" tabindex="-1" aria-labelledby="privacyModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header" style="background: var(--bbk-blue); color: #fff;">
                <h6 class="modal-title" id="privacyModalLabel">
                    <i class="fas fa-shield-halved me-2"></i>Kebijakan Privasi
                </h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body" style="font-size: 0.88rem;">
                <h6 class="fw-bold">1. Pengumpulan Data</h6>
                <p>Kami mengumpulkan data pribadi yang Anda berikan saat pendaftaran, seperti nama, email, nomor telepon, dan alamat. Data ini digunakan untuk memproses pesanan dan meningkatkan layanan.</p>

                <h6 class="fw-bold">2. Penggunaan Data</h6>
                <p>Data pribadi Anda digunakan untuk: pemrosesan pesanan, komunikasi terkait layanan, peningkatan kualitas produk, dan keperluan operasional lainnya.</p>

                <h6 class="fw-bold">3. Perlindungan Data</h6>
                <p>Kami menerapkan langkah-langkah keamanan untuk melindungi data pribadi Anda dari akses yang tidak sah, penggunaan yang tidak semestinya, atau pengungkapan yang tidak wajar.</p>

                <h6 class="fw-bold">4. Hak Pengguna</h6>
                <p>Anda berhak mengakses, memperbaiki, atau menghapus data pribadi Anda. Untuk permintaan ini, silakan hubungi tim kami melalui halaman kontak.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm px-4" style="background: var(--bbk-blue); color: #fff; border-radius: 8px;" data-bs-dismiss="modal">
                    Saya Mengerti
                </button>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {

    // ── Role Card Selection ────────────────────────────────
    const roleInput  = document.getElementById('roleInput');
    const roleCards  = document.querySelectorAll('.role-card');
    const invSection = document.getElementById('invitationSection');

    function selectRole(card) {
        // Deselect all
        roleCards.forEach(function (c) {
            c.classList.remove('selected');
            c.setAttribute('aria-checked', 'false');
        });

        // Select the clicked card
        card.classList.add('selected');
        card.setAttribute('aria-checked', 'true');

        // Update hidden input
        var role = card.dataset.role;
        roleInput.value = role;

        // Show/hide invitation code section
        if (role === 'agent') {
            invSection.classList.add('show');
        } else {
            invSection.classList.remove('show');
        }
    }

    roleCards.forEach(function (card) {
        card.addEventListener('click', function () {
            selectRole(card);
        });

        // Keyboard accessibility
        card.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                selectRole(card);
            }
        });
    });

    // ── Password Show / Hide Toggle ─────────────────────────
    function setupPasswordToggle(toggleId, inputId) {
        var toggleBtn    = document.getElementById(toggleId);
        var inputField   = document.getElementById(inputId);
        var toggleIcon   = toggleBtn.querySelector('i');

        toggleBtn.addEventListener('click', function () {
            if (inputField.type === 'password') {
                inputField.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                inputField.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        });
    }

    setupPasswordToggle('togglePassword', 'password');
    setupPasswordToggle('toggleConfirmPassword', 'password_confirmation');

    // ── Password Strength Meter ─────────────────────────────
    var passwordInput  = document.getElementById('password');
    var strengthWidget = document.getElementById('passwordStrength');
    var strengthText   = document.getElementById('strengthText');

    function calculateStrength(password) {
        var score = 0;

        if (password.length === 0) return { score: 0, label: '', level: '' };

        // Length checks
        if (password.length >= 8)  score += 1;
        if (password.length >= 12) score += 1;

        // Character variety checks
        if (/[a-z]/.test(password))       score += 1;  // lowercase
        if (/[A-Z]/.test(password))       score += 1;  // uppercase
        if (/[0-9]/.test(password))       score += 1;  // numbers
        if (/[^a-zA-Z0-9]/.test(password)) score += 1; // special chars

        // Map score to level
        if (score <= 2) return { score: score, label: 'Lemah', level: 'strength-weak' };
        if (score <= 3) return { score: score, label: 'Cukup', level: 'strength-fair' };
        if (score <= 5) return { score: score, label: 'Kuat', level: 'strength-good' };
        return { score: score, label: 'Sangat Kuat', level: 'strength-strong' };
    }

    passwordInput.addEventListener('input', function () {
        var result = calculateStrength(this.value);

        // Remove all strength classes
        strengthWidget.classList.remove('strength-weak', 'strength-fair', 'strength-good', 'strength-strong');

        if (this.value.length === 0) {
            strengthText.textContent = '';
        } else {
            strengthWidget.classList.add(result.level);
            strengthText.textContent = 'Kekuatan: ' + result.label;
        }
    });

    // ── Phone Number Formatting ─────────────────────────────
    var phoneInput = document.getElementById('phone');

    phoneInput.addEventListener('input', function () {
        var value = this.value;

        // Replace +62 prefix with 0
        if (value.startsWith('+62')) {
            value = '0' + value.substring(3);
        }

        // Remove non-digit characters (except leading +)
        value = value.replace(/[^\d+]/g, '');

        // Ensure starts with 0 or +
        if (value.length > 0 && !value.startsWith('0') && !value.startsWith('+')) {
            value = '0' + value;
        }

        this.value = value;
    });

    phoneInput.addEventListener('blur', function () {
        var value = this.value.trim();

        // Auto-prefix with 0 if user typed just 8xx...
        if (value.length > 0 && value.startsWith('8')) {
            this.value = '0' + value;
        }
    });

    // ── Form Submission: disable button to prevent double-click ──
    var registerForm = document.getElementById('registerForm');
    var btnRegister  = document.getElementById('btnRegister');

    registerForm.addEventListener('submit', function (e) {
        // Basic client-side terms check
        var termsCheckbox = document.getElementById('terms');
        if (!termsCheckbox.checked) {
            e.preventDefault();
            termsCheckbox.classList.add('is-invalid');
            alert('Anda harus menyetujui Syarat & Ketentuan untuk mendaftar.');
            return;
        }

        btnRegister.disabled = true;
        btnRegister.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> Memproses...';
    });

    // Remove invalid state from terms checkbox when checked
    document.getElementById('terms').addEventListener('change', function () {
        if (this.checked) {
            this.classList.remove('is-invalid');
        }
    });

});
</script>
@endpush
