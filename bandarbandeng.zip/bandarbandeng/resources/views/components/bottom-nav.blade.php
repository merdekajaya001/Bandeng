@php
    $currentRoute = request()->route() ? request()->route()->getName() : '';
    $navItems = [
        [
            'label' => 'Home',
            'icon' => 'fa-home',
            'route' => 'home',
            'active' => $currentRoute === 'home',
        ],
        [
            'label' => 'Produk',
            'icon' => 'fa-fish',
            'route' => 'public.products',
            'active' => str_starts_with($currentRoute, 'public.product'),
        ],
        [
            'label' => 'Agen',
            'icon' => 'fa-users',
            'route' => 'public.agents',
            'active' => str_starts_with($currentRoute, 'public.agent') || str_starts_with($currentRoute, 'public.find'),
        ],
        [
            'label' => 'Pesanan',
            'icon' => 'fa-receipt',
            'route' => auth()->check() && auth()->user()->hasRole('customer') ? 'customer.orders.index' : 'login',
            'active' => str_starts_with($currentRoute, 'customer.orders') || str_starts_with($currentRoute, 'agent.orders') || str_starts_with($currentRoute, 'stockist.orders'),
        ],
        [
            'label' => 'Akun',
            'icon' => 'fa-user',
            'route' => auth()->check() ? 'profile.index' : 'login',
            'active' => str_starts_with($currentRoute, 'profile') || str_starts_with($currentRoute, 'wallet') || $currentRoute === 'login' || $currentRoute === 'register',
        ],
    ];
@endphp

<!-- Mobile Bottom Navigation - Only visible on small screens -->
<nav class="d-md-none fixed-bottom bg-white border-top shadow-lg"
     style="z-index: 1050; padding-bottom: env(safe-area-inset-bottom, 0px);"
     aria-label="Mobile navigation">

    <div class="d-flex justify-content-around align-items-center py-1">
        @foreach ($navItems as $item)
            <a href="{{ route($item['route']) }}"
               class="text-center text-decoration-none flex-fill py-1 px-1 {{ $item['active'] ? '' : '' }}"
               style="min-width: 60px;">

                @if ($item['active'])
                    <div class="d-flex flex-column align-items-center">
                        <div class="rounded-circle d-flex align-items-center justify-content-center mb-1"
                             style="width: 40px; height: 40px; background: linear-gradient(135deg, #0C4B8E, #1A6FB5);">
                            <i class="fas {{ $item['icon'] }} text-white" style="font-size: 1rem;"></i>
                        </div>
                        <span style="font-size: 0.65rem; font-weight: 700; color: #0C4B8E;">
                            {{ $item['label'] }}
                        </span>
                    </div>
                @else
                    <div class="d-flex flex-column align-items-center">
                        <div class="d-flex align-items-center justify-content-center mb-1"
                             style="width: 40px; height: 40px;">
                            <i class="fas {{ $item['icon'] }}" style="font-size: 1rem; color: #6c757d;"></i>
                        </div>
                        <span style="font-size: 0.65rem; color: #6c757d;">
                            {{ $item['label'] }}
                        </span>
                    </div>
                @endif
            </a>
        @endforeach
    </div>
</nav>

@push('styles')
<style>
    [data-bs-theme="dark"] nav.d-md-none.fixed-bottom {
        background: #1f2937 !important;
        border-color: #374151 !important;
    }

    [data-bs-theme="dark"] nav.d-md-none.fixed-bottom span {
        color: #9ca3af !important;
    }

    [data-bs-theme="dark"] nav.d-md-none.fixed-bottom a.active span {
        color: #F4D03F !important;
    }
</style>
@endpush
