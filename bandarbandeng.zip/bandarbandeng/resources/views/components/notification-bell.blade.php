@auth
@php
    $unreadCount = auth()->user()->notifications()->unread()->count();
    $recentNotifications = auth()->user()->notifications()->recent()->take(5)->get();
@endphp

<a class="btn btn-sm btn-outline-light border-0 position-relative dropdown-toggle"
   href="#" id="notificationDropdown" role="button"
   data-bs-toggle="dropdown" aria-expanded="false" title="Notifikasi">
    <i class="fas fa-bell"></i>
    @if($unreadCount > 0)
        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-badge">
            {{ $unreadCount > 99 ? '99+' : $unreadCount }}
        </span>
    @endif
</a>

<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationDropdown"
    style="width: 340px; max-height: 400px; overflow-y: auto;">

    <!-- Header -->
    <li class="dropdown-header d-flex justify-content-between align-items-center py-2">
        <span class="fw-bold">Notifikasi</span>
        @if($unreadCount > 0)
            <a href="#" class="text-decoration-none" style="font-size: 0.75rem;"
               onclick="markAllAsRead(event)">
                Tandai semua dibaca
            </a>
        @endif
    </li>
    <li><hr class="dropdown-divider my-0"></li>

    <!-- Notification Items -->
    @forelse($recentNotifications as $notification)
        <li>
            <a class="dropdown-item py-3 {{ is_null($notification->read_at) ? 'bg-light' : '' }}"
               href="{{ $notification->data['url'] ?? '#' }}"
               data-notification-id="{{ $notification->id }}">

                <div class="d-flex align-items-start">
                    <!-- Icon based on type -->
                    <div class="me-3 mt-1">
                        @if($notification->type === 'order')
                            <div class="rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 36px; height: 36px; background: rgba(12, 75, 142, 0.1);">
                                <i class="fas fa-receipt" style="color: #0C4B8E; font-size: 0.85rem;"></i>
                            </div>
                        @elseif($notification->type === 'payment')
                            <div class="rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 36px; height: 36px; background: rgba(212, 160, 23, 0.1);">
                                <i class="fas fa-credit-card" style="color: #D4A017; font-size: 0.85rem;"></i>
                            </div>
                        @elseif($notification->type === 'stock')
                            <div class="rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 36px; height: 36px; background: rgba(39, 174, 96, 0.1);">
                                <i class="fas fa-cubes" style="color: #27AE60; font-size: 0.85rem;"></i>
                            </div>
                        @elseif($notification->type === 'withdrawal')
                            <div class="rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 36px; height: 36px; background: rgba(231, 76, 60, 0.1);">
                                <i class="fas fa-money-bill-wave" style="color: #e74c3c; font-size: 0.85rem;"></i>
                            </div>
                        @else
                            <div class="rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 36px; height: 36px; background: rgba(26, 111, 181, 0.1);">
                                <i class="fas fa-info-circle" style="color: #1A6FB5; font-size: 0.85rem;"></i>
                            </div>
                        @endif
                    </div>

                    <!-- Content -->
                    <div class="flex-grow-1" style="min-width: 0;">
                        <div class="fw-semibold text-dark" style="font-size: 0.85rem; line-height: 1.3;">
                            {{ Str::limit($notification->title, 50) }}
                        </div>
                        <div class="text-muted" style="font-size: 0.78rem; line-height: 1.4;">
                            {{ Str::limit($notification->message, 80) }}
                        </div>
                        <div class="text-muted mt-1" style="font-size: 0.7rem;">
                            {{ $notification->created_at->diffForHumans() }}
                        </div>
                    </div>

                    <!-- Unread indicator -->
                    @if(is_null($notification->read_at))
                        <div class="ms-2">
                            <span class="rounded-circle bg-primary d-inline-block"
                                  style="width: 8px; height: 8px;"></span>
                        </div>
                    @endif
                </div>
            </a>
        </li>
    @empty
        <li class="dropdown-item text-center text-muted py-4">
            <i class="fas fa-bell-slash mb-2" style="font-size: 1.5rem; opacity: 0.3;"></i>
            <div style="font-size: 0.85rem;">Belum ada notifikasi</div>
        </li>
    @endforelse

    <!-- Footer -->
    @if($recentNotifications->count() > 0)
        <li><hr class="dropdown-divider my-0"></li>
        <li>
            <a class="dropdown-item text-center text-primary py-2 fw-semibold"
               href="#" style="font-size: 0.85rem;">
                Lihat Semua Notifikasi
            </a>
        </li>
    @endif
</ul>

@push('styles')
<style>
    [data-bs-theme="dark"] .dropdown-item.bg-light {
        background: rgba(59, 130, 246, 0.1) !important;
    }

    [data-bs-theme="dark"] .dropdown-item .fw-semibold.text-dark {
        color: #e5e7eb !important;
    }

    .dropdown-item:active .fw-semibold.text-dark,
    .dropdown-item:active .text-muted {
        color: #fff !important;
    }
</style>
@endpush

@push('scripts')
<script>
    function markAllAsRead(event) {
        event.preventDefault();

        fetch('{{ url("/notifications/mark-all-read") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
                    || document.querySelector('input[name="_token"]')?.value
            }
        }).then(function (response) {
            if (response.ok) {
                // Remove unread indicators
                document.querySelectorAll('.notification-badge').forEach(function (badge) {
                    badge.remove();
                });
                document.querySelectorAll('.dropdown-item.bg-light').forEach(function (item) {
                    item.classList.remove('bg-light');
                });
                // Remove unread dots
                document.querySelectorAll('.bg-primary.d-inline-block[style]').forEach(function (dot) {
                    if (dot.style.width === '8px') {
                        dot.remove();
                    }
                });
                // Hide "mark all read" link
                var markAllLink = event.target;
                if (markAllLink) {
                    markAllLink.style.display = 'none';
                }
            }
        }).catch(function (error) {
            console.error('Failed to mark notifications as read:', error);
        });
    }
</script>
@endpush

@endauth
