@php
    $currentMode = $themeMode ?? 'auto';
@endphp

<div class="dropdown">
    <button class="btn btn-sm btn-outline-light border-0 dropdown-toggle"
            type="button" id="themeDropdown" data-bs-toggle="dropdown"
            aria-expanded="false" title="Ubah tema">
        @if($currentMode === 'light')
            <i class="fas fa-sun"></i>
        @elseif($currentMode === 'dark')
            <i class="fas fa-moon"></i>
        @else
            <i class="fas fa-adjust"></i>
        @endif
    </button>

    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="themeDropdown" style="min-width: 160px;">
        <li>
            <button class="dropdown-item theme-option {{ $currentMode === 'auto' ? 'active' : '' }}"
                    data-theme="auto" onclick="setTheme('auto')">
                <i class="fas fa-adjust me-2 {{ $currentMode === 'auto' ? 'text-primary' : '' }}"></i>
                Otomatis
                @if($currentMode === 'auto')
                    <i class="fas fa-check ms-auto text-primary"></i>
                @endif
            </button>
        </li>
        <li>
            <button class="dropdown-item theme-option {{ $currentMode === 'light' ? 'active' : '' }}"
                    data-theme="light" onclick="setTheme('light')">
                <i class="fas fa-sun me-2 {{ $currentMode === 'light' ? 'text-warning' : '' }}"></i>
                Terang
                @if($currentMode === 'light')
                    <i class="fas fa-check ms-auto text-primary"></i>
                @endif
            </button>
        </li>
        <li>
            <button class="dropdown-item theme-option {{ $currentMode === 'dark' ? 'active' : '' }}"
                    data-theme="dark" onclick="setTheme('dark')">
                <i class="fas fa-moon me-2 {{ $currentMode === 'dark' ? 'text-info' : '' }}"></i>
                Gelap
                @if($currentMode === 'dark')
                    <i class="fas fa-check ms-auto text-primary"></i>
                @endif
            </button>
        </li>
    </ul>
</div>

@push('scripts')
<script>
    function setTheme(mode) {
        // Send AJAX request to persist theme in session
        fetch('{{ url("/theme") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content')
                    || document.querySelector('input[name="_token"]')?.value
            },
            body: JSON.stringify({ theme: mode })
        }).then(function (response) {
            if (response.ok) {
                // Reload page to apply the theme
                window.location.reload();
            }
        }).catch(function (error) {
            console.error('Failed to set theme:', error);
            // Fallback: just reload with query param
            window.location.href = '{{ url("/") }}?theme=' + mode;
        });
    }
</script>
@endpush
