@extends('layouts.customer')

@section('title', 'Ajukan Komplain - Bandar Bandeng Kalimantan')
@section('page_title', 'Ajukan Komplain')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('customer.orders.index') }}">Pesanan</a></li>
    <li class="breadcrumb-item active">Komplain</li>
@endsection

@section('customer_content')
<div class="row g-4 justify-content-center">
    <div class="col-lg-7">
        {{-- Order Summary --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">No. Pesanan</span>
                    <strong>{{ $order->order_number }}</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Agen</span>
                    <strong>{{ $order->seller->name ?? '-' }}</strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Total</span>
                    <strong style="color: var(--bbk-blue);">Rp {{ number_format($order->total, 0, ',', '.') }}</strong>
                </div>
            </div>
        </div>

        {{-- Complaint Form --}}
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-4" style="color: var(--bbk-blue);">
                    <i class="fas fa-flag me-2"></i>Formulir Komplain
                </h6>

                <form action="{{ route('customer.complaints.store', $order->id) }}" method="POST"
                      enctype="multipart/form-data">
                    @csrf

                    {{-- Complaint Type --}}
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Jenis Komplain</label>
                        <select name="type" class="form-select" required>
                            <option value="">-- Pilih Jenis --</option>
                            <option value="product_damage" {{ old('type') === 'product_damage' ? 'selected' : '' }}>
                                🐟 Produk Rusak / Tidak Sesuai
                            </option>
                            <option value="wrong_item" {{ old('type') === 'wrong_item' ? 'selected' : '' }}>
                                📦 Barang Salah / Kurang
                            </option>
                            <option value="late_delivery" {{ old('type') === 'late_delivery' ? 'selected' : '' }}>
                                🚚 Pengiriman Terlambat
                            </option>
                            <option value="other" {{ old('type') === 'other' ? 'selected' : '' }}>
                                ❓ Lainnya
                            </option>
                        </select>
                        @error('type')
                            <div class="text-danger small mt-1">{{ $message }}</div>
                        @enderror
                    </div>

                    {{-- Description --}}
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Deskripsi Komplain</label>
                        <textarea name="description" class="form-control" rows="5"
                                  placeholder="Jelaskan masalah yang Anda alami secara detail..."
                                  maxlength="1000" required>{{ old('description') }}</textarea>
                        <div class="text-end"><small class="text-muted"><span id="charCount">0</span>/1000</small></div>
                        @error('description')
                            <div class="text-danger small mt-1">{{ $message }}</div>
                        @enderror
                    </div>

                    {{-- Image Upload --}}
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Foto Pendukung <small class="text-muted">(maks. 3 foto)</small></label>
                        <div class="border rounded-3 p-3" id="imageDropZone"
                             style="border-style: dashed !important; cursor: pointer;"
                             onclick="document.getElementById('complaintImages').click()">
                            <div class="text-center" id="imagePlaceholder">
                                <i class="fas fa-camera fa-2x text-muted mb-2"></i>
                                <p class="text-muted small mb-0">Klik untuk upload foto bukti</p>
                                <small class="text-muted">JPG, PNG max 2MB per foto</small>
                            </div>
                            <div id="imagePreviewContainer" class="row g-2 d-none"></div>
                        </div>
                        <input type="file" name="images[]" id="complaintImages" class="d-none"
                               accept="image/jpeg,image/png,image/webp" multiple max="3">
                        @error('images')
                            <div class="text-danger small mt-1">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="alert alert-warning py-2 small mb-4">
                        <i class="fas fa-info-circle me-1"></i>
                        Komplain akan ditinjau oleh tim kami. Kami akan menghubungi Anda melalui WhatsApp untuk proses lebih lanjut.
                    </div>

                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-lg text-white fw-semibold"
                                style="background: linear-gradient(135deg, #e74c3c, #c0392b);">
                            <i class="fas fa-paper-plane me-2"></i>Kirim Komplain
                        </button>
                        <a href="{{ route('customer.orders.show', $order->id) }}"
                           class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i>Kembali ke Detail Pesanan
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Char counter
    document.querySelector('textarea[name="description"]').addEventListener('input', function() {
        document.getElementById('charCount').textContent = this.value.length;
    });

    // Image upload
    const imageInput = document.getElementById('complaintImages');
    const previewContainer = document.getElementById('imagePreviewContainer');
    const placeholder = document.getElementById('imagePlaceholder');
    let selectedFiles = [];

    imageInput.addEventListener('change', function() {
        Array.from(this.files).forEach(file => {
            if (selectedFiles.length >= 3) return;
            if (!file.type.match('image.*')) return;
            if (file.size > 2 * 1024 * 1024) { alert('File ' + file.name + ' terlalu besar (max 2MB)'); return; }
            selectedFiles.push(file);
        });
        renderPreviews();
    });

    function renderPreviews() {
        previewContainer.innerHTML = '';
        if (selectedFiles.length === 0) {
            placeholder.classList.remove('d-none');
            previewContainer.classList.add('d-none');
            return;
        }
        placeholder.classList.add('d-none');
        previewContainer.classList.remove('d-none');

        selectedFiles.forEach((file, idx) => {
            const reader = new FileReader();
            reader.onload = e => {
                const col = document.createElement('div');
                col.className = 'col-4';
                col.innerHTML = `
                    <div class="position-relative">
                        <img src="${e.target.result}" class="img-fluid rounded border" style="height:80px; object-fit:cover; width:100%;">
                        <button type="button" class="btn btn-sm btn-danger position-absolute top-0 end-0 rounded-circle p-0"
                                style="width:22px;height:22px;font-size:10px;line-height:22px;"
                                onclick="removeImage(${idx})">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>`;
                previewContainer.appendChild(col);
            };
            reader.readAsDataURL(file);
        });
    }

    function removeImage(idx) {
        selectedFiles.splice(idx, 1);
        const dt = new DataTransfer();
        selectedFiles.forEach(f => dt.items.add(f));
        imageInput.files = dt.files;
        renderPreviews();
    }
</script>
@endpush
