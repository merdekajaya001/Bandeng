@extends('layouts.customer')

@section('title', 'Dashboard Pelanggan - Bandar Bandeng Kalimantan')

@section('page_title', 'Dashboard')

@push('styles')
<style>
    .welcome-card {
        border: none;
        border-radius: 16px;
        background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 60%, #2980B9 100%);
        color: white;
        overflow: hidden;
        position: relative;
    }
    .welcome-card::after {
        content: '';
        position: absolute;
        top: -30px;
        right: -30px;
        width: 180px;
        height: 180px;
        border-radius: 50%;
        background: rgba(255,255,255,0.06);
    }
    .welcome-card::before {
        content: '';
        position: absolute;
        bottom: -50px;
        right: 60px;
        width: 120px;
        height: 120px;
        border-radius: 50%;
        background: rgba(212,160,23,0.12);
    }
    .stat-card {
        border: none;
        border-radius: 12px;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    .stat-card .stat-icon {
        width: 52px;
        height: 52px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.3rem;
    }
    .stat-card .stat-number {
        font-size: 1.5rem;
        font-weight: 800;
        line-height: 1.2;
    }
    .stat-card .stat-label {
        font-size: 0.8rem;
        color: #6c757d;
        font-weight: 500;
    }
    .agent-card {
        border: none;
        border-radius: 12px;
        border-left: 4px solid #D4A017;
    }
    .order-item {
        border: none;
        border-radius: 12px;
        transition: box-shadow 0.2s;
    }
    .order-item:hover {
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }
    .status-badge {
        font-size: 0.72rem;
        font-weight: 600;
        padding: 0.3em 0.7em;
        border-radius: 50px;
    }
    .quick-action-btn {
        border-radius: 12px;
        padding: 1.5rem;
        text-align: center;
        transition: all 0.2s;
        text-decoration: none;
        display: block;
    }
    .quick-action-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        color: white;
    }
    .wa-btn {
        background: #25D366;
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.4rem 1rem;
        font-size: 0.85rem;
        font-weight: 600;
        transition: all 0.2s;
    }
    .wa-btn:hover {
        background: #1DA851;
        color: white;
    }
</style>
@endpush

@section('customer_content')

{{-- Flash Messages --}}
@include('partials.flash-messages')

{{-- Welcome Card --}}
<div class="card welcome-card shadow-sm mb-4">
    <div class="card-body p-4 position-relative">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h4 class="fw-bold mb-1">Selamat Datang, {{ auth()->user()->name }}! 👋</h4>
                <p class="mb-2 opacity-85">Temukan bandeng segar terbaik dari Kalimantan. Pesan langsung dari agen terdekat Anda.</p>
                <a href="{{ route('customer.orders.create') }}" class="btn btn-sm px-4 py-2 fw-semibold" style="background: #D4A017; color: #333; border: none; border-radius: 8px;">
                    <i class="fas fa-cart-plus me-1"></i> Buat Pesanan Baru
                </a>
            </div>
            <div class="col-md-4 text-end d-none d-md-block position-relative" style="z-index:1;">
                <i class="fas fa-fish" style="font-size: 4rem; opacity: 0.2;"></i>
            </div>
        </div>
    </div>
</div>

{{-- Stat Cards --}}
<div class="row g-3 mb-4">
    {{-- Total Pesanan --}}
    <div class="col-md-4">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(12,75,142,0.12); color: #0C4B8E;">
                    <i class="fas fa-receipt"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #0C4B8E;">
                        {{ $stats['total_orders'] ?? 0 }}
                    </div>
                    <div class="stat-label">Total Pesanan</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Pesanan Aktif --}}
    <div class="col-md-4">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                    <i class="fas fa-spinner"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #D4A017;">
                        {{ $stats['active_orders'] ?? 0 }}
                    </div>
                    <div class="stat-label">Pesanan Aktif</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Saldo Dompet --}}
    <div class="col-md-4">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(39,174,96,0.12); color: #27AE60;">
                    <i class="fas fa-wallet"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #27AE60; font-size: 1.25rem;">
                        Rp {{ number_format($stats['wallet_balance'] ?? 0, 0, ',', '.') }}
                    </div>
                    <div class="stat-label">Saldo Dompet</div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    {{-- Nearest Agent --}}
    <div class="col-lg-5">
        <div class="card agent-card shadow-sm">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-map-marker-alt me-2" style="color: #D4A017;"></i>Agen Terdekat
                </h6>
            </div>
            <div class="card-body">
                @if($nearestAgent ?? null)
                <div class="d-flex align-items-start mb-3">
                    <div class="rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0"
                         style="width: 50px; height: 50px; background: rgba(12,75,142,0.1);">
                        <i class="fas fa-user-tie" style="color: #0C4B8E; font-size: 1.2rem;"></i>
                    </div>
                    <div>
                        <div class="fw-bold" style="color: #0C4B8E;">{{ $nearestAgent->name }}</div>
                        <div class="text-muted small">
                            <i class="fas fa-city me-1"></i>{{ $nearestAgent->city ?? '-' }}
                        </div>
                        <div class="text-muted small">
                            <i class="fas fa-route me-1"></i>Jarak: ~{{ $nearestAgent->distance ?? '-' }} km
                        </div>
                    </div>
                </div>
                @if($nearestAgent->phone ?? null)
                <a href="https://wa.me/{{ preg_replace('/[^0-9]/', '', $nearestAgent->phone) }}?text=Halo%2C%20saya%20ingin%20memesan%20bandeng"
                   target="_blank" class="wa-btn w-100 text-center">
                    <i class="fab fa-whatsapp me-2"></i>Hubungi via WhatsApp
                </a>
                @else
                <button class="btn btn-outline-secondary w-100" disabled>
                    <i class="fas fa-phone me-1"></i> Nomor tidak tersedia
                </button>
                @endif
                @else
                <div class="text-center py-4 text-muted">
                    <i class="fas fa-map-marked-alt fa-2x mb-2 d-block opacity-50"></i>
                    <p class="mb-1">Belum ada agen terdekat ditemukan</p>
                    <small>Lengkapi profil Anda untuk menemukan agen di area Anda</small>
                </div>
                @endif
            </div>
        </div>

        {{-- Quick Action --}}
        <div class="mt-3">
            <a href="{{ route('customer.orders.create') }}" class="quick-action-btn card shadow-sm"
               style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); color: white;">
                <i class="fas fa-cart-plus fa-2x mb-2"></i>
                <div class="fw-bold">Buat Pesanan Baru</div>
                <small style="opacity: 0.85;">Pesan bandeng segar langsung dari agen</small>
            </a>
        </div>
    </div>

    {{-- Recent Orders --}}
    <div class="col-lg-7">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #D4A017;">
                    <i class="fas fa-receipt me-2"></i>Pesanan Terbaru
                </h6>
                <a href="{{ route('customer.orders.index') }}" class="btn btn-sm btn-outline-primary" style="border-radius: 8px;">
                    Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="card-body">
                @forelse($recentOrders ?? [] as $order)
                @php
                    $statusConfig = [
                        'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Menunggu'],
                        'confirmed'  => ['color' => 'info', 'icon' => 'check', 'label' => 'Dikonfirmasi'],
                        'processing' => ['color' => 'primary', 'icon' => 'cog', 'label' => 'Diproses'],
                        'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                        'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                        'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                        'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                    ];
                    $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
                @endphp
                <div class="card order-item shadow-sm mb-2">
                    <div class="card-body p-3">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <a href="{{ route('customer.orders.show', $order->id) }}" class="fw-bold text-decoration-none" style="color: #0C4B8E;">
                                    #{{ $order->order_number ?? $order->id }}
                                </a>
                                <div class="text-muted small mt-1">
                                    <i class="far fa-calendar me-1"></i>{{ $order->created_at ? $order->created_at->format('d M Y, H:i') : '-' }}
                                </div>
                            </div>
                            <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                                <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                            </span>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="small text-muted">
                                {{ $order->items->count() ?? 0 }} item
                            </div>
                            <div class="fw-bold" style="color: #0C4B8E;">
                                Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}
                            </div>
                        </div>
                    </div>
                </div>
                @empty
                <div class="text-center py-5 text-muted">
                    <i class="fas fa-inbox fa-3x mb-3 d-block opacity-40"></i>
                    <p class="mb-1">Belum ada pesanan</p>
                    <a href="{{ route('customer.orders.create') }}" class="btn btn-sm mt-2 fw-semibold" style="background: #D4A017; color: #333; border-radius: 8px;">
                        <i class="fas fa-cart-plus me-1"></i> Buat Pesanan Pertama
                    </a>
                </div>
                @endforelse
            </div>
        </div>
    </div>
</div>

@endsection
