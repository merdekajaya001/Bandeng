@extends('layouts.customer')

@section('title', 'Buat Pesanan - Bandar Bandeng Kalimantan')

@section('page_title', 'Buat Pesanan Baru')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('customer.orders.index') }}">Pesanan Saya</a></li>
    <li class="breadcrumb-item active" aria-current="page">Buat Pesanan</li>
@endsection

@push('styles')
<style>
    .agent-info-card {
        border: none;
        border-radius: 12px;
        border-left: 4px solid #D4A017;
    }
    .variant-card {
        border: 2px solid #e9ecef;
        border-radius: 12px;
        transition: all 0.2s;
        cursor: pointer;
    }
    .variant-card:hover {
        border-color: #0C4B8E;
        box-shadow: 0 2px 10px rgba(12,75,142,0.1);
    }
    .variant-card.selected {
        border-color: #0C4B8E;
        background: rgba(12,75,142,0.04);
    }
    .variant-card .variant-img {
        width: 100%;
        height: 120px;
        object-fit: cover;
        border-radius: 8px;
    }
    .qty-control {
        display: inline-flex;
        align-items: center;
        border: 2px solid #dee2e6;
        border-radius: 8px;
        overflow: hidden;
    }
    .qty-control button {
        width: 36px;
        height: 36px;
        border: none;
        background: transparent;
        font-size: 1rem;
        font-weight: 700;
        color: #0C4B8E;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.15s;
    }
    .qty-control button:hover {
        background: rgba(12,75,142,0.1);
    }
    .qty-control input {
        width: 48px;
        height: 36px;
        text-align: center;
        border: none;
        border-left: 1px solid #dee2e6;
        border-right: 1px solid #dee2e6;
        font-weight: 700;
        font-size: 0.9rem;
        color: #0C4B8E;
        outline: none;
    }
    .qty-control input::-webkit-inner-spin-button,
    .qty-control input::-webkit-outer-spin-button {
        -webkit-appearance: none;
    }
    .summary-card {
        border: none;
        border-radius: 12px;
        position: sticky;
        top: 20px;
    }
    .payment-tab {
        border: 2px solid #dee2e6;
        border-radius: 10px;
        padding: 0.75rem 1rem;
        cursor: pointer;
        transition: all 0.2s;
        text-align: center;
    }
    .payment-tab:hover {
        border-color: #0C4B8E;
    }
    .payment-tab.active {
        border-color: #0C4B8E;
        background: rgba(12,75,142,0.06);
    }
    .payment-tab input[type="radio"] {
        display: none;
    }
    .summary-item-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.5rem 0;
    }
    .summary-item-row:not(:last-child) {
        border-bottom: 1px dashed #eee;
    }
</style>
@endpush

@section('customer_content')

@include('partials.flash-messages')

<form action="{{ route('customer.orders.store') }}" method="POST" id="orderForm">
@csrf

<div class="row g-4">
    {{-- Left Column: Products & Details --}}
    <div class="col-lg-8">

        {{-- Nearest Agent Info --}}
        @if($nearestAgent ?? null)
        <div class="card agent-info-card shadow-sm mb-4">
            <div class="card-body p-3">
                <div class="d-flex align-items-center">
                    <div class="rounded-circle d-flex align-items-center justify-content-center me-3 flex-shrink-0"
                         style="width: 44px; height: 44px; background: rgba(12,75,142,0.1);">
                        <i class="fas fa-user-tie" style="color: #0C4B8E;"></i>
                    </div>
                    <div class="flex-grow-1">
                        <div class="fw-bold small" style="color: #0C4B8E;">Agen Terdekat (Terpilih Otomatis)</div>
                        <div class="text-muted small">
                            {{ $nearestAgent->name }} — {{ $nearestAgent->city ?? '-' }} (~{{ $nearestAgent->distance ?? '-' }} km)
                        </div>
                    </div>
                    <input type="hidden" name="agent_id" value="{{ $nearestAgent->id }}">
                    <i class="fas fa-check-circle" style="color: #27AE60;"></i>
                </div>
            </div>
        </div>
        @else
        <div class="alert alert-warning rounded-3 mb-4">
            <i class="fas fa-exclamation-triangle me-2"></i>
            <strong>Agen tidak ditemukan.</strong> Lengkapi alamat profil Anda agar sistem dapat menemukan agen terdekat.
        </div>
        @endif

        {{-- Product Variants --}}
        <div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-box me-2"></i>Pilih Produk & Jumlah
                </h6>
            </div>
            <div class="card-body">
                @if($errors->has('items'))
                    <div class="alert alert-danger small rounded-3">
                        <i class="fas fa-exclamation-circle me-1"></i>{{ $errors->first('items') }}
                    </div>
                @endif

                <div class="row g-3">
                    @forelse($variants ?? [] as $variant)
                    <div class="col-md-6">
                        <div class="variant-card p-3" id="variant-{{ $variant->id }}">
                            <div class="d-flex align-items-start">
                                <div class="flex-shrink-0 me-3">
                                    @if($variant->image ?? null)
                                    <img src="{{ asset('storage/' . $variant->image) }}" alt="{{ $variant->name }}" class="variant-img">
                                    @elseif($variant->product->image ?? null)
                                    <img src="{{ asset('storage/' . $variant->product->image) }}" alt="{{ $variant->name }}" class="variant-img">
                                    @else
                                    <div class="variant-img d-flex align-items-center justify-content-center" style="background: rgba(12,75,142,0.06);">
                                        <i class="fas fa-fish fa-2x" style="color: #0C4B8E; opacity: 0.3;"></i>
                                    </div>
                                    @endif
                                </div>
                                <div class="flex-grow-1">
                                    <div class="fw-bold small" style="color: #0C4B8E;">{{ $variant->product->name ?? 'Produk' }}</div>
                                    <div class="text-muted" style="font-size: 0.82rem;">{{ $variant->name }}</div>
                                    <div class="fw-bold mt-1" style="color: #D4A017; font-size: 0.95rem;">
                                        Rp {{ number_format($variant->price ?? 0, 0, ',', '.') }}
                                    </div>
                                    @if($variant->stock !== null)
                                    <div class="small text-muted">Stok: {{ $variant->stock }}</div>
                                    @endif
                                </div>
                            </div>
                            <div class="mt-3 d-flex justify-content-between align-items-center">
                                <label class="form-check-label small text-muted">Jumlah:</label>
                                <div class="qty-control">
                                    <button type="button" onclick="changeQty({{ $variant->id }}, -1)">
                                        <i class="fas fa-minus" style="font-size: 0.7rem;"></i>
                                    </button>
                                    <input type="number" name="items[{{ $variant->id }}][quantity]"
                                           id="qty-{{ $variant->id }}"
                                           value="0" min="0"
                                           max="{{ $variant->stock ?? 999 }}"
                                           data-price="{{ $variant->price ?? 0 }}"
                                           onchange="updateSummary()">
                                    <button type="button" onclick="changeQty({{ $variant->id }}, 1)">
                                        <i class="fas fa-plus" style="font-size: 0.7rem;"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="col-12">
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-box-open fa-2x mb-2 d-block opacity-40"></i>
                            Tidak ada varian produk tersedia saat ini.
                        </div>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>

        {{-- Shipping Address --}}
        <div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-map-marker-alt me-2"></i>Alamat Pengiriman
                </h6>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label small fw-semibold">Alamat Lengkap <span class="text-danger">*</span></label>
                        <textarea name="shipping_address" class="form-control @error('shipping_address') is-invalid @enderror"
                                  rows="3" placeholder="Masukkan alamat lengkap pengiriman">{{ old('shipping_address', auth()->user()->address ?? '') }}</textarea>
                        @error('shipping_address')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Kota <span class="text-danger">*</span></label>
                        <input type="text" name="shipping_city" class="form-control @error('shipping_city') is-invalid @enderror"
                               value="{{ old('shipping_city', auth()->user()->city ?? '') }}" placeholder="Kota">
                        @error('shipping_city')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Provinsi</label>
                        <input type="text" name="shipping_province" class="form-control @error('shipping_province') is-invalid @enderror"
                               value="{{ old('shipping_province', auth()->user()->province ?? '') }}" placeholder="Provinsi">
                        @error('shipping_province')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Kode Pos</label>
                        <input type="text" name="shipping_postal_code" class="form-control @error('shipping_postal_code') is-invalid @enderror"
                               value="{{ old('shipping_postal_code', auth()->user()->postal_code ?? '') }}" placeholder="Kode Pos">
                        @error('shipping_postal_code')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">No. Telepon</label>
                        <input type="text" name="shipping_phone" class="form-control @error('shipping_phone') is-invalid @enderror"
                               value="{{ old('shipping_phone', auth()->user()->phone ?? '') }}" placeholder="Nomor telepon">
                        @error('shipping_phone')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
            </div>
        </div>

        {{-- Payment Method --}}
        <div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-credit-card me-2"></i>Metode Pembayaran
                </h6>
            </div>
            <div class="card-body">
                @if($errors->has('payment_method'))
                    <div class="alert alert-danger small rounded-3 mb-3">
                        <i class="fas fa-exclamation-circle me-1"></i>{{ $errors->first('payment_method') }}
                    </div>
                @endif

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="payment-tab w-100 {{ old('payment_method') === 'deposit' ? 'active' : '' }}"
                               id="label-deposit" onclick="selectPayment('deposit')">
                            <input type="radio" name="payment_method" value="deposit"
                                   {{ old('payment_method') === 'deposit' ? 'checked' : '' }}>
                            <div>
                                <i class="fas fa-wallet fa-lg me-2" style="color: #27AE60;"></i>
                                <span class="fw-semibold">Deposit / Saldo</span>
                                <div class="small text-muted mt-1">Bayar dari saldo dompet Anda</div>
                                <div class="small mt-1">
                                    Saldo: <strong style="color: #27AE60;">Rp {{ number_format(auth()->user()->wallet->balance ?? 0, 0, ',', '.') }}</strong>
                                </div>
                            </div>
                        </label>
                    </div>
                    <div class="col-md-6">
                        <label class="payment-tab w-100 {{ old('payment_method') === 'transfer' || !old('payment_method') ? 'active' : '' }}"
                               id="label-transfer" onclick="selectPayment('transfer')">
                            <input type="radio" name="payment_method" value="transfer"
                                   {{ old('payment_method') === 'transfer' || !old('payment_method') ? 'checked' : '' }}>
                            <div>
                                <i class="fas fa-university fa-lg me-2" style="color: #0C4B8E;"></i>
                                <span class="fw-semibold">Transfer Bank</span>
                                <div class="small text-muted mt-1">Transfer ke rekening resmi BBK</div>
                            </div>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        {{-- Notes --}}
        <div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-sticky-note me-2"></i>Catatan Pesanan
                </h6>
            </div>
            <div class="card-body">
                <textarea name="notes" class="form-control @error('notes') is-invalid @enderror"
                          rows="3" placeholder="Catatan tambahan (opsional), misal: jam pengiriman yang diinginkan">{{ old('notes') }}</textarea>
                @error('notes')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
        </div>
    </div>

    {{-- Right Column: Order Summary --}}
    <div class="col-lg-4">
        <div class="card summary-card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0">
                <h6 class="fw-bold mb-0" style="color: #D4A017;">
                    <i class="fas fa-receipt me-2"></i>Ringkasan Pesanan
                </h6>
            </div>
            <div class="card-body" id="orderSummary">
                {{-- Dynamic items will be rendered here --}}
                <div id="summaryEmpty" class="text-center py-4 text-muted">
                    <i class="fas fa-shopping-cart fa-2x mb-2 d-block opacity-40"></i>
                    <small>Belum ada produk dipilih</small>
                </div>

                <div id="summaryItems" style="display: none;"></div>

                <hr class="my-3">

                <div class="summary-item-row">
                    <span class="text-muted small">Subtotal</span>
                    <span class="fw-semibold" id="summarySubtotal">Rp 0</span>
                </div>
                <div class="summary-item-row">
                    <span class="text-muted small">Ongkir</span>
                    <span class="fw-semibold" id="summaryOngkir">
                        @if($ongkir ?? null)
                            Rp {{ number_format($ongkir, 0, ',', '.') }}
                        @else
                            Akan dihitung
                        @endif
                    </span>
                </div>
                <hr class="my-2">
                <div class="summary-item-row">
                    <span class="fw-bold" style="color: #0C4B8E;">Total</span>
                    <span class="fw-bold fs-5" style="color: #0C4B8E;" id="summaryTotal">Rp 0</span>
                </div>
            </div>

            <div class="card-footer bg-white border-0 p-3">
                <button type="submit" class="btn w-100 fw-bold py-2" id="submitOrder"
                        style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); color: white; border-radius: 10px;">
                    <i class="fas fa-paper-plane me-2"></i>Kirim Pesanan
                </button>
                <div class="text-center mt-2">
                    <small class="text-muted">Dengan mengirim, Anda menyetujui syarat & ketentuan</small>
                </div>
            </div>
        </div>
    </div>
</div>

</form>

@endpush

@push('scripts')
<script>
    function changeQty(variantId, delta) {
        const input = document.getElementById('qty-' + variantId);
        let val = parseInt(input.value) || 0;
        val += delta;
        const max = parseInt(input.getAttribute('max')) || 999;
        if (val < 0) val = 0;
        if (val > max) val = max;
        input.value = val;

        const card = document.getElementById('variant-' + variantId);
        if (val > 0) {
            card.classList.add('selected');
        } else {
            card.classList.remove('selected');
        }

        updateSummary();
    }

    function updateSummary() {
        const qtyInputs = document.querySelectorAll('[id^="qty-"]');
        let subtotal = 0;
        let itemsHtml = '';
        let hasItems = false;

        qtyInputs.forEach(function(input) {
            const qty = parseInt(input.value) || 0;
            if (qty > 0) {
                hasItems = true;
                const price = parseFloat(input.getAttribute('data-price')) || 0;
                const lineTotal = qty * price;
                subtotal += lineTotal;

                const variantId = input.id.replace('qty-', '');
                const card = document.getElementById('variant-' + variantId);
                const nameEl = card.querySelector('.fw-bold.small');
                const variantEl = card.querySelector('.text-muted');
                const name = nameEl ? nameEl.textContent.trim() : 'Produk';
                const variant = variantEl ? variantEl.textContent.trim() : '';

                itemsHtml += `
                    <div class="summary-item-row">
                        <div>
                            <div class="small fw-semibold" style="color: #0C4B8E;">${name}</div>
                            <div class="small text-muted">${variant} x${qty}</div>
                        </div>
                        <div class="small fw-semibold">Rp ${lineTotal.toLocaleString('id-ID')}</div>
                    </div>
                `;
            }
        });

        document.getElementById('summaryItems').innerHTML = itemsHtml;
        document.getElementById('summaryEmpty').style.display = hasItems ? 'none' : 'block';
        document.getElementById('summaryItems').style.display = hasItems ? 'block' : 'none';

        document.getElementById('summarySubtotal').textContent = 'Rp ' + subtotal.toLocaleString('id-ID');

        const ongkirText = document.getElementById('summaryOngkir').textContent.trim();
        let ongkir = 0;
        const ongkirMatch = ongkirText.match(/[\d.,]+/);
        if (ongkirMatch && ongkirText !== 'Akan dihitung') {
            ongkir = parseFloat(ongkirMatch[0].replace(/\./g, '').replace(',', '.'));
        }

        const total = subtotal + ongkir;
        document.getElementById('summaryTotal').textContent = 'Rp ' + total.toLocaleString('id-ID');

        const submitBtn = document.getElementById('submitOrder');
        submitBtn.disabled = !hasItems;
        if (!hasItems) {
            submitBtn.style.opacity = '0.6';
        } else {
            submitBtn.style.opacity = '1';
        }
    }

    function selectPayment(method) {
        document.getElementById('label-deposit').classList.remove('active');
        document.getElementById('label-transfer').classList.remove('active');
        document.getElementById('label-' + method).classList.add('active');
    }

    // Initialize summary on page load
    document.addEventListener('DOMContentLoaded', function() {
        updateSummary();

        // Also update on direct input change
        document.querySelectorAll('[id^="qty-"]').forEach(function(input) {
            input.addEventListener('input', function() {
                const variantId = this.id.replace('qty-', '');
                const card = document.getElementById('variant-' + variantId);
                const val = parseInt(this.value) || 0;
                if (val > 0) {
                    card.classList.add('selected');
                } else {
                    card.classList.remove('selected');
                }
                updateSummary();
            });
        });

        // Form validation
        document.getElementById('orderForm').addEventListener('submit', function(e) {
            const qtyInputs = document.querySelectorAll('[id^="qty-"]');
            let hasItems = false;
            qtyInputs.forEach(function(input) {
                if (parseInt(input.value) > 0) hasItems = true;
            });
            if (!hasItems) {
                e.preventDefault();
                alert('Silakan pilih minimal 1 produk dan jumlahnya.');
            }
        });
    });
</script>
@endpush
