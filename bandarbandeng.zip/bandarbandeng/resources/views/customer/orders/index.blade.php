@extends('layouts.customer')

@section('title', 'Pesanan Saya - Bandar Bandeng Kalimantan')

@section('page_title', 'Pesanan Saya')

@section('page_actions')
    <a href="{{ route('customer.orders.create') }}" class="btn btn-sm fw-semibold" style="background: #D4A017; color: #333; border-radius: 8px;">
        <i class="fas fa-plus me-1"></i> Buat Pesanan
    </a>
@endsection

@push('styles')
<style>
    .filter-tabs {
        display: flex;
        overflow-x: auto;
        gap: 0.5rem;
        padding-bottom: 0.5rem;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
    }
    .filter-tabs::-webkit-scrollbar {
        display: none;
    }
    .filter-tab {
        white-space: nowrap;
        padding: 0.5rem 1rem;
        border-radius: 50px;
        font-size: 0.82rem;
        font-weight: 600;
        border: 2px solid #dee2e6;
        background: white;
        color: #6c757d;
        text-decoration: none;
        transition: all 0.2s;
        cursor: pointer;
    }
    .filter-tab:hover {
        border-color: #0C4B8E;
        color: #0C4B8E;
    }
    .filter-tab.active {
        background: #0C4B8E;
        border-color: #0C4B8E;
        color: white;
    }
    .order-card {
        border: none;
        border-radius: 12px;
        transition: box-shadow 0.2s;
    }
    .order-card:hover {
        box-shadow: 0 4px 15px rgba(0,0,0,0.08);
    }
    .status-badge {
        font-size: 0.72rem;
        font-weight: 600;
        padding: 0.3em 0.7em;
        border-radius: 50px;
    }
    .item-tag {
        display: inline-block;
        background: rgba(12,75,142,0.06);
        color: #0C4B8E;
        border-radius: 6px;
        padding: 0.2em 0.6em;
        font-size: 0.78rem;
        margin: 0.15rem;
    }
</style>
@endpush

@section('customer_content')

{{-- Flash Messages --}}
@include('partials.flash-messages')

{{-- Filter Tabs --}}
<div class="filter-tabs mb-4">
    @php
        $currentFilter = request('status', 'all');
        $tabs = [
            'all'       => ['label' => 'Semua', 'icon' => 'list'],
            'pending'   => ['label' => 'Menunggu', 'icon' => 'clock'],
            'confirmed' => ['label' => 'Dikonfirmasi', 'icon' => 'check'],
            'processing'=> ['label' => 'Diproses', 'icon' => 'cog'],
            'shipped'   => ['label' => 'Dikirim', 'icon' => 'truck'],
            'delivered' => ['label' => 'Selesai', 'icon' => 'check-double'],
            'cancelled' => ['label' => 'Dibatalkan', 'icon' => 'times-circle'],
        ];
    @endphp

    @foreach($tabs as $key => $tab)
        <a href="{{ route('customer.orders.index') }}{{ $key !== 'all' ? '?status='.$key : '' }}"
           class="filter-tab {{ $currentFilter === $key ? 'active' : '' }}">
            <i class="fas fa-{{ $tab['icon'] }} me-1"></i>{{ $tab['label'] }}
        </a>
    @endforeach
</div>

{{-- Order Cards --}}
@forelse($orders ?? [] as $order)
@php
    $statusConfig = [
        'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Menunggu Pembayaran'],
        'confirmed'  => ['color' => 'info', 'icon' => 'check', 'label' => 'Dikonfirmasi'],
        'processing' => ['color' => 'primary', 'icon' => 'cog', 'label' => 'Sedang Diproses'],
        'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dalam Pengiriman'],
        'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
        'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
        'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
    ];
    $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
@endphp
<div class="card order-card shadow-sm mb-3">
    <div class="card-body p-3 p-md-4">
        {{-- Header: Order number, date, status --}}
        <div class="d-flex justify-content-between align-items-start mb-3">
            <div>
                <a href="{{ route('customer.orders.show', $order->id) }}" class="fw-bold text-decoration-none" style="color: #0C4B8E; font-size: 1.05rem;">
                    #{{ $order->order_number ?? $order->id }}
                </a>
                <div class="text-muted small mt-1">
                    <i class="far fa-calendar me-1"></i>{{ $order->created_at ? $order->created_at->format('d M Y, H:i') : '-' }}
                </div>
            </div>
            <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
            </span>
        </div>

        {{-- Items summary --}}
        <div class="mb-3">
            @foreach($order->items ?? [] as $item)
                <span class="item-tag">
                    {{ $item->variant->name ?? $item->product_name ?? 'Produk' }} x{{ $item->quantity ?? 0 }}
                </span>
            @endforeach
            @if(($order->items ?? collect())->count() > 3)
                <span class="item-tag" style="background: rgba(212,160,23,0.1); color: #D4A017;">
                    +{{ $order->items->count() - 3 }} lainnya
                </span>
            @endif
        </div>

        {{-- Total + Action --}}
        <div class="d-flex justify-content-between align-items-center pt-2" style="border-top: 1px solid #f0f0f0;">
            <div>
                <span class="text-muted small">Total</span>
                <div class="fw-bold" style="color: #0C4B8E;">
                    Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}
                </div>
            </div>
            <div class="d-flex gap-2">
                @if($order->status === 'pending')
                    <a href="{{ route('customer.payments.show', $order->id) }}"
                       class="btn btn-sm fw-semibold" style="background: #D4A017; color: #333; border-radius: 8px;">
                        <i class="fas fa-credit-card me-1"></i> Bayar
                    </a>
                    <form action="{{ route('customer.orders.cancel', $order->id) }}" method="POST"
                          onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?')">
                        @csrf
                        <button type="submit" class="btn btn-sm btn-outline-danger" style="border-radius: 8px;">
                            <i class="fas fa-times me-1"></i> Batalkan
                        </button>
                    </form>
                @elseif($order->status === 'shipped')
                    <span class="text-muted small align-self-center">
                        <i class="fas fa-truck me-1"></i>Sedang dikirim
                    </span>
                @elseif($order->status === 'delivered' || $order->status === 'completed')
                    @if(!($order->rating ?? null))
                    <a href="{{ route('customer.ratings.create', $order->id) }}"
                       class="btn btn-sm btn-outline-warning fw-semibold" style="border-radius: 8px;">
                        <i class="fas fa-star me-1"></i> Beri Rating
                    </a>
                    @endif
                @endif

                <a href="{{ route('customer.orders.show', $order->id) }}"
                   class="btn btn-sm btn-outline-primary" style="border-radius: 8px;">
                    <i class="fas fa-eye me-1"></i> Detail
                </a>
            </div>
        </div>
    </div>
</div>
@empty
<div class="text-center py-5">
    <i class="fas fa-inbox fa-3x mb-3 d-block opacity-40" style="color: #0C4B8E;"></i>
    <h6 class="fw-bold mb-1" style="color: #0C4B8E;">Belum Ada Pesanan</h6>
    <p class="text-muted mb-3">Anda belum memiliki pesanan{{ $currentFilter !== 'all' ? ' dengan status ini' : '' }}.</p>
    <a href="{{ route('customer.orders.create') }}" class="btn fw-semibold" style="background: #D4A017; color: #333; border-radius: 8px;">
        <i class="fas fa-cart-plus me-1"></i> Buat Pesanan Baru
    </a>
</div>
@endforelse

{{-- Pagination --}}
@if(method_exists($orders ?? collect(), 'links'))
<div class="mt-4">
    {{ $orders->withQueryString()->links() }}
</div>
@endif

@endsection
