@extends('layouts.customer')

@section('title', 'Detail Pesanan - Bandar Bandeng Kalimantan')
@section('page_title', 'Detail Pesanan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('customer.orders.index') }}">Pesanan Saya</a></li>
    <li class="breadcrumb-item active">{{ $order->order_number }}</li>
@endsection

@section('customer_content')
<div class="row g-4">
    {{-- Order Status Timeline --}}
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-3" style="color: var(--bbk-blue);">
                    <i class="fas fa-route me-2"></i>Status Pesanan
                </h6>
                <div class="d-flex justify-content-between position-relative" style="overflow-x: auto;">
                    {{-- Connecting Line --}}
                    <div class="position-absolute" style="top: 20px; left: 10%; right: 10%; height: 3px; background: #e0e0e0; z-index: 0;"></div>
                    @php
                        $statuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered'];
                        $statusLabels = [
                            'pending' => 'Menunggu',
                            'confirmed' => 'Dikonfirmasi',
                            'processing' => 'Diproses',
                            'shipped' => 'Dikirim',
                            'delivered' => 'Diterima',
                            'completed' => 'Selesai',
                            'cancelled' => 'Dibatalkan',
                        ];
                        $statusIcons = [
                            'pending' => 'fa-clock',
                            'confirmed' => 'fa-check-circle',
                            'processing' => 'fa-cog',
                            'shipped' => 'fa-truck',
                            'delivered' => 'fa-box-open',
                        ];
                        $currentIdx = array_search($order->status, $statuses);
                        if ($currentIdx === false) $currentIdx = -1;
                    @endphp

                    @foreach($statuses as $i => $st)
                        <div class="text-center position-relative" style="z-index: 1; min-width: 70px;">
                            <div class="rounded-circle d-flex align-items-center justify-content-center mx-auto mb-2 {{
                                $i <= $currentIdx ? 'bg-success' : 'bg-light border'
                            }}" style="width: 40px; height: 40px; {{
                                $i <= $currentIdx ? 'color: #fff;' : 'color: #aaa;'
                            }}">
                                <i class="fas {{ $statusIcons[$st] ?? 'fa-circle' }} fs-6"></i>
                            </div>
                            <small class="{{ $i <= $currentIdx ? 'fw-bold text-success' : 'text-muted' }}" style="font-size: 0.72rem;">
                                {{ $statusLabels[$st] ?? $st }}
                            </small>
                        </div>
                    @endforeach
                </div>
                @if($order->status === 'cancelled')
                    <div class="mt-3 alert alert-danger mb-0 py-2">
                        <i class="fas fa-times-circle me-1"></i>
                        <strong>Dibatalkan</strong>
                        @if($order->cancellation_reason)
                            : {{ $order->cancellation_reason }}
                        @endif
                    </div>
                @endif
            </div>
        </div>
    </div>

    {{-- Order Info --}}
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-transparent border-bottom py-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="fw-bold mb-0" style="color: var(--bbk-blue);">
                        <i class="fas fa-file-invoice me-2"></i>Informasi Pesanan
                    </h6>
                    <span class="badge {{
                        $order->status === 'completed' ? 'bg-success' :
                        ($order->status === 'cancelled' ? 'bg-danger' :
                        ($order->status === 'pending' ? 'bg-warning text-dark' :
                        ($order->status === 'shipped' ? 'bg-info' : 'bg-primary')))
                    }} bg-opacity-10 {{
                        $order->status === 'completed' ? 'text-success' :
                        ($order->status === 'cancelled' ? 'text-danger' :
                        ($order->status === 'pending' ? 'text-warning' :
                        ($order->status === 'shipped' ? 'text-info' : 'text-primary')))
                    }}">
                        {{ $order->status_label }}
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-sm-6">
                        <small class="text-muted d-block">No. Pesanan</small>
                        <strong>{{ $order->order_number }}</strong>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block">Tanggal Pesanan</small>
                        <strong>{{ $order->created_at->format('d M Y, H:i') }}</strong>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block">Tipe Pesanan</small>
                        <strong>{{ $order->order_type_label }}</strong>
                    </div>
                    <div class="col-sm-6">
                        <small class="text-muted d-block">Agen</small>
                        <strong>{{ $order->seller->name ?? '-' }}</strong>
                    </div>
                    @if($order->tracking_number)
                        <div class="col-sm-6">
                            <small class="text-muted d-block">No. Resi</small>
                            <strong>{{ $order->tracking_number }}</strong>
                        </div>
                    @endif
                    @if($order->notes)
                        <div class="col-12">
                            <small class="text-muted d-block">Catatan</small>
                            <strong>{{ $order->notes }}</strong>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        {{-- Order Items --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-transparent border-bottom py-3">
                <h6 class="fw-bold mb-0" style="color: var(--bbk-blue);">
                    <i class="fas fa-box me-2"></i>Item Pesanan
                </h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">Produk</th>
                                <th class="text-center">Qty</th>
                                <th class="text-end">Harga</th>
                                <th class="text-end pe-3">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->orderItems as $item)
                            <tr>
                                <td class="ps-3">
                                    <div class="d-flex align-items-center">
                                        <div class="rounded bg-light d-flex align-items-center justify-content-center me-2"
                                             style="width: 40px; height: 40px; min-width: 40px;">
                                            <i class="fas fa-fish text-primary"></i>
                                        </div>
                                        <div>
                                            <div class="fw-semibold small">{{ $item->productVariant->name ?? 'Produk' }}</div>
                                            <small class="text-muted">{{ $item->productVariant->fish_count_label ?? '' }}</small>
                                        </div>
                                    </div>
                                </td>
                                <td class="text-center">{{ $item->quantity }}</td>
                                <td class="text-end">Rp {{ number_format($item->price_per_unit, 0, ',', '.') }}</td>
                                <td class="text-end fw-semibold pe-3">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot class="table-light">
                            <tr>
                                <td colspan="3" class="text-end fw-semibold ps-3">Subtotal</td>
                                <td class="text-end pe-3">Rp {{ number_format($order->subtotal, 0, ',', '.') }}</td>
                            </tr>
                            @if($order->shipping_cost > 0)
                            <tr>
                                <td colspan="3" class="text-end fw-semibold ps-3">Ongkir</td>
                                <td class="text-end pe-3">Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</td>
                            </tr>
                            @endif
                            <tr>
                                <td colspan="3" class="text-end fw-bold ps-3" style="color: var(--bbk-blue);">Total</td>
                                <td class="text-end fw-bold pe-3" style="color: var(--bbk-blue); font-size: 1.1rem;">
                                    Rp {{ number_format($order->total, 0, ',', '.') }}
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        {{-- Shipping Info --}}
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-transparent border-bottom py-3">
                <h6 class="fw-bold mb-0" style="color: var(--bbk-blue);">
                    <i class="fas fa-map-marker-alt me-2"></i>Alamat Pengiriman
                </h6>
            </div>
            <div class="card-body">
                <div class="fw-semibold">{{ $order->recipient_name }}</div>
                <div class="small text-muted">{{ $order->recipient_phone }}</div>
                <div class="small mt-1">
                    {{ $order->shipping_address }},
                    {{ $order->shipping_city }},
                    {{ $order->shipping_province }}
                    {{ $order->shipping_postal_code }}
                </div>
            </div>
        </div>
    </div>

    {{-- Sidebar: Payment & Actions --}}
    <div class="col-lg-4">
        {{-- Payment Info --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-transparent border-bottom py-3">
                <h6 class="fw-bold mb-0" style="color: var(--bbk-blue);">
                    <i class="fas fa-credit-card me-2"></i>Pembayaran
                </h6>
            </div>
            <div class="card-body">
                @if($order->payments->count() > 0)
                    @foreach($order->payments as $payment)
                        <div class="mb-3">
                            <small class="text-muted d-block">Metode</small>
                            <span class="badge bg-primary bg-opacity-10 text-primary">
                                {{ $payment->payment_method === 'deposit' ? 'Saldo/Deposit' : 'Transfer Bank' }}
                            </span>
                        </div>
                        <div class="mb-3">
                            <small class="text-muted d-block">Jumlah</small>
                            <strong>Rp {{ number_format($payment->amount, 0, ',', '.') }}</strong>
                        </div>
                        <div class="mb-3">
                            <small class="text-muted d-block">Status</small>
                            <span class="badge {{
                                $payment->status === 'verified' ? 'bg-success' :
                                ($payment->status === 'rejected' ? 'bg-danger' :
                                ($payment->status === 'pending' ? 'bg-warning text-dark' : 'bg-secondary'))
                            }} bg-opacity-10 {{
                                $payment->status === 'verified' ? 'text-success' :
                                ($payment->status === 'rejected' ? 'text-danger' :
                                ($payment->status === 'pending' ? 'text-warning' : 'text-secondary'))
                            }}">
                                {{ $payment->status_label }}
                            </span>
                        </div>
                        @if($payment->proof_image)
                            <div class="mb-3">
                                <small class="text-muted d-block">Bukti Transfer</small>
                                <img src="{{ asset('storage/' . $payment->proof_image) }}"
                                     alt="Bukti Transfer" class="img-fluid rounded border mt-1"
                                     style="max-height: 200px; cursor: pointer;"
                                     onclick="window.open(this.src)">
                            </div>
                        @endif
                        @if($payment->rejected_reason)
                            <div class="alert alert-danger py-2 small">
                                <i class="fas fa-exclamation-triangle me-1"></i>
                                {{ $payment->rejected_reason }}
                            </div>
                        @endif
                    @endforeach
                @else
                    <div class="text-center py-3">
                        <i class="fas fa-receipt fa-2x text-muted mb-2"></i>
                        <p class="text-muted small mb-0">Belum ada pembayaran</p>
                    </div>
                @endif
            </div>
        </div>

        {{-- Action Buttons --}}
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h6 class="fw-bold mb-3" style="color: var(--bbk-blue);">
                    <i class="fas fa-bolt me-2"></i>Aksi
                </h6>

                {{-- Cancel Order --}}
                @if($order->can_cancel)
                    <form action="{{ route('customer.orders.cancel', $order->id) }}" method="POST"
                          onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?');">
                        @csrf
                        <button type="submit" class="btn btn-outline-danger w-100 mb-2">
                            <i class="fas fa-times me-1"></i> Batalkan Pesanan
                        </button>
                    </form>
                @endif

                {{-- Pay / Upload Proof --}}
                @if($order->status === 'pending' && $order->payments->where('status', 'verified')->count() === 0)
                    <a href="{{ route('customer.payments.show', $order->id) }}"
                       class="btn btn-success w-100 mb-2">
                        <i class="fas fa-credit-card me-1"></i> Bayar Sekarang
                    </a>
                @endif

                {{-- Rate Order --}}
                @if($order->status === 'completed' || $order->status === 'delivered')
                    @if(!$order->ratings->where('user_id', auth()->id())->count())
                        <a href="{{ route('customer.ratings.create', $order->id) }}"
                           class="btn btn-warning w-100 mb-2">
                            <i class="fas fa-star me-1"></i> Beri Rating
                        </a>
                    @endif
                @endif

                {{-- File Complaint --}}
                @if(in_array($order->status, ['delivered', 'completed']))
                    <a href="{{ route('customer.complaints.create', $order->id) }}"
                       class="btn btn-outline-secondary w-100 mb-2">
                        <i class="fas fa-flag me-1"></i> Ajukan Komplain
                    </a>
                @endif

                {{-- Contact Agent via WA --}}
                @if($order->seller && $order->seller->phone)
                    <a href="https://wa.me/62{{ ltrim($order->seller->phone, '0') }}?text=Halo, saya ingin bertanya tentang pesanan {{ $order->order_number }}"
                       target="_blank" class="btn btn-outline-success w-100">
                        <i class="fab fa-whatsapp me-1"></i> Hubungi Agen
                    </a>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
