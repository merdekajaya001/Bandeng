@extends('layouts.customer')

@section('title', 'Pembayaran - Bandar Bandeng Kalimantan')
@section('page_title', 'Pembayaran Pesanan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('customer.orders.index') }}">Pesanan</a></li>
    <li class="breadcrumb-item"><a href="{{ route('customer.orders.show', $order->id) }}">{{ $order->order_number }}</a></li>
    <li class="breadcrumb-item active">Pembayaran</li>
@endsection

@section('customer_content')
<div class="row g-4 justify-content-center">
    <div class="col-lg-8">
        {{-- Order Summary --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-transparent border-bottom py-3">
                <h6 class="fw-bold mb-0" style="color: var(--bbk-blue);">
                    <i class="fas fa-file-invoice me-2"></i>Ringkasan Pesanan
                </h6>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">No. Pesanan</span>
                    <strong>{{ $order->order_number }}</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Subtotal</span>
                    <span>Rp {{ number_format($order->subtotal, 0, ',', '.') }}</span>
                </div>
                @if($order->shipping_cost > 0)
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Ongkir</span>
                        <span>Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</span>
                    </div>
                @endif
                <hr>
                <div class="d-flex justify-content-between">
                    <span class="fw-bold" style="color: var(--bbk-blue);">Total Bayar</span>
                    <span class="fw-bold fs-5" style="color: var(--bbk-blue);">
                        Rp {{ number_format($order->total, 0, ',', '.') }}
                    </span>
                </div>
            </div>
        </div>

        {{-- Payment Method Tabs --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-3" style="color: var(--bbk-blue);">
                    <i class="fas fa-wallet me-2"></i>Pilih Metode Pembayaran
                </h6>

                <ul class="nav nav-pills mb-4" id="paymentTabs" role="tablist">
                    <li class="nav-item flex-fill text-center" role="presentation">
                        <button class="nav-link w-100 active" id="bank-tab" data-bs-toggle="pill"
                                data-bs-target="#bankTransfer" type="button" role="tab">
                            <i class="fas fa-university d-block fs-4 mb-1"></i>
                            <small>Transfer Bank</small>
                        </button>
                    </li>
                    <li class="nav-item flex-fill text-center ms-2" role="presentation">
                        <button class="nav-link w-100" id="deposit-tab" data-bs-toggle="pill"
                                data-bs-target="#depositPay" type="button" role="tab">
                            <i class="fas fa-wallet d-block fs-4 mb-1"></i>
                            <small>Saldo/Deposit</small>
                        </button>
                    </li>
                </ul>

                <div class="tab-content" id="paymentTabContent">
                    {{-- Bank Transfer Tab --}}
                    <div class="tab-pane fade show active" id="bankTransfer" role="tabpanel">
                        <div class="alert alert-info py-2 small mb-4">
                            <i class="fas fa-info-circle me-1"></i>
                            Silakan transfer ke salah satu rekening berikut, lalu upload bukti transfer.
                        </div>

                        {{-- Bank Accounts --}}
                        <div class="row g-3 mb-4">
                            <div class="col-md-4">
                                <div class="card border h-100" style="border-color: var(--bbk-blue) !important;">
                                    <div class="card-body text-center p-3">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Bank_Central_Asia.svg/200px-Bank_Central_Asia.svg.png"
                                             alt="BCA" style="height: 30px;" class="mb-2">
                                        <div class="fw-bold">BCA</div>
                                        <div class="text-primary fw-semibold">8720-3456-7890</div>
                                        <small class="text-muted">a.n. PT Bandar Bandeng KAL</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border h-100">
                                    <div class="card-body text-center p-3">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/68/BANK_RAKYAT_INDONESIA_logo.svg/200px-BANK_RAKYAT_INDONESIA_logo.svg.png"
                                             alt="BRI" style="height: 30px;" class="mb-2">
                                        <div class="fw-bold">BRI</div>
                                        <div class="text-primary fw-semibold">0012-3456-7890-12</div>
                                        <small class="text-muted">a.n. PT Bandar Bandeng KAL</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border h-100">
                                    <div class="card-body text-center p-3">
                                        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Bank_Mandiri_logo_2016.svg/200px-Bank_Mandiri_logo_2016.svg.png"
                                             alt="Mandiri" style="height: 30px;" class="mb-2">
                                        <div class="fw-bold">Mandiri</div>
                                        <div class="text-primary fw-semibold">1234-5678-9012</div>
                                        <small class="text-muted">a.n. PT Bandar Bandeng KAL</small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {{-- Upload Proof Form --}}
                        <form action="{{ route('customer.payments.upload-proof', $order->id) }}" method="POST"
                              enctype="multipart/form-data" id="proofForm">
                            @csrf

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Bank Tujuan Transfer</label>
                                <select name="bank_name" class="form-select" required>
                                    <option value="">-- Pilih Bank --</option>
                                    <option value="BCA">BCA</option>
                                    <option value="BRI">BRI</option>
                                    <option value="Mandiri">Mandiri</option>
                                </select>
                                @error('bank_name')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Nama Pengirim</label>
                                <input type="text" name="bank_holder" class="form-control"
                                       value="{{ old('bank_holder') }}" placeholder="Nama di rekening pengirim" required>
                                @error('bank_holder')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>

                            <div class="mb-3">
                                <label class="form-label fw-semibold">Bukti Transfer</label>
                                <div class="border rounded-3 p-4 text-center" id="dropZone"
                                     style="border-style: dashed !important; cursor: pointer;"
                                     onclick="document.getElementById('proofImage').click()">
                                    <div id="uploadPlaceholder">
                                        <i class="fas fa-cloud-upload-alt fa-2x text-muted mb-2"></i>
                                        <p class="text-muted small mb-1">Klik atau drag & drop bukti transfer</p>
                                        <small class="text-muted">JPG, PNG, max 2MB</small>
                                    </div>
                                    <div id="uploadPreview" class="d-none">
                                        <img id="previewImg" src="" alt="Preview" class="img-fluid rounded" style="max-height: 200px;">
                                        <div class="mt-2">
                                            <small class="text-success"><i class="fas fa-check-circle me-1"></i>File dipilih</small>
                                        </div>
                                    </div>
                                </div>
                                <input type="file" name="proof_image" id="proofImage" class="d-none"
                                       accept="image/jpeg,image/png,image/webp" required>
                                @error('proof_image')
                                    <div class="text-danger small mt-1">{{ $message }}</div>
                                @enderror
                            </div>

                            <button type="submit" class="btn btn-lg w-100 text-white fw-semibold"
                                    style="background: linear-gradient(135deg, var(--bbk-blue), var(--bbk-blue-light));">
                                <i class="fas fa-upload me-2"></i>Upload Bukti Transfer
                            </button>
                        </form>
                    </div>

                    {{-- Deposit Payment Tab --}}
                    <div class="tab-pane fade" id="depositPay" role="tabpanel">
                        @php $wallet = auth()->user()->wallet; @endphp

                        <div class="card mb-4" style="border-color: var(--bbk-gold) !important;">
                            <div class="card-body">
                                <div class="d-flex align-items-center mb-2">
                                    <i class="fas fa-wallet fa-2x me-3" style="color: var(--bbk-gold);"></i>
                                    <div>
                                        <div class="text-muted small">Saldo Anda</div>
                                        <div class="fw-bold fs-5" style="color: var(--bbk-gold);">
                                            Rp {{ number_format($wallet ? $wallet->balance : 0, 0, ',', '.') }}
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between mt-3 pt-2 border-top">
                                    <span class="text-muted">Total Bayar</span>
                                    <span class="fw-semibold">Rp {{ number_format($order->total, 0, ',', '.') }}</span>
                                </div>
                            </div>
                        </div>

                        @if($wallet && $wallet->balance >= $order->total)
                            <div class="alert alert-success py-2 small mb-4">
                                <i class="fas fa-check-circle me-1"></i>
                                Saldo Anda mencukupi untuk pembayaran ini.
                            </div>

                            <form action="{{ route('customer.payments.pay-deposit', $order->id) }}" method="POST"
                                  onsubmit="return confirm('Konfirmasi pembayaran menggunakan saldo deposit sebesar Rp {{ number_format($order->total, 0, ',', '.') }}?');">
                                @csrf
                                <button type="submit" class="btn btn-lg w-100 fw-semibold text-white"
                                        style="background: linear-gradient(135deg, #27AE60, #2ECC71);">
                                    <i class="fas fa-wallet me-2"></i>Bayar dengan Saldo
                                </button>
                            </form>
                        @else
                            <div class="alert alert-warning py-2 small mb-4">
                                <i class="fas fa-exclamation-triangle me-1"></i>
                                Saldo Anda tidak mencukupi. Silakan top-up terlebih dahulu atau gunakan transfer bank.
                            </div>
                            <a href="{{ route('wallet.index') }}" class="btn btn-warning w-100 fw-semibold">
                                <i class="fas fa-plus-circle me-2"></i>Top Up Saldo
                            </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Drag & Drop
    const dropZone = document.getElementById('dropZone');
    const proofImage = document.getElementById('proofImage');

    ['dragenter', 'dragover'].forEach(evt => {
        dropZone.addEventListener(evt, e => { e.preventDefault(); dropZone.classList.add('border-primary'); });
    });
    ['dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, e => { e.preventDefault(); dropZone.classList.remove('border-primary'); });
    });
    dropZone.addEventListener('drop', e => {
        const files = e.dataTransfer.files;
        if (files.length) { proofImage.files = files; showPreview(files[0]); }
    });
    proofImage.addEventListener('change', function() {
        if (this.files.length) showPreview(this.files[0]);
    });

    function showPreview(file) {
        if (!file.type.match('image.*')) { alert('Hanya file gambar yang diperbolehkan'); return; }
        const reader = new FileReader();
        reader.onload = e => {
            document.getElementById('previewImg').src = e.target.result;
            document.getElementById('uploadPlaceholder').classList.add('d-none');
            document.getElementById('uploadPreview').classList.remove('d-none');
        };
        reader.readAsDataURL(file);
    }
</script>
@endpush
