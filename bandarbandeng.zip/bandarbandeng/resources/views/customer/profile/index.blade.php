@extends('layouts.customer')

@section('title', 'Profil Saya - Bandar Bandeng Kalimantan')
@section('page_title', 'Profil Saya')

@section('customer_content')
<div class="row g-4">
    {{-- Profile Card --}}
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm text-center">
            <div class="card-body p-4">
                {{-- Avatar --}}
                <div class="position-relative d-inline-block mb-3">
                    <div class="rounded-circle d-flex align-items-center justify-content-center mx-auto"
                         style="width: 100px; height: 100px; background: linear-gradient(135deg, var(--bbk-blue), var(--bbk-blue-light)); color: #fff; font-size: 2.5rem; font-weight: 700;">
                        {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                    </div>
                    <button type="button" class="btn btn-sm btn-primary position-absolute bottom-0 end-0 rounded-circle"
                            style="width: 32px; height: 32px;" onclick="document.getElementById('avatarInput').click()">
                        <i class="fas fa-camera" style="font-size: 0.7rem;"></i>
                    </button>
                    <form action="{{ route('profile.update-avatar') }}" method="POST" enctype="multipart/form-data"
                          id="avatarForm" class="d-none">
                        @csrf @method('PUT')
                        <input type="file" name="avatar" id="avatarInput" accept="image/jpeg,image/png,image/webp"
                               onchange="this.form.submit()">
                    </form>
                </div>
                <h5 class="fw-bold mb-1" style="color: var(--bbk-blue);">{{ auth()->user()->name }}</h5>
                <span class="badge bg-primary bg-opacity-10 text-primary">
                    {{ auth()->user()->role_label }}
                </span>

                <hr>

                {{-- Quick Info --}}
                <div class="text-start">
                    <div class="d-flex justify-content-between mb-2">
                        <small class="text-muted"><i class="fas fa-envelope me-2"></i>Email</small>
                        <small class="fw-semibold text-truncate" style="max-width: 160px;">{{ auth()->user()->email }}</small>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <small class="text-muted"><i class="fas fa-phone me-2"></i>Telepon</small>
                        <small class="fw-semibold">{{ auth()->user()->phone ?? '-' }}</small>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <small class="text-muted"><i class="fas fa-map-marker-alt me-2"></i>Kota</small>
                        <small class="fw-semibold">{{ auth()->user()->city ?? '-' }}</small>
                    </div>
                </div>

                <hr>

                {{-- Wallet Summary --}}
                @php $wallet = auth()->user()->wallet; @endphp
                <div class="rounded-3 p-3" style="background: linear-gradient(135deg, var(--bbk-gold), #F4D03F);">
                    <div class="text-start">
                        <small class="text-dark opacity-75">Saldo Dompet</small>
                        <div class="fw-bold fs-5 text-dark">
                            Rp {{ number_format($wallet ? $wallet->balance : 0, 0, ',', '.') }}
                        </div>
                    </div>
                </div>
                <a href="{{ route('wallet.index') }}" class="btn btn-sm btn-outline-primary mt-3 w-100">
                    <i class="fas fa-wallet me-1"></i>Kelola Dompet
                </a>
            </div>
        </div>
    </div>

    {{-- Edit Forms --}}
    <div class="col-lg-8">
        {{-- Edit Profile --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-transparent border-bottom py-3">
                <h6 class="fw-bold mb-0" style="color: var(--bbk-blue);">
                    <i class="fas fa-user-edit me-2"></i>Edit Profil
                </h6>
            </div>
            <div class="card-body p-4">
                <form action="{{ route('profile.update') }}" method="POST">
                    @csrf @method('PUT')

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Nama Lengkap</label>
                            <input type="text" name="name" class="form-control" value="{{ old('name', auth()->user()->name) }}" required>
                            @error('name')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Email</label>
                            <input type="email" name="email" class="form-control" value="{{ old('email', auth()->user()->email) }}" required>
                            @error('email')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">No. Telepon</label>
                            <input type="text" name="phone" class="form-control" value="{{ old('phone', auth()->user()->phone) }}"
                                   placeholder="08xxxxxxxxxx">
                            @error('phone')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Kota</label>
                            <input type="text" name="city" class="form-control" value="{{ old('city', auth()->user()->city) }}">
                            @error('city')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Provinsi</label>
                            <select name="province" class="form-select">
                                <option value="">-- Pilih --</option>
                                @foreach(['Kalimantan Selatan','Kalimantan Timur','Kalimantan Tengah','Kalimantan Barat','Kalimantan Utara'] as $prov)
                                    <option value="{{ $prov }}" {{ old('province', auth()->user()->province) === $prov ? 'selected' : '' }}>{{ $prov }}</option>
                                @endforeach
                            </select>
                            @error('province')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Kode Pos</label>
                            <input type="text" name="postal_code" class="form-control" value="{{ old('postal_code', auth()->user()->postal_code) }}">
                            @error('postal_code')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-12">
                            <label class="form-label fw-semibold">Alamat Lengkap</label>
                            <textarea name="address" class="form-control" rows="3">{{ old('address', auth()->user()->address) }}</textarea>
                            @error('address')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <button type="submit" class="btn mt-3 text-white fw-semibold"
                            style="background: linear-gradient(135deg, var(--bbk-blue), var(--bbk-blue-light));">
                        <i class="fas fa-save me-1"></i>Simpan Perubahan
                    </button>
                </form>
            </div>
        </div>

        {{-- Change Password --}}
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-transparent border-bottom py-3">
                <h6 class="fw-bold mb-0" style="color: var(--bbk-blue);">
                    <i class="fas fa-lock me-2"></i>Ubah Password
                </h6>
            </div>
            <div class="card-body p-4">
                <form action="{{ route('profile.update-password') }}" method="POST">
                    @csrf @method('PUT')

                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Password Lama</label>
                            <div class="input-group">
                                <input type="password" name="current_password" class="form-control" id="oldPass" required>
                                <button type="button" class="btn btn-outline-secondary" onclick="togglePass('oldPass', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            @error('current_password')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Password Baru</label>
                            <div class="input-group">
                                <input type="password" name="password" class="form-control" id="newPass" required minlength="8">
                                <button type="button" class="btn btn-outline-secondary" onclick="togglePass('newPass', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            @error('password')
                                <div class="text-danger small mt-1">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">Konfirmasi Password</label>
                            <div class="input-group">
                                <input type="password" name="password_confirmation" class="form-control" id="confirmPass" required>
                                <button type="button" class="btn btn-outline-secondary" onclick="togglePass('confirmPass', this)">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-outline-danger mt-3 fw-semibold">
                        <i class="fas fa-key me-1"></i>Ubah Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    function togglePass(inputId, btn) {
        const input = document.getElementById(inputId);
        const icon = btn.querySelector('i');
        if (input.type === 'password') {
            input.type = 'text';
            icon.classList.replace('fa-eye', 'fa-eye-slash');
        } else {
            input.type = 'password';
            icon.classList.replace('fa-eye-slash', 'fa-eye');
        }
    }
</script>
@endpush
