@extends('layouts.customer')

@section('title', 'Beri Rating - Bandar Bandeng Kalimantan')
@section('page_title', 'Beri Rating')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('customer.orders.index') }}">Pesanan</a></li>
    <li class="breadcrumb-item active">Rating</li>
@endsection

@section('customer_content')
<div class="row g-4 justify-content-center">
    <div class="col-lg-6">
        {{-- Order Summary --}}
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">No. Pesanan</span>
                    <strong>{{ $order->order_number }}</strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">Agen</span>
                    <strong>{{ $order->seller->name ?? '-' }}</strong>
                </div>
                <div class="d-flex justify-content-between">
                    <span class="text-muted">Total</span>
                    <strong style="color: var(--bbk-blue);">Rp {{ number_format($order->total, 0, ',', '.') }}</strong>
                </div>
            </div>
        </div>

        {{-- Rating Form --}}
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h6 class="fw-bold mb-4 text-center" style="color: var(--bbk-blue);">
                    <i class="fas fa-star me-2"></i>Bagaimana pengalaman Anda?
                </h6>

                <form action="{{ route('customer.ratings.store', $order->id) }}" method="POST">
                    @csrf

                    {{-- Star Rating --}}
                    <div class="text-center mb-4">
                        <div class="d-inline-flex gap-2" id="starRating">
                            @for($i = 1; $i <= 5; $i++)
                                <button type="button" class="btn btn-lg p-1 star-btn" data-rating="{{ $i }}"
                                        style="font-size: 2.5rem; border: none; background: none; cursor: pointer;">
                                    <i class="fas fa-star text-muted"></i>
                                </button>
                            @endfor
                        </div>
                        <input type="hidden" name="rating" id="ratingInput" value="0" required>
                        <div id="ratingLabel" class="mt-2 fw-semibold text-muted">Pilih rating</div>
                        @error('rating')
                            <div class="text-danger small mt-1">{{ $message }}</div>
                        @enderror
                    </div>

                    {{-- Review Text --}}
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Ulasan</label>
                        <textarea name="review" class="form-control" rows="4"
                                  placeholder="Ceritakan pengalaman Anda..." maxlength="500">{{ old('review') }}</textarea>
                        <div class="text-end"><small class="text-muted"><span id="charCount">0</span>/500</small></div>
                        @error('review')
                            <div class="text-danger small mt-1">{{ $message }}</div>
                        @enderror
                    </div>

                    {{-- Anonymous --}}
                    <div class="form-check mb-4">
                        <input type="checkbox" name="is_anonymous" class="form-check-input" id="anonCheck" value="1"
                               {{ old('is_anonymous') ? 'checked' : '' }}>
                        <label class="form-check-label small text-muted" for="anonCheck">
                            <i class="fas fa-user-secret me-1"></i>Kirim sebagai anonim
                        </label>
                    </div>

                    <button type="submit" class="btn btn-lg w-100 text-white fw-semibold"
                            style="background: linear-gradient(135deg, var(--bbk-blue), var(--bbk-blue-light));"
                            id="submitBtn" disabled>
                        <i class="fas fa-paper-plane me-2"></i>Kirim Rating
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const ratingLabels = ['', 'Sangat Buruk', 'Buruk', 'Cukup', 'Baik', 'Sangat Baik'];
    const ratingColors = ['', '#e74c3c', '#e67e22', '#f39c12', '#27ae60', '#0C4B8E'];
    let currentRating = 0;

    document.querySelectorAll('.star-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            currentRating = parseInt(this.dataset.rating);
            document.getElementById('ratingInput').value = currentRating;
            document.getElementById('ratingLabel').textContent = ratingLabels[currentRating];
            document.getElementById('ratingLabel').style.color = ratingColors[currentRating];
            document.getElementById('submitBtn').disabled = false;

            document.querySelectorAll('.star-btn').forEach((s, idx) => {
                const icon = s.querySelector('i');
                if (idx < currentRating) {
                    icon.classList.remove('text-muted');
                    icon.style.color = '#D4A017';
                } else {
                    icon.classList.add('text-muted');
                    icon.style.color = '';
                }
            });
        });

        btn.addEventListener('mouseenter', function() {
            const hoverRating = parseInt(this.dataset.rating);
            document.querySelectorAll('.star-btn').forEach((s, idx) => {
                const icon = s.querySelector('i');
                if (idx < hoverRating) {
                    icon.style.color = '#F4D03F';
                }
            });
        });

        btn.addEventListener('mouseleave', function() {
            document.querySelectorAll('.star-btn').forEach((s, idx) => {
                const icon = s.querySelector('i');
                if (idx < currentRating) {
                    icon.style.color = '#D4A017';
                } else {
                    icon.style.color = '';
                    icon.classList.add('text-muted');
                }
            });
        });
    });

    // Char counter
    document.querySelector('textarea[name="review"]').addEventListener('input', function() {
        document.getElementById('charCount').textContent = this.value.length;
    });
</script>
@endpush
