<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bandar Bandeng Kalimantan - Ikan Bandeng Tanpa Duri #1 Kalimantan</title>
    <meta name="description" content="Bandar Bandeng Kalimantan - Ikan Bandeng Tanpa Duri #1 di Kalimantan. Diproses higienis, dikemas segar, langsung dari pengolahan ke rumah Anda.">
    <meta name="keywords" content="ikan bandeng, bandeng tanpa duri, bandeng kalimantan, bandeng presto, ikan segar, bandar bandeng">
    <meta name="author" content="Bandar Bandeng Kalimantan">

    <!-- Open Graph -->
    <meta property="og:title" content="Bandar Bandeng Kalimantan - Ikan Bandeng Tanpa Duri #1 Kalimantan">
    <meta property="og:description" content="Diproses higienis, dikemas segar, langsung dari pengolahan ke rumah Anda.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url('/') }}">
    <meta property="og:image" content="{{ asset('images/hero-product.png') }}">
    <meta property="og:locale" content="id_ID">
    <meta property="og:site_name" content="Bandar Bandeng Kalimantan">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Bandar Bandeng Kalimantan - Ikan Bandeng Tanpa Duri #1 Kalimantan">
    <meta name="twitter:description" content="Diproses higienis, dikemas segar, langsung dari pengolahan ke rumah Anda.">
    <meta name="twitter:image" content="{{ asset('images/hero-product.png') }}">

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="{{ asset('images/logo.png') }}">

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- AOS Animation Library -->
    <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@700;800;900&display=swap" rel="stylesheet">

    <style>
        /* ==========================================================================
           CSS Variables & Root
           ========================================================================== */
        :root {
            --sea-blue: #0C4B8E;
            --sea-blue-dark: #083660;
            --sea-blue-light: #1565C0;
            --gold: #D4A017;
            --gold-light: #F0C94B;
            --gold-dark: #B8860B;
            --green: #27AE60;
            --green-light: #2ECC71;
            --white: #FFFFFF;
            --off-white: #F8FAFC;
            --gray-100: #F1F5F9;
            --gray-200: #E2E8F0;
            --gray-300: #CBD5E1;
            --gray-500: #64748B;
            --gray-700: #334155;
            --gray-900: #0F172A;
            --font-primary: 'Poppins', sans-serif;
            --font-display: 'Playfair Display', serif;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
            --shadow-md: 0 4px 16px rgba(0,0,0,0.1);
            --shadow-lg: 0 8px 32px rgba(0,0,0,0.12);
            --shadow-xl: 0 16px 48px rgba(0,0,0,0.15);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 20px;
            --radius-xl: 28px;
        }

        /* ==========================================================================
           Base & Reset
           ========================================================================== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
            scroll-padding-top: 80px;
        }

        body {
            font-family: var(--font-primary);
            color: var(--gray-700);
            line-height: 1.7;
            overflow-x: hidden;
            background-color: var(--white);
        }

        h1, h2, h3, h4, h5, h6 {
            font-family: var(--font-primary);
            font-weight: 700;
            color: var(--gray-900);
            line-height: 1.3;
        }

        a {
            text-decoration: none;
            transition: all 0.3s ease;
        }

        img {
            max-width: 100%;
            height: auto;
        }

        /* ==========================================================================
           Section Shared Styles
           ========================================================================== */
        .section-padding {
            padding: 100px 0;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--gray-900);
            margin-bottom: 0.5rem;
        }

        .section-subtitle {
            font-size: 1.1rem;
            color: var(--gray-500);
            margin-bottom: 3rem;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .section-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--sea-blue), var(--sea-blue-light));
            color: var(--white);
            padding: 6px 20px;
            border-radius: 50px;
            font-size: 0.8rem;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 1rem;
        }

        .gold-accent-line {
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, var(--gold), var(--gold-light));
            border-radius: 2px;
            margin: 1rem auto 1.5rem;
        }

        /* ==========================================================================
           Navbar
           ========================================================================== */
        .navbar-landing {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1050;
            padding: 16px 0;
            transition: all 0.4s ease;
            background: transparent;
        }

        .navbar-landing.scrolled {
            background: rgba(255, 255, 255, 0.97);
            backdrop-filter: blur(12px);
            box-shadow: var(--shadow-md);
            padding: 10px 0;
        }

        .navbar-landing .navbar-brand {
            font-weight: 800;
            font-size: 1.35rem;
            color: var(--white);
            transition: color 0.3s ease;
        }

        .navbar-landing.scrolled .navbar-brand {
            color: var(--sea-blue);
        }

        .navbar-landing .navbar-brand .brand-icon {
            width: 38px;
            height: 38px;
            background: linear-gradient(135deg, var(--gold), var(--gold-light));
            border-radius: var(--radius-sm);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-right: 10px;
            font-size: 1.1rem;
        }

        .navbar-landing .nav-link {
            color: rgba(255, 255, 255, 0.9);
            font-weight: 500;
            font-size: 0.9rem;
            padding: 8px 16px !important;
            border-radius: var(--radius-sm);
            transition: all 0.3s ease;
        }

        .navbar-landing .nav-link:hover,
        .navbar-landing .nav-link.active {
            color: var(--white);
            background: rgba(255, 255, 255, 0.15);
        }

        .navbar-landing.scrolled .nav-link {
            color: var(--gray-700);
        }

        .navbar-landing.scrolled .nav-link:hover,
        .navbar-landing.scrolled .nav-link.active {
            color: var(--sea-blue);
            background: rgba(12, 75, 142, 0.08);
        }

        .navbar-landing .btn-nav-cta {
            background: linear-gradient(135deg, var(--gold), var(--gold-dark));
            color: var(--white) !important;
            font-weight: 600;
            padding: 8px 24px !important;
            border-radius: 50px;
            box-shadow: 0 4px 15px rgba(212, 160, 23, 0.3);
        }

        .navbar-landing .btn-nav-cta:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(212, 160, 23, 0.4);
        }

        .navbar-landing .navbar-toggler {
            border: none;
            padding: 6px;
            color: var(--white);
        }

        .navbar-landing.scrolled .navbar-toggler {
            color: var(--sea-blue);
        }

        .navbar-landing .navbar-toggler:focus {
            box-shadow: none;
        }

        /* ==========================================================================
           1. Hero Section
           ========================================================================== */
        .hero-section {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            background: linear-gradient(135deg, var(--sea-blue-dark) 0%, var(--sea-blue) 40%, var(--sea-blue-light) 100%);
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: -50%;
            right: -20%;
            width: 800px;
            height: 800px;
            background: radial-gradient(circle, rgba(212, 160, 23, 0.1) 0%, transparent 70%);
            border-radius: 50%;
            animation: float 8s ease-in-out infinite;
        }

        .hero-section::after {
            content: '';
            position: absolute;
            bottom: -30%;
            left: -10%;
            width: 600px;
            height: 600px;
            background: radial-gradient(circle, rgba(39, 174, 96, 0.1) 0%, transparent 70%);
            border-radius: 50%;
            animation: float 10s ease-in-out infinite reverse;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-30px); }
        }

        .hero-content {
            position: relative;
            z-index: 2;
            padding-top: 100px;
        }

        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(212, 160, 23, 0.15);
            border: 1px solid rgba(212, 160, 23, 0.3);
            color: var(--gold-light);
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 500;
            margin-bottom: 1.5rem;
        }

        .hero-badge i {
            font-size: 0.75rem;
        }

        .hero-title {
            font-size: 3.5rem;
            font-weight: 900;
            color: var(--white);
            line-height: 1.15;
            margin-bottom: 1.5rem;
        }

        .hero-title .gold-text {
            color: var(--gold-light);
            position: relative;
        }

        .hero-title .gold-text::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--gold), var(--gold-light));
            border-radius: 2px;
        }

        .hero-subtitle {
            font-size: 1.15rem;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 2.5rem;
            max-width: 540px;
            line-height: 1.8;
        }

        .hero-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 3rem;
        }

        .btn-gold {
            background: linear-gradient(135deg, var(--gold), var(--gold-dark));
            color: var(--white);
            border: none;
            padding: 14px 36px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1rem;
            box-shadow: 0 4px 20px rgba(212, 160, 23, 0.35);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-gold:hover {
            background: linear-gradient(135deg, var(--gold-light), var(--gold));
            color: var(--white);
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(212, 160, 23, 0.45);
        }

        .btn-outline-white {
            background: transparent;
            color: var(--white);
            border: 2px solid rgba(255, 255, 255, 0.4);
            padding: 12px 36px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-outline-white:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: var(--white);
            color: var(--white);
            transform: translateY(-3px);
        }

        .hero-image-wrapper {
            position: relative;
            z-index: 2;
        }

        .hero-image-wrapper img {
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-xl);
            animation: heroFloat 6s ease-in-out infinite;
        }

        @keyframes heroFloat {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(1deg); }
        }

        .hero-floating-card {
            position: absolute;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: var(--radius-md);
            padding: 14px 20px;
            box-shadow: var(--shadow-lg);
            animation: floatCard 5s ease-in-out infinite;
            z-index: 3;
        }

        .hero-floating-card.card-fish {
            top: 10%;
            right: -20px;
            animation-delay: 0s;
        }

        .hero-floating-card.card-quality {
            bottom: 15%;
            left: -30px;
            animation-delay: 1.5s;
        }

        .hero-floating-card .card-icon {
            width: 42px;
            height: 42px;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            margin-right: 12px;
        }

        .hero-floating-card .card-icon.sea-blue {
            background: rgba(12, 75, 142, 0.1);
            color: var(--sea-blue);
        }

        .hero-floating-card .card-icon.gold {
            background: rgba(212, 160, 23, 0.1);
            color: var(--gold);
        }

        .hero-floating-card .card-text-sm {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin-bottom: 0;
        }

        .hero-floating-card .card-text-bold {
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--gray-900);
            margin-bottom: 0;
        }

        @keyframes floatCard {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-12px); }
        }

        /* Hero Stats */
        .hero-stats {
            position: relative;
            z-index: 2;
            display: flex;
            gap: 40px;
            flex-wrap: wrap;
        }

        .hero-stat-item {
            text-align: left;
        }

        .hero-stat-number {
            font-size: 2.2rem;
            font-weight: 800;
            color: var(--gold-light);
            line-height: 1;
            margin-bottom: 4px;
        }

        .hero-stat-label {
            font-size: 0.85rem;
            color: rgba(255, 255, 255, 0.7);
            font-weight: 400;
        }

        /* Wave Divider */
        .wave-divider {
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 100%;
            z-index: 3;
        }

        .wave-divider svg {
            display: block;
            width: 100%;
            height: auto;
        }

        /* ==========================================================================
           2. Video Promo Section
           ========================================================================== */
        .video-section {
            background: var(--off-white);
            position: relative;
        }

        .video-wrapper {
            position: relative;
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-xl);
            aspect-ratio: 16 / 9;
            background: var(--gray-900);
            cursor: pointer;
        }

        .video-wrapper .video-placeholder {
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--sea-blue-dark), var(--sea-blue));
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 16px;
        }

        .video-play-btn {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            border: 3px solid rgba(255, 255, 255, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 1.8rem;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .video-play-btn:hover {
            background: var(--gold);
            border-color: var(--gold);
            transform: scale(1.1);
        }

        .video-play-btn i {
            margin-left: 5px;
        }

        .video-wrapper .video-text {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.9rem;
            font-weight: 500;
        }

        /* ==========================================================================
           3. Keunggulan Section
           ========================================================================== */
        .keunggulan-card {
            background: var(--white);
            border-radius: var(--radius-md);
            padding: 36px 28px;
            text-align: center;
            border: 2px solid var(--gray-200);
            transition: all 0.4s ease;
            height: 100%;
        }

        .keunggulan-card:hover {
            border-color: var(--gold);
            box-shadow: 0 8px 40px rgba(212, 160, 23, 0.15);
            transform: translateY(-8px);
        }

        .keunggulan-icon {
            width: 72px;
            height: 72px;
            border-radius: var(--radius-md);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            margin-bottom: 1.25rem;
        }

        .keunggulan-icon.blue {
            background: linear-gradient(135deg, rgba(12, 75, 142, 0.1), rgba(21, 101, 192, 0.15));
            color: var(--sea-blue);
        }

        .keunggulan-icon.green {
            background: linear-gradient(135deg, rgba(39, 174, 96, 0.1), rgba(46, 204, 113, 0.15));
            color: var(--green);
        }

        .keunggulan-icon.gold {
            background: linear-gradient(135deg, rgba(212, 160, 23, 0.1), rgba(240, 201, 75, 0.15));
            color: var(--gold);
        }

        .keunggulan-icon.sea {
            background: linear-gradient(135deg, rgba(12, 75, 142, 0.05), rgba(21, 101, 192, 0.1));
            color: var(--sea-blue-light);
        }

        .keunggulan-card h5 {
            font-weight: 700;
            margin-bottom: 0.75rem;
        }

        .keunggulan-card p {
            font-size: 0.9rem;
            color: var(--gray-500);
            margin-bottom: 0;
        }

        /* ==========================================================================
           4. Proses Higienis Section
           ========================================================================== */
        .proses-section {
            background: var(--off-white);
            position: relative;
            overflow: hidden;
        }

        .timeline {
            position: relative;
            max-width: 900px;
            margin: 0 auto;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 3px;
            height: 100%;
            background: linear-gradient(to bottom, var(--sea-blue), var(--gold));
            border-radius: 2px;
        }

        .timeline-item {
            position: relative;
            margin-bottom: 50px;
            display: flex;
            align-items: flex-start;
        }

        .timeline-item:last-child {
            margin-bottom: 0;
        }

        .timeline-item:nth-child(odd) {
            flex-direction: row;
        }

        .timeline-item:nth-child(even) {
            flex-direction: row-reverse;
        }

        .timeline-content {
            width: 45%;
            background: var(--white);
            border-radius: var(--radius-md);
            padding: 28px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
        }

        .timeline-content:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-4px);
        }

        .timeline-dot {
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--sea-blue), var(--sea-blue-light));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-weight: 700;
            font-size: 1rem;
            z-index: 2;
            box-shadow: 0 4px 15px rgba(12, 75, 142, 0.3);
        }

        .timeline-content .step-number {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--sea-blue);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 0.5rem;
        }

        .timeline-content h5 {
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .timeline-content p {
            font-size: 0.88rem;
            color: var(--gray-500);
            margin-bottom: 0;
        }

        .timeline-spacer {
            width: 45%;
        }

        /* ==========================================================================
           5. Gallery Produksi Section
           ========================================================================== */
        .gallery-section {
            background: var(--white);
        }

        .gallery-item {
            position: relative;
            border-radius: var(--radius-md);
            overflow: hidden;
            cursor: pointer;
            aspect-ratio: 4 / 3;
            background: var(--gray-100);
        }

        .gallery-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .gallery-item:hover img {
            transform: scale(1.08);
        }

        .gallery-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(12, 75, 142, 0.7), rgba(8, 54, 96, 0.8));
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .gallery-item:hover .gallery-overlay {
            opacity: 1;
        }

        .gallery-overlay i {
            color: var(--white);
            font-size: 2rem;
        }

        /* Lightbox */
        .lightbox-modal .modal-content {
            background: transparent;
            border: none;
        }

        .lightbox-modal .btn-close {
            position: absolute;
            top: -40px;
            right: 0;
            filter: brightness(0) invert(1);
            opacity: 1;
        }

        /* ==========================================================================
           6. Nutrisi Section
           ========================================================================== */
        .nutrisi-section {
            background: var(--off-white);
        }

        .nutrisi-card {
            background: var(--white);
            border-radius: var(--radius-md);
            padding: 32px 24px;
            text-align: center;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
        }

        .nutrisi-card:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-md);
        }

        .nutrisi-circle {
            position: relative;
            width: 110px;
            height: 110px;
            margin: 0 auto 1.25rem;
        }

        .nutrisi-circle svg {
            width: 110px;
            height: 110px;
            transform: rotate(-90deg);
        }

        .nutrisi-circle .circle-bg {
            fill: none;
            stroke: var(--gray-200);
            stroke-width: 8;
        }

        .nutrisi-circle .circle-progress {
            fill: none;
            stroke-width: 8;
            stroke-linecap: round;
            transition: stroke-dashoffset 1.5s ease;
        }

        .nutrisi-circle .circle-text {
            position: absolute;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--gray-900);
        }

        .nutrisi-card h6 {
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .nutrisi-card p {
            font-size: 0.85rem;
            color: var(--gray-500);
            margin-bottom: 0;
        }

        /* ==========================================================================
           7. Cara Pemesanan Section
           ========================================================================== */
        .cara-pesan-section {
            background: var(--white);
            position: relative;
        }

        .step-card {
            text-align: center;
            position: relative;
            padding: 30px 20px;
        }

        .step-number-circle {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--sea-blue), var(--sea-blue-light));
            color: var(--white);
            font-size: 1.6rem;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1.25rem;
            box-shadow: 0 6px 20px rgba(12, 75, 142, 0.3);
            position: relative;
            z-index: 2;
        }

        .step-card h6 {
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .step-card p {
            font-size: 0.88rem;
            color: var(--gray-500);
            margin-bottom: 0;
        }

        .step-connector {
            position: absolute;
            top: 65px;
            right: -15%;
            width: 30%;
            height: 3px;
            background: linear-gradient(90deg, var(--sea-blue), var(--gold));
            z-index: 1;
        }

        .step-connector i {
            position: absolute;
            right: -8px;
            top: -7px;
            color: var(--gold);
            font-size: 1rem;
        }

        /* ==========================================================================
           8. Ukuran Produk Section
           ========================================================================== */
        .ukuran-section {
            background: var(--off-white);
        }

        .product-variant-card {
            background: var(--white);
            border-radius: var(--radius-md);
            overflow: hidden;
            border: 2px solid var(--gray-200);
            transition: all 0.4s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .product-variant-card:hover {
            border-color: var(--gold);
            box-shadow: 0 8px 40px rgba(212, 160, 23, 0.15);
            transform: translateY(-8px);
        }

        .product-variant-card .variant-image {
            background: linear-gradient(135deg, rgba(12, 75, 142, 0.05), rgba(21, 101, 192, 0.08));
            padding: 30px;
            text-align: center;
            min-height: 180px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .product-variant-card .variant-image img {
            max-height: 140px;
            object-fit: contain;
        }

        .fish-count-illustration {
            display: flex;
            gap: 8px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .fish-icon-mini {
            font-size: 2.2rem;
            color: var(--sea-blue);
        }

        .product-variant-card .variant-body {
            padding: 24px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .product-variant-card .variant-name {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--gray-900);
            margin-bottom: 4px;
        }

        .product-variant-card .variant-weight {
            font-size: 0.85rem;
            color: var(--gray-500);
            margin-bottom: 12px;
        }

        .product-variant-card .variant-price {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--sea-blue);
            margin-bottom: 16px;
        }

        .product-variant-card .variant-price small {
            font-size: 0.8rem;
            font-weight: 500;
            color: var(--gray-500);
        }

        .product-variant-card .btn-pesan {
            background: linear-gradient(135deg, var(--gold), var(--gold-dark));
            color: var(--white);
            border: none;
            padding: 10px 24px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            margin-top: auto;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .product-variant-card .btn-pesan:hover {
            box-shadow: 0 4px 15px rgba(212, 160, 23, 0.35);
            transform: translateY(-2px);
        }

        /* ==========================================================================
           9. Produk Siap Saji Section
           ========================================================================== */
        .sajian-section {
            background: var(--white);
        }

        .sajian-card {
            background: var(--white);
            border-radius: var(--radius-md);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
            transition: all 0.4s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .sajian-card:hover {
            box-shadow: var(--shadow-lg);
            transform: translateY(-8px);
        }

        .sajian-card .sajian-image {
            height: 220px;
            overflow: hidden;
            position: relative;
        }

        .sajian-card .sajian-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .sajian-card:hover .sajian-image img {
            transform: scale(1.05);
        }

        .sajian-card .sajian-badge {
            position: absolute;
            top: 14px;
            right: 14px;
            background: var(--green);
            color: var(--white);
            padding: 4px 14px;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 600;
        }

        .sajian-card .sajian-body {
            padding: 24px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .sajian-card h5 {
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .sajian-card .sajian-desc {
            font-size: 0.88rem;
            color: var(--gray-500);
            margin-bottom: 1rem;
            flex: 1;
        }

        .sajian-card .sajian-price {
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--sea-blue);
            margin-bottom: 0;
        }

        /* ==========================================================================
           10. Agen Terdekat Section
           ========================================================================== */
        .agen-section {
            background: var(--off-white);
        }

        .search-agent-box {
            max-width: 500px;
            margin: 0 auto 2.5rem;
            position: relative;
        }

        .search-agent-box input {
            border: 2px solid var(--gray-200);
            border-radius: 50px;
            padding: 14px 54px 14px 24px;
            font-size: 0.95rem;
            width: 100%;
            transition: all 0.3s ease;
        }

        .search-agent-box input:focus {
            border-color: var(--sea-blue);
            box-shadow: 0 0 0 4px rgba(12, 75, 142, 0.1);
            outline: none;
        }

        .search-agent-box .search-icon {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-500);
        }

        .agent-card {
            background: var(--white);
            border-radius: var(--radius-md);
            padding: 24px;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
            height: 100%;
            border-left: 4px solid transparent;
        }

        .agent-card:hover {
            box-shadow: var(--shadow-md);
            border-left-color: var(--gold);
            transform: translateY(-4px);
        }

        .agent-avatar {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--gray-200);
        }

        .agent-name {
            font-weight: 700;
            color: var(--gray-900);
            margin-bottom: 2px;
        }

        .agent-city {
            font-size: 0.85rem;
            color: var(--gray-500);
            margin-bottom: 8px;
        }

        .agent-rating {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .agent-rating i {
            color: var(--gold);
            font-size: 0.85rem;
        }

        .agent-rating span {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--gray-700);
            margin-left: 4px;
        }

        .agent-badge-tag {
            display: inline-block;
            background: linear-gradient(135deg, var(--gold), var(--gold-light));
            color: var(--white);
            padding: 3px 12px;
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .agent-area-tag {
            display: inline-block;
            background: rgba(12, 75, 142, 0.08);
            color: var(--sea-blue);
            padding: 3px 12px;
            border-radius: 50px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .link-see-all {
            color: var(--sea-blue);
            font-weight: 600;
            font-size: 0.95rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .link-see-all:hover {
            color: var(--gold);
            gap: 10px;
        }

        /* ==========================================================================
           11. Testimoni Section
           ========================================================================== */
        .testimoni-section {
            background: var(--white);
            overflow: hidden;
        }

        .testimoni-card {
            background: var(--white);
            border-radius: var(--radius-md);
            padding: 32px;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--gray-200);
            height: 100%;
            position: relative;
            transition: all 0.3s ease;
        }

        .testimoni-card:hover {
            box-shadow: var(--shadow-md);
            border-color: var(--gold);
        }

        .testimoni-card .quote-icon {
            font-size: 2.5rem;
            color: var(--gold);
            opacity: 0.3;
            position: absolute;
            top: 20px;
            right: 24px;
        }

        .testimoni-stars {
            display: flex;
            gap: 3px;
            margin-bottom: 1rem;
        }

        .testimoni-stars i {
            color: var(--gold);
            font-size: 0.9rem;
        }

        .testimoni-text {
            font-size: 0.95rem;
            color: var(--gray-700);
            line-height: 1.8;
            margin-bottom: 1.5rem;
            font-style: italic;
        }

        .testimoni-author {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .testimoni-author-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--sea-blue), var(--sea-blue-light));
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.1rem;
        }

        .testimoni-author-name {
            font-weight: 700;
            color: var(--gray-900);
            font-size: 0.95rem;
        }

        .testimoni-author-city {
            font-size: 0.8rem;
            color: var(--gray-500);
        }

        /* ==========================================================================
           12. CTA Section
           ========================================================================== */
        .cta-section {
            position: relative;
            background: linear-gradient(135deg, var(--sea-blue-dark) 0%, var(--sea-blue) 50%, var(--sea-blue-light) 100%);
            overflow: hidden;
        }

        .cta-section::before {
            content: '';
            position: absolute;
            top: -100px;
            right: -100px;
            width: 400px;
            height: 400px;
            background: radial-gradient(circle, rgba(212, 160, 23, 0.1) 0%, transparent 70%);
            border-radius: 50%;
        }

        .cta-section::after {
            content: '';
            position: absolute;
            bottom: -80px;
            left: -80px;
            width: 300px;
            height: 300px;
            background: radial-gradient(circle, rgba(39, 174, 96, 0.08) 0%, transparent 70%);
            border-radius: 50%;
        }

        .cta-content {
            position: relative;
            z-index: 2;
        }

        .cta-title {
            font-size: 2.5rem;
            font-weight: 800;
            color: var(--white);
            margin-bottom: 1rem;
        }

        .cta-subtitle {
            font-size: 1.1rem;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 2.5rem;
            max-width: 550px;
            margin-left: auto;
            margin-right: auto;
        }

        .btn-whatsapp {
            background: var(--green);
            color: var(--white);
            border: none;
            padding: 16px 40px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1.05rem;
            box-shadow: 0 4px 20px rgba(39, 174, 96, 0.35);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-whatsapp:hover {
            background: var(--green-light);
            color: var(--white);
            transform: translateY(-3px);
            box-shadow: 0 8px 30px rgba(39, 174, 96, 0.45);
        }

        .btn-register {
            background: transparent;
            color: var(--white);
            border: 2px solid rgba(255, 255, 255, 0.4);
            padding: 14px 40px;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.05rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-register:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: var(--white);
            color: var(--white);
            transform: translateY(-3px);
        }

        /* ==========================================================================
           Footer
           ========================================================================== */
        .footer-section {
            background: var(--gray-900);
            padding: 60px 0 0;
        }

        .footer-brand {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--white);
            margin-bottom: 1rem;
        }

        .footer-desc {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
            line-height: 1.8;
            margin-bottom: 1.5rem;
        }

        .footer-title {
            color: var(--white);
            font-weight: 700;
            font-size: 1rem;
            margin-bottom: 1.25rem;
        }

        .footer-links {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--gold);
            padding-left: 4px;
        }

        .footer-contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 14px;
        }

        .footer-contact-item i {
            color: var(--gold);
            margin-top: 4px;
        }

        .footer-contact-item span {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9rem;
        }

        .footer-social {
            display: flex;
            gap: 12px;
        }

        .footer-social a {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.08);
            display: flex;
            align-items: center;
            justify-content: center;
            color: rgba(255, 255, 255, 0.6);
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .footer-social a:hover {
            background: var(--gold);
            color: var(--white);
            transform: translateY(-3px);
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 20px 0;
            margin-top: 40px;
        }

        .footer-bottom p {
            color: rgba(255, 255, 255, 0.4);
            font-size: 0.85rem;
            margin-bottom: 0;
        }

        /* ==========================================================================
           Floating WhatsApp Button
           ========================================================================== */
        .whatsapp-float {
            position: fixed;
            bottom: 28px;
            right: 28px;
            width: 62px;
            height: 62px;
            background: var(--green);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-size: 1.8rem;
            box-shadow: 0 6px 24px rgba(39, 174, 96, 0.4);
            z-index: 9999;
            transition: all 0.3s ease;
            animation: waPulse 2s infinite;
        }

        .whatsapp-float:hover {
            background: var(--green-light);
            color: var(--white);
            transform: scale(1.1);
            box-shadow: 0 8px 30px rgba(39, 174, 96, 0.5);
        }

        .whatsapp-float .wa-tooltip {
            position: absolute;
            right: 72px;
            background: var(--white);
            color: var(--gray-700);
            padding: 8px 16px;
            border-radius: var(--radius-sm);
            font-size: 0.85rem;
            font-weight: 500;
            white-space: nowrap;
            box-shadow: var(--shadow-md);
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }

        .whatsapp-float:hover .wa-tooltip {
            opacity: 1;
        }

        @keyframes waPulse {
            0% { box-shadow: 0 6px 24px rgba(39, 174, 96, 0.4); }
            50% { box-shadow: 0 6px 24px rgba(39, 174, 96, 0.4), 0 0 0 12px rgba(39, 174, 96, 0.1); }
            100% { box-shadow: 0 6px 24px rgba(39, 174, 96, 0.4), 0 0 0 20px rgba(39, 174, 96, 0); }
        }

        /* ==========================================================================
           Responsive Adjustments
           ========================================================================== */
        @media (max-width: 991.98px) {
            .hero-title {
                font-size: 2.5rem;
            }

            .section-title {
                font-size: 2rem;
            }

            .hero-image-wrapper {
                margin-top: 3rem;
                text-align: center;
            }

            .hero-floating-card {
                display: none;
            }

            .hero-stats {
                justify-content: center;
            }

            .timeline::before {
                left: 24px;
            }

            .timeline-item {
                flex-direction: row !important;
            }

            .timeline-content {
                width: calc(100% - 64px);
                margin-left: 64px;
            }

            .timeline-dot {
                left: 24px;
                transform: none;
            }

            .timeline-spacer {
                display: none;
            }

            .step-connector {
                display: none;
            }

            .cta-title {
                font-size: 2rem;
            }
        }

        @media (max-width: 767.98px) {
            .section-padding {
                padding: 70px 0;
            }

            .hero-title {
                font-size: 2rem;
            }

            .hero-subtitle {
                font-size: 1rem;
            }

            .section-title {
                font-size: 1.6rem;
            }

            .hero-stat-number {
                font-size: 1.6rem;
            }

            .hero-stats {
                gap: 24px;
            }

            .hero-stat-item {
                text-align: center;
            }

            .whatsapp-float {
                bottom: 20px;
                right: 20px;
                width: 54px;
                height: 54px;
                font-size: 1.5rem;
            }

            .whatsapp-float .wa-tooltip {
                display: none;
            }
        }

        @media (max-width: 575.98px) {
            .hero-buttons {
                flex-direction: column;
            }

            .hero-buttons .btn-gold,
            .hero-buttons .btn-outline-white {
                width: 100%;
                justify-content: center;
            }
        }

        /* ==========================================================================
           Carousel custom indicators
           ========================================================================== */
        .testimoni-carousel .carousel-indicators {
            bottom: -50px;
        }

        .testimoni-carousel .carousel-indicators [data-bs-target] {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: var(--gray-300);
            border: none;
            opacity: 1;
        }

        .testimoni-carousel .carousel-indicators .active {
            background-color: var(--gold);
            width: 28px;
            border-radius: 6px;
        }

        .testimoni-carousel .carousel-control-prev,
        .testimoni-carousel .carousel-control-next {
            width: 44px;
            height: 44px;
            background: var(--white);
            border-radius: 50%;
            box-shadow: var(--shadow-md);
            top: 50%;
            transform: translateY(-50%);
            opacity: 1;
        }

        .testimoni-carousel .carousel-control-prev {
            left: -22px;
        }

        .testimoni-carousel .carousel-control-next {
            right: -22px;
        }

        .testimoni-carousel .carousel-control-prev-icon,
        .testimoni-carousel .carousel-control-next-icon {
            filter: none;
            width: 16px;
            height: 16px;
        }

        .testimoni-carousel .carousel-control-prev-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230C4B8E'%3e%3cpath d='M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z'/%3e%3c/svg%3e");
        }

        .testimoni-carousel .carousel-control-next-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16' fill='%230C4B8E'%3e%3cpath d='M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z'/%3e%3c/svg%3e");
        }

        /* Navbar mobile bg fix */
        @media (max-width: 991.98px) {
            .navbar-landing .navbar-collapse {
                background: rgba(255, 255, 255, 0.98);
                backdrop-filter: blur(12px);
                border-radius: var(--radius-md);
                padding: 16px;
                margin-top: 10px;
                box-shadow: var(--shadow-lg);
            }

            .navbar-landing .navbar-collapse .nav-link {
                color: var(--gray-700);
                padding: 10px 16px !important;
            }

            .navbar-landing .navbar-collapse .nav-link:hover {
                color: var(--sea-blue);
                background: rgba(12, 75, 142, 0.08);
            }

            .navbar-landing .navbar-collapse .btn-nav-cta {
                margin-top: 8px;
                text-align: center;
                display: block;
            }
        }
    </style>
</head>
<body>

    <!-- ======================================================================
         NAVBAR
         ====================================================================== -->
    <nav class="navbar navbar-expand-lg navbar-landing" id="mainNav">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="{{ url('/') }}">
                <span class="brand-icon"><i class="fas fa-fish"></i></span>
                <span>Bandar Bandeng</span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navContent" aria-controls="navContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars fa-lg"></i>
            </button>
            <div class="collapse navbar-collapse" id="navContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link" href="#hero">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link" href="#keunggulan">Keunggulan</a></li>
                    <li class="nav-item"><a class="nav-link" href="#produk">Produk</a></li>
                    <li class="nav-item"><a class="nav-link" href="#agen">Agen</a></li>
                    <li class="nav-item"><a class="nav-link" href="#testimoni">Testimoni</a></li>
                </ul>
                <a href="https://wa.me/622243922576" target="_blank" class="btn btn-nav-cta">
                    <i class="fab fa-whatsapp"></i> Hubungi Kami
                </a>
            </div>
        </div>
    </nav>

    <!-- ======================================================================
         1. HERO SECTION
         ====================================================================== -->
    <section class="hero-section" id="hero">
        <div class="container hero-content">
            <div class="row align-items-center">
                <div class="col-lg-6" data-aos="fade-right" data-aos-duration="1000">
                    <div class="hero-badge">
                        <i class="fas fa-certificate"></i>
                        Ikan Bandeng Premium Kalimantan
                    </div>
                    <h1 class="hero-title">
                        Ikan Bandeng<br>
                        <span class="gold-text">Tanpa Duri</span><br>
                        #1 Kalimantan
                    </h1>
                    <p class="hero-subtitle">
                        Diproses higienis, dikemas segar, langsung dari pengolahan ke rumah Anda. Nikmati ikan bandeng tanpa duri berkualitas tinggi dari Kalimantan.
                    </p>
                    <div class="hero-buttons">
                        <a href="https://wa.me/622243922576?text=Halo%20Bandar%20Bandeng%2C%20saya%20ingin%20memesan%20ikan%20bandeng%20tanpa%20duri" target="_blank" class="btn btn-gold">
                            <i class="fab fa-whatsapp"></i> Pesan Sekarang
                        </a>
                        <a href="#produk" class="btn btn-outline-white">
                            <i class="fas fa-eye"></i> Lihat Produk
                        </a>
                    </div>
                    <div class="hero-stats">
                        <div class="hero-stat-item">
                            <div class="hero-stat-number" data-count="{{ $stats['total_customers'] ?? 10000 }}">{{ number_format($stats['total_customers'] ?? 10000) }}+</div>
                            <div class="hero-stat-label">Pelanggan</div>
                        </div>
                        <div class="hero-stat-item">
                            <div class="hero-stat-number">{{ number_format($stats['total_agents'] ?? 50) }}+</div>
                            <div class="hero-stat-label">Agen</div>
                        </div>
                        <div class="hero-stat-item">
                            <div class="hero-stat-number">5+</div>
                            <div class="hero-stat-label">Kota</div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" data-aos="fade-left" data-aos-duration="1000" data-aos-delay="200">
                    <div class="hero-image-wrapper text-center">
                        <img src="{{ asset('images/hero-product.png') }}" alt="Ikan Bandeng Tanpa Duri Premium" class="img-fluid" loading="eager">

                        <!-- Floating card: fish count -->
                        <div class="hero-floating-card card-fish d-flex align-items-center">
                            <div class="card-icon sea-blue">
                                <i class="fas fa-fish"></i>
                            </div>
                            <div>
                                <p class="card-text-sm">Varian Tersedia</p>
                                <p class="card-text-bold">{{ $products->count() }} Produk</p>
                            </div>
                        </div>

                        <!-- Floating card: quality -->
                        <div class="hero-floating-card card-quality d-flex align-items-center">
                            <div class="card-icon gold">
                                <i class="fas fa-shield-halved"></i>
                            </div>
                            <div>
                                <p class="card-text-sm">Jaminan</p>
                                <p class="card-text-bold">100% Tanpa Duri</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Wave SVG Divider -->
        <div class="wave-divider">
            <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
                <path d="M0 60L48 52C96 44 192 28 288 24C384 20 480 28 576 40C672 52 768 68 864 72C960 76 1056 68 1152 56C1248 44 1344 28 1392 20L1440 12V120H1392C1344 120 1248 120 1152 120C1056 120 960 120 864 120C768 120 672 120 576 120C480 120 384 120 288 120C192 120 96 120 48 120H0V60Z" fill="#F8FAFC"/>
            </svg>
        </div>
    </section>

    <!-- ======================================================================
         2. VIDEO PROMO SECTION
         ====================================================================== -->
    <section class="video-section section-padding" id="video">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-play me-1"></i> Video</span>
                <h2 class="section-title">Lihat Proses Kami</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Saksikan bagaimana kami mengolah ikan bandeng tanpa duri dengan standar higienis tertinggi</p>
            </div>
            <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="200">
                <div class="col-lg-9">
                    <div class="video-wrapper" id="videoWrapper">
                        <div class="video-placeholder" id="videoPlaceholder">
                            <button class="video-play-btn" id="playBtn" aria-label="Play video">
                                <i class="fas fa-play"></i>
                            </button>
                            <span class="video-text">Tonton Video Proses Kami</span>
                        </div>
                        <!-- YouTube iframe will be injected here on play -->
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ======================================================================
         3. KEUNGGULAN SECTION
         ====================================================================== -->
    <section class="section-padding" id="keunggulan">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-star me-1"></i> Keunggulan</span>
                <h2 class="section-title">Mengapa Bandar Bandeng?</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Kualitas terbaik dengan proses higienis yang terjamin</p>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="0">
                    <div class="keunggulan-card">
                        <div class="keunggulan-icon blue">
                            <i class="fas fa-ban"></i>
                        </div>
                        <h5>Tanpa Duri 100%</h5>
                        <p>Duri bandeng dihilangkan secara manual oleh tenaga ahli berpengalaman. Bebas duri, aman untuk semua usia.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                    <div class="keunggulan-card">
                        <div class="keunggulan-icon green">
                            <i class="fas fa-certificate"></i>
                        </div>
                        <h5>Higienis & Halal</h5>
                        <p>Diproses dalam fasilitas bersih dengan standar kebersihan tinggi. Berlabel halal dan aman dikonsumsi.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                    <div class="keunggulan-card">
                        <div class="keunggulan-icon gold">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <h5>Fresh dari Kalimantan</h5>
                        <p>Langsung dari perairan Kalimantan yang kaya nutrisi. Kesegaran terjaga dari tangkapan hingga tiba di rumah Anda.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                    <div class="keunggulan-card">
                        <div class="keunggulan-icon sea">
                            <i class="fas fa-truck-fast"></i>
                        </div>
                        <h5>Pengiriman Cepat</h5>
                        <p>Jaringan agen tersebar di berbagai kota. Pengiriman cepat melalui agen terdekat ke lokasi Anda.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ======================================================================
         4. PROSES HIGIENIS SECTION
         ====================================================================== -->
    <section class="proses-section section-padding" id="proses">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-clipboard-check me-1"></i> Proses</span>
                <h2 class="section-title">Proses Higienis Kami</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Setiap langkah dijaga dengan standar kebersihan dan kualitas tertinggi</p>
            </div>
            <div class="timeline">
                <!-- Step 1 -->
                <div class="timeline-item" data-aos="fade-right">
                    <div class="timeline-content">
                        <div class="step-number">Langkah 01</div>
                        <h5><i class="fas fa-water me-2 text-primary"></i>Tangkap</h5>
                        <p>Ikan bandeng ditangkap langsung dari perairan Kalimantan yang masih alami dan kaya nutrisi.</p>
                    </div>
                    <div class="timeline-dot">1</div>
                    <div class="timeline-spacer"></div>
                </div>
                <!-- Step 2 -->
                <div class="timeline-item" data-aos="fade-left">
                    <div class="timeline-spacer"></div>
                    <div class="timeline-dot">2</div>
                    <div class="timeline-content">
                        <div class="step-number">Langkah 02</div>
                        <h5><i class="fas fa-hand-sparkles me-2 text-info"></i>Bersihkan</h5>
                        <p>Dibersihkan secara menyeluruh dengan air bersih mengalir, memastikan tidak ada kotoran yang tersisa.</p>
                    </div>
                </div>
                <!-- Step 3 -->
                <div class="timeline-item" data-aos="fade-right">
                    <div class="timeline-content">
                        <div class="step-number">Langkah 03</div>
                        <h5><i class="fas fa-magnifying-glass me-2 text-warning"></i>Bersihkan Duri</h5>
                        <p>Duri dihilangkan satu per satu secara manual oleh tenaga ahli berpengalaman hingga 100% bebas duri.</p>
                    </div>
                    <div class="timeline-dot">3</div>
                    <div class="timeline-spacer"></div>
                </div>
                <!-- Step 4 -->
                <div class="timeline-item" data-aos="fade-left">
                    <div class="timeline-spacer"></div>
                    <div class="timeline-dot">4</div>
                    <div class="timeline-content">
                        <div class="step-number">Langkah 04</div>
                        <h5><i class="fas fa-pepper-hot me-2 text-danger"></i>Marinasi</h5>
                        <p>Dibumbui dengan resep khas Kalimantan yang lezat, meresap sempurna ke dalam daging ikan.</p>
                    </div>
                </div>
                <!-- Step 5 -->
                <div class="timeline-item" data-aos="fade-right">
                    <div class="timeline-content">
                        <div class="step-number">Langkah 05</div>
                        <h5><i class="fas fa-box me-2 text-success"></i>Kemas</h5>
                        <p>Dikemas dengan teknologi vacuum sealing untuk menjaga kesegaran dan kualitas selama distribusi.</p>
                    </div>
                    <div class="timeline-dot">5</div>
                    <div class="timeline-spacer"></div>
                </div>
                <!-- Step 6 -->
                <div class="timeline-item" data-aos="fade-left">
                    <div class="timeline-spacer"></div>
                    <div class="timeline-dot">6</div>
                    <div class="timeline-content">
                        <div class="step-number">Langkah 06</div>
                        <h5><i class="fas fa-truck me-2" style="color: var(--sea-blue)"></i>Distribusi</h5>
                        <p>Dikirim melalui jaringan agen kami yang tersebar di berbagai kota di Kalimantan dengan pengiriman cepat.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ======================================================================
         5. GALLERY PRODUKSI SECTION
         ====================================================================== -->
    <section class="gallery-section section-padding" id="gallery">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-images me-1"></i> Gallery</span>
                <h2 class="section-title">Gallery Produksi</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Lihat langsung proses dan kualitas produksi kami</p>
            </div>
            <div class="row g-3">
                <div class="col-12 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#lightboxModal" data-index="0">
                        <img src="{{ asset('images/process-hygienis.png') }}" alt="Proses Higienis" loading="lazy">
                        <div class="gallery-overlay">
                            <i class="fas fa-expand"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#lightboxModal" data-index="1">
                        <img src="{{ asset('images/bone-removal.png') }}" alt="Pembersihan Duri" loading="lazy">
                        <div class="gallery-overlay">
                            <i class="fas fa-expand"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#lightboxModal" data-index="2">
                        <img src="{{ asset('images/product-clean.png') }}" alt="Produk Bersih" loading="lazy">
                        <div class="gallery-overlay">
                            <i class="fas fa-expand"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="300">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#lightboxModal" data-index="3">
                        <img src="{{ asset('images/packaging.png') }}" alt="Pengemasan" loading="lazy">
                        <div class="gallery-overlay">
                            <i class="fas fa-expand"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="400">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#lightboxModal" data-index="4">
                        <img src="{{ asset('images/plated-dish.png') }}" alt="Hidangan Siap Saji" loading="lazy">
                        <div class="gallery-overlay">
                            <i class="fas fa-expand"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-delay="500">
                    <div class="gallery-item" data-bs-toggle="modal" data-bs-target="#lightboxModal" data-index="5">
                        <img src="{{ asset('images/family-enjoying.png') }}" alt="Keluarga Menikmati" loading="lazy">
                        <div class="gallery-overlay">
                            <i class="fas fa-expand"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Lightbox Modal -->
    <div class="modal fade lightbox-modal" id="lightboxModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                <img src="" alt="Gallery Image" id="lightboxImage" class="img-fluid" style="border-radius: var(--radius-md);">
            </div>
        </div>
    </div>

    <!-- ======================================================================
         6. NUTRISI SECTION
         ====================================================================== -->
    <section class="nutrisi-section section-padding" id="nutrisi">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-heartbeat me-1"></i> Nutrisi</span>
                <h2 class="section-title">Kandungan Nutrisi Ikan Bandeng</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Ikan bandeng kaya akan nutrisi penting untuk kesehatan tubuh Anda</p>
            </div>
            <div class="row g-4">
                @php
                    $nutrisi = [
                        ['name' => 'Protein Tinggi', 'desc' => 'Membantu pertumbuhan dan perbaikan sel tubuh', 'percent' => 85, 'color' => '#0C4B8E'],
                        ['name' => 'Omega-3', 'desc' => 'Menjaga kesehatan jantung dan otak', 'percent' => 75, 'color' => '#27AE60'],
                        ['name' => 'Vitamin D', 'desc' => 'Meningkatkan penyerapan kalsium dan imunitas', 'percent' => 60, 'color' => '#D4A017'],
                        ['name' => 'Kalsium', 'desc' => 'Memperkuat tulang dan gigi', 'percent' => 70, 'color' => '#1565C0'],
                        ['name' => 'Rendah Lemak', 'desc' => 'Cocok untuk diet sehat dan menu harian', 'percent' => 90, 'color' => '#2ECC71'],
                    ];
                @endphp
                @foreach($nutrisi as $index => $n)
                <div class="col-6 col-md-4 col-lg" data-aos="fade-up" data-aos-delay="{{ $index * 100 }}">
                    <div class="nutrisi-card">
                        <div class="nutrisi-circle">
                            <svg viewBox="0 0 120 120">
                                <circle class="circle-bg" cx="60" cy="60" r="50"></circle>
                                <circle class="circle-progress" cx="60" cy="60" r="50"
                                    stroke="{{ $n['color'] }}"
                                    stroke-dasharray="314.16"
                                    stroke-dashoffset="{{ 314.16 - (314.16 * $n['percent'] / 100) }}"
                                ></circle>
                            </svg>
                            <div class="circle-text">{{ $n['percent'] }}%</div>
                        </div>
                        <h6>{{ $n['name'] }}</h6>
                        <p>{{ $n['desc'] }}</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- ======================================================================
         7. CARA PEMESANAN SECTION
         ====================================================================== -->
    <section class="cara-pesan-section section-padding" id="cara-pesan">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-list-ol me-1"></i> Panduan</span>
                <h2 class="section-title">Cara Pemesanan</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Pesan ikan bandeng tanpa duri dalam 4 langkah mudah</p>
            </div>
            <div class="row g-4 justify-content-center">
                @php
                    $steps = [
                        ['number' => 1, 'icon' => 'fa-box-open', 'title' => 'Pilih Produk', 'desc' => 'Pilih varian ikan bandeng sesuai kebutuhan Anda'],
                        ['number' => 2, 'icon' => 'fa-map-pin', 'title' => 'Pilih Agen Terdekat', 'desc' => 'Cari dan pilih agen terdekat dengan lokasi Anda'],
                        ['number' => 3, 'icon' => 'fa-credit-card', 'title' => 'Bayar', 'desc' => 'Lakukan pembayaran via transfer bank atau e-wallet'],
                        ['number' => 4, 'icon' => 'fa-hand-holding-heart', 'title' => 'Terima Pesanan', 'desc' => 'Pesanan diantar langsung ke alamat Anda'],
                    ];
                @endphp
                @foreach($steps as $index => $step)
                <div class="col-6 col-md-3" data-aos="fade-up" data-aos-delay="{{ $index * 150 }}">
                    <div class="step-card">
                        <div class="step-number-circle">
                            {{ $step['number'] }}
                        </div>
                        @if($index < count($steps) - 1)
                        <div class="step-connector d-none d-md-block">
                            <i class="fas fa-chevron-right"></i>
                        </div>
                        @endif
                        <h6><i class="fas {{ $step['icon'] }} me-2" style="color: var(--sea-blue)"></i>{{ $step['title'] }}</h6>
                        <p>{{ $step['desc'] }}</p>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- ======================================================================
         8. UKURAN PRODUK SECTION
         ====================================================================== -->
    <section class="ukuran-section section-padding" id="produk">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-ruler me-1"></i> Varian</span>
                <h2 class="section-title">Ukuran Produk Tersedia</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Pilih ukuran ikan bandeng tanpa duri sesuai kebutuhan Anda</p>
            </div>
            <div class="row g-4">
                @foreach($products as $product)
                    @foreach($product->variants as $variant)
                    <div class="col-12 col-sm-6 col-lg-3" data-aos="fade-up" data-aos-delay="{{ $loop->index * 100 }}">
                        <div class="product-variant-card">
                            <div class="variant-image">
                                @if($variant->image)
                                    <img src="{{ $variant->image_url }}" alt="{{ $variant->name }}" loading="lazy">
                                @else
                                    <div class="fish-count-illustration">
                                        @for($i = 0; $i < min($variant->fish_count, 5); $i++)
                                            <i class="fas fa-fish fish-icon-mini"></i>
                                        @endfor
                                    </div>
                                @endif
                            </div>
                            <div class="variant-body">
                                <div class="variant-name">{{ $variant->fish_count_label }}</div>
                                <div class="variant-weight">
                                    @if($variant->weight_kg)
                                        {{ $variant->weight_kg }} kg
                                    @else
                                        &asymp; {{ $variant->fish_count === 1 ? '250g - 500g' : number_format(1 / $variant->fish_count, 2) . ' kg/ekor' }}
                                    @endif
                                </div>
                                <div class="variant-price">
                                    Rp {{ number_format($variant->price, 0, ',', '.') }}
                                    <small>/{{ $variant->fish_count === 1 ? 'ekor' : 'kg' }}</small>
                                </div>
                                <a href="https://wa.me/622243922576?text=Halo%20Bandar%20Bandeng%2C%20saya%20ingin%20memesan%20{{ urlencode($variant->fish_count_label) }}" target="_blank" class="btn btn-pesan w-100">
                                    <i class="fab fa-whatsapp"></i> Pesan
                                </a>
                            </div>
                        </div>
                    </div>
                    @endforeach
                @endforeach

                @if($products->isEmpty())
                    <!-- Fallback static variants when no products in database -->
                    @php
                        $staticVariants = [
                            ['name' => '5 Ekor/kg', 'fish_count' => 5, 'price' => 85000, 'weight' => '1 kg'],
                            ['name' => '4 Ekor/kg', 'fish_count' => 4, 'price' => 95000, 'weight' => '1 kg'],
                            ['name' => '3 Ekor/kg', 'fish_count' => 3, 'price' => 115000, 'weight' => '1 kg'],
                            ['name' => 'Per Ekor', 'fish_count' => 1, 'price' => 35000, 'weight' => '250g - 500g'],
                        ];
                    @endphp
                    @foreach($staticVariants as $sv)
                    <div class="col-12 col-sm-6 col-lg-3" data-aos="fade-up" data-aos-delay="{{ $loop->index * 100 }}">
                        <div class="product-variant-card">
                            <div class="variant-image">
                                <div class="fish-count-illustration">
                                    @for($i = 0; $i < $sv['fish_count']; $i++)
                                        <i class="fas fa-fish fish-icon-mini"></i>
                                    @endfor
                                </div>
                            </div>
                            <div class="variant-body">
                                <div class="variant-name">{{ $sv['name'] }}</div>
                                <div class="variant-weight">{{ $sv['weight'] }}</div>
                                <div class="variant-price">
                                    Rp {{ number_format($sv['price'], 0, ',', '.') }}
                                    <small>/{{ $sv['fish_count'] === 1 ? 'ekor' : 'kg' }}</small>
                                </div>
                                <a href="https://wa.me/622243922576?text=Halo%20Bandar%20Bandeng%2C%20saya%20ingin%20memesan%20{{ urlencode($sv['name']) }}" target="_blank" class="btn btn-pesan w-100">
                                    <i class="fab fa-whatsapp"></i> Pesan
                                </a>
                            </div>
                        </div>
                    </div>
                    @endforeach
                @endif
            </div>
        </div>
    </section>

    <!-- ======================================================================
         9. PRODUK SIAP SAJI SECTION
         ====================================================================== -->
    <section class="sajian-section section-padding" id="sajian">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-utensils me-1"></i> Siap Saji</span>
                <h2 class="section-title">Produk Siap Saji</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Praktis dan lezat, tinggal panaskan dan nikmati</p>
            </div>
            <div class="row g-4">
                @php
                    $readyProducts = [
                        [
                            'name' => 'Bandeng Presto',
                            'desc' => 'Ikan bandeng tanpa duri yang dimasak dengan teknik presto hingga empuk dan bumbu meresap sempurna. Tinggal goreng sebentar dan siap dinikmati.',
                            'price' => 'Rp 45.000 - Rp 65.000',
                            'image' => 'images/bandeng-goreng.png',
                            'badge' => 'Terlaris',
                        ],
                        [
                            'name' => 'Bandeng Bakar',
                            'desc' => 'Bandeng tanpa duri yang dibakar dengan bumbu khas Kalimantan. Aroma smokey yang menggugah selera dengan rasa yang nikmat.',
                            'price' => 'Rp 55.000 - Rp 75.000',
                            'image' => 'images/bandeng-bakar.png',
                            'badge' => 'Favorit',
                        ],
                        [
                            'name' => 'Bandeng Asap',
                            'desc' => 'Bandeng tanpa duri yang diasap dengan kayu pilihan menghasilkan cita rasa khas yang autentik dan tahan lama.',
                            'price' => 'Rp 60.000 - Rp 85.000',
                            'image' => 'images/product-clean.png',
                            'badge' => 'Premium',
                        ],
                    ];
                @endphp
                @foreach($readyProducts as $index => $rp)
                <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="{{ $index * 150 }}">
                    <div class="sajian-card">
                        <div class="sajian-image">
                            <img src="{{ asset($rp['image']) }}" alt="{{ $rp['name'] }}" loading="lazy">
                            <span class="sajian-badge">{{ $rp['badge'] }}</span>
                        </div>
                        <div class="sajian-body">
                            <h5>{{ $rp['name'] }}</h5>
                            <p class="sajian-desc">{{ $rp['desc'] }}</p>
                            <div class="d-flex align-items-center justify-content-between">
                                <span class="sajian-price">{{ $rp['price'] }}</span>
                                <a href="https://wa.me/622243922576?text=Halo%20Bandar%20Bandeng%2C%20saya%20ingin%20memesan%20{{ urlencode($rp['name']) }}" target="_blank" class="btn btn-sm btn-pesan">
                                    <i class="fab fa-whatsapp"></i> Pesan
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </section>

    <!-- ======================================================================
         10. AGEN TERDEKAT SECTION
         ====================================================================== -->
    <section class="agen-section section-padding" id="agen">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-users me-1"></i> Agen</span>
                <h2 class="section-title">Temukan Agen Terdekat</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Jaringan agen kami tersebar di berbagai kota di Kalimantan</p>
            </div>

            <!-- Search -->
            <div class="search-agent-box" data-aos="fade-up" data-aos-delay="100">
                <input type="text" id="agentSearch" placeholder="Cari berdasarkan kota..." class="form-control">
                <i class="fas fa-search search-icon"></i>
            </div>

            <div class="row g-4" id="agentCards">
                @foreach($agents as $index => $agent)
                <div class="col-12 col-sm-6 col-lg-3 agent-card-col" data-aos="fade-up" data-aos-delay="{{ ($loop->index % 4) * 100 }}" data-city="{{ $agent->city ?? '' }}">
                    <div class="agent-card">
                        <div class="d-flex align-items-center gap-3 mb-3">
                            <img src="{{ $agent->avatar_url }}" alt="{{ $agent->name }}" class="agent-avatar">
                            <div>
                                <div class="agent-name">{{ $agent->name }}</div>
                                <div class="agent-city">
                                    <i class="fas fa-map-marker-alt me-1"></i>{{ $agent->city ?? 'Kalimantan' }}
                                </div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <div class="agent-rating">
                                @php
                                    $avgRating = $agent->receivedRatings()->avg('rating') ?? 4.5;
                                @endphp
                                @for($i = 1; $i <= 5; $i++)
                                    <i class="fas fa-star{{ $i <= round($avgRating) ? '' : '-half-alt' }}" style="{{ $i > round($avgRating) ? 'opacity: 0.3' : '' }}"></i>
                                @endfor
                                <span>{{ number_format($avgRating, 1) }}</span>
                            </div>
                            @if($agent->agentBadges->count() > 0)
                                @foreach($agent->agentBadges as $badge)
                                    <span class="agent-badge-tag" style="background: {{ $badge->color ?? 'linear-gradient(135deg, var(--gold), var(--gold-light))' }}">
                                        <i class="fas {{ $badge->icon ?? 'fa-medal' }} me-1"></i>{{ $badge->name }}
                                    </span>
                                @endforeach
                            @else
                                <span class="agent-badge-tag">
                                    <i class="fas fa-check-circle me-1"></i>Terverifikasi
                                </span>
                            @endif
                        </div>
                        @if($agent->agentAreas->count() > 0)
                            <div class="d-flex flex-wrap gap-2">
                                @foreach($agent->agentAreas->take(3) as $area)
                                    <span class="agent-area-tag">{{ $area->city }}</span>
                                @endforeach
                            </div>
                        @endif
                    </div>
                </div>
                @endforeach

                @if($agents->isEmpty())
                    <!-- Fallback when no agents in database -->
                    @php
                        $fallbackAgents = [
                            ['name' => 'Agen Samarinda', 'city' => 'Samarinda', 'rating' => 4.8, 'badge' => 'Gold'],
                            ['name' => 'Agen Balikpapan', 'city' => 'Balikpapan', 'rating' => 4.7, 'badge' => 'Silver'],
                            ['name' => 'Agen Banjarmasin', 'city' => 'Banjarmasin', 'rating' => 4.9, 'badge' => 'Gold'],
                            ['name' => 'Agen Pontianak', 'city' => 'Pontianak', 'rating' => 4.6, 'badge' => 'Silver'],
                        ];
                    @endphp
                    @foreach($fallbackAgents as $fa)
                    <div class="col-12 col-sm-6 col-lg-3 agent-card-col" data-aos="fade-up" data-aos-delay="{{ $loop->index * 100 }}" data-city="{{ $fa['city'] }}">
                        <div class="agent-card">
                            <div class="d-flex align-items-center gap-3 mb-3">
                                <div class="agent-avatar d-flex align-items-center justify-content-center" style="background: linear-gradient(135deg, var(--sea-blue), var(--sea-blue-light)); color: white; font-weight: 700; font-size: 1.1rem;">
                                    {{ strtoupper(substr($fa['name'], 0, 1)) }}
                                </div>
                                <div>
                                    <div class="agent-name">{{ $fa['name'] }}</div>
                                    <div class="agent-city"><i class="fas fa-map-marker-alt me-1"></i>{{ $fa['city'] }}</div>
                                </div>
                            </div>
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="agent-rating">
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fas fa-star{{ $i <= round($fa['rating']) ? '' : '-half-alt' }}" style="{{ $i > round($fa['rating']) ? 'opacity: 0.3' : '' }}"></i>
                                    @endfor
                                    <span>{{ number_format($fa['rating'], 1) }}</span>
                                </div>
                                <span class="agent-badge-tag"><i class="fas fa-medal me-1"></i>{{ $fa['badge'] }}</span>
                            </div>
                        </div>
                    </div>
                    @endforeach
                @endif
            </div>

            <div class="text-center mt-4" data-aos="fade-up">
                <a href="{{ route('public.agents') }}" class="link-see-all">
                    Lihat Semua Agen <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- ======================================================================
         11. TESTIMONI SECTION
         ====================================================================== -->
    <section class="testimoni-section section-padding" id="testimoni">
        <div class="container">
            <div class="text-center" data-aos="fade-up">
                <span class="section-badge"><i class="fas fa-quote-left me-1"></i> Testimoni</span>
                <h2 class="section-title">Apa Kata Pelanggan Kami</h2>
                <div class="gold-accent-line"></div>
                <p class="section-subtitle">Ribuan pelanggan puas dengan ikan bandeng tanpa duri kami</p>
            </div>

            @if($testimonials->count() > 0)
                <div id="testimoniCarousel" class="carousel slide testimoni-carousel" data-bs-ride="carousel" data-bs-interval="5000" data-aos="fade-up" data-aos-delay="200">
                    <div class="carousel-inner">
                        @php
                            $chunks = $testimonials->chunk(3);
                        @endphp
                        @foreach($chunks as $chunkIndex => $chunk)
                        <div class="carousel-item {{ $chunkIndex === 0 ? 'active' : '' }}">
                            <div class="row g-4 px-2">
                                @foreach($chunk as $testimonial)
                                <div class="col-12 col-md-4">
                                    <div class="testimoni-card">
                                        <i class="fas fa-quote-right quote-icon"></i>
                                        <div class="testimoni-stars">
                                            @for($i = 1; $i <= 5; $i++)
                                                <i class="fas fa-star{{ $i <= $testimonial->rating ? '' : '-half-alt' }}" style="{{ $i > $testimonial->rating ? 'opacity: 0.3' : '' }}"></i>
                                            @endfor
                                        </div>
                                        <p class="testimoni-text">"{{ $testimonial->content }}"</p>
                                        <div class="testimoni-author">
                                            <div class="testimoni-author-avatar">
                                                {{ strtoupper(substr($testimonial->name, 0, 1)) }}
                                            </div>
                                            <div>
                                                <div class="testimoni-author-name">{{ $testimonial->name }}</div>
                                                <div class="testimoni-author-city">
                                                    <i class="fas fa-map-marker-alt me-1"></i>
                                                    {{ $testimonial->user ? $testimonial->user->city : 'Kalimantan' }}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        @endforeach
                    </div>

                    @if($chunks->count() > 1)
                    <div class="carousel-indicators position-relative mt-4">
                        @foreach($chunks as $chunkIndex => $chunk)
                        <button type="button" data-bs-target="#testimoniCarousel" data-bs-slide-to="{{ $chunkIndex }}" {{ $chunkIndex === 0 ? 'class="active" aria-current="true"' : '' }} aria-label="Slide {{ $chunkIndex + 1 }}"></button>
                        @endforeach
                    </div>
                    @endif
                </div>
            @else
                <!-- Fallback testimonials -->
                @php
                    $fallbackTestimonials = [
                        ['name' => 'Ibu Sari', 'city' => 'Samarinda', 'content' => 'Bandengnya enak banget, anak-anak suka karena tidak ada durinya sama sekali. Jadi bisa makan tenang tanpa khawatir.', 'rating' => 5],
                        ['name' => 'Pak Budi', 'city' => 'Balikpapan', 'content' => 'Sudah langganan beli di sini. Kualitasnya konsisten, pengirimannya juga cepat lewat agen terdekat. Recommended!', 'rating' => 5],
                        ['name' => 'Ibu Rina', 'city' => 'Banjarmasin', 'content' => 'Praktis banget, tinggal goreng langsung makan. Rasa bandeng presto-nya enak dan bumbu meresap sempurna.', 'rating' => 4],
                        ['name' => 'Pak Andi', 'city' => 'Pontianak', 'content' => 'Saya jual lagi di warung, laris manis pembelangnya. Margin-nya juga bagus. Terima kasih Bandar Bandeng!', 'rating' => 5],
                        ['name' => 'Ibu Dewi', 'city' => 'Tarakan', 'content' => 'Pertama kali coba bandeng tanpa duri, ternyata benar-benar tidak ada duri sama sekali. Kualitas premium!', 'rating' => 5],
                        ['name' => 'Pak Rizal', 'city' => 'Samarinda', 'content' => 'Proses pemesanan mudah, agen responsif, dan bandengnya segar. Sudah order berkali-kali tidak pernah mengecewakan.', 'rating' => 4],
                    ];
                @endphp
                <div id="testimoniCarousel" class="carousel slide testimoni-carousel" data-bs-ride="carousel" data-bs-interval="5000" data-aos="fade-up" data-aos-delay="200">
                    <div class="carousel-inner">
                        @php
                            $fbChunks = collect($fallbackTestimonials)->chunk(3);
                        @endphp
                        @foreach($fbChunks as $chunkIndex => $chunk)
                        <div class="carousel-item {{ $chunkIndex === 0 ? 'active' : '' }}">
                            <div class="row g-4 px-2">
                                @foreach($chunk as $ft)
                                <div class="col-12 col-md-4">
                                    <div class="testimoni-card">
                                        <i class="fas fa-quote-right quote-icon"></i>
                                        <div class="testimoni-stars">
                                            @for($i = 1; $i <= 5; $i++)
                                                <i class="fas fa-star{{ $i <= $ft['rating'] ? '' : '-half-alt' }}" style="{{ $i > $ft['rating'] ? 'opacity: 0.3' : '' }}"></i>
                                            @endfor
                                        </div>
                                        <p class="testimoni-text">"{{ $ft['content'] }}"</p>
                                        <div class="testimoni-author">
                                            <div class="testimoni-author-avatar">
                                                {{ strtoupper(substr($ft['name'], 0, 1)) }}
                                            </div>
                                            <div>
                                                <div class="testimoni-author-name">{{ $ft['name'] }}</div>
                                                <div class="testimoni-author-city">
                                                    <i class="fas fa-map-marker-alt me-1"></i>{{ $ft['city'] }}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                        </div>
                        @endforeach
                    </div>
                    <div class="carousel-indicators position-relative mt-4">
                        @foreach($fbChunks as $chunkIndex => $chunk)
                        <button type="button" data-bs-target="#testimoniCarousel" data-bs-slide-to="{{ $chunkIndex }}" {{ $chunkIndex === 0 ? 'class="active" aria-current="true"' : '' }} aria-label="Slide {{ $chunkIndex + 1 }}"></button>
                        @endforeach
                    </div>
                </div>
            @endif
        </div>
    </section>

    <!-- ======================================================================
         12. CTA SECTION
         ====================================================================== -->
    <section class="cta-section section-padding" id="cta">
        <div class="container">
            <div class="cta-content text-center" data-aos="zoom-in" data-aos-duration="800">
                <h2 class="cta-title">
                    Siap Menikmati Ikan Bandeng<br><span style="color: var(--gold-light)">Tanpa Duri?</span>
                </h2>
                <p class="cta-subtitle">
                    Pesan sekarang dan rasakan kelezatan ikan bandeng tanpa duri langsung dari Kalimantan. Tersedia dalam berbagai ukuran dan varian siap saji.
                </p>
                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <a href="https://wa.me/622243922576?text=Halo%20Bandar%20Bandeng%2C%20saya%20ingin%20memesan%20ikan%20bandeng%20tanpa%20duri" target="_blank" class="btn btn-whatsapp">
                        <i class="fab fa-whatsapp fa-lg"></i> Chat WhatsApp
                    </a>
                    <a href="{{ route('register') }}" class="btn btn-register">
                        <i class="fas fa-user-plus"></i> Daftar Sekarang
                    </a>
                </div>
            </div>
        </div>

        <!-- Wave top divider -->
        <div style="position: absolute; top: -2px; left: 0; width: 100%; z-index: 3;">
            <svg viewBox="0 0 1440 80" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
                <path d="M0 80L48 72C96 64 192 48 288 40C384 32 480 32 576 40C672 48 768 64 864 68C960 72 1056 64 1152 52C1248 40 1344 24 1392 16L1440 8V0H0V80Z" fill="#FFFFFF"/>
            </svg>
        </div>
    </section>

    <!-- ======================================================================
         FOOTER
         ====================================================================== -->
    <footer class="footer-section">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="footer-brand">
                        <i class="fas fa-fish me-2" style="color: var(--gold)"></i>Bandar Bandeng Kalimantan
                    </div>
                    <p class="footer-desc">
                        Penyedia ikan bandeng tanpa duri #1 di Kalimantan. Diproses higienis, dikemas segar, dan didistribusikan melalui jaringan agen terpercaya.
                    </p>
                    <div class="footer-social">
                        <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" aria-label="TikTok"><i class="fab fa-tiktok"></i></a>
                        <a href="https://wa.me/622243922576" target="_blank" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h6 class="footer-title">Menu</h6>
                    <ul class="footer-links">
                        <li><a href="#hero">Beranda</a></li>
                        <li><a href="#keunggulan">Keunggulan</a></li>
                        <li><a href="#produk">Produk</a></li>
                        <li><a href="#agen">Agen</a></li>
                        <li><a href="#testimoni">Testimoni</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h6 class="footer-title">Layanan</h6>
                    <ul class="footer-links">
                        <li><a href="{{ route('public.products') }}">Produk Kami</a></li>
                        <li><a href="{{ route('public.agents') }}">Cari Agen</a></li>
                        <li><a href="{{ route('register') }}">Daftar Agen</a></li>
                        <li><a href="{{ route('login') }}">Login</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h6 class="footer-title">Hubungi Kami</h6>
                    <div class="footer-contact-item">
                        <i class="fab fa-whatsapp"></i>
                        <span>0822 4392 2576</span>
                    </div>
                    <div class="footer-contact-item">
                        <i class="fas fa-envelope"></i>
                        <span>info@bandarbandeng.com</span>
                    </div>
                    <div class="footer-contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>Kalimantan Timur, Indonesia</span>
                    </div>
                </div>
            </div>
            <div class="footer-bottom text-center">
                <p>&copy; {{ date('Y') }} Bandar Bandeng Kalimantan. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- ======================================================================
         FLOATING WHATSAPP BUTTON
         ====================================================================== -->
    <a href="https://wa.me/622243922576?text=Halo%20Bandar%20Bandeng%2C%20saya%20ingin%20bertanya%20tentang%20produk%20ikan%20bandeng" target="_blank" class="whatsapp-float" aria-label="Chat WhatsApp">
        <i class="fab fa-whatsapp"></i>
        <span class="wa-tooltip">Chat dengan kami</span>
    </a>

    <!-- ======================================================================
         SCRIPTS
         ====================================================================== -->
    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- AOS Animation Library -->
    <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>

    <script>
        // =========================================================================
        // AOS Initialization
        // =========================================================================
        AOS.init({
            duration: 800,
            easing: 'ease-out-cubic',
            once: true,
            offset: 80,
            disable: window.innerWidth < 768 ? 'phone' : false
        });

        // =========================================================================
        // Navbar Scroll Effect
        // =========================================================================
        (function() {
            const navbar = document.getElementById('mainNav');
            const handleScroll = function() {
                if (window.scrollY > 60) {
                    navbar.classList.add('scrolled');
                } else {
                    navbar.classList.remove('scrolled');
                }
            };
            window.addEventListener('scroll', handleScroll, { passive: true });
            handleScroll(); // Initial check
        })();

        // =========================================================================
        // Smooth Scroll for Anchor Links
        // =========================================================================
        document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                const targetEl = document.querySelector(targetId);
                if (targetEl) {
                    const offset = 80;
                    const targetPosition = targetEl.getBoundingClientRect().top + window.pageYOffset - offset;
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });

                    // Close mobile navbar if open
                    const navCollapse = document.getElementById('navContent');
                    const bsCollapse = bootstrap.Collapse.getInstance(navCollapse);
                    if (bsCollapse) {
                        bsCollapse.hide();
                    }
                }
            });
        });

        // =========================================================================
        // Video Play Button
        // =========================================================================
        (function() {
            const playBtn = document.getElementById('playBtn');
            const videoWrapper = document.getElementById('videoWrapper');
            const videoPlaceholder = document.getElementById('videoPlaceholder');

            if (playBtn && videoWrapper && videoPlaceholder) {
                playBtn.addEventListener('click', function() {
                    // Replace placeholder with YouTube iframe
                    const iframe = document.createElement('iframe');
                    iframe.src = 'https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&rel=0';
                    iframe.title = 'Bandar Bandeng - Proses Kami';
                    iframe.style.width = '100%';
                    iframe.style.height = '100%';
                    iframe.style.border = 'none';
                    iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture';
                    iframe.allowFullscreen = true;

                    videoPlaceholder.remove();
                    videoWrapper.appendChild(iframe);
                });
            }
        })();

        // =========================================================================
        // Gallery Lightbox
        // =========================================================================
        (function() {
            const lightboxModal = document.getElementById('lightboxModal');
            const lightboxImage = document.getElementById('lightboxImage');

            if (lightboxModal && lightboxImage) {
                document.querySelectorAll('.gallery-item').forEach(function(item) {
                    item.addEventListener('click', function() {
                        const img = this.querySelector('img');
                        if (img) {
                            lightboxImage.src = img.src;
                            lightboxImage.alt = img.alt;
                        }
                    });
                });

                // Clear image on modal close
                lightboxModal.addEventListener('hidden.bs.modal', function() {
                    lightboxImage.src = '';
                });
            }
        })();

        // =========================================================================
        // Agent Search Filter
        // =========================================================================
        (function() {
            const searchInput = document.getElementById('agentSearch');
            const agentCards = document.querySelectorAll('.agent-card-col');

            if (searchInput && agentCards.length > 0) {
                searchInput.addEventListener('input', function() {
                    const query = this.value.toLowerCase().trim();
                    agentCards.forEach(function(card) {
                        const city = (card.getAttribute('data-city') || '').toLowerCase();
                        const text = card.textContent.toLowerCase();
                        if (query === '' || city.includes(query) || text.includes(query)) {
                            card.style.display = '';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                });
            }
        })();

        // =========================================================================
        // Nutrisi Circle Animation on Scroll
        // =========================================================================
        (function() {
            const circles = document.querySelectorAll('.circle-progress');
            if (circles.length > 0) {
                // Initially hide progress
                circles.forEach(function(circle) {
                    const fullDash = 314.16;
                    circle.style.strokeDasharray = fullDash;
                    circle.style.strokeDashoffset = fullDash;
                });

                const observer = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            const circle = entry.target;
                            const targetOffset = parseFloat(circle.getAttribute('stroke-dashoffset'));
                            circle.style.strokeDashoffset = targetOffset;
                            observer.unobserve(circle);
                        }
                    });
                }, { threshold: 0.5 });

                circles.forEach(function(circle) {
                    observer.observe(circle);
                });
            }
        })();

        // =========================================================================
        // Active Nav Link on Scroll
        // =========================================================================
        (function() {
            const sections = document.querySelectorAll('section[id]');
            const navLinks = document.querySelectorAll('.navbar-landing .nav-link');

            window.addEventListener('scroll', function() {
                let current = '';
                sections.forEach(function(section) {
                    const sectionTop = section.offsetTop - 120;
                    if (window.pageYOffset >= sectionTop) {
                        current = section.getAttribute('id');
                    }
                });

                navLinks.forEach(function(link) {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === '#' + current) {
                        link.classList.add('active');
                    }
                });
            }, { passive: true });
        })();
    </script>

</body>
</html>
