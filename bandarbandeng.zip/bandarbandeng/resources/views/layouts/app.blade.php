<!DOCTYPE html>
<html lang="id" data-bs-theme="{{ $theme ?? 'light' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Bandar Bandeng Kalimantan - Ikan Bandeng Tanpa Duri #1 Kalimantan">
    <meta name="theme-color" content="#0C4B8E">

    <title>@yield('title', 'Bandar Bandeng Kalimantan')</title>

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YcnS/1lP6UZnhILjCwSBETJ8ViQSmelMsmg6" crossorigin="anonymous">

    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossorigin="anonymous" referrerpolicy="no-referrer">

    <!-- AOS (Animate On Scroll) -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">

    @stack('styles')

    <style>
        :root {
            --bbk-blue: #0C4B8E;
            --bbk-blue-light: #1A6FB5;
            --bbk-gold: #D4A017;
            --bbk-gold-light: #F4D03F;
            --bbk-green: #27AE60;
            --bbk-white: #FFFFFF;
        }

        [data-bs-theme="dark"] {
            --bbk-bg: #111827;
            --bbk-surface: #1f2937;
        }

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            padding-bottom: 70px;
        }

        @media (min-width: 768px) {
            body {
                padding-bottom: 0;
            }
        }

        .navbar-bbk {
            background: linear-gradient(135deg, var(--bbk-blue) 0%, var(--bbk-blue-light) 100%);
            box-shadow: 0 2px 15px rgba(12, 75, 142, 0.3);
        }

        .navbar-bbk .navbar-brand {
            font-weight: 800;
            color: var(--bbk-white) !important;
            letter-spacing: 0.5px;
        }

        .navbar-bbk .nav-link {
            color: rgba(255, 255, 255, 0.85) !important;
            font-weight: 500;
            transition: color 0.2s;
        }

        .navbar-bbk .nav-link:hover,
        .navbar-bbk .nav-link.active {
            color: var(--bbk-gold-light) !important;
        }

        .bbk-logo-icon {
            background: var(--bbk-gold);
            color: var(--bbk-blue);
            font-weight: 900;
            font-size: 1.1rem;
            padding: 2px 8px;
            border-radius: 6px;
            margin-right: 8px;
            display: inline-block;
        }

        .dropdown-notification .dropdown-menu {
            width: 340px;
            max-height: 400px;
            overflow-y: auto;
        }

        @media (max-width: 575.98px) {
            .dropdown-notification .dropdown-menu {
                width: 300px;
            }
        }

        .footer-bbk {
            background: linear-gradient(135deg, var(--bbk-blue) 0%, #0a3a6e 100%);
            color: rgba(255, 255, 255, 0.85);
            margin-top: auto;
        }

        .footer-bbk a {
            color: var(--bbk-gold-light);
            text-decoration: none;
            transition: color 0.2s;
        }

        .footer-bbk a:hover {
            color: var(--bbk-white);
        }

        .footer-bbk h6 {
            color: var(--bbk-gold);
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .notification-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            font-size: 0.6rem;
            min-width: 16px;
            height: 16px;
            line-height: 16px;
        }
    </style>
</head>

<body class="{{ $is_dark ?? false ? 'dark' : '' }}">

    <!-- ============================================================
         NAVBAR
         ============================================================ -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-bbk sticky-top">
        <div class="container">
            <!-- Brand -->
            <a class="navbar-brand d-flex align-items-center" href="{{ route('home') }}">
                <span class="bbk-logo-icon">BBK</span>
                <span class="d-none d-sm-inline">Bandar Bandeng</span>
            </a>

            <!-- Mobile Toggle -->
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarMain" aria-controls="navbarMain"
                    aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Nav Content -->
            <div class="collapse navbar-collapse" id="navbarMain">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('home') ? 'active' : '' }}"
                           href="{{ route('home') }}">
                            <i class="fas fa-home me-1"></i> Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('public.products') ? 'active' : '' }}"
                           href="{{ route('public.products') }}">
                            <i class="fas fa-fish me-1"></i> Produk
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link {{ request()->routeIs('public.agents') ? 'active' : '' }}"
                           href="{{ route('public.agents') }}">
                            <i class="fas fa-users me-1"></i> Agen
                        </a>
                    </li>

                    @auth
                        @if(auth()->user()->hasRole('admin'))
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('admin.*') ? 'active' : '' }}"
                                   href="{{ route('admin.dashboard') }}">
                                    <i class="fas fa-tachometer-alt me-1"></i> Admin
                                </a>
                            </li>
                        @elseif(auth()->user()->hasRole('stockist'))
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('stockist.*') ? 'active' : '' }}"
                                   href="{{ route('stockist.dashboard') }}">
                                    <i class="fas fa-tachometer-alt me-1"></i> Stockist
                                </a>
                            </li>
                        @elseif(auth()->user()->hasRole('agent'))
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('agent.*') ? 'active' : '' }}"
                                   href="{{ route('agent.dashboard') }}">
                                    <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                                </a>
                            </li>
                        @elseif(auth()->user()->hasRole('customer'))
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('customer.*') ? 'active' : '' }}"
                                   href="{{ route('customer.dashboard') }}">
                                    <i class="fas fa-tachometer-alt me-1"></i> Dashboard
                                </a>
                            </li>
                        @endif
                    @endauth
                </ul>

                <!-- Right Side: Theme, Notifications, User -->
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    @auth
                        <!-- Theme Toggle -->
                        <li class="nav-item me-2">
                            @include('components.theme-toggle')
                        </li>

                        <!-- Notification Bell -->
                        <li class="nav-item dropdown dropdown-notification me-2">
                            @include('components.notification-bell')
                        </li>

                        <!-- User Dropdown -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center"
                               href="#" id="userDropdown" role="button"
                               data-bs-toggle="dropdown" aria-expanded="false">
                                @if(auth()->user()->avatar)
                                    <img src="{{ auth()->user()->avatar_url }}"
                                         alt="{{ auth()->user()->name }}"
                                         class="rounded-circle me-2"
                                         width="32" height="32"
                                         style="object-fit: cover;">
                                @else
                                    <div class="bg-white text-primary rounded-circle d-flex align-items-center justify-content-center me-2"
                                         style="width:32px; height:32px; font-size:0.85rem; font-weight:700;">
                                        {{ strtoupper(substr(auth()->user()->name, 0, 1)) }}
                                    </div>
                                @endif
                                <span class="d-none d-lg-inline">{{ auth()->user()->name }}</span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li>
                                    <span class="dropdown-header text-truncate" style="max-width: 200px;">
                                        <small class="text-muted">{{ auth()->user()->role_label }}</small>
                                    </span>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item" href="{{ route('profile.index') }}">
                                        <i class="fas fa-user me-2 text-primary"></i> Profil Saya
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="{{ route('wallet.index') }}">
                                        <i class="fas fa-wallet me-2" style="color: var(--bbk-gold);"></i> Dompet
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form action="{{ route('logout') }}" method="POST">
                                        @csrf
                                        <button type="submit" class="dropdown-item text-danger">
                                            <i class="fas fa-sign-out-alt me-2"></i> Keluar
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    @else
                        <!-- Guest: Theme Toggle + Login -->
                        <li class="nav-item me-2">
                            @include('components.theme-toggle')
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-outline-light btn-sm me-2" href="{{ route('login') }}">
                                <i class="fas fa-sign-in-alt me-1"></i> Masuk
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="btn btn-warning btn-sm text-dark fw-bold" href="{{ route('register') }}">
                                <i class="fas fa-user-plus me-1"></i> Daftar
                            </a>
                        </li>
                    @endauth
                </ul>
            </div>
        </div>
    </nav>

    <!-- ============================================================
         FLASH MESSAGES
         ============================================================ -->
    @include('partials.flash-messages')

    <!-- ============================================================
         MAIN CONTENT
         ============================================================ -->
    <main class="flex-grow-1">
        @yield('content')
    </main>

    <!-- ============================================================
         FOOTER
         ============================================================ -->
    <footer class="footer-bbk py-5 d-none d-md-block">
        <div class="container">
            <div class="row g-4">
                <!-- Company Info -->
                <div class="col-lg-4 col-md-6">
                    <h5 class="text-white fw-bold mb-3">
                        <span style="background: var(--bbk-gold); color: var(--bbk-blue); padding: 2px 8px; border-radius: 6px; font-size: 0.9rem; margin-right: 8px;">BBK</span>
                        Bandar Bandeng Kalimantan
                    </h5>
                    <p class="mb-2" style="font-size: 0.9rem;">
                        Ikan Bandeng Tanpa Duri #1 Kalimantan
                    </p>
                    <p class="mb-2" style="font-size: 0.85rem;">
                        Menyediakan ikan bandeng premium tanpa duri, diproses secara higienis
                        dan dikirim langsung dari Kalimantan ke seluruh Indonesia.
                    </p>
                    <div class="mt-3">
                        <a href="https://wa.me/6282243922576" target="_blank" rel="noopener"
                           class="btn btn-sm px-3 fw-bold"
                           style="background: #25D366; color: white; border: none;">
                            <i class="fab fa-whatsapp me-1"></i> 0822 4392 2576
                        </a>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-2 col-md-6">
                    <h6>Menu</h6>
                    <ul class="list-unstyled" style="font-size: 0.9rem;">
                        <li class="mb-2"><a href="{{ route('home') }}">Beranda</a></li>
                        <li class="mb-2"><a href="{{ route('public.products') }}">Produk</a></li>
                        <li class="mb-2"><a href="{{ route('public.agents') }}">Agen</a></li>
                        <li class="mb-2"><a href="{{ route('public.find-agent') }}">Cari Agen</a></li>
                    </ul>
                </div>

                <!-- Account Links -->
                <div class="col-lg-3 col-md-6">
                    <h6>Akun</h6>
                    <ul class="list-unstyled" style="font-size: 0.9rem;">
                        @auth
                            <li class="mb-2"><a href="{{ route('profile.index') }}">Profil</a></li>
                            <li class="mb-2"><a href="{{ route('wallet.index') }}">Dompet</a></li>
                            <li class="mb-2">
                                <form action="{{ route('logout') }}" method="POST" class="d-inline">
                                    @csrf
                                    <a href="#" onclick="this.closest('form').submit(); return false;">Keluar</a>
                                </form>
                            </li>
                        @else
                            <li class="mb-2"><a href="{{ route('login') }}">Masuk</a></li>
                            <li class="mb-2"><a href="{{ route('register') }}">Daftar</a></li>
                        @endauth
                    </ul>
                </div>

                <!-- Contact -->
                <div class="col-lg-3 col-md-6">
                    <h6>Hubungi Kami</h6>
                    <ul class="list-unstyled" style="font-size: 0.9rem;">
                        <li class="mb-2">
                            <i class="fas fa-globe me-2" style="color: var(--bbk-gold-light);"></i>
                            <a href="https://www.bandarbandeng.com" target="_blank" rel="noopener">www.bandarbandeng.com</a>
                        </li>
                        <li class="mb-2">
                            <i class="fab fa-whatsapp me-2" style="color: #25D366;"></i>
                            <a href="https://wa.me/6282243922576" target="_blank" rel="noopener">0822 4392 2576</a>
                        </li>
                        <li class="mb-2">
                            <i class="fas fa-map-marker-alt me-2" style="color: var(--bbk-gold-light);"></i>
                            Kalimantan, Indonesia
                        </li>
                    </ul>
                </div>
            </div>

            <hr style="border-color: rgba(255,255,255,0.15);">

            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start">
                    <small>&copy; {{ date('Y') }} Bandar Bandeng Kalimantan. Hak cipta dilindungi.</small>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <small>
                        <a href="#" class="me-3"><i class="fab fa-facebook-f"></i></a>
                        <a href="#" class="me-3"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="me-3"><i class="fab fa-tiktok"></i></a>
                        <a href="https://wa.me/6282243922576" target="_blank" rel="noopener">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                    </small>
                </div>
            </div>
        </div>
    </footer>

    <!-- ============================================================
         MOBILE BOTTOM NAVIGATION
         ============================================================ -->
    @include('components.bottom-nav')

    <!-- ============================================================
         SCRIPTS
         ============================================================ -->
    <!-- Bootstrap 5.3 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
            crossorigin="anonymous"></script>

    <!-- AOS Init -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            easing: 'ease-in-out',
            once: true,
            offset: 100
        });
    </script>

    <!-- Custom App JS -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    @stack('scripts')
</body>
</html>
