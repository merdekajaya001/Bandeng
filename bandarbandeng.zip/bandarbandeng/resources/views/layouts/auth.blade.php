<!DOCTYPE html>
<html lang="id" data-bs-theme="{{ $theme ?? 'light' }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Bandar Bandeng Kalimantan - Masuk ke akun Anda">
    <meta name="theme-color" content="#0C4B8E">

    <title>@yield('title', 'Masuk - Bandar Bandeng Kalimantan')</title>

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YcnS/1lP6UZnhILjCwSBETJ8ViQSmelMsmg6" crossorigin="anonymous">

    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
          crossorigin="anonymous" referrerpolicy="no-referrer">

    <!-- AOS -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        :root {
            --bbk-blue: #0C4B8E;
            --bbk-blue-light: #1A6FB5;
            --bbk-gold: #D4A017;
            --bbk-gold-light: #F4D03F;
            --bbk-green: #27AE60;
            --bbk-white: #FFFFFF;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, var(--bbk-blue) 0%, var(--bbk-blue-light) 50%, #2980b9 100%);
            background-attachment: fixed;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at 30% 50%, rgba(212, 160, 23, 0.08) 0%, transparent 50%),
                        radial-gradient(circle at 70% 80%, rgba(26, 111, 181, 0.1) 0%, transparent 40%);
            animation: float-bg 20s ease-in-out infinite;
        }

        @keyframes float-bg {
            0%, 100% { transform: translate(0, 0); }
            50% { transform: translate(-3%, -3%); }
        }

        .auth-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 460px;
            padding: 1rem;
        }

        .auth-card {
            background: rgba(255, 255, 255, 0.97);
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.25);
            padding: 2.5rem 2rem;
            backdrop-filter: blur(10px);
        }

        [data-bs-theme="dark"] .auth-card {
            background: rgba(31, 41, 55, 0.97);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
        }

        .auth-logo {
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .auth-logo-icon {
            background: var(--bbk-gold);
            color: var(--bbk-blue);
            font-weight: 900;
            font-size: 1.5rem;
            padding: 6px 14px;
            border-radius: 10px;
            display: inline-block;
        }

        .auth-logo-text {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--bbk-blue);
            margin-left: 10px;
        }

        [data-bs-theme="dark"] .auth-logo-text {
            color: #93c5fd;
        }

        .auth-tagline {
            text-align: center;
            color: #6c757d;
            font-size: 0.85rem;
            margin-top: -0.5rem;
            margin-bottom: 1.5rem;
        }

        .auth-back-home {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.9rem;
        }

        .auth-back-home a {
            color: var(--bbk-blue-light);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s;
        }

        .auth-back-home a:hover {
            color: var(--bbk-gold);
        }

        [data-bs-theme="dark"] .auth-back-home a {
            color: #93c5fd;
        }

        [data-bs-theme="dark"] .auth-back-home a:hover {
            color: var(--bbk-gold-light);
        }

        /* Fish pattern decoration */
        .auth-card::after {
            content: '\f578';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            bottom: -20px;
            right: -10px;
            font-size: 8rem;
            opacity: 0.03;
            transform: rotate(-15deg);
            pointer-events: none;
        }

        .auth-card {
            position: relative;
            overflow: hidden;
        }
    </style>

    @stack('styles')
</head>

<body>
    <div class="auth-wrapper" data-aos="zoom-in" data-aos-duration="600">
        <div class="auth-card">
            <!-- Logo -->
            <div class="auth-logo">
                <a href="{{ route('home') }}" class="text-decoration-none">
                    <span class="auth-logo-icon">BBK</span>
                    <span class="auth-logo-text">Bandar Bandeng</span>
                </a>
            </div>

            <p class="auth-tagline">Ikan Bandeng Tanpa Duri #1 Kalimantan</p>

            <!-- Flash Messages -->
            @include('partials.flash-messages')

            <!-- Content -->
            @yield('content')

            <!-- Back to Home -->
            <div class="auth-back-home">
                <a href="{{ route('home') }}">
                    <i class="fas fa-arrow-left me-1"></i> Kembali ke Beranda
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
            crossorigin="anonymous"></script>

    <!-- AOS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init({ duration: 600, once: true });
    </script>

    @stack('scripts')
</body>
</html>
