@extends('layouts.app')

@section('title', 'Dashboard Pelanggan - Bandar Bandeng Kalimantan')

@push('styles')
<style>
    .sidebar-bbk {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: 260px;
        background: linear-gradient(180deg, #0a3a6e 0%, var(--bbk-blue) 100%);
        color: rgba(255, 255, 255, 0.85);
        overflow-y: auto;
        z-index: 1040;
        transition: transform 0.3s ease;
        padding-top: 70px;
    }

    .sidebar-bbk .sidebar-brand {
        padding: 1rem 1.25rem;
        font-weight: 800;
        font-size: 1.1rem;
        color: var(--bbk-gold-light);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .sidebar-bbk .nav-link {
        color: rgba(255, 255, 255, 0.75);
        padding: 0.65rem 1.25rem;
        font-size: 0.9rem;
        border-radius: 0;
        transition: all 0.2s;
        border-left: 3px solid transparent;
    }

    .sidebar-bbk .nav-link:hover {
        color: var(--bbk-white);
        background: rgba(255, 255, 255, 0.08);
        border-left-color: var(--bbk-gold);
    }

    .sidebar-bbk .nav-link.active {
        color: var(--bbk-gold-light);
        background: rgba(255, 255, 255, 0.1);
        border-left-color: var(--bbk-gold);
        font-weight: 600;
    }

    .sidebar-bbk .nav-link i {
        width: 24px;
        text-align: center;
        margin-right: 10px;
    }

    .sidebar-bbk .nav-section {
        padding: 0.75rem 1.25rem 0.25rem;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: rgba(255, 255, 255, 0.4);
    }

    .main-content-with-sidebar {
        margin-left: 260px;
        min-height: 100vh;
    }

    .breadcrumb-bbk {
        background: transparent;
        padding: 0;
        margin-bottom: 0;
    }

    .breadcrumb-bbk .breadcrumb-item a {
        color: var(--bbk-blue-light);
        text-decoration: none;
        font-size: 0.85rem;
    }

    .breadcrumb-bbk .breadcrumb-item.active {
        font-size: 0.85rem;
    }

    @media (max-width: 991.98px) {
        .sidebar-bbk {
            transform: translateX(-100%);
        }

        .sidebar-bbk.show {
            transform: translateX(0);
        }

        .main-content-with-sidebar {
            margin-left: 0;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1035;
        }

        .sidebar-overlay.show {
            display: block;
        }
    }

    [data-bs-theme="dark"] .main-content-with-sidebar {
        background: #111827;
    }
</style>
@endpush

@section('content')
<!-- Sidebar Overlay (Mobile) -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<!-- Sidebar -->
<aside class="sidebar-bbk" id="customerSidebar">
    <div class="sidebar-brand">
        <i class="fas fa-user me-2"></i> Pelanggan Panel
    </div>

    <nav class="py-2">
        <div class="nav-section">Utama</div>

        <a href="{{ route('customer.dashboard') }}"
           class="nav-link {{ request()->routeIs('customer.dashboard') ? 'active' : '' }}">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>

        <div class="nav-section mt-2">Pesanan</div>

        <a href="{{ route('customer.orders.index') }}"
           class="nav-link {{ request()->routeIs('customer.orders.*') ? 'active' : '' }}">
            <i class="fas fa-receipt"></i> Pesanan Saya
        </a>

        <a href="{{ route('customer.orders.create') }}"
           class="nav-link {{ request()->routeIs('customer.orders.create') ? 'active' : '' }}">
            <i class="fas fa-cart-plus"></i> Buat Pesanan
        </a>

        <div class="nav-section mt-2">Keuangan</div>

        <a href="{{ route('wallet.index') }}"
           class="nav-link {{ request()->routeIs('wallet.*') ? 'active' : '' }}">
            <i class="fas fa-wallet"></i> Dompet
        </a>

        <a href="{{ route('wallet.history') }}"
           class="nav-link {{ request()->routeIs('wallet.history') ? 'active' : '' }}">
            <i class="fas fa-history"></i> Riwayat Dompet
        </a>

        <div class="nav-section mt-2">Akun</div>

        <a href="{{ route('profile.index') }}"
           class="nav-link {{ request()->routeIs('profile.*') ? 'active' : '' }}">
            <i class="fas fa-user-circle"></i> Profil
        </a>
    </nav>
</aside>

<!-- Main Content -->
<div class="main-content-with-sidebar">
    <div class="container-fluid p-3 p-md-4">
        <!-- Top Bar with Sidebar Toggle (Mobile) + Breadcrumb -->
        <div class="d-flex align-items-center mb-3">
            <button class="btn btn-sm btn-outline-primary d-lg-none me-3"
                    onclick="toggleSidebar()">
                <i class="fas fa-bars"></i>
            </button>

            <nav aria-label="breadcrumb" class="flex-grow-1">
                <ol class="breadcrumb breadcrumb-bbk mb-0">
                    <li class="breadcrumb-item">
                        <a href="{{ route('customer.dashboard') }}"><i class="fas fa-home"></i></a>
                    </li>
                    @hasSection('breadcrumb')
                        @yield('breadcrumb')
                    @else
                        <li class="breadcrumb-item active" aria-current="page">
                            @yield('page_title', 'Dashboard')
                        </li>
                    @endif
                </ol>
            </nav>
        </div>

        <!-- Page Header -->
        @hasSection('page_title')
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="mb-0 fw-bold" style="color: var(--bbk-blue);">
                @yield('page_title')
            </h4>
            <div>
                @yield('page_actions')
            </div>
        </div>
        @endhasSection

        <!-- Page Content -->
        @yield('customer_content')
    </div>
</div>
@endsection

@push('scripts')
<script>
    function toggleSidebar() {
        var sidebar = document.getElementById('customerSidebar');
        var overlay = document.getElementById('sidebarOverlay');
        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');
    }

    window.addEventListener('resize', function () {
        if (window.innerWidth >= 992) {
            var sidebar = document.getElementById('customerSidebar');
            var overlay = document.getElementById('sidebarOverlay');
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        }
    });
</script>
@endpush
