@extends('layouts.app')

@section('title', 'Stockist Dashboard - Bandar Bandeng Kalimantan')

@push('styles')
<style>
    .sidebar-bbk {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        width: 260px;
        background: linear-gradient(180deg, #0a3a6e 0%, var(--bbk-blue) 100%);
        color: rgba(255, 255, 255, 0.85);
        overflow-y: auto;
        z-index: 1040;
        transition: transform 0.3s ease;
        padding-top: 70px;
    }

    .sidebar-bbk .sidebar-brand {
        padding: 1rem 1.25rem;
        font-weight: 800;
        font-size: 1.1rem;
        color: var(--bbk-gold-light);
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .sidebar-bbk .nav-link {
        color: rgba(255, 255, 255, 0.75);
        padding: 0.65rem 1.25rem;
        font-size: 0.9rem;
        border-radius: 0;
        transition: all 0.2s;
        border-left: 3px solid transparent;
    }

    .sidebar-bbk .nav-link:hover {
        color: var(--bbk-white);
        background: rgba(255, 255, 255, 0.08);
        border-left-color: var(--bbk-gold);
    }

    .sidebar-bbk .nav-link.active {
        color: var(--bbk-gold-light);
        background: rgba(255, 255, 255, 0.1);
        border-left-color: var(--bbk-gold);
        font-weight: 600;
    }

    .sidebar-bbk .nav-link i {
        width: 24px;
        text-align: center;
        margin-right: 10px;
    }

    .sidebar-bbk .nav-section {
        padding: 0.75rem 1.25rem 0.25rem;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 1.5px;
        color: rgba(255, 255, 255, 0.4);
    }

    .main-content-with-sidebar {
        margin-left: 260px;
        min-height: 100vh;
    }

    .breadcrumb-bbk {
        background: transparent;
        padding: 0;
        margin-bottom: 0;
    }

    .breadcrumb-bbk .breadcrumb-item a {
        color: var(--bbk-blue-light);
        text-decoration: none;
        font-size: 0.85rem;
    }

    .breadcrumb-bbk .breadcrumb-item.active {
        font-size: 0.85rem;
    }

    @media (max-width: 991.98px) {
        .sidebar-bbk {
            transform: translateX(-100%);
        }

        .sidebar-bbk.show {
            transform: translateX(0);
        }

        .main-content-with-sidebar {
            margin-left: 0;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1035;
        }

        .sidebar-overlay.show {
            display: block;
        }
    }

    [data-bs-theme="dark"] .main-content-with-sidebar {
        background: #111827;
    }
</style>
@endpush

@section('content')
<!-- Sidebar Overlay (Mobile) -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleSidebar()"></div>

<!-- Sidebar -->
<aside class="sidebar-bbk" id="stockistSidebar">
    <div class="sidebar-brand">
        <i class="fas fa-warehouse me-2"></i> Stockist Panel
    </div>

    <nav class="py-2">
        <div class="nav-section">Utama</div>

        <a href="{{ route('stockist.dashboard') }}"
           class="nav-link {{ request()->routeIs('stockist.dashboard') ? 'active' : '' }}">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>

        <div class="nav-section mt-2">Stok</div>

        <a href="{{ route('stockist.stock.index') }}"
           class="nav-link {{ request()->routeIs('stockist.stock.index') && !request()->routeIs('stockist.stock.order') ? 'active' : '' }}">
            <i class="fas fa-cubes"></i> Stok Saya
        </a>

        <a href="{{ route('stockist.stock.order') }}"
           class="nav-link {{ request()->routeIs('stockist.stock.order') ? 'active' : '' }}">
            <i class="fas fa-cart-plus"></i> Pesan ke Admin
        </a>

        <div class="nav-section mt-2">Pesanan</div>

        <a href="{{ route('stockist.orders.index') }}"
           class="nav-link {{ request()->routeIs('stockist.orders.*') ? 'active' : '' }}">
            <i class="fas fa-receipt"></i> Pesanan Masuk
        </a>

        <div class="nav-section mt-2">Keuangan</div>

        <a href="{{ route('wallet.index') }}"
           class="nav-link {{ request()->routeIs('wallet.*') ? 'active' : '' }}">
            <i class="fas fa-wallet"></i> Dompet
        </a>

        <a href="{{ route('withdrawal.create') }}"
           class="nav-link {{ request()->routeIs('withdrawal.*') ? 'active' : '' }}">
            <i class="fas fa-money-bill-wave"></i> Tarik Dana
        </a>
    </nav>
</aside>

<!-- Main Content -->
<div class="main-content-with-sidebar">
    <div class="container-fluid p-3 p-md-4">
        <!-- Top Bar with Sidebar Toggle (Mobile) + Breadcrumb -->
        <div class="d-flex align-items-center mb-3">
            <button class="btn btn-sm btn-outline-primary d-lg-none me-3"
                    onclick="toggleSidebar()">
                <i class="fas fa-bars"></i>
            </button>

            <nav aria-label="breadcrumb" class="flex-grow-1">
                <ol class="breadcrumb breadcrumb-bbk mb-0">
                    <li class="breadcrumb-item">
                        <a href="{{ route('stockist.dashboard') }}"><i class="fas fa-home"></i></a>
                    </li>
                    @hasSection('breadcrumb')
                        @yield('breadcrumb')
                    @else
                        <li class="breadcrumb-item active" aria-current="page">
                            @yield('page_title', 'Dashboard')
                        </li>
                    @endif
                </ol>
            </nav>
        </div>

        <!-- Page Header -->
        @hasSection('page_title')
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h4 class="mb-0 fw-bold" style="color: var(--bbk-blue);">
                @yield('page_title')
            </h4>
            <div>
                @yield('page_actions')
            </div>
        </div>
        @endhasSection

        <!-- Page Content -->
        @yield('stockist_content')
    </div>
</div>
@endsection

@push('scripts')
<script>
    function toggleSidebar() {
        var sidebar = document.getElementById('stockistSidebar');
        var overlay = document.getElementById('sidebarOverlay');
        sidebar.classList.toggle('show');
        overlay.classList.toggle('show');
    }

    window.addEventListener('resize', function () {
        if (window.innerWidth >= 992) {
            var sidebar = document.getElementById('stockistSidebar');
            var overlay = document.getElementById('sidebarOverlay');
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        }
    });
</script>
@endpush
