@php
    $flashTypes = [
        'success' => [
            'class' => 'alert-success',
            'icon' => 'fa-check-circle',
            'iconColor' => '#27AE60',
        ],
        'error' => [
            'class' => 'alert-danger',
            'icon' => 'fa-times-circle',
            'iconColor' => '#e74c3c',
        ],
        'warning' => [
            'class' => 'alert-warning',
            'icon' => 'fa-exclamation-triangle',
            'iconColor' => '#D4A017',
        ],
        'info' => [
            'class' => 'alert-info',
            'icon' => 'fa-info-circle',
            'iconColor' => '#1A6FB5',
        ],
    ];
@endphp

@foreach ($flashTypes as $type => $config)
    @if(session()->has($type))
        <div class="container mt-3">
            <div class="alert {{ $config['class'] }} alert-dismissible fade show d-flex align-items-start shadow-sm"
                 role="alert"
                 data-flash-type="{{ $type }}"
                 style="border-radius: 12px; border: none;">

                <i class="fas {{ $config['icon'] }} me-3 mt-1"
                   style="font-size: 1.2rem; color: {{ $config['iconColor'] }};"></i>

                <div class="flex-grow-1">
                    <strong class="text-capitalize">{{ $type === 'error' ? 'Kesalahan' : $type }}</strong>
                    <div style="font-size: 0.9rem;">{{ session($type) }}</div>
                </div>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    @endif
@endforeach

{{-- Also check for 'message' key as a generic flash --}}
@if(session()->has('message'))
    <div class="container mt-3">
        <div class="alert alert-info alert-dismissible fade show d-flex align-items-start shadow-sm"
             role="alert"
             data-flash-type="message"
             style="border-radius: 12px; border: none;">

            <i class="fas fa-info-circle me-3 mt-1"
               style="font-size: 1.2rem; color: #1A6FB5;"></i>

            <div class="flex-grow-1">
                <strong>Informasi</strong>
                <div style="font-size: 0.9rem;">{{ session('message') }}</div>
            </div>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
@endif

{{-- Check for validation errors --}}
@if($errors->any())
    <div class="container mt-3">
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-start shadow-sm"
             role="alert"
             data-flash-type="validation"
             style="border-radius: 12px; border: none;">

            <i class="fas fa-exclamation-circle me-3 mt-1"
               style="font-size: 1.2rem; color: #e74c3c;"></i>

            <div class="flex-grow-1">
                <strong>Kesalahan Validasi</strong>
                <ul class="mb-0 mt-1" style="font-size: 0.9rem; padding-left: 1rem;">
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
@endif

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Auto-dismiss flash messages after 5 seconds
        var alerts = document.querySelectorAll('[data-flash-type]');
        alerts.forEach(function (alert) {
            setTimeout(function () {
                var bsAlert = bootstrap.Alert.getOrCreateInstance(alert);
                bsAlert.close();
            }, 5000);
        });
    });
</script>
@endpush
