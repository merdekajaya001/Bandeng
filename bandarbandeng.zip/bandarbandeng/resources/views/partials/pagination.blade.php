@php
    /*
    |-------------------------------------------------------------
    | Custom Pagination Partial — Bandar Bandeng Kalimantan
    |-------------------------------------------------------------
    |
    | Usage:
    |   @include('partials.pagination', ['paginator' => $items])
    |
    | The $paginator should be a Laravel LengthAwarePaginator instance.
    | This partial renders Bootstrap 5-styled pagination with:
    |   - Previous/Next buttons with icons
    |   - Page number links
    |   - Ellipsis for large page ranges
    |   - Active page highlighting with brand colors
    |   - Responsive: simplified on mobile
    |
    */

    if (!isset($paginator) || !$paginator instanceof \Illuminate\Pagination\LengthAwarePaginator) {
        return;
    }

    $paginator->withPath(request()->url());
    $elements = $paginator->linkCollection()->toArray();
@endphp

@if($paginator->hasPages())
<nav aria-label="Navigasi halaman" class="d-flex justify-content-center mt-4">
    <ul class="pagination pagination-sm mb-0">

        {{-- Previous Page Button --}}
        <li class="page-item {{ $paginator->onFirstPage() ? 'disabled' : '' }}">
            @if ($paginator->onFirstPage())
                <span class="page-link" aria-disabled="true">
                    <i class="fas fa-chevron-left me-1"></i>
                    <span class="d-none d-sm-inline">Sebelumnya</span>
                </span>
            @else
                <a class="page-link" href="{{ $paginator->previousPageUrl() }}" rel="prev"
                   aria-label="Halaman sebelumnya">
                    <i class="fas fa-chevron-left me-1"></i>
                    <span class="d-none d-sm-inline">Sebelumnya</span>
                </a>
            @endif
        </li>

        {{-- Page Number Links --}}
        @foreach ($elements as $element)
            @if (is_array($element))
                {{-- Array of page numbers --}}
                @foreach ($element as $page => $url)
                    @if ($page == $paginator->currentPage())
                        <li class="page-item active" aria-current="page">
                            <span class="page-link fw-bold">{{ $page }}</span>
                        </li>
                    @else
                        <li class="page-item d-none d-sm-block">
                            <a class="page-link" href="{{ $url }}">{{ $page }}</a>
                        </li>
                    @endif
                @endforeach
            @else
                {{-- Ellipsis ("...") --}}
                <li class="page-item disabled d-none d-sm-block">
                    <span class="page-link">&hellip;</span>
                </li>
            @endif
        @endforeach

        {{-- Mobile: Show current page indicator --}}
        <li class="page-item d-sm-none disabled">
            <span class="page-link text-dark">
                {{ $paginator->currentPage() }} / {{ $paginator->lastPage() }}
            </span>
        </li>

        {{-- Next Page Button --}}
        <li class="page-item {{ $paginator->hasMorePages() ? '' : 'disabled' }}">
            @if ($paginator->hasMorePages())
                <a class="page-link" href="{{ $paginator->nextPageUrl() }}" rel="next"
                   aria-label="Halaman berikutnya">
                    <span class="d-none d-sm-inline">Selanjutnya</span>
                    <i class="fas fa-chevron-right ms-1"></i>
                </a>
            @else
                <span class="page-link" aria-disabled="true">
                    <span class="d-none d-sm-inline">Selanjutnya</span>
                    <i class="fas fa-chevron-right ms-1"></i>
                </span>
            @endif
        </li>
    </ul>
</nav>

{{-- Page info text --}}
<div class="text-center mt-2 text-muted" style="font-size: 0.8rem;">
    Menampilkan {{ $paginator->firstItem() ?? 0 }} - {{ $paginator->lastItem() ?? 0 }}
    dari {{ $paginator->total() }} data
</div>
@endif

@push('styles')
<style>
    .pagination .page-item.active .page-link {
        background: linear-gradient(135deg, #0C4B8E, #1A6FB5);
        border-color: #0C4B8E;
        color: #fff;
    }

    .pagination .page-link {
        color: #0C4B8E;
        border-radius: 8px;
        margin: 0 2px;
        font-size: 0.85rem;
        padding: 0.35rem 0.7rem;
        border: 1px solid #dee2e6;
        transition: all 0.2s;
    }

    .pagination .page-link:hover {
        background: rgba(12, 75, 142, 0.1);
        border-color: #1A6FB5;
        color: #0C4B8E;
    }

    .pagination .page-item.disabled .page-link {
        color: #adb5bd;
    }

    [data-bs-theme="dark"] .pagination .page-link {
        background: #1f2937;
        border-color: #374151;
        color: #93c5fd;
    }

    [data-bs-theme="dark"] .pagination .page-link:hover {
        background: rgba(59, 130, 246, 0.15);
        border-color: #3b82f6;
        color: #93c5fd;
    }

    [data-bs-theme="dark"] .pagination .page-item.active .page-link {
        background: linear-gradient(135deg, #1A6FB5, #2980b9);
        border-color: #1A6FB5;
        color: #fff;
    }

    [data-bs-theme="dark"] .pagination .page-item.disabled .page-link {
        background: #1f2937;
        color: #4b5563;
    }
</style>
@endpush
