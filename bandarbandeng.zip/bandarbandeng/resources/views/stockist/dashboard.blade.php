@extends('layouts.stockist')

@section('title', 'Dashboard Stockist - Bandar Bandeng Kalimantan')

@section('page_title', 'Dashboard')

@push('styles')
<style>
    .stat-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    }
    .stat-card .stat-icon {
        width: 56px;
        height: 56px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.4rem;
    }
    .stat-card .stat-number {
        font-size: 1.75rem;
        font-weight: 800;
        line-height: 1.2;
    }
    .stat-card .stat-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 500;
    }
    .quick-action-btn {
        border-radius: 12px;
        padding: 1.25rem;
        text-align: center;
        transition: all 0.2s;
        text-decoration: none;
        display: block;
    }
    .quick-action-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0,0,0,0.1);
        color: white;
    }
    .status-badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.3em 0.7em;
        border-radius: 50px;
    }
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
</style>
@endpush

@section('stockist_content')

{{-- Flash Messages --}}
@include('partials.flash-messages')

{{-- Stat Cards --}}
<div class="row g-3 mb-4">
    {{-- Stok Saya --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(12,75,142,0.12); color: #0C4B8E;">
                    <i class="fas fa-cubes"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #0C4B8E;">
                        {{ number_format($stats['total_stock'] ?? 0) }}
                    </div>
                    <div class="stat-label">Stok Saya</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Pesanan Masuk --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                    <i class="fas fa-inbox"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #D4A017;">
                        {{ number_format($stats['incoming_orders'] ?? 0) }}
                    </div>
                    <div class="stat-label">Pesanan Masuk</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Pesanan ke Admin --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(39,174,96,0.12); color: #27AE60;">
                    <i class="fas fa-truck"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #27AE60;">
                        {{ number_format($stats['outgoing_orders'] ?? 0) }}
                    </div>
                    <div class="stat-label">Pesanan ke Admin</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Saldo Dompet --}}
    <div class="col-xl-3 col-md-6">
        <div class="card stat-card shadow-sm">
            <div class="card-body d-flex align-items-center p-3">
                <div class="stat-icon me-3" style="background: rgba(108,117,125,0.12); color: #6c757d;">
                    <i class="fas fa-wallet"></i>
                </div>
                <div>
                    <div class="stat-number" style="color: #495057; font-size: 1.35rem;">
                        Rp {{ number_format($stats['wallet_balance'] ?? 0, 0, ',', '.') }}
                    </div>
                    <div class="stat-label">Saldo Dompet</div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Quick Actions --}}
<div class="row g-3 mb-4">
    <div class="col-md-6">
        <a href="{{ route('stockist.stock.order') }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); color: white;">
            <i class="fas fa-cart-plus fa-2x mb-2"></i>
            <div class="fw-bold">Pesan ke Admin</div>
            <small style="opacity: 0.8;">Pesan stok produk dari admin pusat</small>
        </a>
    </div>
    <div class="col-md-6">
        <a href="{{ route('stockist.orders.index', ['tab' => 'incoming']) }}" class="quick-action-btn card shadow-sm"
           style="background: linear-gradient(135deg, #D4A017 0%, #F4D03F 100%); color: #333;">
            <i class="fas fa-clipboard-list fa-2x mb-2"></i>
            <div class="fw-bold">Lihat Pesanan Masuk</div>
            <small style="opacity: 0.8;">Kelola pesanan dari agen</small>
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    {{-- Recent Incoming Orders (from Agents) --}}
    <div class="col-lg-6">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-inbox me-2"></i>Pesanan Masuk (dari Agen)
                </h6>
                <a href="{{ route('stockist.orders.index', ['tab' => 'incoming']) }}" class="btn btn-sm btn-outline-primary" style="border-radius: 8px;">
                    Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="font-size: 0.8rem;">No. Pesanan</th>
                                <th style="font-size: 0.8rem;">Agen</th>
                                <th style="font-size: 0.8rem;" class="text-center">Status</th>
                                <th style="font-size: 0.8rem;" class="text-end pe-3">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($incomingOrders ?? [] as $order)
                            @php
                                $statusConfig = [
                                    'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
                                    'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
                                    'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                                    'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                                    'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                                    'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                                ];
                                $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
                            @endphp
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                        #{{ $order->order_number ?? $order->id }}
                                    </a>
                                </td>
                                <td>{{ $order->buyer->name ?? '-' }}</td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                                        <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                                    </span>
                                </td>
                                <td class="text-end fw-semibold pe-3">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">
                                    <i class="fas fa-inbox fa-2x mb-2 d-block opacity-50"></i>
                                    Belum ada pesanan masuk
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- Recent Outgoing Orders (to Admin) --}}
    <div class="col-lg-6">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #D4A017;">
                    <i class="fas fa-truck me-2"></i>Pesanan ke Admin
                </h6>
                <a href="{{ route('stockist.orders.index', ['tab' => 'outgoing']) }}" class="btn btn-sm btn-outline-warning" style="border-radius: 8px;">
                    Lihat Semua <i class="fas fa-arrow-right ms-1"></i>
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="font-size: 0.8rem;">No. Pesanan</th>
                                <th style="font-size: 0.8rem;" class="text-center">Status</th>
                                <th style="font-size: 0.8rem;" class="text-center">Pembayaran</th>
                                <th style="font-size: 0.8rem;" class="text-end pe-3">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($outgoingOrders ?? [] as $order)
                            @php
                                $statusConfig2 = [
                                    'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
                                    'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
                                    'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                                    'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                                    'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                                    'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                                ];
                                $sc2 = $statusConfig2[$order->status ?? 'pending'] ?? $statusConfig2['pending'];
                                $payStatusConfig = [
                                    'pending'  => ['color' => 'secondary', 'label' => 'Menunggu'],
                                    'paid'     => ['color' => 'success', 'label' => 'Dibayar'],
                                    'verified' => ['color' => 'success', 'label' => 'Terverifikasi'],
                                    'rejected' => ['color' => 'danger', 'label' => 'Ditolak'],
                                ];
                                $psc = $payStatusConfig[$order->payment->status ?? 'pending'] ?? $payStatusConfig['pending'];
                            @endphp
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                        #{{ $order->order_number ?? $order->id }}
                                    </a>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $sc2['color'] }} bg-opacity-10 text-{{ $sc2['color'] }}">
                                        <i class="fas fa-{{ $sc2['icon'] }} me-1"></i>{{ $sc2['label'] }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $psc['color'] }} bg-opacity-10 text-{{ $psc['color'] }}">
                                        {{ $psc['label'] }}
                                    </span>
                                </td>
                                <td class="text-end fw-semibold pe-3">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">
                                    <i class="fas fa-truck fa-2x mb-2 d-block opacity-50"></i>
                                    Belum ada pesanan ke admin
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
