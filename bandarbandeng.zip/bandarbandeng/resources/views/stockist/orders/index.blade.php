@extends('layouts.stockist')

@section('title', 'Pesanan - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Pesanan</li>
@endsection

@section('page_title', 'Pesanan')

@push('styles')
<style>
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .status-badge {
        font-size: 0.75rem;
        font-weight: 600;
        padding: 0.35em 0.75em;
        border-radius: 50px;
    }
    .filter-input {
        border-radius: 10px;
        border: 2px solid #e9ecef;
    }
    .filter-input:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.1);
    }
    .nav-tabs-bbk {
        border-bottom: 2px solid #e9ecef;
    }
    .nav-tabs-bbk .nav-link {
        border: none;
        border-bottom: 3px solid transparent;
        color: #6c757d;
        font-weight: 600;
        padding: 0.75rem 1.25rem;
        transition: all 0.2s;
        border-radius: 0;
    }
    .nav-tabs-bbk .nav-link:hover {
        color: #0C4B8E;
        border-bottom-color: rgba(12,75,142,0.3);
    }
    .nav-tabs-bbk .nav-link.active {
        color: #0C4B8E;
        border-bottom-color: #0C4B8E;
        background: transparent;
    }
    .tab-count {
        font-size: 0.72rem;
        padding: 0.15em 0.55em;
        border-radius: 50px;
        background: rgba(12,75,142,0.1);
        color: #0C4B8E;
        font-weight: 700;
        margin-left: 6px;
    }
</style>
@endpush

@section('stockist_content')

@include('partials.flash-messages')

{{-- Tabs: Semua, Dari Agen, Ke Admin --}}
<ul class="nav nav-tabs nav-tabs-bbk mb-4" id="orderTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link {{ (request('tab') === '' || request('tab') === null) ? 'active' : '' }}"
                id="all-tab" data-bs-toggle="tab" data-bs-target="#all-orders"
                type="button" role="tab" aria-controls="all-orders"
                aria-selected="{{ (request('tab') === '' || request('tab') === null) ? 'true' : 'false' }}"
                onclick="switchTab('')">
            <i class="fas fa-list me-1"></i> Semua
            <span class="tab-count">{{ ($allOrders ?? collect())->count() }}</span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link {{ request('tab') === 'incoming' ? 'active' : '' }}"
                id="incoming-tab" data-bs-toggle="tab" data-bs-target="#incoming-orders"
                type="button" role="tab" aria-controls="incoming-orders"
                aria-selected="{{ request('tab') === 'incoming' ? 'true' : 'false' }}"
                onclick="switchTab('incoming')">
            <i class="fas fa-inbox me-1"></i> Dari Agen
            <span class="tab-count">{{ ($incomingOrders ?? collect())->count() }}</span>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link {{ request('tab') === 'outgoing' ? 'active' : '' }}"
                id="outgoing-tab" data-bs-toggle="tab" data-bs-target="#outgoing-orders"
                type="button" role="tab" aria-controls="outgoing-orders"
                aria-selected="{{ request('tab') === 'outgoing' ? 'true' : 'false' }}"
                onclick="switchTab('outgoing')">
            <i class="fas fa-truck me-1"></i> Ke Admin
            <span class="tab-count">{{ ($outgoingOrders ?? collect())->count() }}</span>
        </button>
    </li>
</ul>

{{-- Filters --}}
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('stockist.orders.index') }}" class="row g-2 align-items-end" id="filterForm">
            <input type="hidden" name="tab" id="tabInput" value="{{ request('tab', '') }}">
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Status</label>
                <select name="status" class="form-select filter-input">
                    <option value="">Semua Status</option>
                    <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Pending</option>
                    <option value="processing" {{ request('status') === 'processing' ? 'selected' : '' }}>Diproses</option>
                    <option value="shipped" {{ request('status') === 'shipped' ? 'selected' : '' }}>Dikirim</option>
                    <option value="delivered" {{ request('status') === 'delivered' ? 'selected' : '' }}>Diterima</option>
                    <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Selesai</option>
                    <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>Dibatalkan</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Dari Tanggal</label>
                <input type="date" name="date_from" class="form-control filter-input" value="{{ request('date_from') }}">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold small mb-1">Sampai Tanggal</label>
                <input type="date" name="date_to" class="form-control filter-input" value="{{ request('date_to') }}">
            </div>
            <div class="col-md-3">
                <label class="form-label fw-semibold small mb-1">Cari</label>
                <input type="text" name="search" class="form-control filter-input"
                       placeholder="No. pesanan / nama..." value="{{ request('search') }}">
            </div>
            <div class="col-md-1">
                <button type="submit" class="btn w-100 text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
                    <i class="fas fa-search"></i>
                </button>
            </div>
            <div class="col-md-2">
                <a href="{{ route('stockist.orders.index') }}" class="btn btn-outline-secondary w-100 fw-bold" style="border-radius: 10px;">
                    <i class="fas fa-undo me-1"></i> Reset
                </a>
            </div>
        </form>
    </div>
</div>

{{-- Tab Content --}}
<div class="tab-content" id="orderTabContent">

    {{-- All Orders Tab --}}
    <div class="tab-pane fade {{ (request('tab') === '' || request('tab') === null) ? 'show active' : '' }}"
         id="all-orders" role="tabpanel" aria-labelledby="all-tab">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">No. Pesanan</th>
                                <th>Tipe</th>
                                <th>Pembeli / Penerima</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Pembayaran</th>
                                <th class="text-end">Total</th>
                                <th>Tanggal</th>
                                <th class="text-center pe-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($allOrders ?? [] as $order)
                            @php
                                $statusConfig = [
                                    'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
                                    'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
                                    'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                                    'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                                    'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                                    'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                                ];
                                $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
                                $payStatusConfig = [
                                    'pending'  => ['color' => 'secondary', 'label' => 'Menunggu'],
                                    'paid'     => ['color' => 'success', 'label' => 'Dibayar'],
                                    'verified' => ['color' => 'success', 'label' => 'Terverifikasi'],
                                    'rejected' => ['color' => 'danger', 'label' => 'Ditolak'],
                                ];
                                $psc = $payStatusConfig[$order->payment->status ?? 'pending'] ?? $payStatusConfig['pending'];
                                $orderType = ($order->type ?? '') === 'incoming' ? 'incoming' : 'outgoing';
                            @endphp
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                        #{{ $order->order_number ?? $order->id }}
                                    </a>
                                </td>
                                <td>
                                    @if($orderType === 'incoming')
                                        <span class="badge bg-info bg-opacity-10 text-info">
                                            <i class="fas fa-inbox me-1"></i>Dari Agen
                                        </span>
                                    @else
                                        <span class="badge bg-warning bg-opacity-10 text-warning">
                                            <i class="fas fa-truck me-1"></i>Ke Admin
                                        </span>
                                    @endif
                                </td>
                                <td>
                                    <div class="fw-semibold">{{ $order->buyer->name ?? $order->seller->name ?? '-' }}</div>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                                        <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $psc['color'] }} bg-opacity-10 text-{{ $psc['color'] }}">
                                        {{ $psc['label'] }}
                                    </span>
                                </td>
                                <td class="text-end fw-semibold">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                                <td>
                                    <div style="font-size: 0.88rem;">{{ $order->created_at ? $order->created_at->format('d M Y') : '-' }}</div>
                                    <small class="text-muted">{{ $order->created_at ? $order->created_at->format('H:i') : '' }}</small>
                                </td>
                                <td class="text-center pe-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}"
                                       class="btn btn-sm btn-outline-primary" style="border-radius: 8px;" title="Detail">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="8" class="text-center text-muted py-5">
                                    <i class="fas fa-receipt fa-3x mb-3 d-block opacity-50"></i>
                                    <p class="mb-1 fw-semibold">Belum ada pesanan</p>
                                    <small>Pesanan yang masuk akan tampil di sini</small>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- Incoming Orders Tab (from Agents) --}}
    <div class="tab-pane fade {{ request('tab') === 'incoming' ? 'show active' : '' }}"
         id="incoming-orders" role="tabpanel" aria-labelledby="incoming-tab">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
                    <i class="fas fa-inbox me-2"></i>Pesanan dari Agen
                </h6>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">No. Pesanan</th>
                                <th>Agen</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Pembayaran</th>
                                <th class="text-end">Total</th>
                                <th>Tanggal</th>
                                <th class="text-center pe-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($incomingOrders ?? [] as $order)
                            @php
                                $statusConfigInc = [
                                    'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
                                    'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
                                    'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                                    'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                                    'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                                    'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                                ];
                                $scInc = $statusConfigInc[$order->status ?? 'pending'] ?? $statusConfigInc['pending'];
                                $pscInc = $payStatusConfig[$order->payment->status ?? 'pending'] ?? $payStatusConfig['pending'];
                            @endphp
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                        #{{ $order->order_number ?? $order->id }}
                                    </a>
                                </td>
                                <td>
                                    <div class="fw-semibold">{{ $order->buyer->name ?? '-' }}</div>
                                    <small class="text-muted">{{ $order->buyer->phone ?? '' }}</small>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $scInc['color'] }} bg-opacity-10 text-{{ $scInc['color'] }}">
                                        <i class="fas fa-{{ $scInc['icon'] }} me-1"></i>{{ $scInc['label'] }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $pscInc['color'] }} bg-opacity-10 text-{{ $pscInc['color'] }}">
                                        {{ $pscInc['label'] }}
                                    </span>
                                </td>
                                <td class="text-end fw-semibold">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                                <td>
                                    <div style="font-size: 0.88rem;">{{ $order->created_at ? $order->created_at->format('d M Y') : '-' }}</div>
                                    <small class="text-muted">{{ $order->created_at ? $order->created_at->format('H:i') : '' }}</small>
                                </td>
                                <td class="text-center pe-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}"
                                       class="btn btn-sm btn-outline-primary" style="border-radius: 8px;" title="Detail">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    @if(($order->status ?? '') === 'pending')
                                    <form action="{{ route('stockist.orders.process', $order->id) }}" method="POST" class="d-inline">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-outline-success" style="border-radius: 8px;" title="Proses">
                                            <i class="fas fa-play"></i>
                                        </button>
                                    </form>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="7" class="text-center text-muted py-5">
                                    <i class="fas fa-inbox fa-3x mb-3 d-block opacity-50"></i>
                                    <p class="mb-1 fw-semibold">Belum ada pesanan dari agen</p>
                                    <small>Pesanan yang dibuat agen akan muncul di sini</small>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- Outgoing Orders Tab (to Admin) --}}
    <div class="tab-pane fade {{ request('tab') === 'outgoing' ? 'show active' : '' }}"
         id="outgoing-orders" role="tabpanel" aria-labelledby="outgoing-tab">
        <div class="card shadow-sm" style="border-radius: 12px; border: none;">
            <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
                <h6 class="fw-bold mb-0" style="color: #D4A017;">
                    <i class="fas fa-truck me-2"></i>Pesanan ke Admin
                </h6>
                <a href="{{ route('stockist.stock.order') }}" class="btn btn-sm text-white fw-bold" style="background: #0C4B8E; border-radius: 8px;">
                    <i class="fas fa-cart-plus me-1"></i> Buat Pesanan
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3">No. Pesanan</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Pembayaran</th>
                                <th class="text-end">Total</th>
                                <th>Tanggal</th>
                                <th class="text-center pe-3">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($outgoingOrders ?? [] as $order)
                            @php
                                $statusConfigOut = [
                                    'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
                                    'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
                                    'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
                                    'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
                                    'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
                                    'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
                                ];
                                $scOut = $statusConfigOut[$order->status ?? 'pending'] ?? $statusConfigOut['pending'];
                                $pscOut = $payStatusConfig[$order->payment->status ?? 'pending'] ?? $payStatusConfig['pending'];
                            @endphp
                            <tr>
                                <td class="ps-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}" class="fw-semibold text-decoration-none" style="color: #0C4B8E;">
                                        #{{ $order->order_number ?? $order->id }}
                                    </a>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $scOut['color'] }} bg-opacity-10 text-{{ $scOut['color'] }}">
                                        <i class="fas fa-{{ $scOut['icon'] }} me-1"></i>{{ $scOut['label'] }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span class="status-badge badge bg-{{ $pscOut['color'] }} bg-opacity-10 text-{{ $pscOut['color'] }}">
                                        {{ $pscOut['label'] }}
                                    </span>
                                </td>
                                <td class="text-end fw-semibold">Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</td>
                                <td>
                                    <div style="font-size: 0.88rem;">{{ $order->created_at ? $order->created_at->format('d M Y') : '-' }}</div>
                                    <small class="text-muted">{{ $order->created_at ? $order->created_at->format('H:i') : '' }}</small>
                                </td>
                                <td class="text-center pe-3">
                                    <a href="{{ route('stockist.orders.show', $order->id) }}"
                                       class="btn btn-sm btn-outline-primary" style="border-radius: 8px;" title="Detail">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    @if(($order->payment->status ?? '') === 'pending' && ($order->status ?? '') !== 'cancelled')
                                    <a href="{{ route('stockist.orders.upload-proof', $order->id) }}"
                                       class="btn btn-sm btn-outline-warning" style="border-radius: 8px;" title="Upload Bukti Bayar">
                                        <i class="fas fa-upload"></i>
                                    </a>
                                    @endif
                                </td>
                            </tr>
                            @empty
                            <tr>
                                <td colspan="6" class="text-center text-muted py-5">
                                    <i class="fas fa-truck fa-3x mb-3 d-block opacity-50"></i>
                                    <p class="mb-1 fw-semibold">Belum ada pesanan ke admin</p>
                                    <a href="{{ route('stockist.stock.order') }}" class="btn btn-sm text-white" style="background: #0C4B8E; border-radius: 8px;">
                                        <i class="fas fa-cart-plus me-1"></i> Pesan Sekarang
                                    </a>
                                </td>
                            </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

{{-- Pagination --}}
@if(isset($allOrders) && method_exists($allOrders, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $allOrders->links() }}
</div>
@endif

@endsection

@push('scripts')
<script>
    function switchTab(tab) {
        document.getElementById('tabInput').value = tab;
    }
</script>
@endpush
