@extends('layouts.stockist')

@section('title', 'Detail Pesanan - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('stockist.orders.index') }}">Pesanan</a></li>
    <li class="breadcrumb-item active" aria-current="page">#{{ $order->order_number ?? $order->id }}</li>
@endsection

@section('page_title', 'Detail Pesanan')

@push('styles')
<style>
    .detail-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.2rem;
    }
    .detail-value {
        font-size: 0.95rem;
        font-weight: 500;
    }
    .status-badge {
        font-size: 0.82rem;
        font-weight: 600;
        padding: 0.4em 1em;
        border-radius: 50px;
    }
    .info-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
    }
    .info-card .card-header {
        font-weight: 700;
        font-size: 0.95rem;
        border-bottom: 2px solid rgba(12,75,142,0.1);
    }
    .proof-image {
        max-width: 250px;
        max-height: 250px;
        border-radius: 10px;
        border: 2px solid #e9ecef;
        cursor: pointer;
        transition: transform 0.2s;
    }
    .proof-image:hover {
        transform: scale(1.02);
    }
    .timeline-item {
        position: relative;
        padding-left: 30px;
        padding-bottom: 1.5rem;
        border-left: 2px solid #e9ecef;
        margin-left: 8px;
    }
    .timeline-item:last-child {
        border-left: 2px solid transparent;
        padding-bottom: 0;
    }
    .timeline-item .timeline-dot {
        position: absolute;
        left: -7px;
        top: 2px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #0C4B8E;
        border: 2px solid white;
    }
    .timeline-item .timeline-dot.inactive {
        background: #e9ecef;
    }
</style>
@endpush

@section('stockist_content')

@include('partials.flash-messages')

@php
    $statusConfig = [
        'pending'    => ['color' => 'secondary', 'icon' => 'clock', 'label' => 'Pending'],
        'processing' => ['color' => 'info', 'icon' => 'cog', 'label' => 'Diproses'],
        'shipped'    => ['color' => 'primary', 'icon' => 'truck', 'label' => 'Dikirim'],
        'delivered'  => ['color' => 'success', 'icon' => 'check-double', 'label' => 'Diterima'],
        'completed'  => ['color' => 'success', 'icon' => 'check-circle', 'label' => 'Selesai'],
        'cancelled'  => ['color' => 'danger', 'icon' => 'times-circle', 'label' => 'Dibatalkan'],
    ];
    $sc = $statusConfig[$order->status ?? 'pending'] ?? $statusConfig['pending'];
    $payStatusConfig = [
        'pending'  => ['color' => 'secondary', 'label' => 'Menunggu'],
        'paid'     => ['color' => 'success', 'label' => 'Dibayar'],
        'verified' => ['color' => 'success', 'label' => 'Terverifikasi'],
        'rejected' => ['color' => 'danger', 'label' => 'Ditolak'],
    ];
    $psc = $payStatusConfig[$order->payment->status ?? 'pending'] ?? $payStatusConfig['pending'];
    $orderType = ($order->type ?? '') === 'incoming' ? 'incoming' : 'outgoing';
@endphp

<div class="row g-4">
    {{-- Main Content --}}
    <div class="col-lg-8">
        {{-- Order Details Card --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
                <span style="color: #0C4B8E;"><i class="fas fa-receipt me-2"></i>Informasi Pesanan</span>
                <div class="d-flex gap-2 align-items-center">
                    @if($orderType === 'incoming')
                        <span class="badge bg-info bg-opacity-10 text-info">
                            <i class="fas fa-inbox me-1"></i>Dari Agen
                        </span>
                    @else
                        <span class="badge bg-warning bg-opacity-10 text-warning">
                            <i class="fas fa-truck me-1"></i>Ke Admin
                        </span>
                    @endif
                    <span class="status-badge badge bg-{{ $sc['color'] }} bg-opacity-10 text-{{ $sc['color'] }}">
                        <i class="fas fa-{{ $sc['icon'] }} me-1"></i>{{ $sc['label'] }}
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="detail-label">No. Pesanan</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">#{{ $order->order_number ?? $order->id }}</div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Tanggal Pesanan</div>
                        <div class="detail-value">{{ $order->created_at ? $order->created_at->format('d F Y, H:i') : '-' }}</div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Tipe Pesanan</div>
                        <div class="detail-value">
                            @if($orderType === 'incoming')
                                <span class="badge bg-info bg-opacity-10 text-info"><i class="fas fa-inbox me-1"></i>Pesanan dari Agen</span>
                            @else
                                <span class="badge bg-warning bg-opacity-10 text-warning"><i class="fas fa-truck me-1"></i>Pesanan ke Admin</span>
                            @endif
                        </div>
                    </div>

                    @if($orderType === 'incoming')
                    <div class="col-md-4">
                        <div class="detail-label">Agen Pembeli</div>
                        <div class="detail-value">
                            <div class="fw-semibold">{{ $order->buyer->name ?? '-' }}</div>
                            <small class="text-muted">{{ $order->buyer->phone ?? '' }}</small>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="detail-label">Email Agen</div>
                        <div class="detail-value">{{ $order->buyer->email ?? '-' }}</div>
                    </div>
                    @else
                    <div class="col-md-4">
                        <div class="detail-label">Admin Penerima</div>
                        <div class="detail-value">
                            <div class="fw-semibold">{{ $order->seller->name ?? 'Admin Pusat' }}</div>
                        </div>
                    </div>
                    @endif

                    @if($order->shipping_address ?? null)
                    <div class="col-md-4">
                        <div class="detail-label">Alamat Pengiriman</div>
                        <div class="detail-value" style="font-size: 0.88rem;">{{ $order->shipping_address }}</div>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        {{-- Items Table --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-box me-2"></i>Item Pesanan
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table mb-0 align-middle">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-3" style="font-size: 0.8rem;">Produk / Varian</th>
                                <th class="text-center" style="font-size: 0.8rem;">Qty</th>
                                <th class="text-end" style="font-size: 0.8rem;">Harga</th>
                                <th class="text-end pe-3" style="font-size: 0.8rem;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->items ?? [] as $item)
                            <tr>
                                <td class="ps-3">
                                    <div class="fw-semibold">{{ $item->productVariant->product->name ?? $item->product_name ?? '-' }}</div>
                                    <small class="text-muted">
                                        <span class="badge" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                                            {{ $item->productVariant->name ?? $item->variant_name ?? '' }}
                                        </span>
                                    </small>
                                </td>
                                <td class="text-center fw-semibold">{{ $item->quantity ?? 1 }}</td>
                                <td class="text-end">Rp {{ number_format($item->price ?? 0, 0, ',', '.') }}</td>
                                <td class="text-end fw-semibold pe-3">Rp {{ number_format($item->subtotal ?? ($item->price * $item->quantity) ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr style="border-top: 2px solid #dee2e6;">
                                <td colspan="3" class="text-end pe-3 pt-3"><strong>Subtotal</strong></td>
                                <td class="text-end pe-3 pt-3 fw-semibold">Rp {{ number_format($order->subtotal ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @if(($order->shipping_cost ?? 0) > 0)
                            <tr>
                                <td colspan="3" class="text-end pe-3"><strong>Ongkos Kirim</strong></td>
                                <td class="text-end pe-3 fw-semibold">Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</td>
                            </tr>
                            @endif
                            @if(($order->discount ?? 0) > 0)
                            <tr>
                                <td colspan="3" class="text-end pe-3 text-danger"><strong>Diskon</strong></td>
                                <td class="text-end pe-3 fw-semibold text-danger">- Rp {{ number_format($order->discount, 0, ',', '.') }}</td>
                            </tr>
                            @endif
                            <tr>
                                <td colspan="3" class="text-end pe-3 pb-3">
                                    <strong style="font-size: 1.1rem; color: #0C4B8E;">Total</strong>
                                </td>
                                <td class="text-end pe-3 pb-3">
                                    <strong style="font-size: 1.1rem; color: #0C4B8E;">
                                        Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}
                                    </strong>
                                </td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        {{-- Order Notes --}}
        @if($order->notes ?? null)
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #6c757d;">
                <i class="fas fa-sticky-note me-2"></i>Catatan Pesanan
            </div>
            <div class="card-body">
                <p class="mb-0" style="font-size: 0.9rem;">{{ $order->notes }}</p>
            </div>
        </div>
        @endif
    </div>

    {{-- Sidebar --}}
    <div class="col-lg-4">
        {{-- Payment Info Card --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #D4A017;">
                <i class="fas fa-credit-card me-2"></i>Informasi Pembayaran
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="detail-label">Metode</div>
                        <div class="detail-value">{{ $order->payment->method_label ?? $order->payment->method ?? 'Transfer Bank' }}</div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Jumlah</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">
                            Rp {{ number_format($order->payment->amount ?? $order->total ?? 0, 0, ',', '.') }}
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Status Bayar</div>
                        <div class="detail-value">
                            <span class="badge bg-{{ $psc['color'] }} bg-opacity-10 text-{{ $psc['color'] }} status-badge">
                                {{ $psc['label'] }}
                            </span>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="detail-label">Tanggal Bayar</div>
                        <div class="detail-value" style="font-size: 0.88rem;">
                            {{ ($order->payment->paid_at ?? null) ? $order->payment->paid_at->format('d M Y, H:i') : '-' }}
                        </div>
                    </div>
                </div>

                @if($order->payment->proof_image ?? null)
                <div class="mt-3">
                    <div class="detail-label mb-2">Bukti Pembayaran</div>
                    <img src="{{ asset('storage/' . $order->payment->proof_image) }}"
                         alt="Bukti Pembayaran" class="proof-image"
                         onclick="window.open(this.src, '_blank')">
                </div>
                @endif
            </div>
        </div>

        {{-- Action Buttons --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-cogs me-2"></i>Aksi
            </div>
            <div class="card-body">

                {{-- Incoming Order Actions (from agents) --}}
                @if($orderType === 'incoming')
                    @if(($order->status ?? '') === 'pending')
                    <form action="{{ route('stockist.orders.process', $order->id) }}" method="POST" class="mb-2">
                        @csrf
                        <button type="submit" class="btn btn-success w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-play me-2"></i>Proses Pesanan
                        </button>
                    </form>
                    @endif

                    @if(($order->status ?? '') === 'processing')
                    <form action="{{ route('stockist.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="shipped">
                        <button type="submit" class="btn btn-primary w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-truck me-2"></i>Tandai Dikirim
                        </button>
                    </form>
                    @endif

                    @if(($order->status ?? '') === 'shipped')
                    <form action="{{ route('stockist.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="delivered">
                        <button type="submit" class="btn btn-info w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-check-double me-2"></i>Tandai Diterima
                        </button>
                    </form>
                    @endif

                    @if(($order->status ?? '') === 'delivered')
                    <form action="{{ route('stockist.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="completed">
                        <button type="submit" class="btn btn-success w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-check-circle me-2"></i>Selesaikan Pesanan
                        </button>
                    </form>
                    @endif

                    @if(in_array($order->status ?? '', ['pending', 'processing']))
                    <form action="{{ route('stockist.orders.update-status', $order->id) }}" method="POST" class="mb-2"
                          onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?')">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="cancelled">
                        <button type="submit" class="btn btn-outline-danger w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-times-circle me-2"></i>Batalkan Pesanan
                        </button>
                    </form>
                    @endif
                @endif

                {{-- Outgoing Order Actions (to admin) --}}
                @if($orderType === 'outgoing')
                    @if(($order->payment->status ?? '') === 'pending' && ($order->status ?? '') !== 'cancelled')
                    <a href="{{ route('stockist.orders.upload-proof', $order->id) }}"
                       class="btn w-100 fw-bold mb-2" style="background: linear-gradient(135deg, #D4A017 0%, #F4D03F 100%); color: #333; border-radius: 10px;">
                        <i class="fas fa-upload me-2"></i>Upload Bukti Pembayaran
                    </a>
                    @endif

                    @if(($order->status ?? '') === 'delivered')
                    <form action="{{ route('stockist.orders.update-status', $order->id) }}" method="POST" class="mb-2">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="completed">
                        <button type="submit" class="btn btn-success w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-check-circle me-2"></i>Konfirmasi Diterima
                        </button>
                    </form>
                    @endif

                    @if(($order->status ?? '') === 'pending')
                    <form action="{{ route('stockist.orders.update-status', $order->id) }}" method="POST" class="mb-2"
                          onsubmit="return confirm('Yakin ingin membatalkan pesanan ini?')">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="status" value="cancelled">
                        <button type="submit" class="btn btn-outline-danger w-100 fw-bold" style="border-radius: 10px;">
                            <i class="fas fa-times-circle me-2"></i>Batalkan Pesanan
                        </button>
                    </form>
                    @endif
                @endif

                <hr>

                {{-- Update Status Dropdown --}}
                <div class="mb-2">
                    <label class="form-label fw-semibold small">Ubah Status Manual</label>
                    <form action="{{ route('stockist.orders.update-status', $order->id) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="input-group">
                            <select name="status" class="form-select" style="border-radius: 10px 0 0 10px;">
                                @foreach($statusConfig as $key => $config)
                                <option value="{{ $key }}" {{ ($order->status ?? '') === $key ? 'selected' : '' }}>
                                    {{ $config['label'] }}
                                </option>
                                @endforeach
                            </select>
                            <button type="submit" class="btn text-white fw-bold" style="background: #0C4B8E; border-radius: 0 10px 10px 0;"
                                    onclick="return confirm('Yakin ingin mengubah status pesanan?')">
                                <i class="fas fa-save"></i>
                            </button>
                        </div>
                    </form>
                </div>

                <hr>

                <a href="javascript:window.print()" class="btn btn-outline-secondary w-100 mb-2" style="border-radius: 10px;">
                    <i class="fas fa-print me-2"></i>Cetak
                </a>

                <a href="{{ route('stockist.orders.index') }}" class="btn btn-outline-primary w-100" style="border-radius: 10px;">
                    <i class="fas fa-arrow-left me-2"></i>Kembali ke Daftar
                </a>
            </div>
        </div>

        {{-- Order Timeline --}}
        <div class="card info-card shadow-sm">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-history me-2"></i>Riwayat Status
            </div>
            <div class="card-body">
                @if($order->statusHistories ?? null)
                    @foreach($order->statusHistories as $history)
                    <div class="timeline-item">
                        <div class="timeline-dot {{ $loop->last ? 'inactive' : '' }}"></div>
                        <div class="fw-semibold" style="font-size: 0.9rem;">
                            {{ $statusConfig[$history->status]['label'] ?? ucfirst($history->status) }}
                        </div>
                        <small class="text-muted">
                            {{ $history->created_at ? $history->created_at->format('d M Y, H:i') : '-' }}
                        </small>
                        @if($history->note ?? null)
                        <div class="text-muted mt-1" style="font-size: 0.82rem;">{{ $history->note }}</div>
                        @endif
                    </div>
                    @endforeach
                @else
                <div class="timeline-item">
                    <div class="timeline-dot"></div>
                    <div class="fw-semibold" style="font-size: 0.9rem;">Pesanan Dibuat</div>
                    <small class="text-muted">
                        {{ $order->created_at ? $order->created_at->format('d M Y, H:i') : '-' }}
                    </small>
                </div>
                <div class="timeline-item">
                    <div class="timeline-dot inactive"></div>
                    <div class="fw-semibold" style="font-size: 0.9rem; color: #6c757d;">
                        Status: {{ $sc['label'] }}
                    </div>
                    <small class="text-muted">Status saat ini</small>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>

@endsection
