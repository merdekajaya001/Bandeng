@extends('layouts.stockist')

@section('title', 'Upload Bukti Pembayaran - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('stockist.orders.index') }}">Pesanan</a></li>
    <li class="breadcrumb-item"><a href="{{ route('stockist.orders.show', $order->id) }}">#{{ $order->order_number ?? $order->id }}</a></li>
    <li class="breadcrumb-item active" aria-current="page">Upload Bukti Bayar</li>
@endsection

@section('page_title', 'Upload Bukti Pembayaran')

@push('styles')
<style>
    .detail-label {
        font-size: 0.82rem;
        color: #6c757d;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 0.2rem;
    }
    .detail-value {
        font-size: 0.95rem;
        font-weight: 500;
    }
    .info-card {
        border: none;
        border-radius: 12px;
        overflow: hidden;
    }
    .info-card .card-header {
        font-weight: 700;
        font-size: 0.95rem;
        border-bottom: 2px solid rgba(12,75,142,0.1);
    }
    .bank-card {
        border: 2px solid #e9ecef;
        border-radius: 12px;
        transition: all 0.2s;
        overflow: hidden;
    }
    .bank-card:hover {
        border-color: rgba(12,75,142,0.3);
        box-shadow: 0 4px 15px rgba(12,75,142,0.08);
    }
    .bank-card .bank-logo {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.3rem;
        font-weight: 800;
    }
    .upload-zone {
        border: 2px dashed rgba(12,75,142,0.3);
        border-radius: 12px;
        padding: 2rem;
        text-align: center;
        transition: all 0.3s;
        cursor: pointer;
        background: linear-gradient(135deg, rgba(12,75,142,0.02) 0%, rgba(212,160,23,0.02) 100%);
    }
    .upload-zone:hover {
        border-color: #0C4B8E;
        background: linear-gradient(135deg, rgba(12,75,142,0.05) 0%, rgba(212,160,23,0.05) 100%);
    }
    .upload-zone.dragover {
        border-color: #0C4B8E;
        background: rgba(12,75,142,0.08);
    }
    .upload-zone.has-file {
        border-color: #27AE60;
        border-style: solid;
        background: rgba(39,174,96,0.03);
    }
    [data-bs-theme="dark"] .upload-zone {
        background: linear-gradient(135deg, rgba(12,75,142,0.08) 0%, rgba(212,160,23,0.05) 100%);
    }
    [data-bs-theme="dark"] .upload-zone:hover {
        background: linear-gradient(135deg, rgba(12,75,142,0.15) 0%, rgba(212,160,23,0.08) 100%);
    }
    .preview-image {
        max-width: 300px;
        max-height: 200px;
        border-radius: 10px;
        border: 2px solid #e9ecef;
    }
</style>
@endpush

@section('stockist_content')

@include('partials.flash-messages')

<div class="row g-4">
    {{-- Left Column: Order Summary + Upload Form --}}
    <div class="col-lg-7">
        {{-- Order Summary --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-receipt me-2"></i>Ringkasan Pesanan
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="detail-label">No. Pesanan</div>
                        <div class="detail-value fw-bold" style="color: #0C4B8E;">#{{ $order->order_number ?? $order->id }}</div>
                    </div>
                    <div class="col-md-6">
                        <div class="detail-label">Tanggal Pesanan</div>
                        <div class="detail-value">{{ $order->created_at ? $order->created_at->format('d F Y, H:i') : '-' }}</div>
                    </div>
                </div>

                <hr>

                {{-- Order Items --}}
                <div class="table-responsive">
                    <table class="table table-sm mb-0 align-middle">
                        <thead>
                            <tr>
                                <th style="font-size: 0.78rem; color: #6c757d;">Produk</th>
                                <th class="text-center" style="font-size: 0.78rem; color: #6c757d;">Qty</th>
                                <th class="text-end" style="font-size: 0.78rem; color: #6c757d;">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->items ?? [] as $item)
                            <tr>
                                <td>
                                    <div class="fw-semibold" style="font-size: 0.88rem;">{{ $item->productVariant->product->name ?? $item->product_name ?? '-' }}</div>
                                    <small class="text-muted">{{ $item->productVariant->name ?? $item->variant_name ?? '' }}</small>
                                </td>
                                <td class="text-center">{{ $item->quantity ?? 1 }}</td>
                                <td class="text-end fw-semibold">Rp {{ number_format($item->subtotal ?? ($item->price * $item->quantity) ?? 0, 0, ',', '.') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <hr>

                <div class="d-flex justify-content-between align-items-center">
                    <span class="fw-bold" style="font-size: 1.1rem;">Total Pembayaran</span>
                    <span class="fw-bold" style="font-size: 1.3rem; color: #0C4B8E;">
                        Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}
                    </span>
                </div>
            </div>
        </div>

        {{-- Upload Payment Proof Form --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #D4A017;">
                <i class="fas fa-upload me-2"></i>Upload Bukti Pembayaran
            </div>
            <div class="card-body">
                <form action="{{ route('stockist.orders.upload-proof', $order->id) }}" method="POST" enctype="multipart/form-data" id="uploadForm">
                    @csrf
                    @method('POST')

                    {{-- Image Upload Zone --}}
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Bukti Transfer / Pembayaran</label>
                        <div class="upload-zone" id="uploadZone" onclick="document.getElementById('proofImage').click()">
                            <div id="uploadPlaceholder">
                                <i class="fas fa-cloud-upload-alt fa-3x mb-3" style="color: rgba(12,75,142,0.3);"></i>
                                <p class="mb-1 fw-semibold" style="color: #0C4B8E;">Klik atau seret gambar ke sini</p>
                                <small class="text-muted">Format: JPG, JPEG, PNG, WEBP (Maks. 2MB)</small>
                            </div>
                            <div id="uploadPreview" style="display: none;">
                                <img id="previewImg" src="" alt="Preview" class="preview-image mb-3">
                                <p class="mb-1 fw-semibold text-success"><i class="fas fa-check-circle me-1"></i>Gambar berhasil dipilih</p>
                                <small class="text-muted" id="fileName"></small>
                            </div>
                        </div>
                        <input type="file" name="proof_image" id="proofImage" accept="image/jpeg,image/png,image/webp"
                               class="d-none" onchange="handleFileSelect(this)" required>
                        @error('proof_image')
                        <div class="text-danger mt-2" style="font-size: 0.85rem;">
                            <i class="fas fa-exclamation-circle me-1"></i>{{ $message }}
                        </div>
                        @enderror
                    </div>

                    {{-- Payment Date --}}
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Tanggal Pembayaran</label>
                        <input type="datetime-local" name="paid_at" class="form-control"
                               style="border-radius: 10px;"
                               value="{{ old('paid_at', now()->format('Y-m-d\TH:i')) }}">
                        @error('paid_at')
                        <div class="text-danger mt-1" style="font-size: 0.85rem;">
                            <i class="fas fa-exclamation-circle me-1"></i>{{ $message }}
                        </div>
                        @enderror
                    </div>

                    {{-- Sender Name --}}
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Pengirim</label>
                        <input type="text" name="sender_name" class="form-control"
                               style="border-radius: 10px;"
                               placeholder="Nama sesuai rekening pengirim"
                               value="{{ old('sender_name', auth()->user()->name ?? '') }}">
                        @error('sender_name')
                        <div class="text-danger mt-1" style="font-size: 0.85rem;">
                            <i class="fas fa-exclamation-circle me-1"></i>{{ $message }}
                        </div>
                        @enderror
                    </div>

                    {{-- Notes --}}
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Catatan (opsional)</label>
                        <textarea name="notes" class="form-control" rows="2"
                                  placeholder="Catatan tambahan untuk admin..."
                                  style="border-radius: 10px;">{{ old('notes') }}</textarea>
                    </div>

                    {{-- Submit Button --}}
                    <button type="submit" class="btn w-100 text-white fw-bold" style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); border-radius: 10px; padding: 0.75rem;"
                            id="submitBtn">
                        <i class="fas fa-paper-plane me-2"></i>Kirim Bukti Pembayaran
                    </button>
                </form>
            </div>
        </div>
    </div>

    {{-- Right Column: Bank Details --}}
    <div class="col-lg-5">
        {{-- Total Payment Highlight --}}
        <div class="card shadow-sm mb-4" style="border-radius: 12px; border: none; background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); color: white;">
            <div class="card-body text-center py-4">
                <div class="small mb-2" style="opacity: 0.8;">Total yang harus dibayar</div>
                <div class="fw-bold" style="font-size: 2rem; line-height: 1.2;">
                    Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}
                </div>
                <div class="mt-2">
                    <small style="opacity: 0.7;">Pesanan #{{ $order->order_number ?? $order->id }}</small>
                </div>
            </div>
        </div>

        {{-- Bank Transfer Details --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #0C4B8E;">
                <i class="fas fa-university me-2"></i>Informasi Rekening Tujuan
            </div>
            <div class="card-body">
                {{-- Bank 1: BCA --}}
                <div class="bank-card p-3 mb-3">
                    <div class="d-flex align-items-center mb-2">
                        <div class="bank-logo me-3" style="background: rgba(0,101,189,0.1); color: #0065BD;">
                            BCA
                        </div>
                        <div>
                            <div class="fw-bold" style="color: #0C4B8E;">Bank BCA</div>
                            <small class="text-muted">Transfer antar bank tersedia</small>
                        </div>
                    </div>
                    <hr class="my-2">
                    <div class="row">
                        <div class="col-6">
                            <div class="detail-label">No. Rekening</div>
                            <div class="detail-value fw-bold" style="color: #0C4B8E; letter-spacing: 1px;">1234 5678 90</div>
                        </div>
                        <div class="col-6">
                            <div class="detail-label">Atas Nama</div>
                            <div class="detail-value">PT Bandar Bandeng</div>
                        </div>
                    </div>
                </div>

                {{-- Bank 2: BRI --}}
                <div class="bank-card p-3 mb-3">
                    <div class="d-flex align-items-center mb-2">
                        <div class="bank-logo me-3" style="background: rgba(0,94,184,0.1); color: #005EB8;">
                            BRI
                        </div>
                        <div>
                            <div class="fw-bold" style="color: #0C4B8E;">Bank BRI</div>
                            <small class="text-muted">Transfer antar bank tersedia</small>
                        </div>
                    </div>
                    <hr class="my-2">
                    <div class="row">
                        <div class="col-6">
                            <div class="detail-label">No. Rekening</div>
                            <div class="detail-value fw-bold" style="color: #0C4B8E; letter-spacing: 1px;">0987 6543 21</div>
                        </div>
                        <div class="col-6">
                            <div class="detail-label">Atas Nama</div>
                            <div class="detail-value">PT Bandar Bandeng</div>
                        </div>
                    </div>
                </div>

                {{-- Bank 3: Mandiri --}}
                <div class="bank-card p-3">
                    <div class="d-flex align-items-center mb-2">
                        <div class="bank-logo me-3" style="background: rgba(0,61,165,0.1); color: #003DA5;">
                            MDR
                        </div>
                        <div>
                            <div class="fw-bold" style="color: #0C4B8E;">Bank Mandiri</div>
                            <small class="text-muted">Transfer antar bank tersedia</small>
                        </div>
                    </div>
                    <hr class="my-2">
                    <div class="row">
                        <div class="col-6">
                            <div class="detail-label">No. Rekening</div>
                            <div class="detail-value fw-bold" style="color: #0C4B8E; letter-spacing: 1px;">1122 3344 55</div>
                        </div>
                        <div class="col-6">
                            <div class="detail-label">Atas Nama</div>
                            <div class="detail-value">PT Bandar Bandeng</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Instructions --}}
        <div class="card info-card shadow-sm mb-4">
            <div class="card-header bg-white py-3" style="color: #D4A017;">
                <i class="fas fa-info-circle me-2"></i>Petunjuk Pembayaran
            </div>
            <div class="card-body">
                <div class="d-flex align-items-start mb-3">
                    <span class="badge me-2 mt-1" style="background: #0C4B8E; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem;">1</span>
                    <div>
                        <div class="fw-semibold" style="font-size: 0.9rem;">Transfer ke rekening tujuan</div>
                        <small class="text-muted">Pilih salah satu rekening di atas</small>
                    </div>
                </div>
                <div class="d-flex align-items-start mb-3">
                    <span class="badge me-2 mt-1" style="background: #0C4B8E; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem;">2</span>
                    <div>
                        <div class="fw-semibold" style="font-size: 0.9rem;">Pastikan nominal sesuai</div>
                        <small class="text-muted">Transfer sesuai total: <strong>Rp {{ number_format($order->total ?? 0, 0, ',', '.') }}</strong></small>
                    </div>
                </div>
                <div class="d-flex align-items-start mb-3">
                    <span class="badge me-2 mt-1" style="background: #0C4B8E; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem;">3</span>
                    <div>
                        <div class="fw-semibold" style="font-size: 0.9rem;">Screenshot bukti transfer</div>
                        <small class="text-muted">Ambil screenshot bukti transfer yang jelas</small>
                    </div>
                </div>
                <div class="d-flex align-items-start">
                    <span class="badge me-2 mt-1" style="background: #0C4B8E; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; font-size: 0.75rem;">4</span>
                    <div>
                        <div class="fw-semibold" style="font-size: 0.9rem;">Upload bukti di formulir</div>
                        <small class="text-muted">Admin akan memverifikasi dalam 1x24 jam</small>
                    </div>
                </div>
            </div>
        </div>

        {{-- Back Button --}}
        <a href="{{ route('stockist.orders.show', $order->id) }}" class="btn btn-outline-primary w-100" style="border-radius: 10px;">
            <i class="fas fa-arrow-left me-2"></i>Kembali ke Detail Pesanan
        </a>
    </div>
</div>

@endsection

@push('scripts')
<script>
    const uploadZone = document.getElementById('uploadZone');
    const proofInput = document.getElementById('proofImage');

    // Drag and drop events
    uploadZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadZone.classList.add('dragover');
    });

    uploadZone.addEventListener('dragleave', function(e) {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
    });

    uploadZone.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadZone.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            proofInput.files = files;
            handleFileSelect(proofInput);
        }
    });

    function handleFileSelect(input) {
        if (input.files && input.files[0]) {
            const file = input.files[0];

            // Validate file type
            const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
            if (!allowedTypes.includes(file.type)) {
                alert('Format file tidak didukung. Gunakan JPG, PNG, atau WEBP.');
                input.value = '';
                return;
            }

            // Validate file size (2MB)
            if (file.size > 2 * 1024 * 1024) {
                alert('Ukuran file terlalu besar. Maksimum 2MB.');
                input.value = '';
                return;
            }

            // Show preview
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('previewImg').src = e.target.result;
                document.getElementById('uploadPlaceholder').style.display = 'none';
                document.getElementById('uploadPreview').style.display = 'block';
                document.getElementById('fileName').textContent = file.name + ' (' + (file.size / 1024).toFixed(1) + ' KB)';
                uploadZone.classList.add('has-file');
            };
            reader.readAsDataURL(file);
        }
    }

    // Form submission with loading state
    document.getElementById('uploadForm').addEventListener('submit', function() {
        const btn = document.getElementById('submitBtn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Mengupload...';
    });
</script>
@endpush
