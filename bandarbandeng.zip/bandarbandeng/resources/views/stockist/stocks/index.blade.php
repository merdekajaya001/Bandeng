@extends('layouts.stockist')

@section('title', 'Stok Saya - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item active" aria-current="page">Stok Saya</li>
@endsection

@section('page_title', 'Stok Saya')

@section('page_actions')
    <a href="{{ route('stockist.stock.order') }}" class="btn text-white fw-bold" style="background: #0C4B8E; border-radius: 10px;">
        <i class="fas fa-cart-plus me-1"></i> Pesan ke Admin
    </a>
@endsection

@push('styles')
<style>
    .stock-indicator {
        height: 6px;
        border-radius: 3px;
        background: #e9ecef;
        overflow: hidden;
    }
    .stock-indicator .fill {
        height: 100%;
        border-radius: 3px;
        transition: width 0.5s ease;
    }
    .table th {
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #6c757d;
        font-weight: 700;
        border-bottom-width: 2px;
    }
    .stock-input {
        width: 90px;
        border-radius: 8px;
        text-align: center;
        font-weight: 700;
    }
    .stock-input:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.12);
    }
    .low-stock-item {
        border-left: 4px solid #dc3545;
        padding: 0.6rem 1rem;
        margin-bottom: 0.5rem;
        background: #fff5f5;
        border-radius: 0 8px 8px 0;
    }
    [data-bs-theme="dark"] .low-stock-item {
        background: rgba(220,53,69,0.1);
    }
</style>
@endpush

@section('stockist_content')

@include('partials.flash-messages')

{{-- Low Stock Alerts --}}
@if(count($lowStocks ?? []) > 0)
<div class="card shadow-sm mb-4" style="border-radius: 12px; border: none;">
    <div class="card-header bg-white border-0 pt-3 pb-0 d-flex justify-content-between align-items-center">
        <h6 class="fw-bold mb-0 text-danger">
            <i class="fas fa-exclamation-triangle me-2"></i>Stok Rendah
        </h6>
        <a href="{{ route('stockist.stock.order') }}" class="btn btn-sm btn-outline-danger" style="border-radius: 8px;">
            <i class="fas fa-cart-plus me-1"></i> Pesan Sekarang
        </a>
    </div>
    <div class="card-body">
        @foreach($lowStocks as $stock)
        <div class="low-stock-item">
            <div class="fw-semibold" style="font-size: 0.9rem;">
                {{ $stock->productVariant->product->name ?? $stock->product_name ?? '-' }}
            </div>
            <div class="d-flex justify-content-between align-items-center mt-1">
                <small class="text-muted">{{ $stock->productVariant->name ?? $stock->variant_name ?? '-' }}</small>
                <span class="badge bg-danger">
                    {{ $stock->available_stock ?? $stock->stock ?? 0 }} tersisa
                </span>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

{{-- Stock Table --}}
<div class="card shadow-sm" style="border-radius: 12px; border: none;">
    <div class="card-header bg-white border-0 pt-3 d-flex justify-content-between align-items-center">
        <h6 class="fw-bold mb-0" style="color: #0C4B8E;">
            <i class="fas fa-cubes me-2"></i>Daftar Stok
        </h6>
        <span class="badge" style="background: rgba(12,75,142,0.1); color: #0C4B8E; font-size: 0.85rem; padding: 0.5em 1em; border-radius: 8px;">
            {{ ($stocks ?? collect())->count() }} varian
        </span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0 align-middle">
                <thead class="table-light">
                    <tr>
                        <th class="ps-3">Varian Produk</th>
                        <th class="text-center">Jumlah Stok</th>
                        <th class="text-center">Stok Terpesan</th>
                        <th class="text-center">Tersedia</th>
                        <th class="text-center" style="min-width: 140px;">Level Stok</th>
                        <th class="text-center pe-3">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($stocks ?? [] as $stock)
                    @php
                        $total = $stock->stock ?? 0;
                        $reserved = $stock->reserved_stock ?? 0;
                        $available = $stock->available_stock ?? ($total - $reserved);
                        $maxStock = max($total, 50);
                        $percentage = $maxStock > 0 ? min(($available / $maxStock) * 100, 100) : 0;
                        $barColor = $available <= 5 ? 'danger' : ($available <= 20 ? 'warning' : 'success');
                    @endphp
                    <tr>
                        <td class="ps-3">
                            <div class="fw-semibold" style="color: #0C4B8E;">
                                {{ $stock->productVariant->product->name ?? $stock->product_name ?? '-' }}
                            </div>
                            <small class="text-muted">
                                <span class="badge" style="background: rgba(212,160,23,0.12); color: #D4A017;">
                                    {{ $stock->productVariant->name ?? $stock->variant_name ?? '-' }}
                                </span>
                            </small>
                        </td>
                        <td class="text-center">
                            <form action="{{ route('stockist.stock.update', $stock->id ?? 0) }}" method="POST" class="d-inline">
                                @csrf
                                @method('PUT')
                                <div class="input-group input-group-sm justify-content-center">
                                    <input type="number" name="stock" class="form-control stock-input"
                                           value="{{ $total }}" min="0">
                                    <button type="submit" class="btn btn-sm btn-outline-primary" title="Simpan"
                                            style="border-radius: 0 8px 8px 0;">
                                        <i class="fas fa-save"></i>
                                    </button>
                                </div>
                            </form>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold text-warning">{{ $reserved }}</span>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold" style="color: {{ $available <= 5 ? '#dc3545' : '#27AE60' }};">
                                {{ $available }}
                            </span>
                        </td>
                        <td class="text-center">
                            <div class="d-flex align-items-center justify-content-center gap-2">
                                <div class="stock-indicator flex-grow-1">
                                    <div class="fill bg-{{ $barColor }}" style="width: {{ $percentage }}%;"></div>
                                </div>
                                <small class="fw-bold text-{{ $barColor }}">{{ $percentage }}%</small>
                            </div>
                        </td>
                        <td class="text-center pe-3">
                            @if($available <= 20)
                            <a href="{{ route('stockist.stock.order') }}" class="btn btn-sm btn-outline-warning" title="Pesan Stok" style="border-radius: 8px;">
                                <i class="fas fa-cart-plus"></i>
                            </a>
                            @else
                            <button type="button" class="btn btn-sm btn-outline-success" title="Stok Aman" disabled style="border-radius: 8px;">
                                <i class="fas fa-check"></i>
                            </button>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-5">
                            <i class="fas fa-cubes fa-3x mb-3 d-block opacity-50"></i>
                            <p class="mb-1 fw-semibold">Belum ada data stok</p>
                            <a href="{{ route('stockist.stock.order') }}" class="btn btn-sm text-white" style="background: #0C4B8E; border-radius: 8px;">
                                <i class="fas fa-cart-plus me-1"></i> Pesan Stok dari Admin
                            </a>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

{{-- Pagination --}}
@if(isset($stocks) && method_exists($stocks, 'links'))
<div class="mt-3 d-flex justify-content-center">
    {{ $stocks->links() }}
</div>
@endif

@endsection
