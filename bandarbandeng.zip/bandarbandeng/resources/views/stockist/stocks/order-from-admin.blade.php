@extends('layouts.stockist')

@section('title', 'Pesan ke Admin - Bandar Bandeng Kalimantan')

@section('breadcrumb')
    <li class="breadcrumb-item"><a href="{{ route('stockist.stock.index') }}">Stok Saya</a></li>
    <li class="breadcrumb-item active" aria-current="page">Pesan ke Admin</li>
@endsection

@section('page_title', 'Pesan ke Admin')

@push('styles')
<style>
    .variant-card {
        border: 2px solid #e9ecef;
        border-radius: 12px;
        transition: all 0.2s;
        overflow: hidden;
    }
    .variant-card:hover {
        border-color: rgba(12,75,142,0.3);
        box-shadow: 0 4px 15px rgba(12,75,142,0.08);
    }
    .variant-card.selected {
        border-color: #0C4B8E;
        box-shadow: 0 4px 15px rgba(12,75,142,0.15);
    }
    .variant-card .card-header {
        background: linear-gradient(135deg, rgba(12,75,142,0.05) 0%, rgba(212,160,23,0.05) 100%);
        border-bottom: 1px solid #e9ecef;
        font-weight: 700;
        color: #0C4B8E;
    }
    [data-bs-theme="dark"] .variant-card .card-header {
        background: rgba(12,75,142,0.15);
    }
    .qty-input {
        width: 80px;
        border-radius: 8px;
        text-align: center;
        font-weight: 700;
        border: 2px solid #e9ecef;
    }
    .qty-input:focus {
        border-color: #0C4B8E;
        box-shadow: 0 0 0 3px rgba(12,75,142,0.12);
    }
    .qty-btn {
        width: 36px;
        height: 36px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        border: 2px solid #e9ecef;
        background: white;
        cursor: pointer;
        transition: all 0.15s;
    }
    .qty-btn:hover {
        border-color: #0C4B8E;
        background: rgba(12,75,142,0.05);
    }
    .order-summary {
        border: none;
        border-radius: 12px;
        position: sticky;
        top: 80px;
    }
    .summary-item {
        display: flex;
        justify-content: space-between;
        padding: 0.5rem 0;
        border-bottom: 1px dashed #e9ecef;
        font-size: 0.9rem;
    }
    .summary-item:last-child {
        border-bottom: none;
    }
    .admin-stock-badge {
        font-size: 0.78rem;
        padding: 0.3em 0.65em;
        border-radius: 6px;
        font-weight: 600;
    }
</style>
@endpush

@section('stockist_content')

@include('partials.flash-messages')

<form action="{{ route('stockist.stock.order.post') }}" method="POST" id="orderForm">
    @csrf

    <div class="row g-4">
        {{-- Product Variant Cards --}}
        <div class="col-lg-8">
            @forelse($productVariants ?? [] as $variant)
            @php
                $adminStock = $variant->adminStock->available_stock ?? $variant->adminStock->stock ?? 0;
                $price = $variant->wholesale_price ?? $variant->price ?? 0;
            @endphp
            <div class="card variant-card shadow-sm mb-3" data-variant-id="{{ $variant->id }}" data-price="{{ $price }}">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <div>
                        <span class="fw-bold">{{ $variant->product->name ?? '-' }}</span>
                        <span class="badge ms-2" style="background: rgba(212,160,23,0.15); color: #D4A017;">
                            {{ $variant->name ?? '-' }}
                        </span>
                    </div>
                    <span class="admin-stock-badge" style="background: rgba(39,174,96,0.1); color: #27AE60;">
                        <i class="fas fa-warehouse me-1"></i>Stok Admin: {{ $adminStock }}
                    </span>
                </div>
                <div class="card-body py-3">
                    <div class="row align-items-center">
                        <div class="col-md-5">
                            <div class="text-muted small mb-1">Harga Grosir</div>
                            <div class="fw-bold" style="color: #0C4B8E; font-size: 1.1rem;">
                                Rp {{ number_format($price, 0, ',', '.') }}
                            </div>
                            @if($variant->unit ?? null)
                            <small class="text-muted">per {{ $variant->unit }}</small>
                            @endif
                        </div>
                        <div class="col-md-4">
                            <div class="text-muted small mb-1">Jumlah Pesan</div>
                            <div class="d-flex align-items-center gap-2">
                                <button type="button" class="qty-btn" onclick="changeQty({{ $variant->id }}, -1)">
                                    <i class="fas fa-minus"></i>
                                </button>
                                <input type="number" name="quantities[{{ $variant->id }}]"
                                       class="form-control qty-input"
                                       value="0" min="0" max="{{ $adminStock }}"
                                       data-variant-id="{{ $variant->id }}"
                                       data-price="{{ $price }}"
                                       onchange="updateSummary()">
                                <button type="button" class="qty-btn" onclick="changeQty({{ $variant->id }}, 1)">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                            @if($adminStock <= 0)
                            <small class="text-danger mt-1 d-block"><i class="fas fa-exclamation-circle me-1"></i>Stok habis</small>
                            @endif
                        </div>
                        <div class="col-md-3 text-end">
                            <div class="text-muted small mb-1">Subtotal</div>
                            <div class="fw-bold subtotal-display" id="subtotal-{{ $variant->id }}" style="color: #D4A017;">
                                Rp 0
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @empty
            <div class="text-center text-muted py-5">
                <i class="fas fa-box-open fa-3x mb-3 d-block opacity-50"></i>
                <p class="mb-1 fw-semibold">Tidak ada varian produk tersedia</p>
                <small>Hubungi admin untuk menambahkan produk</small>
            </div>
            @endforelse
        </div>

        {{-- Order Summary --}}
        <div class="col-lg-4">
            <div class="card order-summary shadow-sm">
                <div class="card-header bg-white py-3" style="color: #0C4B8E; font-weight: 700; border-bottom: 2px solid rgba(12,75,142,0.1);">
                    <i class="fas fa-receipt me-2"></i>Ringkasan Pesanan
                </div>
                <div class="card-body">
                    <div id="orderItemsList">
                        <div class="text-center text-muted py-3">
                            <i class="fas fa-shopping-cart fa-2x mb-2 d-block opacity-50"></i>
                            <small>Belum ada item dipilih</small>
                        </div>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Total Item</span>
                        <span class="fw-bold" id="totalItems">0</span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Total Varian</span>
                        <span class="fw-bold" id="totalVariants">0</span>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fw-bold" style="font-size: 1.05rem;">Total Pembayaran</span>
                        <span class="fw-bold" style="font-size: 1.3rem; color: #0C4B8E;" id="grandTotal">
                            Rp 0
                        </span>
                    </div>

                    <div class="mt-3">
                        <label class="form-label fw-semibold small">Catatan (opsional)</label>
                        <textarea name="notes" class="form-control" rows="2"
                                  placeholder="Catatan untuk pesanan ini..."
                                  style="border-radius: 10px;"></textarea>
                    </div>

                    <button type="submit" class="btn w-100 text-white fw-bold mt-3" style="background: linear-gradient(135deg, #0C4B8E 0%, #1A6FB5 100%); border-radius: 10px; padding: 0.75rem;"
                            id="submitBtn" disabled>
                        <i class="fas fa-paper-plane me-2"></i>Kirim Pesanan
                    </button>

                    <a href="{{ route('stockist.stock.index') }}" class="btn btn-outline-secondary w-100 mt-2" style="border-radius: 10px;">
                        <i class="fas fa-arrow-left me-1"></i> Kembali ke Stok Saya
                    </a>
                </div>
            </div>
        </div>
    </div>
</form>

@endsection

@push('scripts')
<script>
    function changeQty(variantId, delta) {
        const input = document.querySelector(`input[data-variant-id="${variantId}"]`);
        if (!input) return;

        let currentVal = parseInt(input.value) || 0;
        let maxVal = parseInt(input.max) || 9999;
        let newVal = Math.max(0, Math.min(currentVal + delta, maxVal));

        input.value = newVal;
        updateSummary();
    }

    function updateSummary() {
        const inputs = document.querySelectorAll('.qty-input');
        let totalItems = 0;
        let totalVariants = 0;
        let grandTotal = 0;
        let itemsHtml = '';

        inputs.forEach(function(input) {
            const qty = parseInt(input.value) || 0;
            const price = parseFloat(input.dataset.price) || 0;
            const variantId = input.dataset.variantId;

            if (qty > 0) {
                const subtotal = qty * price;
                totalItems += qty;
                totalVariants++;
                grandTotal += subtotal;

                // Update individual subtotal
                const subtotalEl = document.getElementById('subtotal-' + variantId);
                if (subtotalEl) {
                    subtotalEl.textContent = 'Rp ' + subtotal.toLocaleString('id-ID');
                }

                // Highlight card
                const card = input.closest('.variant-card');
                if (card) card.classList.add('selected');

                // Add to summary list
                const cardHeader = card ? card.querySelector('.card-header .fw-bold') : null;
                const variantName = card ? card.querySelector('.card-header .badge') : null;
                const productName = cardHeader ? cardHeader.textContent.trim() : 'Produk';
                const vName = variantName ? variantName.textContent.trim() : '';

                itemsHtml += `
                    <div class="summary-item">
                        <div>
                            <div class="fw-semibold" style="font-size: 0.85rem;">${productName}</div>
                            <small class="text-muted">${vName} x ${qty}</small>
                        </div>
                        <div class="fw-semibold" style="color: #D4A017;">Rp ${subtotal.toLocaleString('id-ID')}</div>
                    </div>
                `;
            } else {
                // Remove highlight
                const card = input.closest('.variant-card');
                if (card) card.classList.remove('selected');

                const subtotalEl = document.getElementById('subtotal-' + variantId);
                if (subtotalEl) {
                    subtotalEl.textContent = 'Rp 0';
                }
            }
        });

        // Update summary
        const itemsList = document.getElementById('orderItemsList');
        if (itemsHtml) {
            itemsList.innerHTML = itemsHtml;
        } else {
            itemsList.innerHTML = `
                <div class="text-center text-muted py-3">
                    <i class="fas fa-shopping-cart fa-2x mb-2 d-block opacity-50"></i>
                    <small>Belum ada item dipilih</small>
                </div>
            `;
        }

        document.getElementById('totalItems').textContent = totalItems;
        document.getElementById('totalVariants').textContent = totalVariants;
        document.getElementById('grandTotal').textContent = 'Rp ' + grandTotal.toLocaleString('id-ID');

        // Enable/disable submit
        document.getElementById('submitBtn').disabled = (totalItems === 0);
    }

    // Initialize on load
    document.addEventListener('DOMContentLoaded', updateSummary);
</script>
@endpush
