<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes — Bandar Bandeng Kalimantan
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group.
|
*/

/*
|==========================================================================
| 1. PUBLIC ROUTES (No Authentication Required)
|==========================================================================
*/
Route::get('/', [App\Http\Controllers\LandingController::class, 'index'])->name('home');
Route::get('/produk', [App\Http\Controllers\LandingController::class, 'products'])->name('public.products');
Route::get('/produk/{slug}', [App\Http\Controllers\LandingController::class, 'productDetail'])->name('public.product-detail');
Route::get('/agen', [App\Http\Controllers\LandingController::class, 'agents'])->name('public.agents');
Route::get('/cari-agen', [App\Http\Controllers\LandingController::class, 'findAgent'])->name('public.find-agent');

/*
|==========================================================================
| 2. AUTH ROUTES (Login / Register / Logout)
|==========================================================================
*/
Route::middleware('guest')->group(function () {
    Route::get('/login', [App\Http\Controllers\Auth\LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [App\Http\Controllers\Auth\LoginController::class, 'login'])->name('login.post');
    Route::get('/register', [App\Http\Controllers\Auth\RegisterController::class, 'showRegistrationForm'])->name('register');
    Route::post('/register', [App\Http\Controllers\Auth\RegisterController::class, 'register'])->name('register.post');
});

Route::post('/logout', [App\Http\Controllers\Auth\LoginController::class, 'logout'])->name('logout');

/*
|==========================================================================
| 3. ADMIN ROUTES
|    Prefix     : admin
|    Middleware : auth, role:admin
|    Name       : admin.*
|==========================================================================
*/
Route::prefix('admin')->middleware(['auth', 'role:admin'])->name('admin.')->group(function () {

    // Dashboard
    Route::get('/', [App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('dashboard');
    Route::get('/stats', [App\Http\Controllers\Admin\DashboardController::class, 'getStats'])->name('stats');

    // Products (Resource: except show)
    Route::resource('products', App\Http\Controllers\Admin\ProductController::class)->except(['show']);

    // Stock Management
    Route::get('/stok', [App\Http\Controllers\Admin\StockController::class, 'index'])->name('stock.index');
    Route::post('/stok', [App\Http\Controllers\Admin\StockController::class, 'addStock'])->name('stock.add');
    Route::put('/stok/{id}', [App\Http\Controllers\Admin\StockController::class, 'updateStock'])->name('stock.update');

    // Orders (Resource: only index, show, update + custom actions)
    Route::resource('orders', App\Http\Controllers\Admin\OrderController::class)->only(['index', 'show', 'update']);
    Route::post('/orders/{id}/approve', [App\Http\Controllers\Admin\OrderController::class, 'approveOrder'])->name('orders.approve');

    // Payments (Resource: only index + custom actions)
    Route::resource('payments', App\Http\Controllers\Admin\PaymentController::class)->only(['index']);
    Route::post('/payments/{id}/verify', [App\Http\Controllers\Admin\PaymentController::class, 'verify'])->name('payments.verify');
    Route::post('/payments/{id}/reject', [App\Http\Controllers\Admin\PaymentController::class, 'reject'])->name('payments.reject');

    // Withdrawals (Resource: only index + custom actions)
    Route::resource('withdrawals', App\Http\Controllers\Admin\WithdrawalController::class)->only(['index']);
    Route::post('/withdrawals/{id}/approve', [App\Http\Controllers\Admin\WithdrawalController::class, 'approve'])->name('withdrawals.approve');
    Route::post('/withdrawals/{id}/reject', [App\Http\Controllers\Admin\WithdrawalController::class, 'reject'])->name('withdrawals.reject');

    // Users (Resource: only index, show + custom action)
    Route::resource('users', App\Http\Controllers\Admin\UserController::class)->only(['index', 'show']);
    Route::post('/users/{id}/toggle-status', [App\Http\Controllers\Admin\UserController::class, 'toggleStatus'])->name('users.toggle-status');

    // Testimonials (Resource: only index, destroy + custom actions)
    Route::resource('testimonials', App\Http\Controllers\Admin\TestimonialController::class)->only(['index', 'destroy']);
    Route::post('/testimonials/{id}/toggle-featured', [App\Http\Controllers\Admin\TestimonialController::class, 'toggleFeatured'])->name('testimonials.toggle-featured');
    Route::post('/testimonials/{id}/toggle-active', [App\Http\Controllers\Admin\TestimonialController::class, 'toggleActive'])->name('testimonials.toggle-active');
});

/*
|==========================================================================
| 4. STOCKIST ROUTES
|    Prefix     : stockist
|    Middleware : auth, role:stockist
|    Name       : stockist.*
|==========================================================================
*/
Route::prefix('stockist')->middleware(['auth', 'role:stockist'])->name('stockist.')->group(function () {

    // Dashboard
    Route::get('/', [App\Http\Controllers\Stockist\DashboardController::class, 'index'])->name('dashboard');

    // Stock Management
    Route::get('/stok', [App\Http\Controllers\Stockist\StockController::class, 'index'])->name('stock.index');
    Route::get('/stok/pesan', [App\Http\Controllers\Stockist\StockController::class, 'orderFromAdmin'])->name('stock.order');
    Route::post('/stok/pesan', [App\Http\Controllers\Stockist\StockController::class, 'placeOrder'])->name('stock.order.post');
    Route::put('/stok/{id}', [App\Http\Controllers\Stockist\StockController::class, 'updateStock'])->name('stock.update');

    // Order Management
    Route::get('/pesanan', [App\Http\Controllers\Stockist\OrderController::class, 'index'])->name('orders.index');
    Route::get('/pesanan/{id}', [App\Http\Controllers\Stockist\OrderController::class, 'show'])->name('orders.show');
    Route::post('/pesanan/{id}/proses', [App\Http\Controllers\Stockist\OrderController::class, 'processAgentOrder'])->name('orders.process');
    Route::put('/pesanan/{id}/status', [App\Http\Controllers\Stockist\OrderController::class, 'updateStatus'])->name('orders.update-status');
    Route::post('/pesanan/{id}/bukti-bayar', [App\Http\Controllers\Stockist\OrderController::class, 'uploadPaymentProof'])->name('orders.upload-proof');
});

/*
|==========================================================================
| 5. AGENT ROUTES
|    Prefix     : agen
|    Middleware : auth, role:agent
|    Name       : agent.*
|==========================================================================
*/
Route::prefix('agen')->middleware(['auth', 'role:agent'])->name('agent.')->group(function () {

    // Dashboard
    Route::get('/', [App\Http\Controllers\Agent\DashboardController::class, 'index'])->name('dashboard');

    // Stock Management
    Route::get('/stok', [App\Http\Controllers\Agent\StockController::class, 'index'])->name('stock.index');
    Route::get('/stok/pesan', [App\Http\Controllers\Agent\StockController::class, 'orderFromStockist'])->name('stock.order');
    Route::post('/stok/pesan', [App\Http\Controllers\Agent\StockController::class, 'placeOrder'])->name('stock.order.post');
    Route::put('/stok/{id}', [App\Http\Controllers\Agent\StockController::class, 'updateStock'])->name('stock.update');

    // Order Management
    Route::get('/pesanan', [App\Http\Controllers\Agent\OrderController::class, 'index'])->name('orders.index');
    Route::get('/pesanan/{id}', [App\Http\Controllers\Agent\OrderController::class, 'show'])->name('orders.show');
    Route::put('/pesanan/{id}/status', [App\Http\Controllers\Agent\OrderController::class, 'updateStatus'])->name('orders.update-status');
    Route::post('/pesanan/{id}/kirim', [App\Http\Controllers\Agent\OrderController::class, 'deliverOrder'])->name('orders.deliver');

    // Area / Wilayah Management
    Route::get('/wilayah', [App\Http\Controllers\Agent\AreaController::class, 'index'])->name('areas.index');
    Route::post('/wilayah', [App\Http\Controllers\Agent\AreaController::class, 'store'])->name('areas.store');
    Route::put('/wilayah/{id}', [App\Http\Controllers\Agent\AreaController::class, 'update'])->name('areas.update');
    Route::delete('/wilayah/{id}', [App\Http\Controllers\Agent\AreaController::class, 'destroy'])->name('areas.destroy');
});

/*
|==========================================================================
| 6. CUSTOMER ROUTES
|    Prefix     : pelanggan
|    Middleware : auth, role:customer
|    Name       : customer.*
|==========================================================================
*/
Route::prefix('pelanggan')->middleware(['auth', 'role:customer'])->name('customer.')->group(function () {

    // Dashboard
    Route::get('/', [App\Http\Controllers\Customer\DashboardController::class, 'index'])->name('dashboard');

    // Order Management
    Route::get('/pesanan', [App\Http\Controllers\Customer\OrderController::class, 'index'])->name('orders.index');
    Route::get('/pesanan/buat', [App\Http\Controllers\Customer\OrderController::class, 'create'])->name('orders.create');
    Route::post('/pesanan', [App\Http\Controllers\Customer\OrderController::class, 'store'])->name('orders.store');
    Route::get('/pesanan/{id}', [App\Http\Controllers\Customer\OrderController::class, 'show'])->name('orders.show');
    Route::post('/pesanan/{id}/batalkan', [App\Http\Controllers\Customer\OrderController::class, 'cancel'])->name('orders.cancel');

    // Payment
    Route::get('/pembayaran/{orderId}', [App\Http\Controllers\Customer\PaymentController::class, 'show'])->name('payments.show');
    Route::post('/pembayaran/{orderId}/bukti', [App\Http\Controllers\Customer\PaymentController::class, 'uploadProof'])->name('payments.upload-proof');
    Route::post('/pembayaran/{orderId}/deposit', [App\Http\Controllers\Customer\PaymentController::class, 'payWithDeposit'])->name('payments.pay-deposit');

    // Rating
    Route::get('/rating/{orderId}', [App\Http\Controllers\Customer\RatingController::class, 'create'])->name('ratings.create');
    Route::post('/rating/{orderId}', [App\Http\Controllers\Customer\RatingController::class, 'store'])->name('ratings.store');

    // Complaint
    Route::get('/komplain/{orderId}', [App\Http\Controllers\Customer\ComplaintController::class, 'create'])->name('complaints.create');
    Route::post('/komplain/{orderId}', [App\Http\Controllers\Customer\ComplaintController::class, 'store'])->name('complaints.store');
});

/*
|==========================================================================
| 7. SHARED AUTH ROUTES (Any authenticated user)
|    Middleware : auth
|==========================================================================
*/
Route::middleware('auth')->group(function () {

    // Profile
    Route::get('/profil', [App\Http\Controllers\ProfileController::class, 'index'])->name('profile.index');
    Route::put('/profil', [App\Http\Controllers\ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profil/password', [App\Http\Controllers\ProfileController::class, 'updatePassword'])->name('profile.update-password');
    Route::post('/profil/avatar', [App\Http\Controllers\ProfileController::class, 'updateAvatar'])->name('profile.update-avatar');

    // Wallet / Dompet
    Route::get('/dompet', [App\Http\Controllers\WalletController::class, 'index'])->name('wallet.index');
    Route::post('/dompet/topup', [App\Http\Controllers\WalletController::class, 'topUp'])->name('wallet.topup');
    Route::get('/dompet/riwayat', [App\Http\Controllers\WalletController::class, 'history'])->name('wallet.history');

    // Withdrawal / Tarik Dana
    Route::get('/tarik-dana', [App\Http\Controllers\WithdrawalController::class, 'create'])->name('withdrawal.create');
    Route::post('/tarik-dana', [App\Http\Controllers\WithdrawalController::class, 'store'])->name('withdrawal.store');
});
